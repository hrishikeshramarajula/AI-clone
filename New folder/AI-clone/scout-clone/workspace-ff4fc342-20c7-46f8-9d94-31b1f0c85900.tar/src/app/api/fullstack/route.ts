import { NextRequest, NextResponse } from 'next/server';
import { enhancedAIProvider } from '@/lib/enhancedAIProvider';

interface FullStackRequest {
  prompt: string;
  model: string;
  files?: any[];
}

export async function POST(request: NextRequest) {
  try {
    const body: FullStackRequest = await request.json();
    const { prompt, model, files = [] } = body;

    if (!prompt || !model) {
      return NextResponse.json(
        { error: 'Prompt and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing full-stack project generation request:', { prompt, model, filesCount: files.length });

    // Check if model is available
    if (!enhancedAIProvider.isModelAvailable(model)) {
      return NextResponse.json(
        { error: `Model ${model} is not available` },
        { status: 400 }
      );
    }

    try {
      // Generate full-stack project
      const projectBundle = await enhancedAIProvider.generateFullStackProject(prompt, files);
      
      console.log('Full-stack project generated successfully');

      return NextResponse.json({
        success: true,
        project: projectBundle,
        model,
        timestamp: new Date().toISOString(),
      });

    } catch (error) {
      console.error('Full-stack generation error:', error);
      return NextResponse.json(
        { 
          error: 'Failed to generate full-stack project', 
          details: error instanceof Error ? error.message : 'Unknown error' 
        },
        { status: 500 }
      );
    }

  } catch (error) {
    console.error('Full-stack API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return available models for full-stack development
    const healthStatus = enhancedAIProvider.getHealthStatus();
    const availableModels = enhancedAIProvider.getAvailableModels();
    
    // Filter models that are good for full-stack development
    const fullstackModels = [
      'z-ai-fullstack',
      'gpt-4-turbo',
      'claude-3-opus',
      'gpt-4',
      'glm-4.5'
    ].filter(model => availableModels.includes(model));

    return NextResponse.json({ 
      models: fullstackModels,
      health: healthStatus,
      availableModels: fullstackModels
    });
  } catch (error) {
    console.error('Error getting full-stack models:', error);
    return NextResponse.json(
      { error: 'Failed to get full-stack models', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}