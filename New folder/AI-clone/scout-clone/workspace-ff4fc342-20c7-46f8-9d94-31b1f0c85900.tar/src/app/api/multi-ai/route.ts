import { NextRequest, NextResponse } from 'next/server';
import { multiProviderAI } from '@/lib/multiProviderAI';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      message, 
      providerId, 
      modelId, 
      mode = 'chat',
      temperature = 0.7,
      maxTokens,
      systemPrompt 
    } = body;

    console.log('Multi-AI Request:', { 
      message, 
      providerId, 
      modelId, 
      mode,
      temperature,
      maxTokens: maxTokens || 'default'
    });

    if (!message || !providerId || !modelId) {
      return NextResponse.json(
        { 
          success: false, 
          error: 'Missing required fields: message, providerId, and modelId are required' 
        },
        { status: 400 }
      );
    }

    const aiRequest = {
      message,
      providerId,
      modelId,
      mode,
      temperature,
      maxTokens,
      systemPrompt
    };

    const response = await multiProviderAI.generateResponse(aiRequest);

    console.log('Multi-AI Response:', {
      provider: response.provider,
      model: response.model,
      contentLength: response.content.length,
      hasImageData: !!response.imageData,
      hasSearchResults: !!response.searchResults,
      tokensUsed: response.tokensUsed,
      cost: response.cost
    });

    return NextResponse.json({
      success: true,
      response: response.content,
      provider: response.provider,
      model: response.model,
      tokensUsed: response.tokensUsed,
      cost: response.cost,
      timestamp: response.timestamp,
      searchResults: response.searchResults,
      imageData: response.imageData,
      imagePrompt: response.imagePrompt
    });

  } catch (error) {
    console.error('Multi-AI API Error:', error);
    
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to process AI request',
        details: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return available providers and models
    const { AI_PROVIDERS, getAvailableModels, getProviderStats } = await import('@/lib/aiProviders');
    
    const stats = getProviderStats();
    const availableModels = getAvailableModels();
    
    const providers = AI_PROVIDERS.map(provider => ({
      id: provider.id,
      name: provider.name,
      description: provider.description,
      category: provider.category,
      hasApiKey: !!provider.apiKey,
      modelCount: provider.models.length,
      features: provider.features
    }));

    return NextResponse.json({
      success: true,
      providers,
      availableModels,
      stats,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Multi-AI Info Error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: 'Failed to get provider information',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}