import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

export async function POST(request: NextRequest) {
  try {
    const data = await request.formData();
    const file: File | null = data.get('file') as unknown as File;

    if (!file) {
      return NextResponse.json(
        { error: 'No file uploaded' },
        { status: 400 }
      );
    }

    console.log('Processing file upload:', {
      name: file.name,
      size: file.size,
      type: file.type
    });

    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'uploads');
    try {
      await mkdir(uploadsDir, { recursive: true });
    } catch (error) {
      // Directory already exists or other error
      console.log('Uploads directory check:', error);
    }

    // Generate unique filename
    const timestamp = Date.now();
    const uniqueName = `${timestamp}-${file.name}`;
    const filePath = join(uploadsDir, uniqueName);

    // Convert file to buffer and save
    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    await writeFile(filePath, buffer);

    console.log('File saved successfully:', filePath);

    // Read file content for text-based files
    let content = '';
    if (file.type.startsWith('text/') || file.name.endsWith('.ts') || file.name.endsWith('.js') || file.name.endsWith('.tsx') || file.name.endsWith('.jsx')) {
      try {
        content = buffer.toString('utf-8');
      } catch (error) {
        console.warn('Could not read file content as text:', error);
      }
    }

    return NextResponse.json({
      success: true,
      file: {
        name: file.name,
        size: file.size,
        type: file.type,
        path: `/uploads/${uniqueName}`,
        content: content,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('File upload error:', error);
    return NextResponse.json(
      { error: 'Failed to upload file', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'File upload endpoint is available',
    maxFileSize: '50MB',
    supportedTypes: [
      'text/plain',
      'text/javascript',
      'text/typescript',
      'text/html',
      'text/css',
      'application/json',
      '.ts',
      '.js',
      '.tsx',
      '.jsx',
      '.html',
      '.css',
      '.json'
    ]
  });
}