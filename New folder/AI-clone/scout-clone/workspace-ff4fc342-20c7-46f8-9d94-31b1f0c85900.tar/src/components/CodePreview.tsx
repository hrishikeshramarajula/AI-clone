'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Copy, Download, ExternalLink, Play } from 'lucide-react';

interface CodePreviewProps {
  project?: {
    frontend: string;
    backend: string;
    projectStructure: string;
    setupInstructions: string;
  };
  isVisible: boolean;
  onClose: () => void;
}

export function CodePreview({ project, isVisible, onClose }: CodePreviewProps) {
  const [activeTab, setActiveTab] = useState('frontend');
  const [copiedCode, setCopiedCode] = useState('');

  if (!isVisible || !project) {
    return null;
  }

  const copyToClipboard = async (code: string, type: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(type);
      setTimeout(() => setCopiedCode(''), 2000);
    } catch (error) {
      console.error('Failed to copy code:', error);
    }
  };

  const downloadCode = (code: string, filename: string) => {
    const blob = new Blob([code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatCode = (code: string) => {
    // Simple code formatting for display
    return code
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-6xl max-h-[90vh] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between pb-4">
          <CardTitle className="flex items-center gap-2">
            <Play className="w-5 h-5" />
            Generated Full-Stack Project
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">Live Preview</Badge>
            <Button variant="outline" size="sm" onClick={onClose}>
              Close
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="frontend">Frontend</TabsTrigger>
              <TabsTrigger value="backend">Backend</TabsTrigger>
              <TabsTrigger value="structure">Structure</TabsTrigger>
              <TabsTrigger value="setup">Setup</TabsTrigger>
            </TabsList>
            
            <div className="flex-1 overflow-hidden">
              <TabsContent value="frontend" className="h-full mt-0">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between p-2 border-b">
                    <span className="text-sm font-medium">Frontend Code</span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(project.frontend, 'frontend')}
                      >
                        <Copy className="w-4 h-4" />
                        {copiedCode === 'frontend' ? 'Copied!' : 'Copy'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadCode(project.frontend, 'frontend.js')}
                      >
                        <Download className="w-4 h-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <ScrollArea className="flex-1">
                    <pre className="p-4 text-sm bg-gray-50 rounded">
                      <code>{formatCode(project.frontend)}</code>
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="backend" className="h-full mt-0">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between p-2 border-b">
                    <span className="text-sm font-medium">Backend Code</span>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(project.backend, 'backend')}
                      >
                        <Copy className="w-4 h-4" />
                        {copiedCode === 'backend' ? 'Copied!' : 'Copy'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadCode(project.backend, 'backend.py')}
                      >
                        <Download className="w-4 h-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <ScrollArea className="flex-1">
                    <pre className="p-4 text-sm bg-gray-50 rounded">
                      <code>{formatCode(project.backend)}</code>
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="structure" className="h-full mt-0">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between p-2 border-b">
                    <span className="text-sm font-medium">Project Structure</span>
                  </div>
                  <ScrollArea className="flex-1">
                    <pre className="p-4 text-sm bg-gray-50 rounded whitespace-pre-wrap">
                      {project.projectStructure || 'Project structure not provided'}
                    </pre>
                  </ScrollArea>
                </div>
              </TabsContent>
              
              <TabsContent value="setup" className="h-full mt-0">
                <div className="h-full flex flex-col">
                  <div className="flex items-center justify-between p-2 border-b">
                    <span className="text-sm font-medium">Setup Instructions</span>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-4 text-sm bg-gray-50 rounded whitespace-pre-wrap">
                      {project.setupInstructions || 'Setup instructions not provided'}
                    </div>
                  </ScrollArea>
                </div>
              </TabsContent>
            </div>
          </Tabs>
          
          <div className="flex items-center justify-between p-4 border-t mt-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline">React + FastAPI</Badge>
              <Badge variant="outline">TypeScript</Badge>
              <Badge variant="outline">Production Ready</Badge>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <ExternalLink className="w-4 h-4 mr-2" />
                Deploy
              </Button>
              <Button size="sm">
                <Play className="w-4 h-4 mr-2" />
                Run Locally
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}