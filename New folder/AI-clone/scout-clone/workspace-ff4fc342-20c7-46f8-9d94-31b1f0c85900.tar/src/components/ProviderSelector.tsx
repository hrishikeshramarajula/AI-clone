'use client';

import React, { useState, useEffect } from 'react';
import { Brain, Zap, Settings, ChevronDown, Check, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AI_PROVIDERS, getAvailableModels, getProvider, getModel } from '@/lib/aiProviders';
import { multiProviderAI } from '@/lib/multiProviderAI';

interface ProviderSelection {
  providerId: string;
  modelId: string;
  category: string;
}

interface ProviderSelectorProps {
  selectedProvider: ProviderSelection;
  onSelectionChange: (selection: ProviderSelection) => void;
  mode: 'chat' | 'search' | 'code' | 'analysis' | 'image';
}

export default function ProviderSelector({ selectedProvider, onSelectionChange, mode }: ProviderSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [availableModels, setAvailableModels] = useState<any[]>([]);
  const [providerStats, setProviderStats] = useState<Record<string, any>>({});

  useEffect(() => {
    loadAvailableModels();
    loadProviderStats();
  }, [mode]);

  const loadAvailableModels = () => {
    const models = getAvailableModels(getCategoryForMode(mode));
    setAvailableModels(models);
  };

  const loadProviderStats = async () => {
    const stats: Record<string, any> = {};
    
    for (const provider of AI_PROVIDERS) {
      if (provider.apiKey) {
        try {
          const isHealthy = await multiProviderAI.checkProviderHealth(provider.id);
          stats[provider.id] = {
            isHealthy,
            modelCount: provider.models.length,
            category: provider.category
          };
        } catch (error) {
          stats[provider.id] = {
            isHealthy: false,
            modelCount: provider.models.length,
            category: provider.category
          };
        }
      }
    }
    
    setProviderStats(stats);
  };

  const getCategoryForMode = (mode: string) => {
    switch (mode) {
      case 'chat': return 'chat';
      case 'search': return 'chat';
      case 'code': return 'code';
      case 'analysis': return 'analysis';
      case 'image': return 'image';
      default: return 'chat';
    }
  };

  const handleProviderChange = (providerId: string) => {
    const provider = getProvider(providerId);
    if (provider) {
      const firstModel = provider.models.find(m => 
        !mode || m.category === getCategoryForMode(mode) || m.category === 'multimodal'
      );
      
      if (firstModel) {
        onSelectionChange({
          providerId,
          modelId: firstModel.id,
          category: getCategoryForMode(mode)
        });
      }
    }
  };

  const handleModelChange = (modelId: string) => {
    onSelectionChange({
      ...selectedProvider,
      modelId
    });
  };

  const getProviderModels = (providerId: string) => {
    const provider = getProvider(providerId);
    if (!provider) return [];
    
    return provider.models.filter(model => 
      !mode || model.category === getCategoryForMode(mode) || model.category === 'multimodal'
    );
  };

  const selectedProviderData = getProvider(selectedProvider.providerId);
  const selectedModelData = getModel(selectedProvider.providerId, selectedProvider.modelId);
  const providerModels = getProviderModels(selectedProvider.providerId);

  return (
    <div className="space-y-4">
      {/* Provider Selection */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-blue-500" />
          <span className="font-medium">Provider:</span>
        </div>
        
        <Select value={selectedProvider.providerId} onValueChange={handleProviderChange}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Select AI Provider" />
          </SelectTrigger>
          <SelectContent>
            {AI_PROVIDERS.map((provider) => {
              const stats = providerStats[provider.id];
              const isAvailable = !!provider.apiKey;
              const isHealthy = stats?.isHealthy;
              
              return (
                <SelectItem key={provider.id} value={provider.id}>
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2">
                      <div>{provider.name}</div>
                      {provider.id === 'z-ai' && <Star className="w-3 h-3 text-yellow-500" />}
                    </div>
                    <div className="flex items-center gap-2">
                      {isAvailable ? (
                        isHealthy ? (
                          <div className="w-2 h-2 bg-green-500 rounded-full" />
                        ) : (
                          <div className="w-2 h-2 bg-red-500 rounded-full" />
                        )
                      ) : (
                        <div className="w-2 h-2 bg-gray-300 rounded-full" />
                      )}
                      <Badge variant="outline" className="text-xs">
                        {provider.category}
                      </Badge>
                    </div>
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>

        <div className="flex items-center gap-2">
          <Zap className="w-5 h-5 text-purple-500" />
          <span className="font-medium">Model:</span>
        </div>
        
        <Select value={selectedProvider.modelId} onValueChange={handleModelChange}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Select Model" />
          </SelectTrigger>
          <SelectContent>
            {providerModels.map((model) => (
              <SelectItem key={model.id} value={model.id}>
                <div className="flex flex-col">
                  <div className="font-medium">{model.name}</div>
                  <div className="text-xs text-gray-500">
                    {model.maxTokens ? `${model.maxTokens} tokens` : 'Variable tokens'}
                    {model.costPer1kTokens && ` • $${model.costPer1kTokens}/1K`}
                  </div>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Provider Info Card */}
      {selectedProviderData && (
        <Card className="border-blue-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                {selectedProviderData.name}
                {selectedProviderData.id === 'z-ai' && (
                  <Star className="w-4 h-4 text-yellow-500" />
                )}
              </CardTitle>
              <div className="flex items-center gap-2">
                <Badge variant={selectedProviderData.apiKey ? "default" : "secondary"}>
                  {selectedProviderData.apiKey ? "Active" : "Inactive"}
                </Badge>
                <Badge variant="outline">{selectedProviderData.category}</Badge>
                {providerStats[selectedProviderData.id]?.isHealthy && (
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Healthy
                  </Badge>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-3">{selectedProviderData.description}</p>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div>
                <div className="font-medium">Models Available</div>
                <div className="text-gray-500">{selectedProviderData.models.length}</div>
              </div>
              <div>
                <div className="font-medium">Features</div>
                <div className="text-gray-500">
                  {Object.values(selectedProviderData.features).filter(Boolean).length}
                </div>
              </div>
              {selectedProviderData.pricing && (
                <>
                  <div>
                    <div className="font-medium">Input Cost</div>
                    <div className="text-gray-500">
                      ${selectedProviderData.pricing.inputTokenCost}/1K
                    </div>
                  </div>
                  <div>
                    <div className="font-medium">Output Cost</div>
                    <div className="text-gray-500">
                      ${selectedProviderData.pricing.outputTokenCost}/1K
                    </div>
                  </div>
                </>
              )}
            </div>
            
            {/* Features */}
            <div className="mt-3">
              <div className="text-xs font-medium mb-2">Available Features:</div>
              <div className="flex flex-wrap gap-1">
                {Object.entries(selectedProviderData.features).map(([feature, enabled]) => 
                  enabled ? (
                    <Badge key={feature} variant="secondary" className="text-xs">
                      {feature}
                    </Badge>
                  ) : null
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Model Info Card */}
      {selectedModelData && (
        <Card className="border-purple-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg">{selectedModelData.name}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-3">{selectedModelData.description}</p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
              {selectedModelData.maxTokens && (
                <div>
                  <div className="font-medium">Max Tokens</div>
                  <div className="text-gray-500">{selectedModelData.maxTokens.toLocaleString()}</div>
                </div>
              )}
              {selectedModelData.costPer1kTokens && (
                <div>
                  <div className="font-medium">Cost</div>
                  <div className="text-gray-500">${selectedModelData.costPer1kTokens}/1K tokens</div>
                </div>
              )}
              <div>
                <div className="font-medium">Category</div>
                <div className="text-gray-500">
                  <Badge variant="outline" className="text-xs">
                    {selectedModelData.category}
                  </Badge>
                </div>
              </div>
            </div>
            
            {/* Capabilities */}
            <div className="mt-3">
              <div className="text-xs font-medium mb-2">Capabilities:</div>
              <div className="flex flex-wrap gap-1">
                {selectedModelData.supportsVision && (
                  <Badge variant="secondary" className="text-xs">Vision</Badge>
                )}
                {selectedModelData.supportsCode && (
                  <Badge variant="secondary" className="text-xs">Code</Badge>
                )}
                {selectedModelData.supportsAnalysis && (
                  <Badge variant="secondary" className="text-xs">Analysis</Badge>
                )}
                {selectedModelData.supportsImageGeneration && (
                  <Badge variant="secondary" className="text-xs">Image Generation</Badge>
                )}
                {selectedModelData.supportsWebSearch && (
                  <Badge variant="secondary" className="text-xs">Web Search</Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-lg font-bold text-blue-500">
              {AI_PROVIDERS.filter(p => p.apiKey).length}
            </div>
            <div className="text-xs text-gray-500">Active Providers</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-lg font-bold text-green-500">
              {availableModels.length}
            </div>
            <div className="text-xs text-gray-500">Available Models</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-lg font-bold text-purple-500">
              {Object.values(providerStats).filter(s => s.isHealthy).length}
            </div>
            <div className="text-xs text-gray-500">Healthy Providers</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-3 text-center">
            <div className="text-lg font-bold text-orange-500">
              {providerModels.length}
            </div>
            <div className="text-xs text-gray-500">Models for {mode}</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}