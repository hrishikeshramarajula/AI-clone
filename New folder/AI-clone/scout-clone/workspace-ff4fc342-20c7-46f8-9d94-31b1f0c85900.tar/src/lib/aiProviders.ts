// AI Provider Configuration and Management

export interface AIProvider {
  id: string;
  name: string;
  description: string;
  baseUrl?: string;
  apiKey: string;
  models: AIModel[];
  features: ProviderFeatures;
  pricing?: PricingInfo;
  category: 'premium' | 'opensource' | 'local' | 'integrated';
}

export interface AIModel {
  id: string;
  name: string;
  description: string;
  maxTokens?: number;
  supportsVision?: boolean;
  supportsCode?: boolean;
  supportsAnalysis?: boolean;
  supportsImageGeneration?: boolean;
  supportsWebSearch?: boolean;
  costPer1kTokens?: number;
  category: 'chat' | 'code' | 'analysis' | 'image' | 'multimodal' | 'fullstack';
}

export interface ProviderFeatures {
  chat: boolean;
  vision: boolean;
  code: boolean;
  analysis: boolean;
  imageGeneration: boolean;
  webSearch: boolean;
  streaming: boolean;
  jsonMode: boolean;
  functionCalling: boolean;
}

export interface PricingInfo {
  currency: string;
  inputTokenCost: number;
  outputTokenCost: number;
  freeTierLimit?: number;
}

export interface AIProviderConfig {
  providers: AIProvider[];
  defaultProvider: string;
  fallbackProviders: string[];
}

// Provider Configurations
export const AI_PROVIDERS: AIProvider[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    description: 'Leading AI models including GPT-4, GPT-4o, and DALL-E',
    apiKey: process.env.OPENAI_API_KEY || '',
    baseUrl: 'https://api.openai.com/v1',
    models: [
      {
        id: 'gpt-4o',
        name: 'GPT-4o',
        description: 'Most capable GPT-4 model with vision and code capabilities',
        maxTokens: 128000,
        supportsVision: true,
        supportsCode: true,
        supportsAnalysis: true,
        supportsWebSearch: false,
        costPer1kTokens: 0.005,
        category: 'multimodal'
      },
      {
        id: 'gpt-4',
        name: 'GPT-4',
        description: 'Advanced reasoning and complex task solving',
        maxTokens: 8192,
        supportsCode: true,
        supportsAnalysis: true,
        costPer1kTokens: 0.03,
        category: 'chat'
      },
      {
        id: 'gpt-3.5-turbo',
        name: 'GPT-3.5 Turbo',
        description: 'Fast and efficient for most tasks',
        maxTokens: 16385,
        supportsCode: true,
        costPer1kTokens: 0.0015,
        category: 'chat'
      },
      {
        id: 'dall-e-3',
        name: 'DALL-E 3',
        description: 'Advanced image generation',
        supportsImageGeneration: true,
        category: 'image'
      },
      {
        id: 'gpt-4-turbo',
        name: 'GPT-4 Turbo',
        description: 'Optimized for full-stack development with code, analysis, and architecture',
        maxTokens: 128000,
        supportsCode: true,
        supportsAnalysis: true,
        supportsVision: true,
        costPer1kTokens: 0.01,
        category: 'fullstack'
      }
    ],
    features: {
      chat: true,
      vision: true,
      code: true,
      analysis: true,
      imageGeneration: true,
      webSearch: false,
      streaming: true,
      jsonMode: true,
      functionCalling: true
    },
    pricing: {
      currency: 'USD',
      inputTokenCost: 0.005,
      outputTokenCost: 0.015
    },
    category: 'premium'
  },
  {
    id: 'openrouter',
    name: 'OpenRouter',
    description: 'Access to 100+ AI models including Claude, Llama, and Gemini',
    apiKey: process.env.OPENROUTER_API_KEY || '',
    baseUrl: 'https://openrouter.ai/api/v1',
    models: [
      {
        id: 'anthropic/claude-3.5-sonnet',
        name: 'Claude 3.5 Sonnet',
        description: 'Latest Claude model with advanced reasoning',
        maxTokens: 200000,
        supportsCode: true,
        supportsAnalysis: true,
        costPer1kTokens: 0.003,
        category: 'chat'
      },
      {
        id: 'meta-llama/llama-3.1-70b',
        name: 'Llama 3.1 70B',
        description: 'Meta\'s latest open-source model',
        maxTokens: 131072,
        supportsCode: true,
        supportsAnalysis: true,
        costPer1kTokens: 0.00088,
        category: 'chat'
      },
      {
        id: 'mistralai/mixtral-8x7b',
        name: 'Mixtral 8x7B',
        description: 'Mixture of experts model',
        maxTokens: 32768,
        supportsCode: true,
        costPer1kTokens: 0.0005,
        category: 'chat'
      },
      {
        id: 'google/gemini-pro',
        name: 'Gemini Pro',
        description: 'Google\'s multimodal AI model',
        supportsVision: true,
        supportsAnalysis: true,
        costPer1kTokens: 0.00125,
        category: 'multimodal'
      },
      {
        id: 'anthropic/claude-3-opus',
        name: 'Claude 3 Opus',
        description: 'Most capable Claude model for complex full-stack tasks',
        maxTokens: 200000,
        supportsCode: true,
        supportsAnalysis: true,
        costPer1kTokens: 0.015,
        category: 'fullstack'
      }
    ],
    features: {
      chat: true,
      vision: true,
      code: true,
      analysis: true,
      imageGeneration: false,
      webSearch: false,
      streaming: true,
      jsonMode: true,
      functionCalling: true
    },
    pricing: {
      currency: 'USD',
      inputTokenCost: 0.00088,
      outputTokenCost: 0.00088,
      freeTierLimit: 1000000
    },
    category: 'opensource'
  },
  {
    id: 'huggingface',
    name: 'HuggingFace',
    description: 'Thousands of open-source models and inference API',
    apiKey: process.env.HUGGINGFACE_API_KEY || '',
    baseUrl: process.env.HF_INFERENCE_URL || 'https://api-inference.huggingface.co/models',
    models: [
      {
        id: 'meta-llama/Llama-2-70b-chat-hf',
        name: 'Llama 2 70B Chat',
        description: 'Meta\'s Llama 2 fine-tuned for chat',
        maxTokens: 4096,
        supportsCode: true,
        category: 'chat'
      },
      {
        id: 'mistralai/Mixtral-8x7B-Instruct-v0.1',
        name: 'Mixtral 8x7B Instruct',
        description: 'Instruction-tuned mixture of experts',
        maxTokens: 32768,
        supportsCode: true,
        category: 'chat'
      },
      {
        id: 'stabilityai/stable-diffusion-2-1',
        name: 'Stable Diffusion 2.1',
        description: 'Image generation model',
        supportsImageGeneration: true,
        category: 'image'
      },
      {
        id: 'google/flan-t5-xxl',
        name: 'FLAN-T5 XXL',
        description: 'Text-to-text transfer transformer',
        supportsAnalysis: true,
        category: 'analysis'
      }
    ],
    features: {
      chat: true,
      vision: false,
      code: true,
      analysis: true,
      imageGeneration: true,
      webSearch: false,
      streaming: false,
      jsonMode: false,
      functionCalling: false
    },
    pricing: {
      currency: 'USD',
      inputTokenCost: 0.0002,
      outputTokenCost: 0.0002,
      freeTierLimit: 30000
    },
    category: 'opensource'
  },
  {
    id: 'ollama',
    name: 'Ollama',
    description: 'Local and cloud deployment of open-source models',
    apiKey: process.env.OLLAMA_API_KEY || '',
    baseUrl: 'http://localhost:11434/api',
    models: [
      {
        id: 'llama3.1',
        name: 'Llama 3.1',
        description: 'Meta\'s latest Llama model',
        maxTokens: 8192,
        supportsCode: true,
        supportsAnalysis: true,
        category: 'chat'
      },
      {
        id: 'mistral',
        name: 'Mistral',
        description: 'Mistral AI\'s 7B model',
        maxTokens: 8192,
        supportsCode: true,
        category: 'chat'
      },
      {
        id: 'codellama',
        name: 'Code Llama',
        description: 'Code-specialized Llama model',
        supportsCode: true,
        category: 'code'
      },
      {
        id: 'gemma',
        name: 'Gemma',
        description: 'Google\'s open lightweight model',
        maxTokens: 8192,
        supportsAnalysis: true,
        category: 'chat'
      }
    ],
    features: {
      chat: true,
      vision: false,
      code: true,
      analysis: true,
      imageGeneration: false,
      webSearch: false,
      streaming: true,
      jsonMode: false,
      functionCalling: false
    },
    pricing: {
      currency: 'USD',
      inputTokenCost: 0,
      outputTokenCost: 0
    },
    category: 'local'
  },
  {
    id: 'z-ai',
    name: 'Z-AI SDK',
    description: 'Integrated AI SDK with web search and image generation',
    apiKey: 'integrated',
    models: [
      {
        id: 'glm-4.5',
        name: 'GLM-4.5',
        description: 'Zhipu AI\'s latest model with web search',
        supportsCode: true,
        supportsAnalysis: true,
        supportsWebSearch: true,
        category: 'chat'
      },
      {
        id: 'z-ai-chat',
        name: 'Z-AI Chat',
        description: 'General purpose chat model',
        supportsAnalysis: true,
        category: 'chat'
      },
      {
        id: 'z-ai-image',
        name: 'Z-AI Image',
        description: 'Image generation model',
        supportsImageGeneration: true,
        category: 'image'
      },
      {
        id: 'z-ai-fullstack',
        name: 'Z-AI Full Stack',
        description: 'Integrated full-stack development assistant',
        supportsCode: true,
        supportsAnalysis: true,
        supportsWebSearch: true,
        category: 'fullstack'
      }
    ],
    features: {
      chat: true,
      vision: false,
      code: true,
      analysis: true,
      imageGeneration: true,
      webSearch: true,
      streaming: true,
      jsonMode: true,
      functionCalling: false
    },
    category: 'integrated'
  }
];

// Provider Configuration
export const AI_CONFIG: AIProviderConfig = {
  providers: AI_PROVIDERS,
  defaultProvider: 'z-ai',
  fallbackProviders: ['openrouter', 'huggingface', 'ollama', 'openai']
};

// Utility Functions
export function getProvider(providerId: string): AIProvider | undefined {
  return AI_PROVIDERS.find(p => p.id === providerId);
}

export function getModel(providerId: string, modelId: string): AIModel | undefined {
  const provider = getProvider(providerId);
  return provider?.models.find(m => m.id === modelId);
}

export function getAvailableModels(category?: string): AIModel[] {
  const allModels: AIModel[] = [];
  
  AI_PROVIDERS.forEach(provider => {
    if (provider.apiKey) { // Only include providers with API keys
      provider.models.forEach(model => {
        if (!category || model.category === category) {
          allModels.push({ ...model, providerId: provider.id });
        }
      });
    }
  });
  
  return allModels;
}

export function getProvidersByFeature(feature: keyof ProviderFeatures): AIProvider[] {
  return AI_PROVIDERS.filter(provider => 
    provider.apiKey && provider.features[feature]
  );
}

export function isProviderAvailable(providerId: string): boolean {
  const provider = getProvider(providerId);
  return !!provider?.apiKey;
}

export function getProviderStats() {
  const stats = {
    totalProviders: AI_PROVIDERS.length,
    availableProviders: 0,
    totalModels: 0,
    availableModels: 0,
    categories: {
      chat: 0,
      code: 0,
      analysis: 0,
      image: 0,
      multimodal: 0,
      fullstack: 0
    }
  };

  AI_PROVIDERS.forEach(provider => {
    if (provider.apiKey) {
      stats.availableProviders++;
      provider.models.forEach(model => {
        stats.availableModels++;
        if (model.category === 'multimodal') {
          stats.categories.multimodal++;
        } else {
          stats.categories[model.category]++;
        }
      });
    }
    stats.totalModels += provider.models.length;
  });

  return stats;
}