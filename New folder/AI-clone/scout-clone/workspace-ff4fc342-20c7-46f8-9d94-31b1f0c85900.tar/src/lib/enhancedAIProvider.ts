// Enhanced AI Provider Integration with real API keys
// Multiple AI service support: OpenAI, OpenRouter, HuggingFace, Ollama, and Z-AI SDK

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

interface FullStackCodeBundle {
  frontend: string;
  backend: string;
  projectStructure: string;
  setupInstructions: string;
}

class EnhancedAIProvider {
  private zaiInstance: any = null;
  private isInitialized: boolean = false;
  private initializationPromise: Promise<boolean> | null = null;
  private maxRetries: number = 3;
  private retryDelay: number = 2000;
  
  // API Keys from environment
  private openaiApiKey: string;
  private openRouterApiKey: string;
  private huggingFaceApiKey: string;
  private ollamaApiKey: string;
  private huggingFaceInferenceUrl: string;

  constructor() {
    // Load API keys from environment variables
    this.openaiApiKey = process.env.OPENAI_API_KEY || '';
    this.openRouterApiKey = process.env.OPENROUTER_API_KEY || '';
    this.huggingFaceApiKey = process.env.HUGGINGFACE_API_KEY || '';
    this.ollamaApiKey = process.env.OLLAMA_API_KEY || '';
    this.huggingFaceInferenceUrl = process.env.HUGGINGFACE_INFERENCE_URL || 'https://api-inference.huggingface.co/models';
    
    console.log('Enhanced AI Provider initialized with API keys:', {
      hasOpenAI: !!this.openaiApiKey,
      hasOpenRouter: !!this.openRouterApiKey,
      hasHuggingFace: !!this.huggingFaceApiKey,
      hasOllama: !!this.ollamaApiKey
    });
    
    this.initializeZAI();
  }

  private async initializeZAI(retryCount: number = 0): Promise<void> {
    if (this.initializationPromise) {
      return this.initializationPromise.then(() => {});
    }

    this.initializationPromise = this.performInitialization(retryCount);
    return this.initializationPromise.then(() => {});
  }

  private async performInitialization(retryCount: number): Promise<boolean> {
    try {
      console.log(`Initializing Z-AI SDK... (Attempt ${retryCount + 1}/${this.maxRetries})`);
      
      // Import the SDK dynamically with timeout
      const ZAI = await Promise.race([
        import('z-ai-web-dev-sdk'),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Z-AI SDK import timeout')), 10000)
        )
      ]) as any;
      
      console.log('Z-AI SDK imported successfully');
      
      // Try different possible SDK structures
      let createFunction = null;
      
      if (typeof ZAI.create === 'function') {
        createFunction = ZAI.create;
      } else if (typeof ZAI.default?.create === 'function') {
        createFunction = ZAI.default.create;
      } else if (typeof ZAI.default === 'function') {
        createFunction = ZAI.default;
      } else if (ZAI.ZAI && typeof ZAI.ZAI.create === 'function') {
        createFunction = ZAI.ZAI.create;
      }
      
      if (!createFunction) {
        throw new Error('Z-AI SDK create function not available');
      }

      console.log('Creating Z-AI instance...');
      this.zaiInstance = await Promise.race([
        createFunction(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Z-AI SDK creation timeout')), 15000)
        )
      ]);
      
      if (!this.zaiInstance) {
        throw new Error('Z-AI SDK instance not created');
      }

      console.log('Z-AI SDK initialized successfully');
      this.isInitialized = true;
      return true;
      
    } catch (error) {
      console.error(`Z-AI SDK initialization failed (Attempt ${retryCount + 1}/${this.maxRetries}):`, error);
      
      if (retryCount < this.maxRetries - 1) {
        console.log(`Retrying in ${this.retryDelay / 1000} seconds...`);
        await new Promise(resolve => setTimeout(resolve, this.retryDelay));
        return this.performInitialization(retryCount + 1);
      }
      
      this.isInitialized = false;
      return false;
    }
  }

  private async ensureInitialized(): Promise<boolean> {
    if (!this.isInitialized || !this.zaiInstance) {
      await this.initializeZAI();
    }
    return this.isInitialized && this.zaiInstance !== null;
  }

  // Direct OpenAI API integration
  private async callOpenAI(messages: ChatMessage[], model: string = 'gpt-4'): Promise<string> {
    if (!this.openaiApiKey) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.openaiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model,
          messages: messages,
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`OpenAI API error: ${error}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || 'No response from OpenAI';
    } catch (error) {
      console.error('OpenAI API error:', error);
      throw error;
    }
  }

  // OpenRouter API integration
  private async callOpenRouter(messages: ChatMessage[], model: string = 'anthropic/claude-3-opus'): Promise<string> {
    if (!this.openRouterApiKey) {
      throw new Error('OpenRouter API key not configured');
    }

    try {
      const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.openRouterApiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://localhost:3000',
          'X-Title': 'AI Agent',
        },
        body: JSON.stringify({
          model: model,
          messages: messages,
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`OpenRouter API error: ${error}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || 'No response from OpenRouter';
    } catch (error) {
      console.error('OpenRouter API error:', error);
      throw error;
    }
  }

  // HuggingFace API integration
  private async callHuggingFace(prompt: string, model: string): Promise<string> {
    if (!this.huggingFaceApiKey) {
      throw new Error('HuggingFace API key not configured');
    }

    try {
      const response = await fetch(`${this.huggingFaceInferenceUrl}/${model}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.huggingFaceApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: prompt,
          parameters: {
            max_new_tokens: 1000,
            temperature: 0.7,
          },
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`HuggingFace API error: ${error}`);
      }

      const data = await response.json();
      return data[0]?.generated_text || 'No response from HuggingFace';
    } catch (error) {
      console.error('HuggingFace API error:', error);
      throw error;
    }
  }

  // Ollama API integration
  private async callOllama(messages: ChatMessage[], model: string = 'llama2'): Promise<string> {
    if (!this.ollamaApiKey) {
      throw new Error('Ollama API key not configured');
    }

    try {
      const response = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model,
          prompt: messages.map(m => `${m.role}: ${m.content}`).join('\n'),
          stream: false,
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Ollama API error: ${error}`);
      }

      const data = await response.json();
      return data.response || 'No response from Ollama';
    } catch (error) {
      console.error('Ollama API error:', error);
      throw error;
    }
  }

  // Z-AI SDK integration
  private async callZAI(messages: ChatMessage[], model: string): Promise<string> {
    const initialized = await this.ensureInitialized();
    if (!initialized) {
      throw new Error('Z-AI SDK not initialized');
    }

    try {
      const completion = await this.zaiInstance.chat.completions.create({
        messages,
        model: model,
        temperature: 0.7,
        max_tokens: 2000,
      });

      if (completion.choices && completion.choices[0]?.message?.content) {
        return completion.choices[0].message.content;
      } else {
        throw new Error('No response generated from Z-AI');
      }
    } catch (error) {
      console.error('Z-AI SDK error:', error);
      throw error;
    }
  }

  // Main AI call method with provider selection
  async callAI(modelName: string, messages: ChatMessage[], mode: string = 'chat'): Promise<string> {
    try {
      console.log(`Calling AI with model: ${modelName}, mode: ${mode}`);

      // Map model names to providers and actual model names
      const modelConfig = this.getModelConfig(modelName);
      
      // Try providers in order of preference
      const providers = [
        () => this.callZAI(messages, modelConfig.zaiModel),
        () => this.callOpenAI(messages, modelConfig.openaiModel),
        () => this.callOpenRouter(messages, modelConfig.openRouterModel),
        () => this.callHuggingFace(messages[messages.length - 1].content, modelConfig.huggingFaceModel),
        () => this.callOllama(messages, modelConfig.ollamaModel),
      ];

      let lastError: Error | null = null;
      
      for (const providerCall of providers) {
        try {
          const response = await providerCall();
          console.log(`AI response generated using ${providerCall.name}`);
          return response;
        } catch (error) {
          lastError = error as Error;
          console.warn(`${providerCall.name} failed:`, error);
          continue;
        }
      }

      throw lastError || new Error('All AI providers failed');
    } catch (error) {
      console.error('AI Provider error:', error);
      throw error;
    }
  }

  // Get model configuration for different providers
  private getModelConfig(modelName: string) {
    const configs: Record<string, any> = {
      'gpt-4': {
        zaiModel: 'gpt-4',
        openaiModel: 'gpt-4',
        openRouterModel: 'openai/gpt-4',
        huggingFaceModel: 'gpt2',
        ollamaModel: 'llama2'
      },
      'gpt-4-turbo': {
        zaiModel: 'gpt-4-turbo',
        openaiModel: 'gpt-4-turbo',
        openRouterModel: 'openai/gpt-4-turbo',
        huggingFaceModel: 'gpt2',
        ollamaModel: 'llama2'
      },
      'gpt-3.5-turbo': {
        zaiModel: 'gpt-3.5-turbo',
        openaiModel: 'gpt-3.5-turbo',
        openRouterModel: 'openai/gpt-3.5-turbo',
        huggingFaceModel: 'gpt2',
        ollamaModel: 'llama2'
      },
      'glm-4.5': {
        zaiModel: 'glm-4.5',
        openaiModel: 'gpt-4',
        openRouterModel: 'google/gemini-pro',
        huggingFaceModel: 'google/gemma-7b',
        ollamaModel: 'llama2'
      },
      'claude-3-opus': {
        zaiModel: 'claude-3-opus',
        openaiModel: 'gpt-4',
        openRouterModel: 'anthropic/claude-3-opus',
        huggingFaceModel: 'mistralai/Mixtral-8x7B-v0.1',
        ollamaModel: 'llama2'
      },
      'claude-3-sonnet': {
        zaiModel: 'claude-3-sonnet',
        openaiModel: 'gpt-4',
        openRouterModel: 'anthropic/claude-3-sonnet',
        huggingFaceModel: 'mistralai/Mixtral-8x7B-v0.1',
        ollamaModel: 'llama2'
      },
      'gemini-pro': {
        zaiModel: 'gemini-pro',
        openaiModel: 'gpt-4',
        openRouterModel: 'google/gemini-pro',
        huggingFaceModel: 'google/gemma-7b',
        ollamaModel: 'llama2'
      },
      'llama-3-70b': {
        zaiModel: 'llama-3-70b',
        openaiModel: 'gpt-4',
        openRouterModel: 'meta-llama/llama-3-70b',
        huggingFaceModel: 'meta-llama/Meta-Llama-3-70B',
        ollamaModel: 'llama3'
      },
      'mixtral-8x7b': {
        zaiModel: 'mixtral-8x7b',
        openaiModel: 'gpt-4',
        openRouterModel: 'mistralai/mixtral-8x7b',
        huggingFaceModel: 'mistralai/Mixtral-8x7B-v0.1',
        ollamaModel: 'mixtral'
      },
      'command-r-plus': {
        zaiModel: 'command-r-plus',
        openaiModel: 'gpt-4',
        openRouterModel: 'cohere/command-r-plus',
        huggingFaceModel: 'cohere/command-r-plus',
        ollamaModel: 'llama2'
      },
      'z-ai-fullstack': {
        zaiModel: 'glm-4.5',
        openaiModel: 'gpt-4-turbo',
        openRouterModel: 'anthropic/claude-3-opus',
        huggingFaceModel: 'mistralai/Mixtral-8x7B-v0.1',
        ollamaModel: 'llama2'
      }
    };

    return configs[modelName] || configs['gpt-4'];
  }

  async performWebSearch(query: string): Promise<SearchResult[]> {
    try {
      const initialized = await this.ensureInitialized();
      if (!initialized) {
        throw new Error('Z-AI SDK not initialized');
      }

      console.log('Performing web search for:', query);

      const searchResult = await this.zaiInstance.functions.invoke("web_search", {
        query: query,
        num: 5,
      });

      if (searchResult && Array.isArray(searchResult)) {
        return searchResult.map((result: any, index: number) => ({
          url: result.url || '',
          name: result.name || `Search Result ${index + 1}`,
          snippet: result.snippet || '',
          host_name: result.host_name || '',
          rank: result.rank || index + 1,
          date: result.date || new Date().toISOString(),
          favicon: result.favicon || ''
        }));
      }

      return [];
    } catch (error) {
      console.error('Web search error:', error);
      return [];
    }
  }

  async generateImage(prompt: string, model: string): Promise<string> {
    try {
      const initialized = await this.ensureInitialized();
      if (!initialized) {
        throw new Error('Z-AI SDK not initialized');
      }

      console.log('Generating image with model:', model);

      const imageModelMapping: Record<string, string> = {
        'Stable Diffusion': 'stabilityai/stable-diffusion-2-1',
        'MidJourney': 'prompthero/openjourney',
        'DALL-E': 'openai/dall-e-2',
        'stable-diffusion': 'stabilityai/stable-diffusion-2-1',
        'midjourney': 'prompthero/openjourney',
        'dalle': 'openai/dall-e-2'
      };

      const actualModel = imageModelMapping[model] || 'stabilityai/stable-diffusion-2-1';

      const imageResponse = await this.zaiInstance.images.generations.create({
        prompt: prompt,
        model: actualModel,
        size: '1024x1024',
      });

      if (imageResponse.data && imageResponse.data[0]?.base64) {
        return imageResponse.data[0].base64;
      } else {
        throw new Error('No image generated');
      }
    } catch (error) {
      console.error('Image generation error:', error);
      throw error;
    }
  }

  async generateCode(prompt: string, model: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are an expert programmer. Provide clean, well-commented code solutions. Include explanations when necessary. Use appropriate code formatting and best practices.'
      },
      {
        role: 'user',
        content: prompt
      }
    ];

    return await this.callAI(model, messages, 'code');
  }

  async performAnalysis(prompt: string, model: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: 'You are an analytical AI assistant. Provide detailed analysis, insights, and data-driven responses. Be thorough and comprehensive in your analysis.'
      },
      {
        role: 'user',
        content: prompt
      }
    ];

    return await this.callAI(model, messages, 'analysis');
  }

  async fullStackDevelopment(prompt: string, model: string): Promise<string> {
    const messages: ChatMessage[] = [
      {
        role: 'system',
        content: `You are a full-stack development expert. Provide comprehensive solutions including:
1. Frontend implementation (React/Next.js components, styling, user interface)
2. Backend development (API routes, database schema, server logic)
3. Database design (schema, relationships, queries)
4. Architecture recommendations (best practices, scalability, security)
5. Deployment strategies and configuration

Include code examples, file structures, and step-by-step implementation guidance. Use modern technologies and frameworks.`
      },
      {
        role: 'user',
        content: prompt
      }
    ];

    return await this.callAI(model, messages, 'fullstack');
  }

  // New method for full-stack code generation with file outputs
  async generateFullStackProject(prompt: string, files: any[] = []): Promise<FullStackCodeBundle> {
    try {
      console.log('Generating full-stack project for:', prompt);
      
      const systemPrompt = `You are a full-stack code generator. Given the prompt: '${prompt}', and these files: ${JSON.stringify(files)}, produce a complete React+FastAPI project.

Your response should include:
1. Frontend code (React components, styling, configuration)
2. Backend code (FastAPI routes, models, database setup)
3. Project structure and setup instructions
4. Dependencies and installation guide

Format your response as JSON with the following structure:
{
  "frontend": "complete frontend code as string",
  "backend": "complete backend code as string", 
  "projectStructure": "directory structure and file organization",
  "setupInstructions": "step-by-step setup and deployment guide"
}`;

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: systemPrompt
        },
        {
          role: 'user',
          content: `Generate a complete full-stack project for: ${prompt}`
        }
      ];

      const response = await this.callAI('z-ai-fullstack', messages, 'fullstack');
      
      try {
        // Try to parse as JSON first
        const parsed = JSON.parse(response);
        return {
          frontend: parsed.frontend || response,
          backend: parsed.backend || '',
          projectStructure: parsed.projectStructure || '',
          setupInstructions: parsed.setupInstructions || ''
        };
      } catch {
        // If not JSON, return the response as frontend
        return {
          frontend: response,
          backend: '',
          projectStructure: '',
          setupInstructions: ''
        };
      }
    } catch (error) {
      console.error('Full-stack generation error:', error);
      throw error;
    }
  }

  getAvailableModels(): string[] {
    return [
      'gpt-4',
      'gpt-4-turbo', 
      'gpt-3.5-turbo',
      'glm-4.5',
      'claude-3-opus',
      'claude-3-sonnet',
      'gemini-pro',
      'llama-3-70b',
      'mixtral-8x7b',
      'command-r-plus',
      'z-ai-fullstack'
    ];
  }

  isModelAvailable(modelName: string): boolean {
    const availableModels = this.getAvailableModels();
    return availableModels.includes(modelName);
  }

  getHealthStatus(): { status: 'healthy' | 'unhealthy' | 'initializing'; message: string; details?: any } {
    if (this.initializationPromise) {
      return {
        status: 'initializing',
        message: 'AI services are currently initializing',
        details: {
          isInitialized: this.isInitialized,
          hasInstance: this.zaiInstance !== null,
          hasOpenAI: !!this.openaiApiKey,
          hasOpenRouter: !!this.openRouterApiKey,
          hasHuggingFace: !!this.huggingFaceApiKey,
          hasOllama: !!this.ollamaApiKey
        }
      };
    }

    if (this.isInitialized && this.zaiInstance) {
      return {
        status: 'healthy',
        message: 'All AI services are operational',
        details: {
          providers: ['Z-AI SDK', 'OpenAI', 'OpenRouter', 'HuggingFace', 'Ollama'],
          availableModels: this.getAvailableModels()
        }
      };
    }

    return {
      status: 'unhealthy',
      message: 'AI services are unavailable',
      details: {
        isInitialized: this.isInitialized,
        hasInstance: this.zaiInstance !== null
      }
    };
  }
}

// Export singleton instance
export const enhancedAIProvider = new EnhancedAIProvider();