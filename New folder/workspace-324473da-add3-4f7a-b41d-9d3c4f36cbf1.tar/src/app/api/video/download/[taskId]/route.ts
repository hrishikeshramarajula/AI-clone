import { NextRequest, NextResponse } from 'next/server';
import { readFile, existsSync } from 'fs';
import { join } from 'path';

// In-memory storage reference (in production, this would be a database)
const videoStorage = new Map<string, string>();

export async function GET(
  request: NextRequest,
  { params }: { params: { taskId: string } }
) {
  try {
    const { taskId } = params;
    
    if (!taskId) {
      return NextResponse.json(
        { error: 'Task ID is required' },
        { status: 400 }
      );
    }

    // Get video path from storage (in a real app, this would come from a database)
    const videoPath = join(process.cwd(), 'public', 'videos', `${taskId}.mp4`);
    
    if (!existsSync(videoPath)) {
      return NextResponse.json(
        { error: 'Video file not found' },
        { status: 404 }
      );
    }

    // Read the video file
    const videoBuffer = await readFile(videoPath);
    
    // For demo purposes, we'll create a simple MP4 file placeholder
    // In a real implementation, this would be the actual video file
    
    // Set appropriate headers for file download
    const headers = new Headers();
    headers.set('Content-Type', 'video/mp4');
    headers.set('Content-Disposition', `attachment; filename="video_${taskId}.mp4"`);
    headers.set('Content-Length', videoBuffer.length.toString());

    return new NextResponse(videoBuffer, {
      status: 200,
      headers,
    });

  } catch (error) {
    console.error('Video download error:', error);
    return NextResponse.json(
      { error: 'Failed to download video' },
      { status: 500 }
    );
  }
}