import { NextRequest, NextResponse } from 'next/server';
import { getVideoJob } from '../generate/route';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const filename = searchParams.get('filename');

    if (!filename) {
      return NextResponse.json(
        { error: 'Filename is required' },
        { status: 400 }
      );
    }

    // Extract video ID from filename
    const videoId = filename.replace('.mp4', '');
    const job = getVideoJob(videoId);

    if (!job || job.status !== 'completed') {
      return NextResponse.json(
        { error: 'Video not found or not ready for download' },
        { status: 404 }
      );
    }

    // For now, return a placeholder video response
    // In production, you would serve the actual video file
    return NextResponse.json({
      message: 'Video download endpoint',
      filename,
      videoId,
      status: 'ready',
      downloadUrl: job.videoUrl,
      note: 'This is a placeholder. In production, this would serve the actual video file.'
    });

  } catch (error) {
    console.error('Video Download API Error:', error);
    return NextResponse.json(
      { error: 'Failed to process video download' },
      { status: 500 }
    );
  }
}