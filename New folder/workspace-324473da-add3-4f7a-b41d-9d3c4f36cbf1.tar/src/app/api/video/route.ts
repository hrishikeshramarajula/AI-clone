import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir, readFile, unlink } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';
import ZAI from 'z-ai-web-dev-sdk';

// In-memory storage for video generation tasks (in production, use a database)
const videoTasks = new Map<string, any>();
const videoStorage = new Map<string, string>();

interface VideoGenerationRequest {
  prompt: string;
  duration?: number;
  resolution?: string;
  style?: string;
}

interface VideoGenerationResponse {
  taskId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  message: string;
  videoUrl?: string;
  downloadUrl?: string;
  progress?: number;
  error?: string;
}

// Generate unique ID for video tasks
function generateTaskId(): string {
  return `video_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Create video directory if it doesn't exist
async function ensureVideoDirectory() {
  const videoDir = join(process.cwd(), 'public', 'videos');
  if (!existsSync(videoDir)) {
    await mkdir(videoDir, { recursive: true });
  }
  return videoDir;
}

// Simulate video generation using AI image generation and creating a video from frames
async function generateVideoFromPrompt(prompt: string, taskId: string): Promise<string> {
  try {
    const videoDir = await ensureVideoDirectory();
    const videoPath = join(videoDir, `${taskId}.mp4`);
    
    // Update task status to processing
    const task = videoTasks.get(taskId);
    if (task) {
      task.status = 'processing';
      task.progress = 10;
    }

    // Use Z-AI to generate image frames for the video
    const zai = await ZAI.create();
    
    // Generate multiple frames based on the prompt
    const frames = [];
    const frameCount = 30; // 30 frames for a 1-second video at 30fps
    
    for (let i = 0; i < Math.min(frameCount, 5); i++) { // Limit to 5 frames for demo
      // Update progress
      if (task) {
        task.progress = 20 + (i * 15);
      }
      
      // Generate frame with slight variations
      const framePrompt = `${prompt}, frame ${i + 1}, cinematic lighting, high quality`;
      
      try {
        const imageResponse = await zai.images.generations.create({
          prompt: framePrompt,
          size: '512x512'
        });
        
        const imageBase64 = imageResponse.data[0].base64;
        frames.push(imageBase64);
        
        // Small delay between frame generation
        await new Promise(resolve => setTimeout(resolve, 500));
      } catch (frameError) {
        console.error(`Error generating frame ${i}:`, frameError);
        // Continue with available frames
      }
    }
    
    if (frames.length === 0) {
      throw new Error('Failed to generate any frames for the video');
    }
    
    // Update progress
    if (task) {
      task.progress = 80;
    }
    
    // Create a simple video file (in a real implementation, you'd use FFmpeg or similar)
    // For now, we'll create a placeholder video file with metadata
    const videoMetadata = {
      prompt,
      framesGenerated: frames.length,
      duration: '1 second',
      resolution: '512x512',
      createdAt: new Date().toISOString(),
      frames: frames.slice(0, 3) // Store first 3 frames as preview
    };
    
    await writeFile(videoPath, JSON.stringify(videoMetadata, null, 2));
    
    // Store video info
    videoStorage.set(taskId, videoPath);
    
    // Update task status to completed
    if (task) {
      task.status = 'completed';
      task.progress = 100;
      task.videoUrl = `/videos/${taskId}.mp4`;
      task.downloadUrl = `/api/video/download/${taskId}`;
      task.completedAt = new Date().toISOString();
    }
    
    return videoPath;
    
  } catch (error) {
    console.error('Video generation error:', error);
    
    // Update task status to failed
    const task = videoTasks.get(taskId);
    if (task) {
      task.status = 'failed';
      task.error = error instanceof Error ? error.message : 'Unknown error';
    }
    
    throw error;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: VideoGenerationRequest = await request.json();
    const { prompt, duration = 1, resolution = '512x512', style = 'cinematic' } = body;

    if (!prompt || prompt.trim() === '') {
      return NextResponse.json(
        { error: 'Video prompt is required' },
        { status: 400 }
      );
    }

    // Generate task ID
    const taskId = generateTaskId();
    
    // Create task record
    const task = {
      id: taskId,
      prompt: prompt.trim(),
      duration,
      resolution,
      style,
      status: 'pending' as const,
      progress: 0,
      createdAt: new Date().toISOString(),
      userId: request.headers.get('x-user-id') || 'anonymous'
    };
    
    videoTasks.set(taskId, task);

    // Start video generation in the background
    generateVideoFromPrompt(prompt, taskId).catch(error => {
      console.error(`Background video generation failed for task ${taskId}:`, error);
    });

    // Return immediate response with task ID
    const response: VideoGenerationResponse = {
      taskId,
      status: 'pending',
      message: 'Video generation started. Use the task ID to check status.'
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('Video generation API error:', error);
    return NextResponse.json(
      { error: 'Failed to start video generation' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const taskId = searchParams.get('taskId');
    const action = searchParams.get('action');

    if (action === 'status' && taskId) {
      // Check video generation status
      const task = videoTasks.get(taskId);
      
      if (!task) {
        return NextResponse.json(
          { error: 'Task not found' },
          { status: 404 }
        );
      }

      const response: VideoGenerationResponse = {
        taskId,
        status: task.status,
        message: getTaskStatusMessage(task.status),
        progress: task.progress,
        videoUrl: task.videoUrl,
        downloadUrl: task.downloadUrl,
        error: task.error
      };

      return NextResponse.json(response);
    }

    if (action === 'list') {
      // List all video tasks (for demo purposes)
      const tasks = Array.from(videoTasks.values()).map(task => ({
        id: task.id,
        prompt: task.prompt,
        status: task.status,
        progress: task.progress,
        createdAt: task.createdAt,
        completedAt: task.completedAt
      }));

      return NextResponse.json({
        tasks,
        count: tasks.length
      });
    }

    return NextResponse.json(
      { error: 'Invalid request. Please provide taskId and action parameters.' },
      { status: 400 }
    );

  } catch (error) {
    console.error('Video API GET error:', error);
    return NextResponse.json(
      { error: 'Failed to process request' },
      { status: 500 }
    );
  }
}

function getTaskStatusMessage(status: string): string {
  switch (status) {
    case 'pending':
      return 'Video generation is queued and will start shortly.';
    case 'processing':
      return 'Video is currently being generated...';
    case 'completed':
      return 'Video generation completed successfully!';
    case 'failed':
      return 'Video generation failed. Please try again.';
    default:
      return 'Unknown status.';
  }
}