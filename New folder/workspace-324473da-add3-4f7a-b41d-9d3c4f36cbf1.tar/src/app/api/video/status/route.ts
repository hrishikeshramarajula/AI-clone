import { NextRequest, NextResponse } from 'next/server';
import { getVideoJob } from '../generate/route';

interface VideoStatusResponse {
  videoId: string;
  status: 'processing' | 'completed' | 'failed';
  progress?: number;
  videoUrl?: string;
  error?: string;
  estimatedTime?: number;
  message?: string;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const videoId = searchParams.get('videoId');

    if (!videoId) {
      return NextResponse.json(
        { error: 'Video ID is required' },
        { status: 400 }
      );
    }

    const job = getVideoJob(videoId);

    if (!job) {
      return NextResponse.json(
        { error: 'Video job not found' },
        { status: 404 }
      );
    }

    const response: VideoStatusResponse = {
      videoId: job.videoId,
      status: job.status,
      progress: job.progress,
      videoUrl: job.videoUrl,
      error: job.error,
      estimatedTime: job.estimatedTime
    };

    // Add status messages based on progress
    if (job.status === 'processing') {
      if (job.progress && job.progress <= 10) {
        response.message = 'Initializing AI model...';
      } else if (job.progress && job.progress <= 25) {
        response.message = 'Processing your prompt...';
      } else if (job.progress && job.progress <= 50) {
        response.message = 'Generating video frames...';
      } else if (job.progress && job.progress <= 75) {
        response.message = 'Applying effects and styling...';
      } else if (job.progress && job.progress <= 90) {
        response.message = 'Finalizing video...';
      } else {
        response.message = 'Almost done...';
      }
    } else if (job.status === 'completed') {
      response.message = 'Video generation completed successfully!';
    } else if (job.status === 'failed') {
      response.message = 'Video generation failed. Please try again.';
    }

    return NextResponse.json(response);

  } catch (error) {
    console.error('Video Status API Error:', error);
    return NextResponse.json(
      { error: 'Failed to check video status' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { videoId } = body;

    if (!videoId) {
      return NextResponse.json(
        { error: 'Video ID is required' },
        { status: 400 }
      );
    }

    const job = getVideoJob(videoId);

    if (!job) {
      return NextResponse.json(
        { error: 'Video job not found' },
        { status: 404 }
      );
    }

    const response: VideoStatusResponse = {
      videoId: job.videoId,
      status: job.status,
      progress: job.progress,
      videoUrl: job.videoUrl,
      error: job.error,
      estimatedTime: job.estimatedTime
    };

    // Add status messages based on progress
    if (job.status === 'processing') {
      if (job.progress && job.progress <= 10) {
        response.message = 'Initializing AI model...';
      } else if (job.progress && job.progress <= 25) {
        response.message = 'Processing your prompt...';
      } else if (job.progress && job.progress <= 50) {
        response.message = 'Generating video frames...';
      } else if (job.progress && job.progress <= 75) {
        response.message = 'Applying effects and styling...';
      } else if (job.progress && job.progress <= 90) {
        response.message = 'Finalizing video...';
      } else {
        response.message = 'Almost done...';
      }
    } else if (job.status === 'completed') {
      response.message = 'Video generation completed successfully!';
    } else if (job.status === 'failed') {
      response.message = 'Video generation failed. Please try again.';
    }

    return NextResponse.json(response);

  } catch (error) {
    console.error('Video Status API Error:', error);
    return NextResponse.json(
      { error: 'Failed to check video status' },
      { status: 500 }
    );
  }
}