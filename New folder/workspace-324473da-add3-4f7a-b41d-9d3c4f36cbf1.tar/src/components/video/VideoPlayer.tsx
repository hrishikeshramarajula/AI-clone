'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Download, Share2, Volume2, VolumeX, Maximize, Minimize, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface VideoPlayerProps {
  videoUrl: string;
  downloadUrl?: string;
  title?: string;
  prompt?: string;
  className?: string;
}

interface VideoTask {
  id: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  videoUrl?: string;
  downloadUrl?: string;
  error?: string;
  prompt?: string;
}

export default function VideoPlayer({ 
  videoUrl, 
  downloadUrl, 
  title = "Generated Video", 
  prompt,
  className = "" 
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [showControls, setShowControls] = useState(true);
  const [videoTask, setVideoTask] = useState<VideoTask | null>(null);

  // Auto-hide controls after 3 seconds of inactivity
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    if (isPlaying && showControls) {
      timeout = setTimeout(() => setShowControls(false), 3000);
    }
    return () => clearTimeout(timeout);
  }, [isPlaying, showControls]);

  // Handle video events
  const handleLoadedData = () => {
    setIsLoading(false);
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      setVolume(newVolume);
      setIsMuted(newVolume === 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = newTime;
      setCurrentTime(newTime);
    }
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement && videoRef.current) {
      videoRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleDownload = async () => {
    if (downloadUrl) {
      try {
        const response = await fetch(downloadUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `generated_video_${Date.now()}.mp4`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      } catch (error) {
        console.error('Download failed:', error);
      }
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: prompt || 'Check out this AI-generated video!',
          url: videoUrl,
        });
      } catch (error) {
        console.error('Share failed:', error);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(videoUrl).then(() => {
        alert('Video link copied to clipboard!');
      });
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  // Check if this is a video task URL
  useEffect(() => {
    if (videoUrl.includes('video_')) {
      // Extract task ID from URL
      const taskIdMatch = videoUrl.match(/video_(\d+_\w+)/);
      if (taskIdMatch) {
        const taskId = `video_${taskIdMatch[1]}`;
        checkVideoStatus(taskId);
      }
    }
  }, [videoUrl]);

  const checkVideoStatus = async (taskId: string) => {
    try {
      const response = await fetch(`/api/video?action=status&taskId=${taskId}`);
      const data = await response.json();
      
      setVideoTask(data);
      
      if (data.status === 'processing') {
        // Poll for updates every 2 seconds
        const interval = setInterval(async () => {
          const statusResponse = await fetch(`/api/video?action=status&taskId=${taskId}`);
          const statusData = await statusResponse.json();
          
          setVideoTask(statusData);
          
          if (statusData.status === 'completed') {
            clearInterval(interval);
          }
        }, 2000);
        
        return () => clearInterval(interval);
      }
    } catch (error) {
      console.error('Error checking video status:', error);
    }
  };

  // Show loading state or video generation progress
  if (videoTask?.status === 'processing') {
    return (
      <Card className={`w-full ${className}`}>
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center space-y-4">
            <Loader2 className="w-12 h-12 animate-spin text-blue-500" />
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">Generating Your Video</h3>
              <p className="text-sm text-gray-600">{prompt}</p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${videoTask.progress}%` }}
                />
              </div>
              <p className="text-xs text-gray-500">{videoTask.progress}% complete</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (videoTask?.status === 'failed') {
    return (
      <Card className={`w-full ${className}`}>
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center space-y-4">
            <div className="text-red-500 text-4xl">❌</div>
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold text-red-600">Video Generation Failed</h3>
              <p className="text-sm text-gray-600">{videoTask.error}</p>
              <Button 
                onClick={() => window.location.reload()} 
                variant="outline"
                className="mt-4"
              >
                Try Again
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`w-full ${className}`}>
      <CardContent className="p-0">
        <div className="relative group">
          {/* Video Element */}
          <video
            ref={videoRef}
            src={videoUrl}
            className="w-full h-auto rounded-lg"
            onLoadedData={handleLoadedData}
            onTimeUpdate={handleTimeUpdate}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onEnded={() => setIsPlaying(false)}
            onMouseMove={() => setShowControls(true)}
            onMouseLeave={() => setShowControls(false)}
            onClick={handlePlayPause}
          />
          
          {/* Loading Overlay */}
          {isLoading && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center rounded-lg">
              <Loader2 className="w-8 h-8 animate-spin text-white" />
            </div>
          )}
          
          {/* Video Controls Overlay */}
          {showControls && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 rounded-b-lg">
              {/* Progress Bar */}
              <div className="mb-3">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex justify-between text-xs text-white mt-1">
                  <span>{formatTime(currentTime)}</span>
                  <span>{formatTime(duration)}</span>
                </div>
              </div>
              
              {/* Control Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handlePlayPause}
                    className="text-white hover:text-white hover:bg-white/20"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={handleMute}
                      className="text-white hover:text-white hover:bg-white/20"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </Button>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={isMuted ? 0 : volume}
                      onChange={handleVolumeChange}
                      className="w-20 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handleDownload}
                    className="text-white hover:text-white hover:bg-white/20"
                    disabled={!downloadUrl}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handleShare}
                    className="text-white hover:text-white hover:bg-white/20"
                  >
                    <Share2 className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    size="icon"
                    variant="ghost"
                    onClick={handleFullscreen}
                    className="text-white hover:text-white hover:bg-white/20"
                  >
                    {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          {/* Play/Pause Overlay */}
          {!showControls && (
            <div 
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
              onClick={handlePlayPause}
            >
              {!isPlaying && !isLoading && (
                <div className="bg-black/50 rounded-full p-4">
                  <Play className="w-8 h-8 text-white" />
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Video Info */}
        {(title || prompt) && (
          <div className="p-4 border-t">
            <h3 className="font-semibold text-lg mb-1">{title}</h3>
            {prompt && (
              <p className="text-sm text-gray-600">Prompt: {prompt}</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}