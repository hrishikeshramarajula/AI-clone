import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

interface AIRequest {
  message: string;
  model: string;
  searchType: 'chat' | 'search' | 'code' | 'analysis' | 'image' | 'video';
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: AIRequest = await request.json();
    const { message, model, searchType } = body;

    console.log('AI API Request:', { message, model, searchType });

    const zai = await ZAI.create();
    let response = '';
    let searchResults: SearchResult[] = [];

    if (searchType === 'search') {
      // Perform web search first
      try {
        const searchResult = await zai.functions.invoke("web_search", {
          query: message,
          num: 5
        });

        searchResults = searchResult.map((result: any, index: number) => ({
          url: result.url,
          name: result.name,
          snippet: result.snippet,
          host_name: result.host_name,
          rank: index + 1,
          date: new Date().toISOString(),
          favicon: result.favicon || ''
        }));

        // Generate response based on search results
        const searchContext = searchResults.map(r => `${r.name}: ${r.snippet}`).join('\n');
        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are a helpful AI assistant. Based on the following search results, provide a comprehensive answer to the user\'s question.'
            },
            {
              role: 'user',
              content: `Question: ${message}\n\nSearch Results:\n${searchContext}`
            }
          ]
        });

        response = completion.choices[0]?.message?.content || 'No response generated';
      } catch (searchError) {
        console.error('Search error:', searchError);
        // Fall back to regular chat if search fails
        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are a helpful AI assistant.'
            },
            {
              role: 'user',
              content: message
            }
          ]
        });

        response = completion.choices[0]?.message?.content || 'No response generated';
      }
    } else if (searchType === 'code') {
      // Code generation mode
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an expert programmer. Provide clean, well-commented code solutions to the user\'s request. Include explanations when necessary.'
          },
          {
            role: 'user',
            content: message
          }
        ]
      });

      response = completion.choices[0]?.message?.content || 'No response generated';
    } else if (searchType === 'analysis') {
      // Analysis mode
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an analytical AI assistant. Provide detailed analysis, insights, and data-driven responses to the user\'s request.'
          },
          {
            role: 'user',
            content: message
          }
        ]
      });

      response = completion.choices[0]?.message?.content || 'No response generated';
    } else if (searchType === 'image') {
      // Image generation mode
      try {
        // Use different image generation models based on the selected model
        let imageModel = 'stabilityai/stable-diffusion-2-1'; // default
        
        if (model.includes('Stable Diffusion')) {
          imageModel = 'stabilityai/stable-diffusion-2-1';
        } else if (model.includes('MidJourney')) {
          imageModel = 'prompthero/openjourney';
        } else if (model.includes('DALL-E')) {
          imageModel = 'openai/dall-e-2';
        }

        const imageResponse = await zai.images.generations.create({
          prompt: message,
          model: imageModel,
          size: '1024x1024'
        });

        const imageBase64 = imageResponse.data[0].base64;
        
        response = `I've generated an image using ${model} based on your prompt: "${message}". The image has been created and is ready for use.`;
        
        return NextResponse.json({
          response,
          model,
          imageData: imageBase64,
          imagePrompt: message,
          timestamp: new Date().toISOString()
        });
      } catch (imageError) {
        console.error('Image generation error:', imageError);
        response = `Sorry, I encountered an error while generating the image with ${model}. Please try again with a different prompt or model.`;
      }
    } else if (searchType === 'video') {
      // Video processing mode
      try {
        // Use different video processing models based on the selected model
        let videoSystemPrompt = 'You are a video processing and analysis expert. Provide guidance on video editing, analysis, compression, formats, and related tasks.';
        
        if (model.includes('Video Whisper')) {
          videoSystemPrompt = 'You are an expert in video transcription and audio analysis using Whisper models. Provide guidance on video transcription, subtitle generation, and audio processing.';
        } else if (model.includes('Video CLIP')) {
          videoSystemPrompt = 'You are an expert in video understanding and analysis using CLIP models. Provide guidance on video content analysis, classification, and understanding.';
        }

        const completion = await zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: videoSystemPrompt
            },
            {
              role: 'user',
              content: message
            }
          ]
        });

        response = completion.choices[0]?.message?.content || 'No response generated';
      } catch (videoError) {
        console.error('Video processing error:', videoError);
        response = `Sorry, I encountered an error while processing your video-related request with ${model}. Please try again.`;
      }
    } else {
      // Regular chat mode
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a helpful AI assistant. Provide clear, concise, and accurate responses to the user\'s questions.'
          },
          {
            role: 'user',
            content: message
          }
        ]
      });

      response = completion.choices[0]?.message?.content || 'No response generated';
    }

    return NextResponse.json({
      response,
      model,
      searchResults: searchResults.length > 0 ? searchResults : undefined,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('AI API Error:', error);
    return NextResponse.json(
      { error: 'Failed to process AI request' },
      { status: 500 }
    );
  }
}