'use client';

import React, { useState, useRef } from 'react';
import {
  Search,
  ChevronDown,
  Calendar,
  FileText,
  Globe,
  Settings,
  Send,
  Loader2,
  Brain,
  Code,
  BarChart3,
  MessageSquare,
  Image as ImageIcon,
  Video,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Task {
  id: string;
  status: 'needs-review' | 'completed';
  timestamp: string;
  content: string;
}

interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'video' | 'code' | 'search' | 'analysis';
}

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  model?: string;
  searchResults?: any[];
  imageData?: string;
  imagePrompt?: string;
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<'active' | 'archived'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [showTasks, setShowTasks] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [model, setModel] = useState('GPT-4');
  const [isModelOpen, setIsModelOpen] = useState(false);
  const [isModeOpen, setIsModeOpen] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [chatMode, setChatMode] = useState<'chat' | 'search' | 'code' | 'analysis' | 'image' | 'video'>('search');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const models: AIModel[] = [
    { 
      id: 'gpt-4', 
      name: 'GPT-4', 
      provider: 'OpenAI', 
      description: 'Most capable model', 
      apiModel: 'gpt-4',
      intelligence: 'High',
      contextLength: '128K',
      inputCredits: '10K',
      outputCredits: '30K',
      specialty: 'chat'
    },
    { 
      id: 'glm-4.5', 
      name: 'GLM-4.5', 
      provider: 'Zhipu AI', 
      description: 'Latest Chinese AI model', 
      apiModel: 'glm-4.5',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '8K',
      outputCredits: '25K',
      specialty: 'search'
    },
    { 
      id: 'gpt-3.5-turbo', 
      name: 'GPT-3.5 Turbo', 
      provider: 'OpenAI', 
      description: 'Fast and efficient', 
      apiModel: 'gpt-3.5-turbo',
      intelligence: 'Medium',
      contextLength: '16K',
      inputCredits: '5K',
      outputCredits: '15K',
      specialty: 'chat'
    },
    { 
      id: 'claude-3-opus', 
      name: 'Claude 3 Opus', 
      provider: 'Anthropic', 
      description: 'Advanced reasoning', 
      apiModel: 'claude-3-opus',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '15K',
      outputCredits: '75K',
      specialty: 'analysis'
    },
    { 
      id: 'claude-3-sonnet', 
      name: 'Claude 3 Sonnet', 
      provider: 'Anthropic', 
      description: 'Balanced performance', 
      apiModel: 'claude-3-sonnet',
      intelligence: 'High',
      contextLength: '200K',
      inputCredits: '3K',
      outputCredits: '15K',
      specialty: 'analysis'
    },
    { 
      id: 'gemini-pro', 
      name: 'Gemini Pro', 
      provider: 'Google', 
      description: 'Multimodal capabilities', 
      apiModel: 'gemini-pro',
      intelligence: 'High',
      contextLength: '32K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'search'
    },
    { 
      id: 'llama-3-70b', 
      name: 'Llama 3 70B', 
      provider: 'Meta', 
      description: 'Open source powerhouse', 
      apiModel: 'llama-3-70b',
      intelligence: 'High',
      contextLength: '8K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'code'
    },
    { 
      id: 'mixtral-8x7b', 
      name: 'Mixtral 8x7B', 
      provider: 'Mistral', 
      description: 'Mixture of experts', 
      apiModel: 'mixtral-8x7b',
      intelligence: 'High',
      contextLength: '32K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'code'
    },
    { 
      id: 'command-r-plus', 
      name: 'Command R+', 
      provider: 'Cohere', 
      description: 'Enterprise grade', 
      apiModel: 'command-r-plus',
      intelligence: 'High',
      contextLength: '128K',
      inputCredits: '5K',
      outputCredits: '15K',
      specialty: 'search'
    },
    // Hugging Face Models for Image and Video
    { 
      id: 'stable-diffusion', 
      name: 'Stable Diffusion', 
      provider: 'Hugging Face', 
      description: 'Image generation model', 
      apiModel: 'stabilityai/stable-diffusion-2-1',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'midjourney', 
      name: 'MidJourney', 
      provider: 'Hugging Face', 
      description: 'Artistic image generation', 
      apiModel: 'prompthero/openjourney',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'dalle', 
      name: 'DALL-E', 
      provider: 'Hugging Face', 
      description: 'OpenAI image generation', 
      apiModel: 'openai/dall-e-2',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'video-whisper', 
      name: 'Video Whisper', 
      provider: 'Hugging Face', 
      description: 'Video analysis and transcription', 
      apiModel: 'openai/whisper-large-v3',
      intelligence: 'High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'video'
    },
    { 
      id: 'video-clip', 
      name: 'Video CLIP', 
      provider: 'Hugging Face', 
      description: 'Video understanding and analysis', 
      apiModel: 'facebook/convnextv2-base-224-224-in-22k',
      intelligence: 'High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'video'
    }
  ];

  const tasks: Task[] = [
    { id: 'SCO-010', status: 'needs-review', timestamp: '7 minutes ago', content: 'addr' },
    { id: 'SCO-009', status: 'needs-review', timestamp: 'Sep 2, 9:26 AM', content: 'hi' },
    { id: 'SCO-008', status: 'needs-review', timestamp: 'Sep 1, 12:26 PM', content: 'Enhance Trading Bot…' },
  ];
  const activeCount = tasks.filter(t => t.status === 'needs-review').length;

  // Filter models based on selected mode
  const getFilteredModels = () => {
    if (chatMode === 'image') {
      return models.filter(model => model.specialty === 'image' || !model.specialty);
    } else if (chatMode === 'video') {
      return models.filter(model => model.specialty === 'video' || !model.specialty);
    } else if (chatMode === 'code') {
      // Include GLM-4.5 first, then other code models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'code' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else if (chatMode === 'search') {
      // Include GLM-4.5 first, then other search models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'search' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else if (chatMode === 'analysis') {
      // Include GLM-4.5 first, then other analysis models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'analysis' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else {
      return models.filter(model => model.specialty === 'chat' || !model.specialty);
    }
  };

  const filteredModels = getFilteredModels();

  // Auto-select first available model when mode changes
  React.useEffect(() => {
    if (filteredModels.length > 0) {
      const currentModelExists = filteredModels.some(m => m.name === model);
      if (!currentModelExists) {
        setModel(filteredModels[0].name);
      }
    }
  }, [chatMode, filteredModels]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    console.log('Sending message:', { message: inputValue, model, chatMode });

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToSend = inputValue;
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: messageToSend,
          model,
          searchType: chatMode,
        }),
      });

      console.log('API response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json();
        console.error('API error response:', errorData);
        throw new Error(errorData.error || 'Failed to get AI response');
      }

      const data = await response.json();
      console.log('API response data:', data);
      
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: data.response,
        timestamp: new Date().toISOString(),
        model: data.model,
        searchResults: data.searchResults,
        imageData: data.imageData,
        imagePrompt: data.imagePrompt,
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // Auto-remove blur and focus when response is received
      setIsInputFocused(false);
      
      // Remove focus from textarea
      if (inputRef.current) {
        inputRef.current.blur();
      }
      
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again.`,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
      
      // Also remove blur on error
      setIsInputFocused(false);
      if (inputRef.current) {
        inputRef.current.blur();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'search': return <Search className="w-4 h-4" />;
      case 'code': return <Code className="w-4 h-4" />;
      case 'analysis': return <BarChart3 className="w-4 h-4" />;
      case 'image': return <ImageIcon className="w-4 h-4" />;
      case 'video': return <Video className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getModeLabel = (mode: string) => {
    switch (mode) {
      case 'search': return 'Web Search';
      case 'code': return 'Code Generation';
      case 'analysis': return 'Analysis';
      case 'image': return 'Image Generation';
      case 'video': return 'Video Processing';
      default: return 'Chat';
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className={`flex h-screen ${isInputFocused ? 'blur-bg bg-gray-100' : ''}`}>
      {/* Sidebar */}
      <aside className={`w-64 bg-white border-r border-gray-200 flex flex-col transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
        <div className="flex items-center p-4 gap-2">
          <div className="bg-blue-500 text-white w-8 h-8 rounded-md flex items-center justify-center font-semibold">
            B
          </div>
          <span className="font-medium text-gray-900">BOT</span>
          <ChevronDown className="text-gray-500" />
        </div>

        <div className="relative px-3 mb-3">
          <Search className="absolute top-1/2 left-6 transform -translate-y-1/2 text-gray-500" />
          <Input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-8"
          />
          <span className="absolute top-1/2 right-6 transform -translate-y-1/2 bg-gray-100 px-2 py-1 rounded text-xs text-gray-500">
            ⌘K
          </span>
        </div>

        <nav className="flex flex-col gap-1 px-3">
          <Button variant="ghost" className="justify-start">
            <Calendar className="w-4 h-4 mr-2" />
            Tasks
          </Button>
          <Button variant="ghost" className="justify-start">
            <FileText className="w-4 h-4 mr-2" />
            Files
          </Button>
          <Button variant="ghost" className="justify-start">
            <Globe className="w-4 h-4 mr-2" />
            Apps
          </Button>
          <Button variant="ghost" className="justify-start">
            <Settings className="w-4 h-4 mr-2" />
            Configuration
          </Button>
        </nav>

        <div className="px-3 mt-auto pb-4">
          <Button
            variant="ghost"
            className="w-full justify-between"
            onClick={() => setShowTasks(!showTasks)}
          >
            <span className="font-medium">Active tasks ({activeCount})</span>
            <ChevronDown className={`text-gray-500 transition-transform ${showTasks ? 'rotate-180' : ''}`} />
          </Button>
          {showTasks && (
            <div className="mt-2 flex flex-col gap-2">
              {tasks.map(t => (
                <div key={t.id} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <div className="text-xs text-gray-600">
                    <div className="font-medium">Needs review</div>
                    <div className="text-gray-400">{t.timestamp}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* Main */}
      <main className={`flex-1 flex flex-col bg-white transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
        <header className={`flex items-center p-4 border-b border-gray-200 gap-4 transition-all duration-300 ${isInputFocused ? 'invisible' : ''}`}>
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'active' | 'archived')}>
            <TabsList>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="archived">Archived</TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="ml-auto text-gray-500">Display</div>
        </header>

        <section className={`flex-1 overflow-hidden transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
          <ScrollArea className="h-full p-4 bg-gray-50">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Brain className="w-16 h-16 text-blue-500 mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">AI Search Engine</h2>
                <p className="text-gray-600 mb-6">Ask anything and get intelligent responses with web search capabilities</p>
                <div className="grid grid-cols-2 gap-4 max-w-md">
                  <Button
                    variant={chatMode === 'chat' ? 'default' : 'outline'}
                    onClick={() => setChatMode('chat')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <MessageSquare className="w-6 h-6" />
                    <span className="text-sm">Chat</span>
                  </Button>
                  <Button
                    variant={chatMode === 'search' ? 'default' : 'outline'}
                    onClick={() => setChatMode('search')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Search className="w-6 h-6" />
                    <span className="text-sm">Web Search</span>
                  </Button>
                  <Button
                    variant={chatMode === 'code' ? 'default' : 'outline'}
                    onClick={() => setChatMode('code')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Code className="w-6 h-6" />
                    <span className="text-sm">Code</span>
                  </Button>
                  <Button
                    variant={chatMode === 'analysis' ? 'default' : 'outline'}
                    onClick={() => setChatMode('analysis')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <BarChart3 className="w-6 h-6" />
                    <span className="text-sm">Analysis</span>
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${
                      message.type === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {message.type === 'assistant' && (
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Brain className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-white border border-gray-200'
                      }`}
                    >
                      <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                      {message.model && (
                        <div className="text-xs mt-2 opacity-70">
                          {message.model} • {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      )}
                      {message.searchResults && message.searchResults.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs font-medium mb-2 text-gray-600">Search Results:</div>
                          {message.searchResults.slice(0, 3).map((result: SearchResult, index: number) => (
                            <div key={index} className="mb-2 p-2 bg-gray-50 rounded text-xs">
                              <div className="font-medium text-gray-900">{result.name}</div>
                              <div className="text-gray-600 mt-1">{result.snippet}</div>
                              <div className="text-gray-400 mt-1">{result.host_name}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      {message.imageData && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs font-medium mb-2 text-gray-600">Generated Image:</div>
                          <div className="mt-2">
                            <img 
                              src={`data:image/png;base64,${message.imageData}`} 
                              alt={message.imagePrompt || "Generated image"}
                              className="max-w-full h-auto rounded-lg border border-gray-200"
                            />
                            {message.imagePrompt && (
                              <div className="text-xs text-gray-500 mt-2 italic">
                                Prompt: "{message.imagePrompt}"
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    {message.type === 'user' && (
                      <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-sm font-medium">U</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </section>

        {/* Input Area - This will NOT be blurred when focused */}
        <div className={`border-t border-gray-200 p-4 bg-white transition-all duration-300 ${isInputFocused ? 'z-50 shadow-lg' : ''}`}>
          <div className="flex items-center justify-between mb-4 pr-12">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Mode:</span>
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModeOpen(!isModeOpen)}
                  className="flex items-center gap-1"
                >
                  {getModeIcon(chatMode)}
                  {getModeLabel(chatMode)}
                  <ChevronDown className={`w-3 h-3 transition-transform ${isModeOpen ? 'rotate-180' : ''}`} />
                </Button>
                {isModeOpen && (
                  <div className="absolute bottom-full left-0 mb-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="p-2">
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('search');
                          setIsModeOpen(false);
                        }}
                      >
                        <Search className="w-3 h-3" />
                        Web Search
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('code');
                          setIsModeOpen(false);
                        }}
                      >
                        <Code className="w-3 h-3" />
                        Code Generation
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('analysis');
                          setIsModeOpen(false);
                        }}
                      >
                        <BarChart3 className="w-3 h-3" />
                        Analysis
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('image');
                          setIsModeOpen(false);
                        }}
                      >
                        <ImageIcon className="w-3 h-3" />
                        Image Generation
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('video');
                          setIsModeOpen(false);
                        }}
                      >
                        <Video className="w-3 h-3" />
                        Video Processing
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-2 pr-4">
              <span className="text-sm font-medium text-gray-700">Model:</span>
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModelOpen(!isModelOpen)}
                  className="flex items-center gap-1 min-w-[120px]"
                >
                  {model || 'Select Model'}
                  <ChevronDown className={`w-3 h-3 transition-transform ${isModelOpen ? 'rotate-180' : ''}`} />
                </Button>
                {isModelOpen && (
                  <div className="absolute bottom-full left-0 mb-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="p-2">
                      {filteredModels.map((m) => (
                        <button
                          key={m.id}
                          className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm"
                          onClick={() => {
                            setModel(m.name);
                            setIsModelOpen(false);
                          }}
                        >
                          <div className="font-medium">{m.name}</div>
                          <div className="text-xs text-gray-500">{m.provider}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex gap-2 mb-6">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              onFocus={() => setIsInputFocused(true)}
              onBlur={() => setIsInputFocused(false)}
              placeholder="Ask anything..."
              className="flex-1 resize-none border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              rows={1}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              size="icon"
              className="transition-all duration-300"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
          
          {/* Current Mode Indicator */}
          <div className="flex items-center justify-center">
            <Badge variant="secondary" className="flex items-center gap-2">
              {getModeIcon(chatMode)}
              <span>Current Mode: {getModeLabel(chatMode)}</span>
            </Badge>
          </div>
        </div>
      </main>
    </div>
  );
}