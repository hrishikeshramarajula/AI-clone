import { NextRequest, NextResponse } from 'next/server';

interface FullstackRequest {
  prompt: string;
  model: string;
  files?: any[];
}

interface FullstackResponse {
  success: boolean;
  project?: {
    frontend: string;
    backend: string;
    projectStructure: string;
    setupInstructions: string;
    packageJson: string;
  };
  error?: string;
}

async function generateFullstackProject(prompt: string, model: string, files: any[] = []): Promise<{
  frontend: string;
  backend: string;
  projectStructure: string;
  setupInstructions: string;
  packageJson: string;
}> {
  try {
    console.log('Generating fullstack project for:', prompt, 'model:', model);

    // Import and use the z-ai-web-dev-sdk
    const ZAI = await import('z-ai-web-dev-sdk');
    console.log('ZAI SDK imported successfully for fullstack generation');

    // Get the default export which contains the create method
    const ZAIDefault = ZAI.default || ZAI;
    console.log('ZAI default export type:', typeof ZAIDefault);

    // Check if ZAI default has the create method
    if (typeof ZAIDefault.create !== 'function') {
      throw new Error('ZAI.create is not a function');
    }

    // Create ZAI instance using static create method
    const zai = await ZAIDefault.create();
    console.log('ZAI instance created successfully for fullstack generation');

    // Create system prompt for fullstack development
    const systemPrompt = `You are an expert fullstack developer. Generate a complete fullstack application based on the user's requirements. 
Your response should include:
1. Frontend React/Next.js code with TypeScript
2. Backend FastAPI/Python code
3. Project structure
4. Setup instructions
5. Package.json configuration

Provide complete, production-ready code with proper error handling, TypeScript typing, and best practices.`;

    // Create the full prompt
    let fullPrompt = `Generate a complete fullstack application for: ${prompt}

The application should include:
- Modern React frontend with TypeScript and Tailwind CSS
- FastAPI backend with proper routing and error handling
- Database integration with Prisma
- User authentication if needed
- Responsive design
- Complete setup instructions

Please provide the code in the following format:
===FRONTEND===
[React/Next.js frontend code here]
===BACKEND===
[FastAPI backend code here]
===STRUCTURE===
[Project file structure here]
===SETUP===
[Setup instructions here]
===PACKAGE===
[package.json content here]`;

    // Add file context if files are provided
    if (files && files.length > 0) {
      fullPrompt += '\n\nAdditional context from uploaded files:\n';
      files.forEach((file, index) => {
        fullPrompt += `\nFile ${index + 1}: ${file.name}\n${file.content || '[No content available]'}\n`;
      });
    }

    console.log('Fullstack generation prompt created');

    try {
      // Use ZAI SDK for generation with timeout and error handling
      const completion = await Promise.race([
        zai.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: systemPrompt
            },
            {
              role: 'user',
              content: fullPrompt
            }
          ],
          temperature: 0.3,
          max_tokens: 1000  // Reduced token limit for faster response
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Fullstack generation timeout')), 45000)  // 45 second timeout
        )
      ]);

      console.log('Fullstack generation successful via ZAI SDK');

      // Parse the response
      let response = '';
      if (completion && completion.choices && Array.isArray(completion.choices)) {
        response = completion.choices[0]?.message?.content || '';
      }

      if (!response) {
        throw new Error('No response content received from ZAI SDK');
      }

      console.log('ZAI SDK Response length:', response.length);

      // Parse the response into sections
      const sections = response.split('===');
      let frontend = '';
      let backend = '';
      let projectStructure = '';
      let setupInstructions = '';
      let packageJson = '';

      sections.forEach(section => {
        const trimmed = section.trim();
        if (trimmed.startsWith('FRONTEND')) {
          frontend = trimmed.replace('FRONTEND', '').trim();
        } else if (trimmed.startsWith('BACKEND')) {
          backend = trimmed.replace('BACKEND', '').trim();
        } else if (trimmed.startsWith('STRUCTURE')) {
          projectStructure = trimmed.replace('STRUCTURE', '').trim();
        } else if (trimmed.startsWith('SETUP')) {
          setupInstructions = trimmed.replace('SETUP', '').trim();
        } else if (trimmed.startsWith('PACKAGE')) {
          packageJson = trimmed.replace('PACKAGE', '').trim();
        }
      });

      // If parsing failed, generate default structure
      if (!frontend || !backend) {
        console.log('Response parsing failed, generating default structure');
        frontend = generateDefaultFrontend(prompt);
        backend = generateDefaultBackend(prompt);
        projectStructure = generateDefaultStructure(prompt);
        setupInstructions = generateDefaultSetup(prompt);
        packageJson = generateDefaultPackageJson(prompt);
      }

      return {
        frontend,
        backend,
        projectStructure,
        setupInstructions,
        packageJson
      };

    } catch (generationError) {
      console.error('Fullstack generation failed:', generationError);
      
      // If generation fails, provide a simpler, working response
      console.log('Falling back to simplified project generation');
      
      return {
        frontend: generateSimpleFrontend(prompt),
        backend: generateSimpleBackend(prompt),
        projectStructure: generateSimpleStructure(prompt),
        setupInstructions: generateSimpleSetup(prompt),
        packageJson: generateSimplePackageJson(prompt)
      };
    }
    
    if (sections.length > 1) {
      sections.forEach(section => {
        const trimmed = section.trim();
        if (trimmed.startsWith('FRONTEND')) {
          frontend = trimmed.replace('FRONTEND', '').trim();
        } else if (trimmed.startsWith('BACKEND')) {
          backend = trimmed.replace('BACKEND', '').trim();
        } else if (trimmed.startsWith('STRUCTURE')) {
          projectStructure = trimmed.replace('STRUCTURE', '').trim();
        } else if (trimmed.startsWith('SETUP')) {
          setupInstructions = trimmed.replace('SETUP', '').trim();
        } else if (trimmed.startsWith('PACKAGE')) {
          packageJson = trimmed.replace('PACKAGE', '').trim();
        }
      });
    }

    // If parsing failed, try to extract content using keyword matching
    if (!frontend || !backend) {
      console.log('Trying alternative parsing method');
      
      // Look for frontend code indicators
      const frontendKeywords = ['import React', 'function App', 'export default', 'React component', 'frontend'];
      const backendKeywords = ['from fastapi', 'FastAPI', 'app.get', 'app.post', 'backend', 'server'];
      
      const lines = response.split('\n');
      let currentSection = '';
      let inFrontend = false;
      let inBackend = false;
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Check for section headers
        if (line.toLowerCase().includes('frontend') || frontendKeywords.some(keyword => line.toLowerCase().includes(keyword.toLowerCase()))) {
          if (!inFrontend && !inBackend) {
            currentSection = 'frontend';
            inFrontend = true;
            continue;
          }
        } else if (line.toLowerCase().includes('backend') || backendKeywords.some(keyword => line.toLowerCase().includes(keyword.toLowerCase()))) {
          if (!inBackend) {
            currentSection = 'backend';
            inBackend = true;
            inFrontend = false;
            continue;
          }
        }
        
        // Add content to current section
        if (currentSection === 'frontend' && inFrontend) {
          frontend += line + '\n';
        } else if (currentSection === 'backend' && inBackend) {
          backend += line + '\n';
        }
      }
      
      // If still no good content, try to extract code blocks
      if (!frontend || !backend) {
        console.log('Trying code block extraction');
        const codeBlocks = response.match(/```(?:javascript|typescript|jsx|tsx|python|py)?\s*([\s\S]*?)```/g);
        
        if (codeBlocks && codeBlocks.length >= 2) {
          frontend = codeBlocks[0].replace(/```(?:javascript|typescript|jsx|tsx)?\s*/, '').replace(/```$/, '').trim();
          backend = codeBlocks[1].replace(/```(?:python|py)?\s*/, '').replace(/```$/, '').trim();
        }
      }
    }

    // If parsing still failed, generate default structure
    if (!frontend || !backend) {
      console.log('Response parsing failed, generating default structure');
      frontend = generateDefaultFrontend(prompt);
      backend = generateDefaultBackend(prompt);
      projectStructure = generateDefaultStructure(prompt);
      setupInstructions = generateDefaultSetup(prompt);
      packageJson = generateDefaultPackageJson(prompt);
    } else {
      // Generate missing sections if we have at least frontend and backend
      if (!projectStructure) {
        projectStructure = generateDefaultStructure(prompt);
      }
      if (!setupInstructions) {
        setupInstructions = generateDefaultSetup(prompt);
      }
      if (!packageJson) {
        packageJson = generateDefaultPackageJson(prompt);
      }
    }

    return {
      frontend,
      backend,
      projectStructure,
      setupInstructions,
      packageJson
    };
  } catch (error) {
    console.error('Fullstack generation error:', error);
    
    // Handle timeout specifically
    if (error.message === 'Fullstack generation timeout') {
      return {
        frontend: generateDefaultFrontend(prompt),
        backend: generateDefaultBackend(prompt),
        projectStructure: generateDefaultStructure(prompt),
        setupInstructions: generateDefaultSetup(prompt),
        packageJson: generateDefaultPackageJson(prompt)
      };
    }
    
    throw new Error(`Failed to generate fullstack project: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

// Default generation functions in case AI parsing fails
function generateDefaultFrontend(prompt: string): string {
  return `import React, { useState } from 'react';

export default function App() {
  const [data, setData] = useState([]);

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">${prompt}</h1>
        <div className="bg-white rounded-lg shadow-md p-6">
          <p>Your application for "${prompt}" is ready!</p>
        </div>
      </div>
    </div>
  );
}`;
}

function generateDefaultBackend(prompt: string): string {
  return `from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional

app = FastAPI(title="${prompt} API")

class Item(BaseModel):
    id: Optional[int] = None
    name: str
    description: Optional[str] = None

items = []

@app.get("/")
async def root():
    return {"message": "Welcome to ${prompt} API"}

@app.get("/items", response_model=List[Item])
async def get_items():
    return items

@app.post("/items", response_model=Item)
async def create_item(item: Item):
    item.id = len(items) + 1
    items.append(item)
    return item

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)`;
}

function generateDefaultStructure(prompt: string): string {
  return `project-root/
├── src/
│   ├── components/
│   │   ├── Header.tsx
│   │   └── Footer.tsx
│   ├── pages/
│   │   ├── index.tsx
│   │   └── api/
│   │       └── items.ts
│   ├── App.tsx
│   └── index.tsx
├── server/
│   ├── main.py
│   ├── models.py
│   └── requirements.txt
├── public/
├── package.json
├── tailwind.config.js
└── README.md`;
}

function generateDefaultSetup(prompt: string): string {
  return `# Setup Instructions for ${prompt}

## Frontend Setup
1. Navigate to the project directory
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`
3. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`
4. Open http://localhost:3000 in your browser

## Backend Setup
1. Navigate to the server directory
2. Create a virtual environment:
   \`\`\`bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\\Scripts\\activate
   \`\`\`
3. Install dependencies:
   \`\`\`bash
   pip install fastapi uvicorn pydantic
   \`\`\`
4. Start the server:
   \`\`\`bash
   python main.py
   \`\`\`
5. The API will be available at http://localhost:8000

## Features
- Modern React frontend with TypeScript
- FastAPI backend with automatic API documentation
- Responsive design using Tailwind CSS
- RESTful API endpoints`;
}

function generateDefaultPackageJson(prompt: string): string {
  return `{
  "name": "${prompt.toLowerCase().replace(/\\s+/g, '-')}-app",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "react": "^18",
    "react-dom": "^18",
    "next": "14.0.0",
    "typescript": "^5.0.0",
    "@types/node": "^20.0.0",
    "@types/react": "^18.0.0",
    "@types/react-dom": "^18.0.0",
    "tailwindcss": "^3.3.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0"
  },
  "devDependencies": {
    "eslint": "^8.0.0",
    "eslint-config-next": "14.0.0"
  }
}`;
}

// Simplified fallback functions for when AI generation fails
function generateSimpleFrontend(prompt: string): string {
  return `import React, { useState, useEffect } from 'react';

export default function ${prompt.replace(/\\s+/g, '')}App() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setItems([
        { id: 1, title: 'Sample Item 1', description: 'This is a sample item' },
        { id: 2, title: 'Sample Item 2', description: 'Another sample item' }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">${prompt}</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map(item => (
            <div key={item.id} className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold mb-2">{item.title}</h2>
              <p className="text-gray-600">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}`;
}

function generateSimpleBackend(prompt: string): string {
  return `from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="${prompt} API")

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Item(BaseModel):
    id: Optional[int] = None
    title: str
    description: Optional[str] = None

# Sample data
items = [
    {"id": 1, "title": "Sample Item 1", "description": "This is a sample item"},
    {"id": 2, "title": "Sample Item 2", "description": "Another sample item"}
]

@app.get("/")
async def root():
    return {"message": "Welcome to ${prompt} API", "status": "running"}

@app.get("/api/items", response_model=List[Item])
async def get_items():
    return items

@app.get("/api/items/{item_id}", response_model=Item)
async def get_item(item_id: int):
    item = next((item for item in items if item.id == item_id), None)
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@app.post("/api/items", response_model=Item)
async def create_item(item: Item):
    item.id = len(items) + 1
    items.append(item)
    return item

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)`;
}

function generateSimpleStructure(prompt: string): string {
  return `${prompt.toLowerCase().replace(/\\s+/g, '-')}-app/
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Header.tsx
│   │   │   ├── ItemCard.tsx
│   │   │   └── LoadingSpinner.tsx
│   │   ├── pages/
│   │   │   ├── index.tsx
│   │   │   └── api/
│   │   │       └── items.ts
│   │   ├── App.tsx
│   │   └── index.tsx
│   ├── public/
│   ├── package.json
│   └── tailwind.config.js
├── backend/
│   ├── main.py
│   ├── models.py
│   └── requirements.txt
├── README.md
└── .gitignore`;
}

function generateSimpleSetup(prompt: string): string {
  return `# ${prompt} - Setup Instructions

## 🚀 Quick Start

This is a simple fullstack application for: **${prompt}**

## 📁 Project Structure
\`\`\`
${generateSimpleStructure(prompt)}
\`\`\`

## 🔧 Frontend Setup

1. Navigate to the frontend directory:
   \`\`\`bash
   cd frontend
   \`\`\`

2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

4. Open http://localhost:3000 in your browser

## 🔧 Backend Setup

1. Navigate to the backend directory:
   \`\`\`bash
   cd backend
   \`\`\`

2. Create a virtual environment:
   \`\`\`bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\\\\Scripts\\\\activate
   \`\`\`

3. Install dependencies:
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

4. Start the server:
   \`\`\`bash
   python main.py
   \`\`\`

5. The API will be available at http://localhost:8000
   - API documentation: http://localhost:8000/docs

## ✨ Features

- **Frontend**: React with TypeScript and Tailwind CSS
- **Backend**: FastAPI with automatic API documentation
- **CORS**: Enabled for cross-origin requests
- **Responsive Design**: Mobile-friendly interface
- **Sample Data**: Pre-loaded with example items

## 📡 API Endpoints

- \`GET /\` - Welcome message
- \`GET /api/items\` - Get all items
- \`GET /api/items/{id}\` - Get specific item
- \`POST /api/items\` - Create new item

## 🎯 Next Steps

1. Customize the components for your specific needs
2. Add database integration (SQLite, PostgreSQL, etc.)
3. Implement user authentication
4. Add more API endpoints as needed
5. Deploy to your preferred hosting platform

Happy coding! 🚀`;
}

function generateSimplePackageJson(prompt: string): string {
  return `{
  "name": "${prompt.toLowerCase().replace(/\\s+/g, '-')}-app",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "next": "14.0.0",
    "typescript": "^5.0.0",
    "@types/node": "^20.0.0",
    "@types/react": "^18.0.0",
    "@types/react-dom": "^18.0.0",
    "tailwindcss": "^3.3.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0",
    "axios": "^1.6.0"
  },
  "devDependencies": {
    "eslint": "^8.0.0",
    "eslint-config-next": "14.0.0"
  }
}`;
}

export async function POST(request: NextRequest) {
  try {
    const body: FullstackRequest = await request.json();
    const { prompt, model, files = [] } = body;

    if (!prompt || !model) {
      return NextResponse.json(
        { error: 'Prompt and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing fullstack generation request:', { prompt, model, filesCount: files.length });

    const project = await generateFullstackProject(prompt, model, files);

    const response: FullstackResponse = {
      success: true,
      project
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('Fullstack generation API error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error',
        suggestion: 'Please try again with a more specific project description or check if the AI service is available.'
      },
      { status: 500 }
    );
  }
}