import { NextRequest, NextResponse } from 'next/server';
import {
  generateImageHuggingFace,
  generateImageOpenAI,
  generateImageOpenRouter,
  generateImageMultiProvider,
  saveImageToFile,
  optimizeImage,
  ImageGenerationRequest,
  ImageGenerationResponse
} from '../../../lib/imageGenerators';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      prompt,
      model = 'auto',
      provider = 'auto',
      size = '1024x1024',
      quality = 'standard',
      style = 'vivid',
      negativePrompt,
      steps = 20,
      guidanceScale = 7.5,
      optimize = true,
      saveToFile = false
    } = body;

    // Validation
    if (!prompt?.trim()) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required and cannot be empty'
      }, { status: 400 });
    }

    if (prompt.length > 1000) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is too long (max 1000 characters)'
      }, { status: 400 });
    }

    console.log(`🎨 Image Generation Request:`);
    console.log(`📝 Prompt: ${prompt.substring(0, 100)}...`);
    console.log(`🎛️ Model: ${model}, Provider: ${provider}, Size: ${size}`);

    const imageRequest: ImageGenerationRequest = {
      prompt,
      model,
      size,
      quality,
      style,
      negativePrompt,
      steps,
      guidanceScale
    };

    let result: ImageGenerationResponse;

    // Route to specific provider or use auto-selection
    switch (provider.toLowerCase()) {
      case 'huggingface':
      case 'hf':
        result = await generateImageHuggingFace(imageRequest);
        break;
        
      case 'openai':
      case 'dalle':
        result = await generateImageOpenAI(imageRequest);
        break;
        
      case 'openrouter':
      case 'or':
        result = await generateImageOpenRouter(imageRequest);
        break;
        
      default:
        // Auto-select best provider
        result = await generateImageMultiProvider(imageRequest);
        break;
    }

    if (!result.success) {
      return NextResponse.json({
        success: false,
        error: result.error || 'Image generation failed',
        provider: result.provider,
        suggestion: 'Try a different model or provider, or simplify your prompt.'
      }, { status: 500 });
    }

    // Optimize image if requested
    if (optimize && result.imageData) {
      try {
        console.log('🔧 Optimizing image...');
        result.imageData = await optimizeImage(result.imageData, {
          width: 1024,
          height: 1024,
          quality: 85
        });
        console.log('✅ Image optimized');
      } catch (optimizeError) {
        console.warn('⚠️ Image optimization failed:', optimizeError);
      }
    }

    // Save to file if requested
    let imageUrl: string | undefined;
    if (saveToFile && result.imageData) {
      try {
        imageUrl = await saveImageToFile(result.imageData);
        result.imageUrl = imageUrl;
        console.log('💾 Image saved to file system');
      } catch (saveError) {
        console.warn('⚠️ Image save failed:', saveError);
      }
    }

    // Success response
    const response = {
      success: true,
      imageData: result.imageData,
      imageUrl: result.imageUrl,
      model: result.model,
      provider: result.provider,
      prompt: result.prompt,
      metadata: {
        ...result.metadata,
        generatedAt: new Date().toISOString(),
        processingTime: Date.now() - Date.now(), // You can track this properly
        size: size,
        optimized: optimize
      }
    };

    console.log(`✅ Image generation successful with ${result.provider}`);
    return NextResponse.json(response);

  } catch (error: any) {
    console.error('❌ Image Generation API Error:', error);
    return NextResponse.json({
      success: false,
      error: error.message || 'Internal server error',
      suggestion: 'Please check your API keys and try again. If the problem persists, try a different provider or model.'
    }, { status: 500 });
  }
}

// Health check for image generation service
export async function GET() {
  try {
    const healthStatus = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      providers: {
        huggingface: {
          available: !!process.env.HUGGINGFACE_API_KEY,
          models: ['Stable Diffusion', 'FLUX', 'SDXL', 'Dreamlike', 'Realistic Vision', 'Anime']
        },
        openai: {
          available: !!process.env.OPENAI_API_KEY,
          models: ['DALL-E 2', 'DALL-E 3']
        },
        openrouter: {
          available: !!process.env.OPENROUTER_API_KEY,
          models: ['Enhanced (Claude + HF)']
        }
      },
      supportedSizes: {
        huggingface: ['512x512', '768x768', '1024x1024'],
        openai: ['256x256', '512x512', '1024x1024', '1792x1024', '1024x1792'],
        openrouter: ['512x512', '768x768', '1024x1024']
      },
      features: {
        multiProvider: true,
        optimization: true,
        fileStorage: true,
        negativePrompts: true,
        styleControl: true
      }
    };

    return NextResponse.json({
      health: healthStatus,
      message: '🎨 Image Generation Service is ready!'
    });
  } catch (error: any) {
    return NextResponse.json({
      health: { status: 'error', error: error.message }
    }, { status: 500 });
  }
}