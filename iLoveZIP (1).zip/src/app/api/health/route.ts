import { NextRequest, NextResponse } from 'next/server';

interface HealthResponse {
  status: 'healthy' | 'unhealthy' | 'initializing';
  timestamp: string;
  services: {
    ai: 'available' | 'unavailable';
    image: 'available' | 'unavailable';
    fullstack: 'available' | 'unavailable';
  };
  message?: string;
}

export async function GET(request: NextRequest) {
  try {
    const healthResponse: HealthResponse = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        ai: 'available',
        image: 'available',
        fullstack: 'available'
      }
    };

    // Check if AI SDK is available
    try {
      const ZAI = await import('z-ai-web-dev-sdk');
      console.log('AI SDK is available');
      healthResponse.services.ai = 'available';
    } catch (error) {
      console.error('AI SDK not available:', error);
      healthResponse.services.ai = 'unavailable';
      healthResponse.status = 'unhealthy';
      healthResponse.message = 'AI SDK not available';
    }

    // Check if image generation is available
    try {
      const ZAI = await import('z-ai-web-dev-sdk');
      if (ZAI && (ZAI.create || ZAI.default)) {
        healthResponse.services.image = 'available';
      } else {
        healthResponse.services.image = 'unavailable';
      }
    } catch (error) {
      healthResponse.services.image = 'unavailable';
    }

    // Check if fullstack generation is available
    try {
      const ZAI = await import('z-ai-web-dev-sdk');
      if (ZAI && (ZAI.create || ZAI.default)) {
        healthResponse.services.fullstack = 'available';
      } else {
        healthResponse.services.fullstack = 'unavailable';
      }
    } catch (error) {
      healthResponse.services.fullstack = 'unavailable';
    }

    // If any critical service is unavailable, mark as unhealthy
    if (healthResponse.services.ai === 'unavailable') {
      healthResponse.status = 'unhealthy';
    }

    return NextResponse.json(healthResponse);
  } catch (error) {
    console.error('Health check error:', error);
    return NextResponse.json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      services: {
        ai: 'unavailable',
        image: 'unavailable',
        fullstack: 'unavailable'
      },
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}