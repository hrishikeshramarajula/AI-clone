import { NextRequest, NextResponse } from 'next/server';
import { generateImageHF } from '../../../lib/ai-providers/huggingface';

interface ImageRequest {
  prompt: string;
  model: string;
  size?: string;
}

interface ImageResponse {
  imageData: string;
  prompt: string;
  model: string;
  timestamp: string;
}

// Map user-friendly model names to HuggingFace model IDs
const modelMap: Record<string, string> = {
  '🇮🇳 Stable Diffusion (India)': 'stabilityai/stable-diffusion-2-1',
  '🇮🇳 OpenJourney (India)': 'prompthero/openjourney',
  '🇮🇳 DALL-E Mega (India)': 'openskyml/dalle-mega-1',
  '🇮🇳 Stable Diffusion XL (India)': 'stabilityai/stable-diffusion-xl-base-1.0',
  'Stable Diffusion': 'stabilityai/stable-diffusion-2-1',
  'OpenJourney': 'prompthero/openjourney',
  'DALL-E Mega': 'openskyml/dalle-mega-1',
  'Stable Diffusion XL': 'stabilityai/stable-diffusion-xl-base-1.0'
};

export async function POST(request: NextRequest) {
  try {
    const body: ImageRequest = await request.json();
    const { prompt, model, size = '1024x1024' } = body;

    if (!prompt || !model) {
      return NextResponse.json(
        { error: 'Prompt and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing image generation request:', { prompt, model, size });

    // Get the actual HuggingFace model name
    const huggingFaceModel = modelMap[model] || 'stabilityai/stable-diffusion-2-1';
    console.log('Using HuggingFace model:', huggingFaceModel);

    try {
      // Generate image using HuggingFace API
      const imageData = await generateImageHF(prompt, huggingFaceModel);
      
      console.log('Image generation successful');

      const imageResponse: ImageResponse = {
        imageData,
        prompt,
        model: huggingFaceModel,
        timestamp: new Date().toISOString()
      };

      return NextResponse.json({
        success: true,
        imageData: imageResponse.imageData,
        prompt: imageResponse.prompt,
        model: imageResponse.model,
        timestamp: imageResponse.timestamp
      });

    } catch (imageError) {
      console.error('Image generation failed:', imageError);
      
      // Try fallback models
      const fallbackModels = [
        'runwayml/stable-diffusion-v1-5',
        'prompthero/openjourney',
        'openskyml/dalle-mega-1'
      ];
      
      for (const fallbackModel of fallbackModels) {
        if (fallbackModel === huggingFaceModel) continue;
        
        try {
          console.log(`Trying fallback model: ${fallbackModel}`);
          const fallbackImageData = await generateImageHF(prompt, fallbackModel);
          
          return NextResponse.json({
            success: true,
            imageData: fallbackImageData,
            prompt,
            model: fallbackModel,
            timestamp: new Date().toISOString()
          });
        } catch (fallbackError) {
          console.warn(`Fallback model ${fallbackModel} failed:`, fallbackError.message);
          continue;
        }
      }
      
      // If all models fail, return helpful error message
      return NextResponse.json(
        { 
          success: false,
          error: 'Image generation temporarily unavailable',
          details: imageError instanceof Error ? imageError.message : 'Unknown error',
          prompt,
          suggestedModel: '🇮🇳 Stable Diffusion (India)',
          fallbackMessage: `I understand you wanted to generate an image of: "${prompt}"

Unfortunately, I'm experiencing technical difficulties with image generation services. This could be due to:

• **HuggingFace API issues** - Service may be temporarily unavailable
• **Model loading problems** - AI models might be initializing
• **Rate limiting** - Too many requests at once
• **API configuration** - Credentials might need verification

**What you can do:**
• **Try again in a few moments** - Services often restore quickly
• **Use a different, more specific prompt** - Simpler descriptions work better
• **Try different image models** - Some models may be more available than others
• **Check your internet connection** - Ensure stable connectivity

**Available Image Models:**
🇮🇳 **Stable Diffusion (India)** - Most reliable for general images
🇮🇳 **OpenJourney (India)** - Best for artistic and creative images  
🇮🇳 **DALL-E Mega (India)** - High quality detailed images
🇮🇳 **Stable Diffusion XL (India)** - Premium quality images

**Alternative suggestions:**
• I can help you create a detailed text description of what the image would look like
• I can suggest art styles and techniques for your concept
• I can help you write prompts for other image generation tools

The issue has been logged and our technical team is working to restore full image generation capabilities.`
        },
        { status: 200 }
      );
    }

  } catch (error) {
    console.error('Image generation error:', error);
    
    return NextResponse.json(
      { 
        success: false,
        error: 'Image generation service temporarily unavailable',
        details: error instanceof Error ? error.message : 'Unknown error',
        suggestion: `I apologize, but I'm experiencing technical difficulties with image generation. 

**Immediate solutions:**
• Try again in a few moments
• Use a simpler, more descriptive prompt
• Select a different image model from the available options

**Available Models:**
🇮🇳 Stable Diffusion (India) - Most reliable
🇮🇳 OpenJourney (India) - Artistic style
🇮🇳 DALL-E Mega (India) - High quality
🇮🇳 Stable Diffusion XL (India) - Premium quality

Our team is working to restore full service.`
      },
      { status: 200 }
    );
  }
}