import { HfInference } from '@huggingface/inference';
import OpenAI from 'openai';
import axios from 'axios';
import sharp from 'sharp';
import fs from 'fs-extra';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

// Initialize AI clients
const hf = new HfInference(process.env.HUGGINGFACE_API_KEY);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface ImageGenerationRequest {
  prompt: string;
  model?: string;
  size?: string;
  quality?: string;
  style?: string;
  negativePrompt?: string;
  steps?: number;
  guidanceScale?: number;
}

export interface ImageGenerationResponse {
  success: boolean;
  imageData?: string; // base64
  imageUrl?: string;
  model: string;
  provider: string;
  prompt: string;
  metadata?: any;
  error?: string;
}

// HuggingFace Text-to-Image Generator
export async function generateImageHuggingFace(
  request: ImageGenerationRequest
): Promise<ImageGenerationResponse> {
  console.log('🎨 HuggingFace Image Generation:', request.prompt.substring(0, 50) + '...');
  try {
    // Check if HuggingFace API key is available
    if (!process.env.HUGGINGFACE_API_KEY) {
      throw new Error('HuggingFace API key not configured');
    }

    // Model mappings for HuggingFace
    const modelMap: Record<string, string> = {
      'Stable Diffusion': 'stabilityai/stable-diffusion-2-1',
      'FLUX': 'black-forest-labs/FLUX.1-dev',
      'SDXL': 'stabilityai/stable-diffusion-xl-base-1.0',
      'Dreamlike': 'dreamlike-art/dreamlike-diffusion-1.0',
      'Realistic Vision': 'SG161222/Realistic_Vision_V5.1_noVAE',
      'Anime': 'gsdf/Counterfeit-V2.5',
      'default': 'stabilityai/stable-diffusion-2-1'
    };

    const selectedModel = modelMap[request.model || 'default'] || modelMap.default;
    console.log('🔧 Using HuggingFace model:', selectedModel);

    // Generate image
    const blob = await hf.textToImage({
      model: selectedModel,
      inputs: request.prompt,
      parameters: {
        negative_prompt: request.negativePrompt || 'blurry, bad quality, distorted, deformed',
        num_inference_steps: request.steps || 20,
        guidance_scale: request.guidanceScale || 7.5,
        width: parseInt(request.size?.split('x')[0] || '512'),
        height: parseInt(request.size?.split('x')[1] || '512')
      }
    });

    // Convert blob to base64
    const arrayBuffer = await blob.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64Image = buffer.toString('base64');

    console.log('✅ HuggingFace Success - Image generated');
    return {
      success: true,
      imageData: base64Image,
      model: request.model || 'Stable Diffusion',
      provider: 'HuggingFace',
      prompt: request.prompt,
      metadata: {
        modelUsed: selectedModel,
        size: request.size || '512x512',
        steps: request.steps || 20,
        guidanceScale: request.guidanceScale || 7.5
      }
    };
  } catch (error: any) {
    console.error('❌ HuggingFace Error:', error);
    
    // Handle specific HuggingFace errors
    if (error.message?.includes('Invalid credentials')) {
      return {
        success: false,
        error: 'HuggingFace API key is invalid or expired',
        model: request.model || 'Stable Diffusion',
        provider: 'HuggingFace',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('No Inference Provider available')) {
      return {
        success: false,
        error: 'HuggingFace inference provider not available. Please try again later.',
        model: request.model || 'Stable Diffusion',
        provider: 'HuggingFace',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('rate limit')) {
      return {
        success: false,
        error: 'HuggingFace rate limit exceeded. Please try again later.',
        model: request.model || 'Stable Diffusion',
        provider: 'HuggingFace',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('exceeded your monthly included credits')) {
      return {
        success: false,
        error: 'HuggingFace monthly credits exceeded. Please try OpenAI or try again next month.',
        model: request.model || 'Stable Diffusion',
        provider: 'HuggingFace',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('HTTP error occurred')) {
      return {
        success: false,
        error: 'HuggingFace service temporarily unavailable. Please try again later.',
        model: request.model || 'Stable Diffusion',
        provider: 'HuggingFace',
        prompt: request.prompt
      };
    }
    
    return {
      success: false,
      error: `HuggingFace generation failed: ${error.message}`,
      model: request.model || 'Stable Diffusion',
      provider: 'HuggingFace',
      prompt: request.prompt
    };
  }
}

// OpenAI DALL-E Generator  
export async function generateImageOpenAI(
  request: ImageGenerationRequest
): Promise<ImageGenerationResponse> {
  console.log('🎨 OpenAI DALL-E Generation:', request.prompt.substring(0, 50) + '...');
  try {
    // Check if OpenAI API key is available
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OpenAI API key not configured');
    }

    // Determine DALL-E model
    const dalleModel = request.model?.includes('DALL-E 3') ? 'dall-e-3' : 'dall-e-2';
    console.log('🔧 Using OpenAI model:', dalleModel);

    // Size validation for DALL-E
    let imageSize: "256x256" | "512x512" | "1024x1024" | "1792x1024" | "1024x1792" = "1024x1024";
    if (dalleModel === 'dall-e-3') {
      imageSize = ['1024x1024', '1792x1024', '1024x1792'].includes(request.size || '') 
        ? request.size as any 
        : "1024x1024";
    } else {
      imageSize = ['256x256', '512x512', '1024x1024'].includes(request.size || '') 
        ? request.size as any 
        : "1024x1024";
    }

    const response = await openai.images.generate({
      model: dalleModel,
      prompt: request.prompt,
      n: 1,
      size: imageSize,
      quality: dalleModel === 'dall-e-3' ? (request.quality as "standard" | "hd" || "standard") : undefined,
      style: dalleModel === 'dall-e-3' ? (request.style as "vivid" | "natural" || "vivid") : undefined,
      response_format: "b64_json"
    });

    const base64Image = response.data[0]?.b64_json;
    if (!base64Image) {
      throw new Error('No image data received from OpenAI');
    }

    console.log('✅ OpenAI Success - Image generated');
    return {
      success: true,
      imageData: base64Image,
      model: `DALL-E ${dalleModel === 'dall-e-3' ? '3' : '2'}`,
      provider: 'OpenAI',
      prompt: request.prompt,
      metadata: {
        modelUsed: dalleModel,
        size: imageSize,
        quality: request.quality || 'standard',
        style: request.style || 'vivid',
        revisedPrompt: response.data[0]?.revised_prompt
      }
    };
  } catch (error: any) {
    console.error('❌ OpenAI Error:', error);
    
    // Handle specific OpenAI errors
    if (error.message?.includes('Country, region, or territory not supported')) {
      return {
        success: false,
        error: 'OpenAI services are not available in your region',
        model: request.model || 'DALL-E 3',
        provider: 'OpenAI',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('API key')) {
      return {
        success: false,
        error: 'OpenAI API key configuration issue',
        model: request.model || 'DALL-E 3',
        provider: 'OpenAI',
        prompt: request.prompt
      };
    }
    
    if (error.message?.includes('rate limit')) {
      return {
        success: false,
        error: 'OpenAI rate limit exceeded. Please try again later.',
        model: request.model || 'DALL-E 3',
        provider: 'OpenAI',
        prompt: request.prompt
      };
    }
    
    return {
      success: false,
      error: `OpenAI generation failed: ${error.message}`,
      model: request.model || 'DALL-E 3',
      provider: 'OpenAI',
      prompt: request.prompt
    };
  }
}

// OpenRouter Image Generator (using Stable Diffusion models)
export async function generateImageOpenRouter(
  request: ImageGenerationRequest  
): Promise<ImageGenerationResponse> {
  console.log('🎨 OpenRouter Image Generation:', request.prompt.substring(0, 50) + '...');
  try {
    // Check if OpenRouter API key is available
    if (!process.env.OPENROUTER_API_KEY) {
      throw new Error('OpenRouter API key not configured');
    }

    // OpenRouter doesn't have direct image generation, so we'll use their text completion 
    // to generate a detailed prompt and then use HuggingFace as fallback
    const enhancedPrompt = await enhancePromptWithOpenRouter(request.prompt);
    
    // Try to use HuggingFace with the enhanced prompt
    const result = await generateImageHuggingFace({
      ...request,
      prompt: enhancedPrompt,
      model: 'FLUX'
    });

    return {
      ...result,
      provider: 'OpenRouter + HuggingFace',
      metadata: {
        ...result.metadata,
        originalPrompt: request.prompt,
        enhancedPrompt: enhancedPrompt
      }
    };
  } catch (error: any) {
    console.error('❌ OpenRouter Error:', error);
    return {
      success: false,
      error: `OpenRouter generation failed: ${error.message}`,
      model: request.model || 'Enhanced',
      provider: 'OpenRouter',
      prompt: request.prompt
    };
  }
}

// Enhance prompt using OpenRouter's text generation
async function enhancePromptWithOpenRouter(prompt: string): Promise<string> {
  try {
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: 'anthropic/claude-3-sonnet',
      messages: [
        {
          role: 'system',
          content: 'You are an expert prompt engineer for image generation. Take the user\'s simple prompt and expand it into a detailed, vivid description that will produce better AI-generated images. Keep it under 200 words and focus on visual details, lighting, style, and composition.'
        },
        {
          role: 'user',
          content: `Enhance this image prompt: "${prompt}"`
        }
      ],
      max_tokens: 300,
      temperature: 0.8
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
        'X-Title': 'Image Generator'
      }
    });

    const enhancedPrompt = response.data.choices[0]?.message?.content || prompt;
    console.log('🚀 Enhanced prompt:', enhancedPrompt.substring(0, 100) + '...');
    return enhancedPrompt;
  } catch (error) {
    console.warn('⚠️ Prompt enhancement failed, using original:', error);
    return prompt;
  }
}

// Multi-provider generator with fallback
export async function generateImageMultiProvider(
  request: ImageGenerationRequest
): Promise<ImageGenerationResponse> {
  console.log('🎯 Multi-provider image generation started');

  // Priority order: OpenAI -> HuggingFace -> OpenRouter
  const providers = [
    { name: 'OpenAI', generator: generateImageOpenAI },
    { name: 'HuggingFace', generator: generateImageHuggingFace },
    { name: 'OpenRouter', generator: generateImageOpenRouter }
  ];

  let lastError = '';
  
  for (const provider of providers) {
    try {
      console.log(`🔄 Trying ${provider.name}...`);
      const result = await provider.generator(request);
      
      if (result.success) {
        console.log(`✅ Success with ${provider.name}`);
        return result;
      } else {
        console.warn(`⚠️ ${provider.name} failed:`, result.error);
        lastError = result.error || lastError;
      }
    } catch (error: any) {
      console.error(`❌ ${provider.name} error:`, error.message);
      lastError = error.message;
    }
  }

  return {
    success: false,
    error: lastError || 'All image generation providers failed',
    model: request.model || 'Multi-provider',
    provider: 'Failed',
    prompt: request.prompt
  };
}

// Save image to filesystem (optional)
export async function saveImageToFile(
  base64Data: string, 
  filename?: string
): Promise<string> {
  try {
    const uploadsDir = path.join(process.cwd(), 'uploads', 'images');
    await fs.ensureDir(uploadsDir);
    
    const imageBuffer = Buffer.from(base64Data, 'base64');
    const fileName = filename || `generated-${uuidv4()}.png`;
    const filePath = path.join(uploadsDir, fileName);
    
    await fs.writeFile(filePath, imageBuffer);
    console.log('💾 Image saved to:', filePath);
    
    return `/uploads/images/${fileName}`;
  } catch (error: any) {
    console.error('❌ Save image error:', error);
    throw new Error(`Failed to save image: ${error.message}`);
  }
}

// Optimize image (resize, compress)
export async function optimizeImage(
  base64Data: string, 
  options: { width?: number; height?: number; quality?: number } = {}
): Promise<string> {
  try {
    const imageBuffer = Buffer.from(base64Data, 'base64');
    
    let pipeline = sharp(imageBuffer);
    
    if (options.width || options.height) {
      pipeline = pipeline.resize(options.width, options.height, {
        fit: 'inside',
        withoutEnlargement: true
      });
    }
    
    const optimizedBuffer = await pipeline
      .png({ quality: options.quality || 80 })
      .toBuffer();
    
    return optimizedBuffer.toString('base64');
  } catch (error: any) {
    console.error('❌ Image optimization error:', error);
    return base64Data; // Return original if optimization fails
  }
}