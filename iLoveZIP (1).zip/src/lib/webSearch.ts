import * as cheerio from 'cheerio';

// Real web search implementation
export interface SearchResult {
  url: string;
  title: string;
  snippet: string;
  content: string;
  source: string;
  relevanceScore: number;
}

export class WebSearchEngine {
  private searchEngines: SearchEngine[];

  constructor() {
    this.searchEngines = [
      new DuckDuckGoSearch(),
      new GoogleSearch(),
      new BingSearch()
    ];
  }

  async search(query: string, maxResults: number = 10): Promise<SearchResult[]> {
    const allResults: SearchResult[] = [];
    
    // Try multiple search engines in parallel
    const searchPromises = this.searchEngines.map(engine => 
      this.executeSearchWithFallback(engine, query, Math.ceil(maxResults / this.searchEngines.length))
    );

    const results = await Promise.allSettled(searchPromises);
    
    // Collect successful results
    results.forEach(result => {
      if (result.status === 'fulfilled' && Array.isArray(result.value)) {
        allResults.push(...result.value);
      }
    });

    // Remove duplicates and rank by relevance
    const uniqueResults = this.removeDuplicates(allResults);
    const rankedResults = this.rankResults(uniqueResults, query);
    
    return rankedResults.slice(0, maxResults);
  }

  private async executeSearchWithFallback(engine: SearchEngine, query: string, maxResults: number): Promise<SearchResult[]> {
    try {
      return await engine.search(query, maxResults);
    } catch (error) {
      console.error(`Search failed for ${engine.constructor.name}:`, error);
      return [];
    }
  }

  private removeDuplicates(results: SearchResult[]): SearchResult[] {
    const seen = new Set<string>();
    return results.filter(result => {
      const key = `${result.url}-${result.title}`;
      if (seen.has(key)) {
        return false;
      }
      seen.add(key);
      return true;
    });
  }

  private rankResults(results: SearchResult[], query: string): SearchResult[] {
    const queryLower = query.toLowerCase();
    
    return results.sort((a, b) => {
      const scoreA = this.calculateRelevanceScore(a, queryLower);
      const scoreB = this.calculateRelevanceScore(b, queryLower);
      return scoreB - scoreA;
    });
  }

  private calculateRelevanceScore(result: SearchResult, query: string): number {
    let score = 0;
    
    // Title relevance (highest weight)
    const titleLower = result.title.toLowerCase();
    if (titleLower.includes(query)) {
      score += 0.4;
    }
    
    // Content relevance
    const contentLower = result.content.toLowerCase();
    const queryWords = query.split(' ');
    queryWords.forEach(word => {
      if (contentLower.includes(word)) {
        score += 0.1;
      }
    });
    
    // Source quality bonus
    if (this.isHighQualitySource(result.url)) {
      score += 0.2;
    }
    
    return Math.min(score, 1.0);
  }

  private isHighQualitySource(url: string): boolean {
    const highQualityDomains = [
      'github.com', 'stackoverflow.com', 'wikipedia.org', 'arxiv.org',
      'pubmed.ncbi.nlm.nih.gov', 'scholar.google.com', 'nature.com', 'science.org',
      'medium.com', 'dev.to', 'hackernoon.com', 'towardsdatascience.com'
    ];
    
    try {
      const domain = new URL(url).hostname;
      return highQualityDomains.some(hqd => domain.includes(hqd)) ||
             domain.endsWith('.edu') || 
             domain.endsWith('.ac.uk') || 
             domain.endsWith('.gov');
    } catch {
      return false;
    }
  }
}

interface SearchEngine {
  search(query: string, maxResults: number): Promise<SearchResult[]>;
}

class DuckDuckGoSearch implements SearchEngine {
  async search(query: string, maxResults: number): Promise<SearchResult[]> {
    try {
      const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`;
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      if (!response.ok) {
        throw new Error(`DuckDuckGo API failed: ${response.status}`);
      }

      const text = await response.text();
      
      // Check if response is HTML instead of JSON
      if (text.trim().startsWith('<!DOCTYPE') || text.trim().startsWith('<html')) {
        throw new Error('DuckDuckGo returned HTML instead of JSON');
      }

      const data = JSON.parse(text);
      const results: SearchResult[] = [];

      // Process RelatedTopics
      if (data.RelatedTopics && Array.isArray(data.RelatedTopics)) {
        for (const topic of data.RelatedTopics.slice(0, maxResults)) {
          if (topic.FirstURL && topic.Text) {
            results.push({
              url: topic.FirstURL,
              title: topic.Text.split(' - ')[0],
              snippet: topic.Text,
              content: topic.Text,
              source: 'duckduckgo',
              relevanceScore: 0.5
            });
          }
        }
      }

      // Process Results
      if (data.Results && Array.isArray(data.Results)) {
        for (const result of data.Results.slice(0, maxResults)) {
          if (result.FirstURL && result.Text) {
            results.push({
              url: result.FirstURL,
              title: result.Text.split(' - ')[0],
              snippet: result.Text,
              content: result.Text,
              source: 'duckduckgo',
              relevanceScore: 0.6
            });
          }
        }
      }

      return results;
    } catch (error) {
      console.error('DuckDuckGo search failed:', error);
      throw error;
    }
  }
}

class GoogleSearch implements SearchEngine {
  async search(query: string, maxResults: number): Promise<SearchResult[]> {
    try {
      // Use a more reliable approach for Google search
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}&num=${maxResults}`;
      
      const response = await fetch(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate',
          'DNT': '1',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        }
      });

      if (!response.ok) {
        throw new Error(`Google search failed: ${response.status}`);
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      const results: SearchResult[] = [];
      
      // Extract search results from Google's SERP
      $('div.g').each((index, element) => {
        if (results.length >= maxResults) return;

        const $result = $(element);
        const titleElement = $result.find('h3');
        const linkElement = $result.find('a');
        const snippetElement = $result.find('div[style="-webkit-line-clamp:2"]');

        if (titleElement.length && linkElement.length) {
          const title = titleElement.text();
          const url = linkElement.attr('href') || '';
          const snippet = snippetElement.text() || $result.find('span').text();

          if (title && url && url.startsWith('http')) {
            results.push({
              url,
              title,
              snippet,
              content: snippet,
              source: 'google',
              relevanceScore: 0.7
            });
          }
        }
      });

      return results;
    } catch (error) {
      console.error('Google search failed:', error);
      throw error;
    }
  }
}

class BingSearch implements SearchEngine {
  async search(query: string, maxResults: number): Promise<SearchResult[]> {
    try {
      const searchUrl = `https://www.bing.com/search?q=${encodeURIComponent(query)}&count=${maxResults}`;
      
      const response = await fetch(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate',
          'DNT': '1',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1'
        }
      });

      if (!response.ok) {
        throw new Error(`Bing search failed: ${response.status}`);
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      const results: SearchResult[] = [];
      
      // Extract search results from Bing's SERP
      $('li.b_algo').each((index, element) => {
        if (results.length >= maxResults) return;

        const $result = $(element);
        const titleElement = $result.find('h2');
        const linkElement = $result.find('a');
        const snippetElement = $result.find('div.b_caption p');

        if (titleElement.length && linkElement.length) {
          const title = titleElement.text();
          const url = linkElement.attr('href') || '';
          const snippet = snippetElement.text();

          if (title && url && url.startsWith('http')) {
            results.push({
              url,
              title,
              snippet,
              content: snippet,
              source: 'bing',
              relevanceScore: 0.6
            });
          }
        }
      });

      return results;
    } catch (error) {
      console.error('Bing search failed:', error);
      throw error;
    }
  }
}

// Content scraper for getting full page content
export class ContentScraper {
  async scrapeContent(url: string): Promise<string> {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        },
        timeout: 10000
      });

      if (!response.ok) {
        return '';
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      // Remove unwanted elements
      $('script, style, nav, footer, header, aside, form, .ads, .advertisement, .sidebar, .comments').remove();

      // Extract main content
      let content = '';
      
      // Try to find main content area
      const mainContent = $('main, article, .content, .post, .article-content').first();
      if (mainContent.length) {
        content = mainContent.text();
      } else {
        // Fallback to body content
        content = $('body').text();
      }

      // Clean up the content
      content = content
        .replace(/\s+/g, ' ')
        .replace(/\n\s*\n/g, '\n\n')
        .trim();

      return content;
    } catch (error) {
      console.error(`Failed to scrape content from ${url}:`, error);
      return '';
    }
  }
}

// Export singleton instance
export const webSearchEngine = new WebSearchEngine();
export const contentScraper = new ContentScraper();