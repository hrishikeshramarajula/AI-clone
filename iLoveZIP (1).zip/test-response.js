const fetch = require('node-fetch');

async function testDeepResearch() {
  try {
    console.log('🧪 Testing Deep Research System...');
    
    const response = await fetch('http://localhost:3000/api/deep-search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query: 'how can we design our own AI agent'
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    
    console.log('✅ Test completed successfully!');
    console.log('Response:', {
      success: data.success,
      confidence: data.confidence,
      sources: data.sources?.length || 0,
      processingTime: data.processingTime,
      answerLength: data.answer?.length || 0
    });
    
    console.log('\n--- RESPONSE PREVIEW ---');
    console.log(data.answer?.substring(0, 1000) + '...');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
  }
}

testDeepResearch();