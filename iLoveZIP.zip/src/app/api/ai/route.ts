import { NextRequest, NextResponse } from 'next/server';
import { enhancedAIProvider } from '@/lib/enhancedAIProvider';

interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'code' | 'search' | 'analysis' | 'fullstack';
}

interface AIRequest {
  message: string;
  model: string;
  searchType: 'chat' | 'search' | 'code' | 'analysis' | 'image' | 'fullstack';
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

const models: AIModel[] = [
  { 
    id: 'gpt-4', 
    name: 'GPT-4', 
    provider: 'OpenAI', 
    description: 'Most capable model', 
    apiModel: 'gpt-4',
    intelligence: 'High',
    contextLength: '128K',
    inputCredits: '10K',
    outputCredits: '30K',
    specialty: 'chat'
  },
  { 
    id: 'glm-4.5', 
    name: 'GLM-4.5', 
    provider: 'Zhipu AI', 
    description: 'Latest Chinese AI model', 
    apiModel: 'glm-4.5',
    intelligence: 'Very High',
    contextLength: '200K',
    inputCredits: '8K',
    outputCredits: '25K',
    specialty: 'search'
  },
  { 
    id: 'gpt-3.5-turbo', 
    name: 'GPT-3.5 Turbo', 
    provider: 'OpenAI', 
    description: 'Fast and efficient', 
    apiModel: 'gpt-3.5-turbo',
    intelligence: 'Medium',
    contextLength: '16K',
    inputCredits: '5K',
    outputCredits: '15K',
    specialty: 'chat'
  },
  { 
    id: 'claude-3-opus', 
    name: 'Claude 3 Opus', 
    provider: 'Anthropic', 
    description: 'Advanced reasoning', 
    apiModel: 'claude-3-opus',
    intelligence: 'Very High',
    contextLength: '200K',
    inputCredits: '15K',
    outputCredits: '75K',
    specialty: 'analysis'
  },
  { 
    id: 'claude-3-sonnet', 
    name: 'Claude 3 Sonnet', 
    provider: 'Anthropic', 
    description: 'Balanced performance', 
    apiModel: 'claude-3-sonnet',
    intelligence: 'High',
    contextLength: '200K',
    inputCredits: '3K',
    outputCredits: '15K',
    specialty: 'analysis'
  },
  { 
    id: 'gemini-pro', 
    name: 'Gemini Pro', 
    provider: 'Google', 
    description: 'Multimodal capabilities', 
    apiModel: 'gemini-pro',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'search'
  },
  { 
    id: 'llama-3-70b', 
    name: 'Llama 3 70B', 
    provider: 'Meta', 
    description: 'Open source powerhouse', 
    apiModel: 'llama-3-70b',
    intelligence: 'High',
    contextLength: '8K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'code'
  },
  { 
    id: 'mixtral-8x7b', 
    name: 'Mixtral 8x7B', 
    provider: 'Mistral', 
    description: 'Mixture of experts', 
    apiModel: 'mixtral-8x7b',
    intelligence: 'High',
    contextLength: '32K',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'code'
  },
  { 
    id: 'command-r-plus', 
    name: 'Command R+', 
    provider: 'Cohere', 
    description: 'Enterprise grade', 
    apiModel: 'command-r-plus',
    intelligence: 'High',
    contextLength: '128K',
    inputCredits: '5K',
    outputCredits: '15K',
    specialty: 'search'
  },
  { 
    id: 'stable-diffusion', 
    name: 'Stable Diffusion', 
    provider: 'Hugging Face', 
    description: 'Image generation model', 
    apiModel: 'stabilityai/stable-diffusion-2-1',
    intelligence: 'Very High',
    contextLength: 'N/A',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'image'
  },
  { 
    id: 'midjourney', 
    name: 'MidJourney', 
    provider: 'Hugging Face', 
    description: 'Artistic image generation', 
    apiModel: 'prompthero/openjourney',
    intelligence: 'Very High',
    contextLength: 'N/A',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'image'
  },
  { 
    id: 'dalle', 
    name: 'DALL-E', 
    provider: 'Hugging Face', 
    description: 'OpenAI image generation', 
    apiModel: 'openai/dall-e-2',
    intelligence: 'Very High',
    contextLength: 'N/A',
    inputCredits: 'Free',
    outputCredits: 'Free',
    specialty: 'image'
  },
  { 
    id: 'gpt-4-turbo', 
    name: 'GPT-4 Turbo', 
    provider: 'OpenAI', 
    description: 'Optimized for full-stack development', 
    apiModel: 'gpt-4-turbo',
    intelligence: 'Very High',
    contextLength: '128K',
    inputCredits: '10K',
    outputCredits: '30K',
    specialty: 'fullstack'
  },
  { 
    id: 'z-ai-fullstack', 
    name: 'Z-AI Full Stack', 
    provider: 'Zhipu AI', 
    description: 'Integrated full-stack development assistant', 
    apiModel: 'glm-4.5',
    intelligence: 'Very High',
    contextLength: '200K',
    inputCredits: '8K',
    outputCredits: '25K',
    specialty: 'fullstack'
  }
];

export async function POST(request: NextRequest) {
  try {
    const body: AIRequest = await request.json();
    const { message, model, searchType } = body;

    if (!message || !model) {
      return NextResponse.json(
        { error: 'Message and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing request:', { message, model, searchType });

    // Check if model is available
    if (!enhancedAIProvider.isModelAvailable(model)) {
      return NextResponse.json(
        { error: `Model ${model} is not available` },
        { status: 400 }
      );
    }

    // Find the model configuration
    const modelConfig = models.find(m => m.name === model);
    if (!modelConfig) {
      return NextResponse.json(
        { error: `Model ${model} not found` },
        { status: 400 }
      );
    }

    let response: string;
    let searchResults: SearchResult[] = [];
    let imageData: string | undefined;
    let imagePrompt: string | undefined;

    // Handle different search types using the specialized methods
    switch (searchType) {
      case 'search':
        console.log('Performing web search for:', message);
        try {
          // Perform web search first
          searchResults = await enhancedAIProvider.performWebSearch(message);
          console.log('Search results found:', searchResults.length);
          
          // Then use AI to analyze and summarize the search results
          if (searchResults.length > 0) {
            const searchContext = searchResults.map((result: SearchResult) => 
              `${result.name}: ${result.snippet}`
            ).join('\n\n');
            
            response = await enhancedAIProvider.callAI(model, [
              {
                role: 'system',
                content: 'You are a helpful AI assistant with web search capabilities. When providing answers, prioritize information from search results and cite your sources.'
              },
              {
                role: 'user',
                content: `Based on the following search results, please provide a comprehensive answer to the query: "${message}"\n\nSearch Results:\n${searchContext}`
              }
            ]);
          } else {
            // If no search results, fall back to regular chat with search-focused prompt
            response = await enhancedAIProvider.callAI(model, [
              {
                role: 'system',
                content: 'You are a helpful AI assistant with web search capabilities. Provide comprehensive answers and include current information where possible.'
              },
              {
                role: 'user',
                content: `Please provide a comprehensive answer to: "${message}". Include current information and web sources where possible.`
              }
            ]);
          }
        } catch (error) {
          console.error('Web search error, falling back to regular chat:', error);
          response = await enhancedAIProvider.callAI(model, [
            {
              role: 'system',
              content: 'You are a helpful AI assistant. Provide accurate, helpful, and comprehensive responses.'
            },
            {
              role: 'user',
              content: message
            }
          ]);
        }
        break;
        
      case 'code':
        console.log('Generating code for:', message);
        response = await enhancedAIProvider.generateCode(message, model);
        break;
        
      case 'analysis':
        console.log('Performing analysis for:', message);
        response = await enhancedAIProvider.performAnalysis(message, model);
        break;
        
      case 'image':
        console.log('Generating image for:', message);
        try {
          imageData = await enhancedAIProvider.generateImage(message, model);
          response = `I've generated an image using ${model} based on your prompt: "${message}". The image has been created and is ready for use.`;
          imagePrompt = message;
        } catch (imageError) {
          console.error('Image generation error:', imageError);
          response = `Sorry, I encountered an error while generating the image with ${model}. Please try again with a different prompt or model.`;
        }
        break;
        
      case 'fullstack':
        console.log('Processing full-stack development request:', message);
        response = await enhancedAIProvider.fullStackDevelopment(message, model);
        break;
        
      default: // chat
        console.log('Processing chat message:', message);
        response = await enhancedAIProvider.callAI(model, [
          {
            role: 'system',
            content: 'You are a helpful AI assistant. Provide accurate, helpful, and comprehensive responses.'
          },
          {
            role: 'user',
            content: message
          }
        ]);
    }

    console.log('AI response generated successfully');

    const responseData: any = {
      response,
      model,
      timestamp: new Date().toISOString(),
    };

    // Add optional fields if they exist
    if (searchResults.length > 0) {
      responseData.searchResults = searchResults;
    }
    if (imageData) {
      responseData.imageData = imageData;
    }
    if (imagePrompt) {
      responseData.imagePrompt = imagePrompt;
    }

    return NextResponse.json(responseData);

  } catch (error) {
    console.error('AI API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Return available models with health status
    const healthStatus = enhancedAIProvider.getHealthStatus();
    const availableModels = enhancedAIProvider.getAvailableModels();
    
    return NextResponse.json({ 
      models: models.filter(model => availableModels.includes(model.name)),
      health: healthStatus,
      availableModels
    });
  } catch (error) {
    console.error('Error getting models:', error);
    return NextResponse.json(
      { error: 'Failed to get models', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}