import { NextRequest } from 'next/server';
import { performWebSearch } from '@/lib/search';
import { AIMessage, AIResponse } from '@/types/ai';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';
import { 
  createSuccessResponse, 
  createErrorResponse, 
  withErrorHandling,
  validateRequiredFields 
} from '@/lib/apiUtils';

async function callZAI(messages: AIMessage[], model: string, searchType: string) {
  try {
    console.log('🤖 Calling ZAI with safeZAIChatCompletion...');
    
    const completion = await safeZAIChatCompletion(messages, {
      temperature: 0.7,
      max_tokens: 2000
    });
    
    console.log('✅ ZAI chat completion successful');
    
    // Extract response content
    if (completion && completion.choices && Array.isArray(completion.choices)) {
      return completion.choices[0]?.message?.content || 'No response generated';
    }
    
    throw new Error('Invalid response format from ZAI SDK');
    
  } catch (error) {
    console.error('ZAI SDK Error:', error);
    throw error;
  }
}

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    const body = await request.json();
    
    // Validate required fields
    const validation = validateRequiredFields(body, ['message']);
    if (!validation.valid) {
      return createErrorResponse(validation.error!, 400);
    }

    const { message, model, searchType = 'chat' } = body;
    
    console.log(`Processing request: ${message} with model: ${model} and type: ${searchType}`);

    let response = '';
    let searchResults: any[] = [];
    let imageData: string | undefined;
    let imagePrompt: string | undefined;
    let usedProvider = '';

    // Handle different search types
    switch (searchType) {
      case 'search':
        // Perform web search first
        try {
          searchResults = await performWebSearch(message);
          console.log(`Web search completed with ${searchResults.length} results`);
        } catch (searchError) {
          console.warn('Web search failed, continuing without search results:', searchError);
          searchResults = [];
        }
        
        const searchContext = searchResults.map(result => 
          `Source: ${result.name}\nContent: ${result.snippet}`
        ).join('\n\n');

        const searchMessages: AIMessage[] = [
          {
            role: 'system',
            content: `You are an AI assistant that provides accurate, comprehensive answers based on search results and your knowledge. Use the search results to enhance your response.\n\nSearch Results:\n${searchContext}`
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          response = await callZAI(searchMessages, model, searchType);
          usedProvider = 'ZAI SDK';
        } catch (providerError) {
          console.warn('ZAI SDK failed for search, providing fallback response');
          response = `I apologize, but I'm currently experiencing technical difficulties with AI services. However, I can provide some general information about: "${message}"

This could be due to:
• AI service connectivity issues
• High demand on AI services  
• Temporary service maintenance

Please try again in a few moments. The issue has been logged and our technical team is working on it.

In the meantime, you might want to:
• Try a more specific question
• Break down your request into smaller parts
• Try selecting a different AI model from the dropdown

**ZAI SDK is available but experiencing temporary issues**`;
          usedProvider = 'fallback';
        }
        break;

      case 'image':
        imagePrompt = message;
        
        try {
          // For image generation, we'll provide a helpful response since we need to set up image models
          response = `I understand you want to generate an image of: "${message}"

Currently, I'm focused on text-based AI generation using the ZAI SDK. For image generation, you would need:

• **HuggingFace API setup** for models like Stable Diffusion
• **OpenAI DALL-E integration** for high-quality images
• **Proper API keys and configuration**

**What I can do instead:**
• Provide detailed descriptions of what the image would look like
• Generate text-based art concepts and ideas
• Help you write prompts for other image generation tools
• Suggest art styles and techniques for your concept

Would you like me to help you with any of these alternatives, or would you prefer to set up proper image generation services?`;
          usedProvider = 'ZAI SDK (Text-only)';
        } catch (imageError) {
          console.error('Image generation failed:', imageError);
          response = `I apologize, but I encountered an issue with image generation. 

**Available options:**
• Try text-based AI generation instead
• I can help describe what the image would look like
• Provide art concepts and ideas for your prompt

**To enable image generation:**
• Configure HuggingFace API keys
• Set up OpenAI DALL-E integration
• Install proper image generation models

Would you like me to help you with text-based alternatives?`;
          usedProvider = 'error';
        }
        break;

      case 'code':
        const codeMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are an expert software developer and coding assistant. Provide clear, well-commented, production-ready code solutions with explanations and best practices.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          response = await callZAI(codeMessages, model, searchType);
          usedProvider = 'ZAI SDK';
        } catch (providerError) {
          console.warn('ZAI SDK failed for code, providing fallback response');
          response = `I apologize, but I'm experiencing technical difficulties with code generation. However, I can offer some guidance for: "${message}"

**For better code generation results, consider:**
• Being more specific about the programming language
• Including specific requirements or constraints
• Breaking down complex requests into smaller parts
• Providing context about your project structure

**Please try again shortly. The ZAI SDK is being initialized.**`;
          usedProvider = 'fallback';
        }
        break;

      case 'analysis':
        const analysisMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are an expert data analyst and researcher. Provide thorough, evidence-based analysis with clear insights, trends, and actionable recommendations.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          response = await callZAI(analysisMessages, model, searchType);
          usedProvider = 'ZAI SDK';
        } catch (providerError) {
          console.warn('ZAI SDK failed for analysis, providing fallback response');
          response = `I apologize, but I'm experiencing technical difficulties with analysis services. However, I can offer some insights on: "${message}"

**For better analysis results, consider:**
• Providing more specific data or context
• Specifying the type of analysis you need
• Including relevant metrics or parameters
• Being clear about your analysis goals

**Please try again in a few moments.**`;
          usedProvider = 'fallback';
        }
        break;

      default: // 'chat'
        const chatMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are a helpful, knowledgeable, and friendly AI assistant. Provide accurate, detailed, and useful responses while maintaining a conversational tone.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          response = await callZAI(chatMessages, model, searchType);
          usedProvider = 'ZAI SDK';
        } catch (providerError) {
          console.warn('ZAI SDK failed for chat, providing fallback response');
          response = `I apologize, but I'm experiencing technical difficulties with AI chat services. However, I'm still here to help you with: "${message}"

**This could be due to:**
• Temporary AI service connectivity issues
• High demand on AI services
• Service initialization

**Please try again in a few moments.**`;
          usedProvider = 'fallback';
        }
        break;
    }

    const aiResponse: AIResponse = {
      success: true,
      response: response + (usedProvider !== 'fallback' ? `\n\n*Powered by ${usedProvider}*` : ''),
      searchResults: searchResults.length > 0 ? searchResults : undefined,
      imageData,
      imagePrompt,
      model: `${model} (${usedProvider})`
    };

    return createSuccessResponse(aiResponse.response, aiResponse);
  });
}