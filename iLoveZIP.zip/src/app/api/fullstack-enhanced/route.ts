import { NextRequest, NextResponse } from 'next/server';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';

interface EnhancedFullStackRequest {
  prompt: string;
  model?: string;
  previewMode?: boolean;
  preferences?: {
    frontend?: string;
    backend?: string;
    database?: string;
    styling?: string;
    features?: string[];
  };
}

interface GeneratedFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'database' | 'config' | 'style';
  language: string;
}

interface LivePreview {
  html: string;
  css: string;
  javascript: string;
  componentPreview: string;
}

interface EnhancedFullStackResponse {
  success: boolean;
  project: {
    id: string;
    name: string;
    description: string;
    analysis: {
      requirements: string[];
      architecture: string;
      techStack: string[];
    };
    files: GeneratedFile[];
    livePreview?: LivePreview;
    setup: {
      installation: string;
      running: string;
    };
    estimatedTime: string;
  };
  message: string;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as EnhancedFullStackRequest;
    const { 
      prompt, 
      model = '🇮🇳 GLM-4.5 (India)', 
      previewMode = true,
      preferences = {} 
    } = body;

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'Project description is required' },
        { status: 400 }
      );
    }

    console.log(`🚀 Starting enhanced full-stack generation for: "${prompt}"`);
    console.log(`📊 Preview mode: ${previewMode}`);

    // Analyze the prompt and generate complete project
    const enhancedProject = await generateEnhancedProject(prompt, preferences, previewMode);

    console.log('✅ Enhanced full-stack project generated successfully!');

    return NextResponse.json({
      success: true,
      project: enhancedProject,
      message: `🎉 Enhanced full-stack project "${enhancedProject.name}" generated successfully! ${previewMode ? 'Live preview ready!' : ''}`
    } as EnhancedFullStackResponse);

  } catch (error: any) {
    console.error('Enhanced full-stack generation error:', error);
    
    return NextResponse.json({
      success: false,
      error: error.message || 'Failed to generate enhanced full-stack project',
      message: `I apologize, but I encountered an issue while generating your enhanced full-stack project. 

This could be due to:
• Temporary AI service unavailability
• Complex project requirements
• High demand on AI services

**Immediate Solutions:**
• Try again in a few moments
• Break down your project into smaller components
• Try a simpler project description first

**Alternative Approach:**
I can still help you generate individual components with live previews if you prefer to build the project incrementally.`
    }, { status: 500 });
  }
}

async function generateEnhancedProject(prompt: string, preferences: any, previewMode: boolean) {
  const projectName = extractProjectName(prompt);
  
  // Step 1: Analyze requirements and architecture
  const analysis = await analyzeRequirements(prompt, preferences);
  
  // Step 2: Generate project structure and files
  const files = await generateProjectFiles(projectName, analysis, preferences);
  
  // Step 3: Generate live preview if enabled
  let livePreview: LivePreview | undefined;
  if (previewMode) {
    livePreview = await generateLivePreview(projectName, analysis, files);
  }
  
  return {
    id: `enhanced_${Date.now()}`,
    name: projectName,
    description: `Enhanced ${analysis.architecture} application with live preview`,
    analysis,
    files,
    livePreview,
    setup: {
      installation: generateSetupInstructions(projectName, analysis),
      running: generateRunningInstructions(projectName, analysis)
    },
    estimatedTime: 'Generated instantly with AI'
  };
}

async function analyzeRequirements(prompt: string, preferences: any) {
  const analysisPrompt = `
You are an expert full-stack architect. Analyze the following project requirements and provide a comprehensive analysis:

**Project Requirements:** ${prompt}

**User Preferences:** ${JSON.stringify(preferences, null, 2)}

Provide a detailed analysis including:
1. **Requirements**: Break down into specific functional and non-functional requirements
2. **Architecture**: Recommended architectural pattern (e.g., MVC, Microservices, SPA, etc.)
3. **Tech Stack**: Recommended technologies for frontend, backend, database, and styling
4. **Components**: Key components and their relationships
5. **Features**: Core features to implement

Respond with a JSON structure containing this analysis.`;

  try {
    const response = await safeZAIChatCompletion([
      { role: 'system', content: 'You are an expert full-stack architect. Provide detailed, actionable analysis for project development.' },
      { role: 'user', content: analysisPrompt }
    ], { temperature: 0.3, max_tokens: 2000 });

    const aiContent = response.choices[0]?.message?.content || '';
    
    // Parse the AI response and extract analysis
    return parseAnalysisResponse(aiContent, preferences);
    
  } catch (error) {
    console.error('AI analysis failed:', error);
    return getFallbackAnalysis(prompt, preferences);
  }
}

function parseAnalysisResponse(aiContent: string, preferences: any) {
  // Try to extract JSON from AI response
  let analysis;
  try {
    analysis = JSON.parse(aiContent);
  } catch {
    // If JSON parsing fails, extract from text
    analysis = extractAnalysisFromText(aiContent);
  }

  return {
    requirements: analysis.requirements || [
      'User authentication and authorization',
      'Responsive user interface',
      'Data persistence',
      'Real-time updates'
    ],
    architecture: analysis.architecture || 'Modern SPA with API backend',
    techStack: analysis.techStack || [
      preferences.frontend || 'Next.js with React and TypeScript',
      preferences.backend || 'Node.js with Express',
      preferences.database || 'SQLite with Prisma',
      preferences.styling || 'Tailwind CSS'
    ],
    components: analysis.components || [
      'Authentication components',
      'Dashboard interface',
      'Data management forms',
      'API endpoints'
    ]
  };
}

function extractAnalysisFromText(content: string) {
  // Extract key information from text response
  const requirements = extractSection(content, 'Requirements') || ['Basic CRUD operations', 'User interface'];
  const architecture = extractSection(content, 'Architecture')?.[0] || 'Single Page Application';
  const techStack = extractSection(content, 'Tech Stack') || ['React', 'Node.js', 'Database'];
  
  return { requirements, architecture, techStack };
}

function extractSection(content: string, sectionName: string): string[] | null {
  const regex = new RegExp(`\\*\\*${sectionName}\\*\\*[:\\s]*([\\s\\S]*?)(?=\\n\\n\\*\\*|$)`, 'i');
  const match = content.match(regex);
  if (match) {
    return match[1].split('\n').filter(line => line.trim()).map(line => line.replace(/^[-*•]\s*/, '').trim());
  }
  return null;
}

function getFallbackAnalysis(prompt: string, preferences: any) {
  return {
    requirements: [
      'User-friendly interface',
      'Data management capabilities',
      'Responsive design',
      'Basic authentication'
    ],
    architecture: 'Modern web application',
    techStack: [
      preferences.frontend || 'Next.js with React',
      preferences.backend || 'Node.js with Express',
      preferences.database || 'SQLite',
      preferences.styling || 'Tailwind CSS'
    ],
    components: [
      'User interface components',
      'API endpoints',
      'Database models',
      'Authentication system'
    ]
  };
}

async function generateProjectFiles(projectName: string, analysis: any, preferences: any): Promise<GeneratedFile[]> {
  const files: GeneratedFile[] = [];
  
  // Generate frontend files
  files.push(...await generateFrontendFiles(projectName, analysis, preferences));
  
  // Generate backend files
  files.push(...await generateBackendFiles(projectName, analysis, preferences));
  
  // Generate database files
  files.push(...await generateDatabaseFiles(projectName, analysis, preferences));
  
  // Generate configuration files
  files.push(...await generateConfigFiles(projectName, analysis, preferences));
  
  return files;
}

async function generateFrontendFiles(projectName: string, analysis: any, preferences: any): Promise<GeneratedFile[]> {
  const files: GeneratedFile[] = [];
  
  // Main page component
  const mainPageContent = generateMainPageComponent(projectName, analysis);
  files.push({
    path: `src/app/page.tsx`,
    content: mainPageContent,
    type: 'frontend',
    language: 'typescript'
  });
  
  // Layout component
  const layoutContent = generateLayoutComponent(projectName);
  files.push({
    path: `src/app/layout.tsx`,
    content: layoutContent,
    type: 'frontend',
    language: 'typescript'
  });
  
  // Key UI components based on analysis
  const components = generateUIComponents(projectName, analysis);
  components.forEach(comp => {
    files.push({
      path: `src/components/${comp.name}.tsx`,
      content: comp.content,
      type: 'frontend',
      language: 'typescript'
    });
  });
  
  // Styles
  const stylesContent = generateStyles(projectName, analysis);
  files.push({
    path: `src/app/globals.css`,
    content: stylesContent,
    type: 'style',
    language: 'css'
  });
  
  return files;
}

async function generateBackendFiles(projectName: string, analysis: any, preferences: any): Promise<GeneratedFile[]> {
  const files: GeneratedFile[] = [];
  
  // API routes
  const apiRoutes = generateAPIRoutes(projectName, analysis);
  apiRoutes.forEach(route => {
    files.push({
      path: `src/app/api/${route.path}/route.ts`,
      content: route.content,
      type: 'backend',
      language: 'typescript'
    });
  });
  
  // Database client
  const dbClient = generateDatabaseClient(projectName);
  files.push({
    path: `src/lib/db.ts`,
    content: dbClient,
    type: 'backend',
    language: 'typescript'
  });
  
  // Utility functions
  const utils = generateUtils(projectName, analysis);
  files.push({
    path: `src/lib/utils.ts`,
    content: utils,
    type: 'backend',
    language: 'typescript'
  });
  
  return files;
}

async function generateDatabaseFiles(projectName: string, analysis: any, preferences: any): Promise<GeneratedFile[]> {
  const files: GeneratedFile[] = [];
  
  // Prisma schema
  const prismaSchema = generatePrismaSchema(projectName, analysis);
  files.push({
    path: `prisma/schema.prisma`,
    content: prismaSchema,
    type: 'database',
    language: 'prisma'
  });
  
  return files;
}

async function generateConfigFiles(projectName: string, analysis: any, preferences: any): Promise<GeneratedFile[]> {
  const files: GeneratedFile[] = [];
  
  // Package.json
  const packageJson = generatePackageJson(projectName, analysis);
  files.push({
    path: `package.json`,
    content: packageJson,
    type: 'config',
    language: 'json'
  });
  
  // Tailwind config
  const tailwindConfig = generateTailwindConfig();
  files.push({
    path: `tailwind.config.ts`,
    content: tailwindConfig,
    type: 'config',
    language: 'typescript'
  });
  
  // TypeScript config
  const tsConfig = generateTSConfig();
  files.push({
    path: `tsconfig.json`,
    content: tsConfig,
    type: 'config',
    language: 'json'
  });
  
  return files;
}

async function generateLivePreview(projectName: string, analysis: any, files: GeneratedFile[]): Promise<LivePreview> {
  // Generate a live preview component that showcases the main functionality
  const html = generatePreviewHTML(projectName, analysis);
  const css = generatePreviewCSS(projectName, analysis);
  const javascript = generatePreviewJavaScript(projectName, analysis);
  const componentPreview = generateComponentPreview(projectName, analysis);
  
  return {
    html,
    css,
    javascript,
    componentPreview
  };
}

// Helper functions for content generation
function extractProjectName(prompt: string): string {
  const nameMatch = prompt.match(/(?:create|build|make|develop)\s+(?:a\s+)?([A-Za-z\s]+?)(?:\s+application|\s+app|\s+system|\s+platform|$)/i);
  if (nameMatch) {
    return nameMatch[1].trim().split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  }
  return 'AI Generated Application';
}

function generateMainPageComponent(projectName: string, analysis: any): string {
  return `'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function HomePage() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/data');
      const result = await response.json();
      setData(result.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            ${projectName}
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            ${analysis.architecture}
          </p>
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            ${analysis.techStack.map((tech: string) => `<Badge key="${tech}" variant="outline">${tech}</Badge>`).join('\n            ')}
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Welcome to ${projectName}</CardTitle>
              <CardDescription>
                This is your AI-generated application with modern features and responsive design.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button onClick={fetchData} disabled={loading}>
                  {loading ? 'Loading...' : 'Load Sample Data'}
                </Button>
                
                {data.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-lg font-semibold mb-4">Sample Data:</h3>
                    <div className="space-y-2">
                      {data.map((item, index) => (
                        <div key={index} className="p-3 bg-slate-100 dark:bg-slate-800 rounded-lg">
                          <p className="font-medium">{item.name || 'Item ' + (index + 1)}</p>
                          <p className="text-sm text-muted-foreground">{item.description || 'Sample description'}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}`;
}

function generateLayoutComponent(projectName: string): string {
  return `import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: '${projectName}',
  description: 'AI-generated full-stack application',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}`;
}

function generateUIComponents(projectName: string, analysis: any): Array<{name: string, content: string}> {
  return [
    {
      name: 'DataCard',
      content: `import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface DataCardProps {
  title: string;
  description?: string;
  data?: any;
}

export default function DataCard({ title, description, data }: DataCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        {data ? (
          <pre className="text-sm bg-slate-100 dark:bg-slate-800 p-2 rounded">
            {JSON.stringify(data, null, 2)}
          </pre>
        ) : (
          <p className="text-muted-foreground">No data available</p>
        )}
      </CardContent>
    </Card>
  );
}`
    }
  ];
}

function generateStyles(projectName: string, analysis: any): string {
  return `@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 222.2 84% 4.9%;
    --card: 0 0% 100%;
    --card-foreground: 222.2 84% 4.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 222.2 84% 4.9%;
    --primary: 221.2 83.2% 53.3%;
    --primary-foreground: 210 40% 98%;
    --secondary: 210 40% 96%;
    --secondary-foreground: 222.2 84% 4.9%;
    --muted: 210 40% 96%;
    --muted-foreground: 215.4 16.3% 46.9%;
    --accent: 210 40% 96%;
    --accent-foreground: 222.2 84% 4.9%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 210 40% 98%;
    --border: 214.3 31.8% 91.4%;
    --input: 214.3 31.8% 91.4%;
    --ring: 221.2 83.2% 53.3%;
    --radius: 0.5rem;
  }

  .dark {
    --background: 222.2 84% 4.9%;
    --foreground: 210 40% 98%;
    --card: 222.2 84% 4.9%;
    --card-foreground: 210 40% 98%;
    --popover: 222.2 84% 4.9%;
    --popover-foreground: 210 40% 98%;
    --primary: 217.2 91.2% 59.8%;
    --primary-foreground: 222.2 84% 4.9%;
    --secondary: 217.2 32.6% 17.5%;
    --secondary-foreground: 210 40% 98%;
    --muted: 217.2 32.6% 17.5%;
    --muted-foreground: 215 20.2% 65.1%;
    --accent: 217.2 32.6% 17.5%;
    --accent-foreground: 210 40% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 210 40% 98%;
    --border: 217.2 32.6% 17.5%;
    --input: 217.2 32.6% 17.5%;
    --ring: 224.3 76.3% 94.1%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}`;
}

function generateAPIRoutes(projectName: string, analysis: any): Array<{path: string, content: string}> {
  return [
    {
      path: 'data',
      content: `import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    // Sample data - in a real app, this would come from a database
    const sampleData = [
      {
        id: 1,
        name: 'Sample Item 1',
        description: 'This is a sample item generated by AI',
        createdAt: new Date().toISOString()
      },
      {
        id: 2,
        name: 'Sample Item 2',
        description: 'Another sample item with different data',
        createdAt: new Date().toISOString()
      },
      {
        id: 3,
        name: 'Sample Item 3',
        description: 'Third sample item for demonstration',
        createdAt: new Date().toISOString()
      }
    ];

    return NextResponse.json({
      success: true,
      data: sampleData,
      message: 'Sample data retrieved successfully'
    });

  } catch (error) {
    console.error('Error fetching data:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch data',
      message: 'An error occurred while retrieving data'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // In a real app, you would save this to a database
    const newItem = {
      id: Date.now(),
      ...body,
      createdAt: new Date().toISOString()
    };

    return NextResponse.json({
      success: true,
      data: newItem,
      message: 'Item created successfully'
    });

  } catch (error) {
    console.error('Error creating item:', error);
    return NextResponse.json({
      success: false,
      error: 'Failed to create item',
      message: 'An error occurred while creating the item'
    }, { status: 500 });
  }
}`
    }
  ];
}

function generateDatabaseClient(projectName: string): string {
  return `import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db;`;
}

function generateUtils(projectName: string, analysis: any): string {
  return `import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date | string): string {
  const d = new Date(date);
  return d.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

export function generateId(): string {
  return Math.random().toString(36).substr(2, 9);
}`;
}

function generatePrismaSchema(projectName: string, analysis: any): string {
  return `// This is your Prisma schema file,
// learn more about it in the docs: https://pris.ly/d/prisma-schema

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

model Item {
  id          String   @id @default(cuid())
  name        String
  description String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}`;
}

function generatePackageJson(projectName: string, analysis: any): string {
  return `{
  "name": "${projectName.toLowerCase().replace(' ', '-')}",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "db:push": "prisma db push",
    "db:generate": "prisma generate"
  },
  "dependencies": {
    "@prisma/client": "^5.6.0",
    "clsx": "^2.0.0",
    "lucide-react": "^0.292.0",
    "next": "14.0.0",
    "prisma": "^5.6.0",
    "react": "^18",
    "react-dom": "^18",
    "tailwind-merge": "^2.0.0",
    "tailwindcss-animate": "^1.0.7",
    "class-variance-authority": "^0.7.0"
  },
  "devDependencies": {
    "@types/node": "^20",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "autoprefixer": "^10.0.1",
    "eslint": "^8",
    "eslint-config-next": "14.0.0",
    "postcss": "^8",
    "tailwindcss": "^3.3.0",
    "typescript": "^5"
  }
}`;
}

function generateTailwindConfig(): string {
  return `import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;`;
}

function generateTSConfig(): string {
  return `{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "es6"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}`;
}

function generatePreviewHTML(projectName: string, analysis: any): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${projectName} - Preview</title>
    <style>
        ${generatePreviewCSS(projectName, analysis)}
    </style>
</head>
<body>
    <div class="preview-container">
        <header class="preview-header">
            <h1>${projectName}</h1>
            <p class="subtitle">${analysis.architecture}</p>
        </header>
        
        <main class="preview-main">
            <div class="preview-card">
                <h2>Welcome to ${projectName}</h2>
                <p>This is a live preview of your AI-generated application.</p>
                
                <div class="tech-stack">
                    ${analysis.techStack.map((tech: string) => `<span class="tech-badge">${tech}</span>`).join('')}
                </div>
                
                <div class="preview-actions">
                    <button class="preview-button primary">Load Sample Data</button>
                    <button class="preview-button secondary">View Documentation</button>
                </div>
                
                <div class="preview-content">
                    <div class="preview-item">
                        <h3>Sample Item 1</h3>
                        <p>This demonstrates the UI components and styling.</p>
                    </div>
                    <div class="preview-item">
                        <h3>Sample Item 2</h3>
                        <p>Interactive elements with modern design.</p>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        ${generatePreviewJavaScript(projectName, analysis)}
    </script>
</body>
</html>`;
}

function generatePreviewCSS(projectName: string, analysis: any): string {
  return `* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    color: #333;
}

.preview-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

.preview-header {
    text-align: center;
    margin-bottom: 3rem;
    color: white;
}

.preview-header h1 {
    font-size: 3rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.subtitle {
    font-size: 1.2rem;
    opacity: 0.9;
}

.preview-main {
    display: flex;
    justify-content: center;
}

.preview-card {
    background: white;
    border-radius: 1rem;
    padding: 2rem;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    max-width: 600px;
    width: 100%;
}

.preview-card h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
    color: #4a5568;
}

.tech-stack {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin: 1.5rem 0;
}

.tech-badge {
    background: #e2e8f0;
    color: #4a5568;
    padding: 0.25rem 0.75rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 500;
}

.preview-actions {
    display: flex;
    gap: 1rem;
    margin: 1.5rem 0;
}

.preview-button {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 0.5rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.preview-button.primary {
    background: #667eea;
    color: white;
}

.preview-button.primary:hover {
    background: #5a67d8;
    transform: translateY(-1px);
}

.preview-button.secondary {
    background: #e2e8f0;
    color: #4a5568;
}

.preview-button.secondary:hover {
    background: #cbd5e0;
}

.preview-content {
    margin-top: 2rem;
}

.preview-item {
    background: #f7fafc;
    padding: 1rem;
    border-radius: 0.5rem;
    margin-bottom: 1rem;
    border-left: 4px solid #667eea;
}

.preview-item h3 {
    color: #2d3748;
    margin-bottom: 0.5rem;
}

.preview-item p {
    color: #718096;
    font-size: 0.875rem;
}`;
}

function generatePreviewJavaScript(projectName: string, analysis: any): string {
  return `// Interactive functionality for the preview
document.addEventListener('DOMContentLoaded', function() {
    const loadButton = document.querySelector('.preview-button.primary');
    const previewContent = document.querySelector('.preview-content');
    
    loadButton.addEventListener('click', function() {
        // Simulate loading data
        loadButton.textContent = 'Loading...';
        loadButton.disabled = true;
        
        setTimeout(() => {
            // Add new preview items
            const newItem = document.createElement('div');
            newItem.className = 'preview-item';
            newItem.innerHTML = \`
                <h3>Dynamic Item</h3>
                <p>This item was loaded dynamically to demonstrate interactivity.</p>
            \`;
            
            previewContent.appendChild(newItem);
            
            loadButton.textContent = 'Load Sample Data';
            loadButton.disabled = false;
        }, 1000);
    });
    
    // Add hover effects to preview items
    const previewItems = document.querySelectorAll('.preview-item');
    previewItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateX(5px)';
            this.style.transition = 'transform 0.2s';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateX(0)';
        });
    });
});`;
}

function generateComponentPreview(projectName: string, analysis: any): string {
  return `'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function ComponentPreview() {
  const [items, setItems] = useState([
    { id: 1, name: 'Preview Component 1', description: 'Interactive preview element' },
    { id: 2, name: 'Preview Component 2', description: 'Another preview with styling' }
  ]);
  
  const addItem = () => {
    const newItem = {
      id: Date.now(),
      name: \`Dynamic Item \${items.length + 1}\`,
      description: 'Added dynamically to demonstrate functionality'
    };
    setItems([...items, newItem]);
  };

  return (
    <div className="p-6 bg-white dark:bg-gray-800 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">${projectName} Preview</h3>
        <Button onClick={addItem}>Add Item</Button>
      </div>
      
      <div className="space-y-3">
        {items.map(item => (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">{item.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{item.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}`;
}

function generateSetupInstructions(projectName: string, analysis: any): string {
  return `# Installation Instructions

## 1. Install Dependencies
\`\`\`bash
npm install
\`\`\`

## 2. Set Up Database
\`\`\`bash
# Push database schema
npm run db:push

# Generate Prisma client
npm run db:generate
\`\`\`

## 3. Start Development Server
\`\`\`bash
npm run dev
\`\`\`

## 4. Access Application
- Open http://localhost:3000 in your browser
- The application will be running with live preview enabled`;
}

function generateRunningInstructions(projectName: string, analysis: any): string {
  return `# Running the Application

## Development Mode
\`\`\`bash
npm run dev
\`\`\`
- Starts the development server with hot reload
- Access at http://localhost:3000

## Production Mode
\`\`\`bash
npm run build
npm start
\`\`\`
- Builds the application for production
- Starts the production server

## Features
- **Live Preview**: See your application in real-time
- **Responsive Design**: Works on all devices
- **Modern Stack**: Built with Next.js, TypeScript, and Tailwind CSS
- **Database Integration**: SQLite with Prisma ORM
- **API Endpoints**: RESTful API for data management`;
}