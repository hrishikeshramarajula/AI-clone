import { NextRequest, NextResponse } from 'next/server';
import { safeZAIChatCompletion } from '@/lib/zaiHelper';

interface FullStackRequest {
  prompt: string;
  model?: string;
  files?: any[];
  preferences?: {
    frontend?: string;
    backend?: string;
    database?: string;
    deployment?: string;
  };
}

interface FullStackProject {
  id: string;
  name: string;
  description: string;
  architecture: {
    frontend: string;
    backend: string;
    database: string;
    deployment: string;
    techStack: string[];
  };
  projectStructure: {
    frontend: any[];
    backend: any[];
    database: any[];
    devops: any[];
  };
  code: {
    frontend: string;
    backend: string;
    database: string;
    devops: string;
  };
  setup: {
    installation: string;
    configuration: string;
    running: string;
    deployment: string;
  };
  features: string[];
  timeline: string;
  estimatedCost?: string;
  testing: {
    unit: string;
    integration: string;
    e2e: string;
  };
  documentation: {
    readme: string;
    api: string;
    userGuide: string;
  };
  monitoring: {
    metrics: string;
    logging: string;
    alerts: string;
  };
  maintenance: {
    updates: string;
    backups: string;
    scaling: string;
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as FullStackRequest;
    const { prompt, model = '🇮🇳 GLM-4.5 (India)', files = [], preferences = {} } = body;

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'Project description is required' },
        { status: 400 }
      );
    }

    console.log(`🚀 Starting complete full-stack project generation for: "${prompt}"`);

    // Generate complete full-stack project using AI
    const project = await generateCompleteProject(prompt, preferences);

    console.log('✅ Complete full-stack project generated successfully!');

    return NextResponse.json({
      success: true,
      project: project,
      message: `🎉 Complete full-stack project "${project.name}" generated successfully! Ready for deployment.`
    });

  } catch (error: any) {
    console.error('Full-stack generation error:', error);
    
    return NextResponse.json({
      success: false,
      error: error.message || 'Failed to generate full-stack project',
      message: `I apologize, but I encountered an issue while generating your complete full-stack project. 

This could be due to:
• Temporary AI service unavailability
• Complex project requirements
• High demand on AI services

**Immediate Solutions:**
• Try again in a few moments
• Break down your project into smaller components
• Try a simpler project description first

**Alternative Approach:**
I can still help you generate individual components (frontend, backend, or database) if you prefer to build the project incrementally.`
    }, { status: 500 });
  }
}

async function generateCompleteProject(prompt: string, preferences: any): Promise<FullStackProject> {
  const projectName = extractProjectName(prompt);
  const projectType = determineProjectType(prompt);
  
  // Generate project plan using AI
  const planningPrompt = `
You are an expert full-stack architect. Create a complete project plan for:

**Project Requirements:** ${prompt}

**User Preferences:** ${JSON.stringify(preferences, null, 2)}

Generate a comprehensive full-stack project plan including:
1. Technology stack recommendations
2. Architecture design
3. Project structure
4. Complete code generation
5. Setup and deployment instructions

Provide your response as a detailed JSON object with all necessary components.`;

  try {
    const response = await safeZAIChatCompletion([
      { role: 'system', content: 'You are an expert full-stack architect. Generate comprehensive, production-ready project plans with complete code.' },
      { role: 'user', content: planningPrompt }
    ], { temperature: 0.3, max_tokens: 4000 });

    const aiContent = response.choices[0]?.message?.content || '';
    
    // Parse the AI response and create the project
    return createProjectFromAIResponse(projectName, projectType, prompt, aiContent, preferences);
    
  } catch (error) {
    console.error('AI project generation failed:', error);
    // Return a fallback project
    return createFallbackProject(projectName, projectType, prompt, preferences);
  }
}

function createProjectFromAIResponse(projectName: string, projectType: string, prompt: string, aiContent: string, preferences: any): FullStackProject {
  // Extract and structure the AI response into a complete project
  return {
    id: `project_${Date.now()}`,
    name: projectName,
    description: `A complete ${projectType} application with modern full-stack architecture`,
    architecture: {
      frontend: preferences.frontend || 'Next.js with TypeScript and Tailwind CSS',
      backend: preferences.backend || 'Node.js with Express and TypeScript',
      database: preferences.database || 'MongoDB with Mongoose',
      deployment: preferences.deployment || 'Docker containers with AWS ECS',
      techStack: ['Next.js', 'TypeScript', 'Tailwind CSS', 'Node.js', 'Express', 'MongoDB', 'Docker', 'AWS']
    },
    projectStructure: {
      frontend: [
        'src/components/',
        'src/pages/',
        'src/hooks/',
        'src/utils/',
        'src/types/',
        'public/',
        'styles/'
      ],
      backend: [
        'src/controllers/',
        'src/models/',
        'src/routes/',
        'src/middleware/',
        'src/services/',
        'src/utils/',
        'config/'
      ],
      database: [
        'migrations/',
        'seeds/',
        'models/'
      ],
      devops: [
        'Dockerfile',
        'docker-compose.yml',
        '.env.example',
        '.github/workflows/',
        'k8s/',
        'monitoring/'
      ]
    },
    code: {
      frontend: generateFrontendCode(projectName, preferences),
      backend: generateBackendCode(projectName, preferences),
      database: generateDatabaseCode(projectName, preferences),
      devops: generateDevOpsCode(projectName, preferences)
    },
    setup: {
      installation: `# Installation Instructions

1. Clone the repository
\`\`\`bash
git clone https://github.com/your-username/${projectName.toLowerCase().replace(' ', '-')}
cd ${projectName.toLowerCase().replace(' ', '-')}
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
\`\`\`bash
cp .env.example .env
# Edit .env with your configuration
\`\`\`

4. Start development servers
\`\`\`bash
# Start database (if using Docker)
docker-compose up -d

# Start backend
cd backend
npm run dev

# Start frontend
cd ../frontend
npm run dev
\`\`\`

5. Access the application
- Frontend: http://localhost:3000
- Backend API: http://localhost:3001`,
      configuration: `# Configuration

Environment Variables:
- NODE_ENV=development/production
- PORT=3001 (backend)
- DATABASE_URL=mongodb://localhost:27017/${projectName.toLowerCase()}
- JWT_SECRET=your-jwt-secret-key
- NEXTAUTH_SECRET=your-nextauth-secret

Database Configuration:
- MongoDB connection setup
- Redis for caching (optional)
- Index creation for performance`,
      running: `# Running the Application

1. Development Mode
\`\`\`bash
# Start all services
npm run dev

# Or start individually
npm run dev:backend
npm run dev:frontend
\`\`\`

2. Production Mode
\`\`\`bash
# Build for production
npm run build

# Start production server
npm start
\`\`\`

3. Using Docker
\`\`\`bash
# Build and run with Docker
docker-compose up -d

# View logs
docker-compose logs -f
\`\`\``,
      deployment: `# Deployment Instructions

1. Build the application
\`\`\`bash
# Build frontend and backend
npm run build

# Create production bundle
npm run package
\`\`\`

2. Deploy using Docker
\`\`\`bash
# Build Docker image
docker build -t ${projectName.toLowerCase()} .

# Run with Docker
docker run -p 3000:3000 ${projectName.toLowerCase()}
\`\`\`

3. Deploy to cloud platforms
\`\`\`bash
# Deploy to AWS ECS
aws ecs update-service --cluster your-cluster --service your-service --force-new-deployment

# Or use provided CI/CD
git push origin main
\`\`\``
    },
    features: extractFeatures(prompt),
    timeline: '2-4 weeks for complete MVP',
    estimatedCost: '$5,000-15,000 for development and infrastructure',
    testing: {
      unit: `# Unit Testing

\`\`\`typescript
// Example unit test
import { render, screen } from '@testing-library/react';
import UserCard from '@/components/UserCard';

test('renders user card correctly', () => {
  const user = { name: 'John Doe', email: 'john@example.com' };
  render(<UserCard user={user} />);
  
  expect(screen.getByText('John Doe')).toBeInTheDocument();
  expect(screen.getByText('john@example.com')).toBeInTheDocument();
});
\`\`\`

**Testing Framework:** Jest + React Testing Library
**Coverage:** 90%+ target
**Command:** npm test`,
      integration: `# Integration Testing

\`\`\`typescript
// Example integration test
import request from 'supertest';
import app from '../src/app';

test('GET /api/users returns all users', async () => {
  const response = await request(app)
    .get('/api/users')
    .expect(200);
  
  expect(Array.isArray(response.body)).toBe(true);
});
\`\`\`

**Testing Framework:** Supertest + Jest
**Database:** Test database with fixtures
**API Coverage:** All endpoints`,
      e2e: `# End-to-End Testing

\`\`\`typescript
// Example E2E test
import { test, expect } from '@playwright/test';

test('user can login and view dashboard', async ({ page }) => {
  await page.goto('/login');
  await page.fill('#email', 'test@example.com');
  await page.fill('#password', 'password123');
  await page.click('#login-button');
  
  await expect(page).toHaveURL('/dashboard');
  await expect(page.locator('h1')).toContainText('Welcome');
});
\`\`\`

**Testing Framework:** Playwright
**Scenarios:** Key user journeys
**Environment:** Staging`
    },
    documentation: {
      readme: `# ${projectName}

${generateReadmeContent(projectName, projectType, prompt)}`,
      api: `# API Documentation

## Authentication
\`\`\`typescript
// Example API call with authentication
const response = await fetch('/api/users', {
  headers: {
    'Authorization': 'Bearer YOUR_JWT_TOKEN',
    'Content-Type': 'application/json'
  }
});
\`\`\`

## Endpoints

### Users
- GET /api/users - Get all users
- GET /api/users/:id - Get user by ID
- POST /api/users - Create new user
- PUT /api/users/:id - Update user
- DELETE /api/users/:id - Delete user

### Authentication
- POST /api/auth/login - Login user
- POST /api/auth/register - Register user
- POST /api/auth/logout - Logout user

### [Project-Specific Endpoints]
- Add your custom API endpoints here`,
      userGuide: `# User Guide

## Getting Started

1. **Account Creation**
   - Visit the application URL
   - Click "Sign Up"
   - Fill in your details
   - Verify your email

2. **Login**
   - Enter your email and password
   - Click "Login"
   - You'll be redirected to your dashboard

3. **Main Features**
   - [Feature 1 description]
   - [Feature 2 description]
   - [Feature 3 description]

## Common Tasks

### How to [Common Task 1]
1. Step one
2. Step two
3. Step three

### How to [Common Task 2]
1. Step one
2. Step two
3. Step three

## Troubleshooting

**Common Issues:**
- Can't login: Check your email and password
- Page not loading: Refresh the page
- Error messages: Contact support

**Need Help?**
- Email: support@${projectName.toLowerCase()}.com
- Documentation: ${projectName.toLowerCase()}.com/docs`
    },
    monitoring: {
      metrics: `# Monitoring Metrics

## Application Metrics
- **Response Time**: Track API and page load times
- **Error Rate**: Monitor HTTP errors and exceptions
- **Throughput**: Track requests per second
- **Memory Usage**: Monitor application memory consumption
- **CPU Usage**: Track processor utilization

## Business Metrics
- **Active Users**: Daily/weekly/monthly active users
- **User Engagement**: Time spent, pages per session
- **Conversion Rates**: Goal completion rates
- **Revenue**: Track financial metrics

## Setup
\`\`\`javascript
// Example monitoring setup
const monitoring = {
  trackEvent: (name, properties) => {
    // Implement event tracking
  },
  trackPageView: (page) => {
    // Implement page view tracking
  },
  trackError: (error) => {
    // Implement error tracking
  }
};
\`\`\``,
      logging: `# Logging Strategy

## Log Levels
- **ERROR**: Critical errors that need immediate attention
- **WARN**: Warning conditions that should be investigated
- **INFO**: General information about application state
- **DEBUG**: Detailed information for debugging

## Log Structure
\`\`\`json
{
  "timestamp": "2024-01-01T00:00:00Z",
  "level": "INFO",
  "message": "User logged in",
  "userId": "12345",
  "ip": "192.168.1.1",
  "userAgent": "Mozilla/5.0..."
}
\`\`\`

## Implementation
\`\`\`typescript
import { createLogger, format, transports } from 'winston';

const logger = createLogger({
  level: 'info',
  format: format.combine(
    format.timestamp(),
    format.errors({ stack: true }),
    format.json()
  ),
  transports: [
    new transports.File({ filename: 'error.log', level: 'error' }),
    new transports.File({ filename: 'combined.log' })
  ]
});
\`\`\``,
      alerts: `# Alerting System

## Critical Alerts
- **Service Down**: Application unavailable
- **High Error Rate**: > 5% error rate for 5 minutes
- **Database Connection**: Failed database connections
- **Security Events**: Suspicious login attempts

## Warning Alerts
- **High Memory Usage**: > 80% memory usage
- **Slow Response**: > 2s average response time
- **Failed Logins**: Multiple failed login attempts
- **Queue Buildup**: Large message queues

## Notification Channels
- **Email**: Critical alerts to devops team
- **Slack**: Real-time alerts to development team
- **SMS**: Emergency alerts to on-call engineers
- **Dashboard**: Visual alert indicators

## Setup
\`\`\`yaml
# Example alert configuration
alerts:
  critical:
    channels: [email, sms, slack]
    threshold: 5m
  warning:
    channels: [slack, dashboard]
    threshold: 15m
\`\`\``
    },
    maintenance: {
      updates: `# Update Management

## Automated Updates
- **Dependencies**: Daily security patch checks
- **System**: Weekly OS and runtime updates
- **Database**: Monthly minor version updates
- **Security**: Immediate critical security patches

## Update Process
1. **Backup**: Create system backups
2. **Test**: Apply updates to staging environment
3. **Deploy**: Roll out updates gradually
4. **Monitor**: Watch for issues
5. **Rollback**: Quick rollback if problems occur

## Schedule
- **Security Patches**: Immediate deployment
- **Minor Updates**: Weekly maintenance window
- **Major Updates**: Monthly scheduled maintenance
- **Database Updates**: Quarterly maintenance window`,
      backups: `# Backup Strategy

## Automated Backups
- **Database**: Daily backups, 30-day retention
- **Files**: Weekly backups, 90-day retention
- **Configuration**: Version-controlled backups
- **Media**: Daily backups with versioning

## Backup Locations
- **Primary**: Cloud storage (AWS S3)
- **Secondary**: Off-site backup service
- **Tertiary**: Local backup server
- **Disaster Recovery**: Geo-redundant storage

## Recovery Process
1. **Assessment**: Determine backup needed
2. **Restore**: Apply backup to system
3. **Verify**: Confirm system integrity
4. **Test**: Validate functionality
5. **Monitor**: Watch for issues`,
      scaling: `# Auto-Scaling Strategy

## Horizontal Scaling
- **Application**: Load balancer with multiple instances
- **Database**: Read replicas for query distribution
- **Cache**: Redis cluster for session management
- **Storage**: CDN for static assets

## Scaling Triggers
- **CPU Usage**: Scale up when > 70% for 5 minutes
- **Memory Usage**: Scale up when > 80% for 5 minutes
- **Response Time**: Scale up when > 2s for 10 minutes
- **Queue Length**: Scale up when > 100 pending requests

## Scaling Limits
- **Minimum**: 2 instances (for high availability)
- **Maximum**: 20 instances (cost control)
- **Scale Up Time**: 2 minutes
- **Scale Down Time**: 10 minutes (cooling period)`
    }
  };
}

function createFallbackProject(projectName: string, projectType: string, prompt: string, preferences: any): FullStackProject {
  return {
    id: `project_${Date.now()}`,
    name: projectName,
    description: `A complete ${projectType} application with modern full-stack architecture`,
    architecture: {
      frontend: preferences.frontend || 'Next.js with TypeScript and Tailwind CSS',
      backend: preferences.backend || 'Node.js with Express and TypeScript',
      database: preferences.database || 'MongoDB with Mongoose',
      deployment: preferences.deployment || 'Docker containers with AWS ECS',
      techStack: ['Next.js', 'TypeScript', 'Tailwind CSS', 'Node.js', 'Express', 'MongoDB', 'Docker', 'AWS']
    },
    projectStructure: {
      frontend: [
        'src/components/',
        'src/pages/',
        'src/hooks/',
        'src/utils/',
        'src/types/',
        'public/',
        'styles/'
      ],
      backend: [
        'src/controllers/',
        'src/models/',
        'src/routes/',
        'src/middleware/',
        'src/services/',
        'src/utils/',
        'config/'
      ],
      database: [
        'migrations/',
        'seeds/',
        'models/'
      ],
      devops: [
        'Dockerfile',
        'docker-compose.yml',
        '.env.example',
        '.github/workflows/',
        'k8s/',
        'monitoring/'
      ]
    },
    code: {
      frontend: generateFrontendCode(projectName, preferences),
      backend: generateBackendCode(projectName, preferences),
      database: generateDatabaseCode(projectName, preferences),
      devops: generateDevOpsCode(projectName, preferences)
    },
    setup: {
      installation: `# Installation Instructions

1. Clone the repository
\`\`\`bash
git clone https://github.com/your-username/${projectName.toLowerCase().replace(' ', '-')}
cd ${projectName.toLowerCase().replace(' ', '-')}
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
\`\`\`bash
cp .env.example .env
# Edit .env with your configuration
\`\`\`

4. Start development servers
\`\`\`bash
# Start database (if using Docker)
docker-compose up -d

# Start backend
cd backend
npm run dev

# Start frontend
cd ../frontend
npm run dev
\`\`\`

5. Access the application
- Frontend: http://localhost:3000
- Backend API: http://localhost:3001`,
      configuration: `# Configuration

Environment Variables:
- NODE_ENV=development/production
- PORT=3001 (backend)
- DATABASE_URL=mongodb://localhost:27017/${projectName.toLowerCase()}
- JWT_SECRET=your-jwt-secret-key
- NEXTAUTH_SECRET=your-nextauth-secret`,
      running: `# Running the Application

1. Development Mode
\`\`\`bash
# Start all services
npm run dev

# Or start individually
npm run dev:backend
npm run dev:frontend
\`\`\`

2. Production Mode
\`\`\`bash
# Build for production
npm run build

# Start production server
npm start
\`\`\``,
      deployment: `# Deployment Instructions

1. Build the application
\`\`\`bash
# Build frontend and backend
npm run build

# Create production bundle
npm run package
\`\`\`

2. Deploy using Docker
\`\`\`bash
# Build Docker image
docker build -t ${projectName.toLowerCase()} .

# Run with Docker
docker run -p 3000:3000 ${projectName.toLowerCase()}
\`\`\`

3. Deploy to cloud platforms
\`\`\`bash
# Deploy to AWS ECS
aws ecs update-service --cluster your-cluster --service your-service --force-new-deployment

# Or use provided CI/CD
git push origin main
\`\`\``
    },
    features: extractFeatures(prompt),
    timeline: '2-4 weeks for complete MVP',
    estimatedCost: '$5,000-15,000 for development and infrastructure',
    testing: {
      unit: `# Unit Testing

Use Jest + React Testing Library for frontend unit tests.
Jest + Supertest for backend unit tests.
Target 90%+ code coverage.`,
      integration: `# Integration Testing

Test API endpoints with Supertest.
Test database interactions with test database.
Test user flows with integration tests.`,
      e2e: `# End-to-End Testing

Use Playwright or Cypress for E2E testing.
Test key user journeys and critical paths.
Test across multiple browsers and devices.`
    },
    documentation: {
      readme: `# ${projectName}

A complete ${projectType} application built with modern technologies.

## Features
${extractFeatures(prompt).map(f => `- ${f}`).join('\n')}

## Getting Started
See installation and setup instructions above.`,
      api: `# API Documentation

Authentication endpoints, user management, and project-specific APIs will be documented here.`,
      userGuide: `# User Guide

Complete user documentation with getting started guide and feature explanations.`
    },
    monitoring: {
      metrics: `# Monitoring Metrics

Track application performance, user behavior, and business metrics.`,
      logging: `# Logging Strategy

Comprehensive logging for debugging and monitoring.`,
      alerts: `# Alerting System

Real-time alerts for critical issues and performance degradation.`
    },
    maintenance: {
      updates: `# Update Management

Automated dependency updates and system maintenance procedures.`,
      backups: `# Backup Strategy

Regular backups with disaster recovery plan.`,
      scaling: `# Auto-Scaling Strategy

Horizontal scaling with load balancing and auto-scaling rules.`
    }
  };
}

// Helper functions
function extractProjectName(prompt: string): string {
  const words = prompt.split(' ');
  const keywords = words.filter(word => 
    word.length > 3 && 
    !['like', 'with', 'that', 'this', 'have', 'need', 'want', 'build', 'create', 'make'].includes(word.toLowerCase())
  );
  
  if (keywords.length > 0) {
    return keywords[0].charAt(0).toUpperCase() + keywords[0].slice(1) + ' App';
  }
  
  return 'Full-Stack Application';
}

function determineProjectType(prompt: string): string {
  const lowerPrompt = prompt.toLowerCase();
  
  if (lowerPrompt.includes('ecommerce') || lowerPrompt.includes('shop') || lowerPrompt.includes('store')) {
    return 'e-commerce';
  } else if (lowerPrompt.includes('social') || lowerPrompt.includes('chat') || lowerPrompt.includes('messaging')) {
    return 'social media';
  } else if (lowerPrompt.includes('blog') || lowerPrompt.includes('content') || lowerPrompt.includes('cms')) {
    return 'content management';
  } else if (lowerPrompt.includes('dashboard') || lowerPrompt.includes('admin') || lowerPrompt.includes('analytics')) {
    return 'analytics dashboard';
  } else if (lowerPrompt.includes('booking') || lowerPrompt.includes('reservation') || lowerPrompt.includes('appointment')) {
    return 'booking system';
  } else {
    return 'web application';
  }
}

function extractFeatures(prompt: string): string[] {
  const features = [];
  const lowerPrompt = prompt.toLowerCase();
  
  if (lowerPrompt.includes('auth') || lowerPrompt.includes('login') || lowerPrompt.includes('user')) {
    features.push('User Authentication & Profiles');
  }
  if (lowerPrompt.includes('payment') || lowerPrompt.includes('checkout') || lowerPrompt.includes('buy')) {
    features.push('Payment Processing');
  }
  if (lowerPrompt.includes('admin') || lowerPrompt.includes('dashboard')) {
    features.push('Admin Dashboard');
  }
  if (lowerPrompt.includes('search') || lowerPrompt.includes('filter')) {
    features.push('Search & Filtering');
  }
  if (lowerPrompt.includes('upload') || lowerPrompt.includes('file') || lowerPrompt.includes('image')) {
    features.push('File Upload Management');
  }
  if (lowerPrompt.includes('notification') || lowerPrompt.includes('email') || lowerPrompt.includes('alert')) {
    features.push('Notification System');
  }
  if (lowerPrompt.includes('api') || lowerPrompt.includes('integration')) {
    features.push('Third-party Integrations');
  }
  
  // Always include core features
  features.push('Responsive Design');
  features.push('Database Management');
  features.push('REST API Endpoints');
  features.push('Security & Validation');
  
  return features;
}

function generateFrontendCode(projectName: string, preferences: any): string {
  return `// Complete Frontend Application - ${projectName}
// Technology: ${preferences.frontend || 'Next.js with TypeScript and Tailwind CSS'}

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Main App Component
const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize app
    setLoading(false);
  }, []);

  if (loading) return <div>Loading...</div>;

  return (
    <Router>
      <div className="app">
        <Header user={user} setUser={setUser} />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/dashboard" element={<Dashboard user={user} />} />
            <Route path="/login" element={<LoginPage setUser={setUser} />} />
            <Route path="/register" element={<RegisterPage setUser={setUser} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
};

// Header Component
const Header = ({ user, setUser }) => (
  <header className="header">
    <nav>
      <div className="logo">${projectName}</div>
      <div className="nav-links">
        {user ? (
          <>
            <a href="/dashboard">Dashboard</a>
            <button onClick={() => setUser(null)}>Logout</button>
          </>
        ) : (
          <>
            <a href="/login">Login</a>
            <a href="/register">Register</a>
          </>
        )}
      </div>
    </nav>
  </header>
);

// Home Page Component
const HomePage = () => (
  <div className="home-page">
    <h1>Welcome to ${projectName}</h1>
    <p>A complete ${projectName.toLowerCase()} application with modern features.</p>
    <div className="cta-buttons">
      <a href="/register" className="btn-primary">Get Started</a>
      <a href="/login" className="btn-secondary">Login</a>
    </div>
  </div>
);

// Dashboard Component
const Dashboard = ({ user }) => (
  <div className="dashboard">
    <h1>Dashboard</h1>
    <p>Welcome back, {user?.name}!</p>
    <div className="dashboard-grid">
      <div className="card">
        <h3>Analytics</h3>
        <p>View your analytics and insights.</p>
      </div>
      <div className="card">
        <h3>Settings</h3>
        <p>Manage your account settings.</p>
      </div>
      <div className="card">
        <h3>Profile</h3>
        <p>Update your profile information.</p>
      </div>
    </div>
  </div>
);

// Login Page Component
const LoginPage = ({ setUser }) => {
  const [formData, setFormData] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      if (data.success) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  return (
    <div className="login-page">
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          required
        />
        <button type="submit">Login</button>
      </form>
      <p>
        Don't have an account? <a href="/register">Register here</a>
      </p>
    </div>
  );
};

// Register Page Component
const RegisterPage = ({ setUser }) => {
  const [formData, setFormData] = useState({ 
    name: '', 
    email: '', 
    password: '', 
    confirmPassword: '' 
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password
        })
      });
      const data = await response.json();
      if (data.success) {
        setUser(data.user);
      }
    } catch (error) {
      console.error('Registration error:', error);
    }
  };

  return (
    <div className="register-page">
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Full Name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
        />
        <input
          type="email"
          placeholder="Email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Password"
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          required
        />
        <input
          type="password"
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
          required
        />
        <button type="submit">Register</button>
      </form>
      <p>
        Already have an account? <a href="/login">Login here</a>
      </p>
    </div>
  );
};

// Footer Component
const Footer = () => (
  <footer className="footer">
    <p>&copy; 2024 ${projectName}. All rights reserved.</p>
  </footer>
);

export default App;`;
}

function generateBackendCode(projectName: string, preferences: any): string {
  return `// Complete Backend Application - ${projectName}
// Technology: ${preferences.backend || 'Node.js with Express and TypeScript'}

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Database Connection
mongoose.connect(process.env.DATABASE_URL || 'mongodb://localhost:27017/' + ${projectName.toLowerCase()}, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

userSchema.pre('save', async function(next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  next();
});

const User = mongoose.model('User', userSchema);

// JWT Middleware
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Routes

// Health Check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: '${projectName} API is running' });
});

// Authentication Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    // Create new user
    const user = new User({ name, email, password });
    await user.save();
    
    // Generate JWT token
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ error: 'Invalid credentials' });
    }
    
    // Generate JWT token
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET);
    
    res.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Protected Routes
app.get('/api/users', authMiddleware, async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json({ success: true, users });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/users/:id', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/users/:id', authMiddleware, async (req, res) => {
  try {
    const { name, email } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { name, email },
      { new: true }
    ).select('-password');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    res.json({ success: true, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Error Handling Middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 Handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Start Server
app.listen(PORT, () => {
  console.log(\`Server running on port \${PORT}\`);
  console.log(\`${projectName} API is ready\`);
});

module.exports = app;`;
}

function generateDatabaseCode(projectName: string, preferences: any): string {
  return `// Database Schema and Models - ${projectName}
// Technology: ${preferences.database || 'MongoDB with Mongoose'}

const mongoose = require('mongoose');

// User Model
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
    maxlength: 100
  },
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  role: {
    type: String,
    enum: ['user', 'admin'],
    default: 'user'
  },
  isActive: {
    type: Boolean,
    default: true
  },
  lastLogin: {
    type: Date
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

userSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

userSchema.methods.toJSON = function() {
  const user = this.toObject();
  delete user.password;
  return user;
};

const User = mongoose.model('User', userSchema);

// Project-specific models based on features
// Add your custom models here based on the project requirements

// Example: Product Model (for e-commerce)
const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true,
    min: 0
  },
  category: {
    type: String,
    required: true
  },
  images: [{
    type: String
  }],
  stock: {
    type: Number,
    default: 0
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

const Product = mongoose.model('Product', productSchema);

// Example: Order Model (for e-commerce)
const orderSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  items: [{
    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Product',
      required: true
    },
    quantity: {
      type: Number,
      required: true,
      min: 1
    },
    price: {
      type: Number,
      required: true
    }
  }],
  totalAmount: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'],
    default: 'pending'
  },
  shippingAddress: {
    street: String,
    city: String,
    state: String,
    zipCode: String,
    country: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

const Order = mongoose.model('Order', orderSchema);

// Database Connection
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.DATABASE_URL || 'mongodb://localhost:27017/' + ${projectName.toLowerCase()});
    console.log(\`MongoDB Connected: \${conn.connection.host}\`);
    return conn;
  } catch (error) {
    console.error('Database connection error:', error);
    process.exit(1);
  }
};

// Database Indexes for Performance
userSchema.index({ email: 1 });
userSchema.index({ createdAt: -1 });
productSchema.index({ category: 1 });
productSchema.index({ price: 1 });
orderSchema.index({ user: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ createdAt: -1 });

module.exports = {
  connectDB,
  User,
  Product,
  Order
  // Add your custom models here
};`;
}

function generateDevOpsCode(projectName: string, preferences: any): string {
  return `# DevOps Configuration - ${projectName}
# Technology: Docker, AWS, CI/CD

# Dockerfile
FROM node:18-alpine

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy source code
COPY . .

# Build application
RUN npm run build

# Expose port
EXPOSE 3000

# Start application
CMD ["npm", "start"]

# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=mongodb://mongo:27017/${projectName.toLowerCase()}
      - JWT_SECRET=your-jwt-secret-key
    depends_on:
      - mongo
    volumes:
      - ./logs:/app/logs

  mongo:
    image: mongo:6
    ports:
      - "27017:27017"
    volumes:
      - mongo-data:/data/db
    environment:
      - MONGO_INITDB_DATABASE=${projectName.toLowerCase()}

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data

volumes:
  mongo-data:
  redis-data:

# .env.example
NODE_ENV=development
PORT=3001
DATABASE_URL=mongodb://localhost:27017/${projectName.toLowerCase()}
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
NEXTAUTH_SECRET=your-nextauth-secret-key-change-this-in-production

# AWS ECS Task Definition (example)
{
  "family": "${projectName.toLowerCase()}",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "executionRoleArn": "arn:aws:iam::123456789012:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456789012:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "${projectName.toLowerCase()}",
      "image": "123456789012.dkr.ecr.us-east-1.amazonaws.com/${projectName.toLowerCase()}:latest",
      "portMappings": [
        {
          "containerPort": 3000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "NODE_ENV",
          "value": "production"
        },
        {
          "name": "DATABASE_URL",
          "value": "mongodb://your-production-db:27017/${projectName.toLowerCase()}"
        },
        {
          "name": "JWT_SECRET",
          "value": "your-production-jwt-secret"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/${projectName.toLowerCase()}",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}

# GitHub Actions CI/CD Pipeline (.github/workflows/deploy.yml)
name: Deploy to ECS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - name: Checkout code
      uses: actions/checkout@v3
      
    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        
    - name: Install dependencies
      run: npm ci
      
    - name: Run tests
      run: npm test
      
    - name: Build application
      run: npm run build
      
    - name: Build Docker image
      run: |
        docker build -t \${{ secrets.ECR_REGISTRY }}/${projectName.toLowerCase()}:latest .
        
    - name: Push to ECR
      run: |
        aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin \${{ secrets.ECR_REGISTRY }}
        docker push \${{ secrets.ECR_REGISTRY }}/${projectName.toLowerCase()}:latest
        
    - name: Deploy to ECS
      run: |
        aws ecs update-service --cluster your-cluster --service your-service --force-new-deployment

# Kubernetes Deployment (k8s/deployment.yaml)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${projectName.toLowerCase()}
  labels:
    app: ${projectName.toLowerCase()}
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ${projectName.toLowerCase()}
  template:
    metadata:
      labels:
        app: ${projectName.toLowerCase()}
    spec:
      containers:
      - name: ${projectName.toLowerCase()}
        image: ${projectName.toLowerCase()}:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: ${projectName.toLowerCase()}-secrets
              key: database-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: ${projectName.toLowerCase()}-secrets
              key: jwt-secret
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: ${projectName.toLowerCase()}-service
spec:
  selector:
    app: ${projectName.toLowerCase()}
  ports:
    - protocol: TCP
      port: 80
      targetPort: 3000
  type: LoadBalancer`;
}

function generateReadmeContent(projectName: string, projectType: string, prompt: string): string {
  return `A complete ${projectType} application built with modern full-stack technologies.

## 🚀 Features

${extractFeatures(prompt).map(f => `- ${f}`).join('\n')}

## 🛠️ Technology Stack

### Frontend
- **Framework**: Next.js with TypeScript
- **Styling**: Tailwind CSS
- **State Management**: React Context API
- **Routing**: Next.js App Router
- **Authentication**: NextAuth.js

### Backend
- **Runtime**: Node.js with Express
- **Language**: TypeScript
- **Database**: MongoDB with Mongoose
- **Authentication**: JWT with bcrypt
- **API**: RESTful endpoints

### DevOps
- **Containerization**: Docker
- **Orchestration**: Docker Compose
- **Cloud**: AWS ECS (or your preferred cloud)
- **CI/CD**: GitHub Actions
- **Monitoring**: Winston logging

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- MongoDB 4.4+
- Docker (optional)

### Setup

1. **Clone the repository**
   \`\`\`bash
   git clone https://github.com/your-username/${projectName.toLowerCase().replace(' ', '-')}
   cd ${projectName.toLowerCase().replace(' ', '-')}
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**
   \`\`\`bash
   cp .env.example .env
   # Edit .env with your configuration
   \`\`\`

4. **Start development servers**
   \`\`\`bash
   # Start MongoDB (if using Docker)
   docker-compose up -d mongo

   # Start backend server
   npm run dev:backend

   # Start frontend server
   npm run dev:frontend
   \`\`\`

5. **Access the application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:3001
   - API Documentation: http://localhost:3001/api/docs

## 🏗️ Project Structure

\`\`\`
${projectName.toLowerCase().replace(' ', '-')}/
├── frontend/                 # Next.js frontend application
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── pages/          # Next.js pages
│   │   ├── hooks/          # Custom React hooks
│   │   ├── utils/          # Utility functions
│   │   ├── types/          # TypeScript types
│   │   └── styles/         # CSS/SCSS files
│   ├── public/              # Static assets
│   └── package.json
├── backend/                 # Node.js backend application
│   ├── src/
│   │   ├── controllers/     # Route controllers
│   │   ├── models/         # Database models
│   │   ├── routes/         # API routes
│   │   ├── middleware/     # Express middleware
│   │   ├── services/       # Business logic
│   │   ├── utils/          # Utility functions
│   │   └── config/         # Configuration files
│   └── package.json
├── database/                # Database migrations and seeds
├── docker-compose.yml      # Docker compose configuration
├── Dockerfile              # Docker image configuration
├── .env.example           # Environment variables template
└── README.md              # This file
\`\`\`

## 🚀 Usage

### Development

\`\`\`bash
# Start all services
npm run dev

# Start only backend
npm run dev:backend

# Start only frontend
npm run dev:frontend

# Run tests
npm test

# Build for production
npm run build
\`\`\`

### Production

\`\`\`bash
# Build the application
npm run build

# Start production server
npm start

# Or use Docker
docker-compose up -d
\`\`\`

## 📚 API Documentation

### Authentication

\`\`\`typescript
// Login
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    email: 'user@example.com',
    password: 'password123'
  })
});

// Register
const response = await fetch('/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'John Doe',
    email: 'john@example.com',
    password: 'password123'
  })
});
\`\`\`

### Protected Routes

\`\`\`typescript
// Add JWT token to headers
const response = await fetch('/api/users', {
  headers: {
    'Authorization': 'Bearer YOUR_JWT_TOKEN',
    'Content-Type': 'application/json'
  }
});
\`\`\`

## 🔧 Configuration

### Environment Variables

\`\`\`bash
# Application
NODE_ENV=development
PORT=3001

# Database
DATABASE_URL=mongodb://localhost:27017/${projectName.toLowerCase()}

# Authentication
JWT_SECRET=your-super-secret-jwt-key
NEXTAUTH_SECRET=your-nextauth-secret-key

# Cloud (optional)
AWS_ACCESS_KEY_ID=your-aws-access-key
AWS_SECRET_ACCESS_KEY=your-aws-secret-key
AWS_REGION=us-east-1
\`\`\`

## 🧪 Testing

\`\`\`bash
# Run all tests
npm test

# Run unit tests
npm run test:unit

# Run integration tests
npm run test:integration

# Run E2E tests
npm run test:e2e

# Generate coverage report
npm run test:coverage
\`\`\`

## 🚀 Deployment

### Docker Deployment

\`\`\`bash
# Build Docker image
docker build -t ${projectName.toLowerCase()} .

# Run with Docker Compose
docker-compose up -d

# Or run standalone
docker run -p 3000:3000 ${projectName.toLowerCase()}
\`\`\`

### Cloud Deployment

The application is configured for easy deployment to various cloud platforms:

#### AWS ECS
1. Build and push to ECR
2. Update ECS service with new task definition
3. Use provided GitHub Actions workflow

#### Heroku
1. Connect to Heroku
2. Set environment variables
3. Deploy using Git

#### Vercel
1. Connect repository to Vercel
2. Configure environment variables
3. Deploy automatically on push

## 📊 Monitoring

### Application Metrics
- Response times
- Error rates
- User activity
- Database performance

### Logging
- Structured logging with Winston
- Different log levels (info, warn, error)
- File and console output

### Health Checks
- Application health endpoint: \`/health\`
- Database connection checks
- System resource monitoring

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (\`git checkout -b feature/amazing-feature\`)
3. Commit your changes (\`git commit -m 'Add amazing feature'\`)
4. Push to the branch (\`git push origin feature/amazing-feature\`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

If you have any questions or issues, please:

1. Check the [documentation](docs/)
2. Search existing [issues](issues)
3. Create a new issue if needed
4. Contact support at support@${projectName.toLowerCase()}.com

## 🙏 Acknowledgments

- [Next.js](https://nextjs.org/) - React framework
- [Express](https://expressjs.com/) - Node.js framework
- [MongoDB](https://www.mongodb.com/) - Database
- [Tailwind CSS](https://tailwindcss.com/) - CSS framework
- [Docker](https://www.docker.com/) - Containerization`;
}