import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { 
  imageGenerationLimiter, 
  checkRateLimit, 
  getClientIdentifier 
} from '@/lib/rateLimiter'

interface GenerateRequest {
  prompt: string
  negativePrompt?: string
  style: string
  aspectRatio: string
  quality: number
  numImages: number
  seed?: string
  imageSize: string
}

export async function POST(request: NextRequest) {
  try {
    // Check rate limit
    const clientId = getClientIdentifier(request)
    let rateLimitHeaders: Record<string, string> = {}
    
    try {
      rateLimitHeaders = checkRateLimit(imageGenerationLimiter, clientId)
    } catch (error: any) {
      if (error.name === 'RateLimitError') {
        return NextResponse.json(
          { 
            success: false, 
            error: 'Rate limit exceeded. Please wait before making more requests.',
            retryAfter: Math.ceil((error.resetTime - Date.now()) / 1000)
          },
          { 
            status: 429,
            headers: error.headers 
          }
        )
      }
      throw error
    }

    const body: GenerateRequest = await request.json()
    const { 
      prompt, 
      negativePrompt = '', 
      style, 
      aspectRatio, 
      quality, 
      numImages, 
      seed, 
      imageSize 
    } = body

    if (!prompt?.trim()) {
      return NextResponse.json(
        { success: false, error: 'Prompt is required' },
        { status: 400 }
      )
    }

    // Additional validation for numImages to prevent abuse
    if (numImages > 4) {
      return NextResponse.json(
        { success: false, error: 'Maximum 4 images per request allowed' },
        { status: 400 }
      )
    }

    // Create ZAI instance
    const zai = await ZAI.create()

    // Build enhanced prompt based on style and aspect ratio
    let enhancedPrompt = prompt

    // Add quality modifiers
    if (quality >= 90) {
      enhancedPrompt += ', masterpiece, best quality, ultra detailed, high resolution'
    } else if (quality >= 70) {
      enhancedPrompt += ', high quality, detailed'
    } else {
      enhancedPrompt += ', simple, basic quality'
    }

    // Add style modifiers
    switch (style) {
      case 'photorealistic':
        enhancedPrompt += ', photorealistic, highly detailed, professional photography, 8k, realistic'
        break
      case 'digital-art':
        enhancedPrompt += ', digital art, vibrant colors, modern illustration, concept art'
        break
      case 'anime':
        enhancedPrompt += ', anime style, manga art, Japanese animation style, cel shading'
        break
      case 'oil-painting':
        enhancedPrompt += ', oil painting, classical art, brushstrokes, canvas texture, renaissance'
        break
      case 'watercolor':
        enhancedPrompt += ', watercolor painting, soft edges, artistic, hand-painted, translucent'
        break
      case 'sketch':
        enhancedPrompt += ', pencil sketch, line art, black and white, detailed drawing, monochrome'
        break
      case '3d-render':
        enhancedPrompt += ', 3d render, CGI, digital art, volumetric lighting, blender, octane render'
        break
    }

    // Add aspect ratio guidance
    switch (aspectRatio) {
      case '16:9':
        enhancedPrompt += ', wide angle, landscape composition, panoramic'
        break
      case '9:16':
        enhancedPrompt += ', portrait composition, vertical orientation, full body'
        break
      case '4:3':
        enhancedPrompt += ', standard composition, balanced framing, traditional'
        break
      case '3:2':
        enhancedPrompt += ', photo composition, natural framing, dslr'
        break
    }

    // Add negative prompt if provided
    let finalPrompt = enhancedPrompt
    if (negativePrompt.trim()) {
      finalPrompt += `, avoiding: ${negativePrompt}`
    }

    console.log('Generating image with prompt:', finalPrompt)
    console.log('Parameters:', { numImages, imageSize, seed, quality })

    // Generate multiple images if requested
    const images = []
    for (let i = 0; i < numImages; i++) {
      try {
        // Add seed variation if multiple images and no specific seed
        const generationSeed = seed ? parseInt(seed) + i : undefined
        
        const response = await zai.images.generations.create({
          prompt: finalPrompt,
          size: imageSize as any,
          // Note: seed parameter might not be available in all AI models
          // This is a placeholder for when the feature becomes available
        })

        // Extract base64 image data
        const imageData = response.data[0]?.base64
        if (imageData) {
          images.push(imageData)
        }
      } catch (error) {
        console.error(`Failed to generate image ${i + 1}:`, error)
        // Continue with other images even if one fails
      }
    }

    if (images.length === 0) {
      throw new Error('No images were successfully generated')
    }

    // Return successful response with image data
    const response = NextResponse.json({
      success: true,
      images,
      prompt: finalPrompt,
      style,
      aspectRatio,
      imageSize,
      quality,
      numImages: images.length,
      seed,
      timestamp: new Date().toISOString()
    })

    // Add rate limit headers
    Object.entries(rateLimitHeaders).forEach(([key, value]) => {
      response.headers.set(key, value)
    })

    return response

  } catch (error) {
    console.error('Image generation error:', error)
    
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to generate image' 
      },
      { status: 500 }
    )
  }
}