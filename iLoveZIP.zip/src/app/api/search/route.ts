import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

interface SearchRequest {
  query: string;
  engine?: string;
  num?: number;
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: SearchRequest = await request.json();
    const { query, engine = 'web', num = 10 } = body;

    console.log('Search API Request:', { query, engine, num });

    if (!query || query.trim() === '') {
      return NextResponse.json(
        { error: 'Search query is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    
    const searchResult = await zai.functions.invoke("web_search", {
      query: query.trim(),
      num: num
    });

    const results: SearchResult[] = searchResult.map((result: any, index: number) => ({
      url: result.url,
      name: result.name,
      snippet: result.snippet,
      host_name: result.host_name,
      rank: index + 1,
      date: new Date().toISOString(),
      favicon: result.favicon || ''
    }));

    return NextResponse.json({
      results,
      query,
      engine,
      count: results.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Search API Error:', error);
    return NextResponse.json(
      { error: 'Failed to perform search' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');
    const engine = searchParams.get('engine') || 'web';
    const num = parseInt(searchParams.get('num') || '10');

    if (!query || query.trim() === '') {
      return NextResponse.json(
        { error: 'Search query is required' },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    
    const searchResult = await zai.functions.invoke("web_search", {
      query: query.trim(),
      num: num
    });

    const results: SearchResult[] = searchResult.map((result: any, index: number) => ({
      url: result.url,
      name: result.name,
      snippet: result.snippet,
      host_name: result.host_name,
      rank: index + 1,
      date: new Date().toISOString(),
      favicon: result.favicon || ''
    }));

    return NextResponse.json({
      results,
      query,
      engine,
      count: results.length,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Search API Error:', error);
    return NextResponse.json(
      { error: 'Failed to perform search' },
      { status: 500 }
    );
  }
}