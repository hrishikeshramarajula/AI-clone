import { NextRequest, NextResponse } from 'next/server';

interface Task {
  id: string;
  status: 'needs-review' | 'completed';
  timestamp: string;
  content: string;
}

// In-memory storage for demo purposes
// In a real application, you would use a database
let tasks: Task[] = [
  { 
    id: 'TASK-001', 
    status: 'needs-review' as const, 
    timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(), // 5 minutes ago
    content: 'Review AI model performance metrics' 
  },
  { 
    id: 'TASK-002', 
    status: 'needs-review' as const, 
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
    content: 'Optimize database queries for better performance' 
  },
  { 
    id: 'TASK-003', 
    status: 'completed' as const, 
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
    content: 'Implement user authentication system' 
  }
];

export async function GET(request: NextRequest) {
  try {
    // Return tasks with active count
    const activeCount = tasks.filter(t => t.status === 'needs-review').length;
    
    return NextResponse.json({
      tasks,
      activeCount,
      total: tasks.length
    });
  } catch (error) {
    console.error('Error fetching tasks:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tasks', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content, status = 'needs-review' } = body;

    if (!content) {
      return NextResponse.json(
        { error: 'Task content is required' },
        { status: 400 }
      );
    }

    const newTask: Task = {
      id: `TASK-${String(tasks.length + 1).padStart(3, '0')}`,
      status,
      timestamp: new Date().toISOString(),
      content
    };

    tasks.unshift(newTask); // Add to beginning of array

    return NextResponse.json({
      task: newTask,
      message: 'Task created successfully'
    });
  } catch (error) {
    console.error('Error creating task:', error);
    return NextResponse.json(
      { error: 'Failed to create task', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json(
        { error: 'Task ID and status are required' },
        { status: 400 }
      );
    }

    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex === -1) {
      return NextResponse.json(
        { error: 'Task not found' },
        { status: 404 }
      );
    }

    tasks[taskIndex].status = status;
    tasks[taskIndex].timestamp = new Date().toISOString();

    return NextResponse.json({
      task: tasks[taskIndex],
      message: 'Task updated successfully'
    });
  } catch (error) {
    console.error('Error updating task:', error);
    return NextResponse.json(
      { error: 'Failed to update task', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Task ID is required' },
        { status: 400 }
      );
    }

    const taskIndex = tasks.findIndex(t => t.id === id);
    if (taskIndex === -1) {
      return NextResponse.json(
        { error: 'Task not found' },
        { status: 404 }
      );
    }

    const deletedTask = tasks.splice(taskIndex, 1)[0];

    return NextResponse.json({
      task: deletedTask,
      message: 'Task deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting task:', error);
    return NextResponse.json(
      { error: 'Failed to delete task', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}