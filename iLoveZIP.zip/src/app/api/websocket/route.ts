import { NextRequest } from 'next/server';
import { Server } from 'socket.io';
import { createServer } from 'http';

// Create HTTP server
const httpServer = createServer();
const io = new Server(httpServer, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Store active connections
const connections = new Map<string, any>();

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  // Store connection
  connections.set(socket.id, socket);

  // Handle AI chat messages
  socket.on('ai_message', async (data: { message: string; model: string; searchType: string }) => {
    try {
      console.log('AI message received:', data);
      
      // Simulate processing
      socket.emit('ai_message_status', { status: 'processing', messageId: data.message });
      
      // Here you would integrate with the AI API
      // For now, we'll simulate a response
      setTimeout(() => {
        socket.emit('ai_message_response', {
          id: Date.now().toString(),
          type: 'assistant',
          content: `This is a simulated response to: "${data.message}". Mode: ${data.searchType}, Model: ${data.model}`,
          timestamp: new Date().toISOString(),
          model: data.model,
          searchResults: []
        });
      }, 1000);
      
    } catch (error) {
      console.error('Error processing AI message:', error);
      socket.emit('ai_message_error', { error: 'Failed to process message' });
    }
  });

  // Handle search requests
  socket.on('search_request', async (data: { query: string; engine?: string }) => {
    try {
      console.log('Search request received:', data);
      
      socket.emit('search_status', { status: 'searching', query: data.query });
      
      // Simulate search results
      setTimeout(() => {
        const mockResults = [
          {
            url: `https://example.com/result1`,
            name: `Search Result for "${data.query}"`,
            snippet: `This is a mock search result snippet for the query: ${data.query}`,
            host_name: 'example.com',
            rank: 1,
            date: new Date().toISOString(),
            favicon: ''
          }
        ];
        
        socket.emit('search_results', {
          query: data.query,
          results: mockResults,
          count: mockResults.length
        });
      }, 1500);
      
    } catch (error) {
      console.error('Error processing search:', error);
      socket.emit('search_error', { error: 'Failed to perform search' });
    }
  });

  // Handle tool calls (similar to the Python backend)
  socket.on('tool_call', async (data: { tool: string; [key: string]: any }) => {
    try {
      console.log('Tool call received:', data);
      
      if (data.tool === 'search') {
        const { query, engine = 'web' } = data;
        
        // Simulate search
        const mockResults = [
          {
            title: `Search Result for "${query}"`,
            snippet: `Mock search result for query: ${query}`,
            url: `https://example.com/search?q=${encodeURIComponent(query)}`
          }
        ];
        
        socket.emit('tool_response', {
          tool: 'search',
          results: mockResults
        });
      } else {
        socket.emit('tool_error', { error: `Unsupported tool: ${data.tool}` });
      }
      
    } catch (error) {
      console.error('Error processing tool call:', error);
      socket.emit('tool_error', { error: 'Failed to process tool call' });
    }
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    connections.delete(socket.id);
  });

  // Send welcome message
  socket.emit('connected', {
    connectionId: socket.id,
    message: 'Connected to AI Chat WebSocket Server',
    timestamp: new Date().toISOString()
  });
});

// Start the server
const PORT = process.env.WEBSOCKET_PORT || 3001;
httpServer.listen(PORT, () => {
  console.log(`WebSocket server running on port ${PORT}`);
});

export async function GET(request: NextRequest) {
  return new Response('WebSocket server is running', { status: 200 });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, data } = body;
    
    // Broadcast to all connected clients
    io.emit(type, data);
    
    return Response.json({ success: true, message: 'Message broadcasted' });
  } catch (error) {
    console.error('Error broadcasting message:', error);
    return Response.json({ error: 'Failed to broadcast message' }, { status: 500 });
  }
}