'use client';

import React, { useState, useRef } from 'react';
import {
  Search,
  ChevronDown,
  Calendar,
  FileText,
  Globe,
  Settings,
  Send,
  Loader2,
  Brain,
  Code,
  BarChart3,
  MessageSquare,
  Image as ImageIcon,
  Layers,
  Upload,
  X,
  Play,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileUploader } from '@/components/FileUploader';
import { CodePreview } from '@/components/CodePreview';

interface Task {
  id: string;
  status: 'needs-review' | 'completed';
  timestamp: string;
  content: string;
}

interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'code' | 'search' | 'analysis' | 'fullstack';
}

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  model?: string;
  searchResults?: any[];
  imageData?: string;
  imagePrompt?: string;
  fullstackProject?: {
    frontend: string;
    backend: string;
    projectStructure: string;
    setupInstructions: string;
  };
}

interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

interface UploadedFile {
  name: string;
  size: number;
  type: string;
  path: string;
  content?: string;
  timestamp: string;
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<'active' | 'archived'>('active');
  const [searchQuery, setSearchQuery] = useState('');
  const [showTasks, setShowTasks] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [model, setModel] = useState('GPT-4');
  const [isModelOpen, setIsModelOpen] = useState(false);
  const [isModeOpen, setIsModeOpen] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [chatMode, setChatMode] = useState<'chat' | 'search' | 'code' | 'analysis' | 'image' | 'fullstack'>('search');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [showCodePreview, setShowCodePreview] = useState(false);
  const [currentProject, setCurrentProject] = useState<any>(null);
  const [showFileUploader, setShowFileUploader] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const models: AIModel[] = [
    { 
      id: 'gpt-4', 
      name: 'GPT-4', 
      provider: 'OpenAI', 
      description: 'Most capable model', 
      apiModel: 'gpt-4',
      intelligence: 'High',
      contextLength: '128K',
      inputCredits: '10K',
      outputCredits: '30K',
      specialty: 'chat'
    },
    { 
      id: 'glm-4.5', 
      name: 'GLM-4.5', 
      provider: 'Zhipu AI', 
      description: 'Latest Chinese AI model', 
      apiModel: 'glm-4.5',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '8K',
      outputCredits: '25K',
      specialty: 'search'
    },
    { 
      id: 'gpt-3.5-turbo', 
      name: 'GPT-3.5 Turbo', 
      provider: 'OpenAI', 
      description: 'Fast and efficient', 
      apiModel: 'gpt-3.5-turbo',
      intelligence: 'Medium',
      contextLength: '16K',
      inputCredits: '5K',
      outputCredits: '15K',
      specialty: 'chat'
    },
    { 
      id: 'claude-3-opus', 
      name: 'Claude 3 Opus', 
      provider: 'Anthropic', 
      description: 'Advanced reasoning', 
      apiModel: 'claude-3-opus',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '15K',
      outputCredits: '75K',
      specialty: 'analysis'
    },
    { 
      id: 'claude-3-sonnet', 
      name: 'Claude 3 Sonnet', 
      provider: 'Anthropic', 
      description: 'Balanced performance', 
      apiModel: 'claude-3-sonnet',
      intelligence: 'High',
      contextLength: '200K',
      inputCredits: '3K',
      outputCredits: '15K',
      specialty: 'analysis'
    },
    { 
      id: 'gemini-pro', 
      name: 'Gemini Pro', 
      provider: 'Google', 
      description: 'Multimodal capabilities', 
      apiModel: 'gemini-pro',
      intelligence: 'High',
      contextLength: '32K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'search'
    },
    { 
      id: 'llama-3-70b', 
      name: 'Llama 3 70B', 
      provider: 'Meta', 
      description: 'Open source powerhouse', 
      apiModel: 'llama-3-70b',
      intelligence: 'High',
      contextLength: '8K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'code'
    },
    { 
      id: 'mixtral-8x7b', 
      name: 'Mixtral 8x7B', 
      provider: 'Mistral', 
      description: 'Mixture of experts', 
      apiModel: 'mixtral-8x7b',
      intelligence: 'High',
      contextLength: '32K',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'code'
    },
    { 
      id: 'command-r-plus', 
      name: 'Command R+', 
      provider: 'Cohere', 
      description: 'Enterprise grade', 
      apiModel: 'command-r-plus',
      intelligence: 'High',
      contextLength: '128K',
      inputCredits: '5K',
      outputCredits: '15K',
      specialty: 'search'
    },
    // Hugging Face Models for Image Generation
    { 
      id: 'stable-diffusion', 
      name: 'Stable Diffusion', 
      provider: 'Hugging Face', 
      description: 'Image generation model', 
      apiModel: 'stabilityai/stable-diffusion-2-1',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'midjourney', 
      name: 'MidJourney', 
      provider: 'Hugging Face', 
      description: 'Artistic image generation', 
      apiModel: 'prompthero/openjourney',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'dalle', 
      name: 'DALL-E', 
      provider: 'Hugging Face', 
      description: 'OpenAI image generation', 
      apiModel: 'openai/dall-e-2',
      intelligence: 'Very High',
      contextLength: 'N/A',
      inputCredits: 'Free',
      outputCredits: 'Free',
      specialty: 'image'
    },
    { 
      id: 'gpt-4-turbo', 
      name: 'GPT-4 Turbo', 
      provider: 'OpenAI', 
      description: 'Optimized for full-stack development', 
      apiModel: 'gpt-4-turbo',
      intelligence: 'Very High',
      contextLength: '128K',
      inputCredits: '10K',
      outputCredits: '30K',
      specialty: 'fullstack'
    },
    { 
      id: 'claude-3-opus', 
      name: 'Claude 3 Opus', 
      provider: 'Anthropic', 
      description: 'Advanced reasoning for full-stack', 
      apiModel: 'claude-3-opus',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '15K',
      outputCredits: '75K',
      specialty: 'fullstack'
    },
    { 
      id: 'z-ai-fullstack', 
      name: 'Z-AI Full Stack', 
      provider: 'Zhipu AI', 
      description: 'Integrated full-stack development assistant', 
      apiModel: 'glm-4.5',
      intelligence: 'Very High',
      contextLength: '200K',
      inputCredits: '8K',
      outputCredits: '25K',
      specialty: 'fullstack'
    }
  ];

  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeCount, setActiveCount] = useState(0);

  // Load tasks from API or localStorage
  React.useEffect(() => {
    const loadTasks = async () => {
      try {
        // Try to load from API first
        const response = await fetch('/api/tasks');
        if (response.ok) {
          const data = await response.json();
          setTasks(data.tasks || []);
          setActiveCount(data.tasks?.filter((t: Task) => t.status === 'needs-review').length || 0);
        } else {
          // Fallback to localStorage
          const savedTasks = localStorage.getItem('ai-tasks');
          if (savedTasks) {
            const parsedTasks = JSON.parse(savedTasks);
            setTasks(parsedTasks);
            setActiveCount(parsedTasks.filter((t: Task) => t.status === 'needs-review').length);
          }
        }
      } catch (error) {
        console.error('Failed to load tasks:', error);
        // Fallback to empty tasks
        setTasks([]);
        setActiveCount(0);
      }
    };
    
    loadTasks();
  }, []);

  // Filter models based on selected mode
  const getFilteredModels = () => {
    if (chatMode === 'image') {
      return models.filter(model => model.specialty === 'image' || !model.specialty);
    } else if (chatMode === 'code') {
      // Include GLM-4.5 first, then other code models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'code' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else if (chatMode === 'search') {
      // Include GLM-4.5 first, then other search models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'search' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else if (chatMode === 'analysis') {
      // Include GLM-4.5 first, then other analysis models and general models
      const glm45 = models.find(m => m.id === 'glm-4.5');
      const otherModels = models.filter(model => model.specialty === 'analysis' || (!model.specialty && model.id !== 'glm-4.5'));
      return glm45 ? [glm45, ...otherModels] : otherModels;
    } else if (chatMode === 'fullstack') {
      // Include fullstack models first, then other capable models
      const fullstackModels = models.filter(model => model.specialty === 'fullstack');
      const otherModels = models.filter(model => model.specialty === 'code' || model.specialty === 'analysis' || (!model.specialty && !model.specialty?.includes('image')));
      return [...fullstackModels, ...otherModels];
    } else {
      return models.filter(model => model.specialty === 'chat' || !model.specialty);
    }
  };

  const filteredModels = getFilteredModels();

  // Auto-select first available model when mode changes
  React.useEffect(() => {
    if (filteredModels.length > 0) {
      const currentModelExists = filteredModels.some(m => m.name === model);
      if (!currentModelExists) {
        setModel(filteredModels[0].name);
      }
    }
  }, [chatMode, filteredModels]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    console.log('Sending message:', { message: inputValue, model, chatMode, filesCount: uploadedFiles.length });

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToSend = inputValue;
    setInputValue('');
    setIsLoading(true);

    try {
      // Check if the model is available first
      const healthCheck = await fetch('/api/ai');
      if (!healthCheck.ok) {
        throw new Error('AI service is currently unavailable');
      }

      const healthData = await healthCheck.json();
      console.log('Health status:', healthData.health);
      
      if (healthData.health?.status === 'unhealthy') {
        throw new Error('AI service is currently unavailable. Please try again in a moment.');
      } else if (healthData.health?.status === 'initializing') {
        throw new Error('AI service is starting up. This should only take a moment. Please try again.');
      }

      let response: string;
      let searchResults: any[] = [];
      let imageData: string | undefined;
      let imagePrompt: string | undefined;
      let fullstackProject: any = undefined;

      // Handle fullstack mode differently
      if (chatMode === 'fullstack') {
        console.log('Generating full-stack project for:', messageToSend);
        try {
          const fullstackResponse = await fetch('/api/fullstack', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              prompt: messageToSend,
              model,
              files: uploadedFiles,
            }),
          });

          if (!fullstackResponse.ok) {
            throw new Error('Failed to generate full-stack project');
          }

          const fullstackData = await fullstackResponse.json();
          console.log('Full-stack project generated:', fullstackData);

          if (fullstackData.success && fullstackData.project) {
            fullstackProject = fullstackData.project;
            response = `I've generated a complete full-stack project for: "${messageToSend}". 

The project includes:
• **Frontend**: React/Next.js components with TypeScript
• **Backend**: FastAPI server with proper routing
• **Project Structure**: Organized file hierarchy
• **Setup Instructions**: Complete deployment guide

You can view the generated code, copy it to your clipboard, or download the files. The project is ready for development and deployment!`;
            
            // Set the current project for preview
            setCurrentProject(fullstackProject);
          } else {
            throw new Error('No project data received');
          }
        } catch (fullstackError) {
          console.error('Full-stack generation error:', fullstackError);
          response = `I apologize, but I encountered an issue while generating the full-stack project. 

This could be due to:
• AI service initialization (wait a moment and try again)
• Temporary service unavailability
• Network connectivity issues
• High demand on AI services

Please try again in a few moments. If the problem persists, you may want to:
• Wait 10-20 seconds for the AI service to fully initialize
• Check your internet connection
• Try selecting a different AI model
• Refresh the page and try again`;
        }
      } else {
        // Handle other modes with the existing API
        const aiResponse = await fetch('/api/ai', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: messageToSend,
            model,
            searchType: chatMode,
          }),
        });

        console.log('API response status:', aiResponse.status);

        if (!aiResponse.ok) {
          const errorData = await aiResponse.json();
          console.error('API error response:', errorData);
          throw new Error(errorData.error || `Failed to get AI response (${aiResponse.status})`);
        }

        const data = await aiResponse.json();
        console.log('API response data:', data);
        
        response = data.response;
        searchResults = data.searchResults || [];
        imageData = data.imageData;
        imagePrompt = data.imagePrompt;
      }

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response,
        timestamp: new Date().toISOString(),
        model: model,
        searchResults: searchResults,
        imageData: imageData,
        imagePrompt: imagePrompt,
        fullstackProject: fullstackProject,
      };

      setMessages(prev => [...prev, assistantMessage]);
      
      // Auto-remove blur and focus when response is received
      setIsInputFocused(false);
      
      // Remove focus from textarea
      if (inputRef.current) {
        inputRef.current.blur();
      }
      
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: `I apologize, but I encountered an issue while processing your request: ${error instanceof Error ? error.message : 'Unknown error'}. 

This could be due to:
• AI service is still starting up (wait a moment and try again)
• Temporary service unavailability
• Network connectivity issues
• High demand on AI services

Please try again in a few moments. If the problem persists, you may want to:
• Wait 10-20 seconds for the AI service to fully initialize
• Check your internet connection
• Try selecting a different AI model
• Refresh the page and try again`,
        timestamp: new Date().toISOString(),
      };
      setMessages(prev => [...prev, errorMessage]);
      
      // Also remove blur on error
      setIsInputFocused(false);
      if (inputRef.current) {
        inputRef.current.blur();
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'search': return <Search className="w-4 h-4" />;
      case 'code': return <Code className="w-4 h-4" />;
      case 'analysis': return <BarChart3 className="w-4 h-4" />;
      case 'image': return <ImageIcon className="w-4 h-4" />;
      case 'fullstack': return <Layers className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  const getModeLabel = (mode: string) => {
    switch (mode) {
      case 'search': return 'Web Search';
      case 'code': return 'Code Generation';
      case 'analysis': return 'Analysis';
      case 'image': return 'Image Generation';
      case 'fullstack': return 'Full Stack';
      default: return 'Chat';
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className={`flex h-screen ${isInputFocused ? 'blur-bg bg-gray-100' : ''}`}>
      {/* Sidebar */}
      <aside className={`w-64 bg-white border-r border-gray-200 flex flex-col transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
        <div className="flex items-center p-4 gap-2">
          <div className="bg-blue-500 text-white w-8 h-8 rounded-md flex items-center justify-center font-semibold">
            B
          </div>
          <span className="font-medium text-gray-900">BOT</span>
          <ChevronDown className="text-gray-500" />
        </div>

        <div className="relative px-3 mb-3">
          <Search className="absolute top-1/2 left-6 transform -translate-y-1/2 text-gray-500" />
          <Input
            type="text"
            placeholder="Search"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-8"
          />
          <span className="absolute top-1/2 right-6 transform -translate-y-1/2 bg-gray-100 px-2 py-1 rounded text-xs text-gray-500">
            ⌘K
          </span>
        </div>

        <nav className="flex flex-col gap-1 px-3">
          <Button variant="ghost" className="justify-start">
            <Calendar className="w-4 h-4 mr-2" />
            Tasks
          </Button>
          <Button variant="ghost" className="justify-start">
            <FileText className="w-4 h-4 mr-2" />
            Files
          </Button>
          <Button variant="ghost" className="justify-start">
            <Globe className="w-4 h-4 mr-2" />
            Apps
          </Button>
          <Button variant="ghost" className="justify-start">
            <Settings className="w-4 h-4 mr-2" />
            Configuration
          </Button>
        </nav>

        <div className="px-3 mt-auto pb-4">
          <Button
            variant="ghost"
            className="w-full justify-between"
            onClick={() => setShowTasks(!showTasks)}
          >
            <span className="font-medium">Active tasks ({activeCount})</span>
            <ChevronDown className={`text-gray-500 transition-transform ${showTasks ? 'rotate-180' : ''}`} />
          </Button>
          {showTasks && (
            <div className="mt-2 flex flex-col gap-2">
              {tasks.map(t => (
                <div key={t.id} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500" />
                  <div className="text-xs text-gray-600">
                    <div className="font-medium">Needs review</div>
                    <div className="text-gray-400">{t.timestamp}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* Main */}
      <main className={`flex-1 flex flex-col bg-white transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
        <header className={`flex items-center p-4 border-b border-gray-200 gap-4 transition-all duration-300 ${isInputFocused ? 'invisible' : ''}`}>
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as 'active' | 'archived')}>
            <TabsList>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="archived">Archived</TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="ml-auto text-gray-500">Display</div>
        </header>

        <section className={`flex-1 overflow-hidden transition-all duration-300 ${isInputFocused ? 'blur-sm opacity-70' : ''}`}>
          <ScrollArea className="h-full p-4 bg-gray-50">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Brain className="w-16 h-16 text-blue-500 mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-2">AI Search Engine</h2>
                <p className="text-gray-600 mb-6">Ask anything and get intelligent responses with web search capabilities</p>
                <div className="grid grid-cols-3 gap-4 max-w-lg">
                  <Button
                    variant={chatMode === 'chat' ? 'default' : 'outline'}
                    onClick={() => setChatMode('chat')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <MessageSquare className="w-6 h-6" />
                    <span className="text-sm">Chat</span>
                  </Button>
                  <Button
                    variant={chatMode === 'search' ? 'default' : 'outline'}
                    onClick={() => setChatMode('search')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Search className="w-6 h-6" />
                    <span className="text-sm">Web Search</span>
                  </Button>
                  <Button
                    variant={chatMode === 'code' ? 'default' : 'outline'}
                    onClick={() => setChatMode('code')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Code className="w-6 h-6" />
                    <span className="text-sm">Code</span>
                  </Button>
                  <Button
                    variant={chatMode === 'analysis' ? 'default' : 'outline'}
                    onClick={() => setChatMode('analysis')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <BarChart3 className="w-6 h-6" />
                    <span className="text-sm">Analysis</span>
                  </Button>
                  <Button
                    variant={chatMode === 'image' ? 'default' : 'outline'}
                    onClick={() => setChatMode('image')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <ImageIcon className="w-6 h-6" />
                    <span className="text-sm">Image</span>
                  </Button>
                  <Button
                    variant={chatMode === 'fullstack' ? 'default' : 'outline'}
                    onClick={() => setChatMode('fullstack')}
                    className="flex flex-col items-center gap-2 h-auto py-4"
                  >
                    <Layers className="w-6 h-6" />
                    <span className="text-sm">Full Stack</span>
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${
                      message.type === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    {message.type === 'assistant' && (
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <Brain className="w-4 h-4 text-white" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        message.type === 'user'
                          ? 'bg-blue-500 text-white'
                          : 'bg-white border border-gray-200'
                      }`}
                    >
                      <div className="text-sm whitespace-pre-wrap">{message.content}</div>
                      {message.model && (
                        <div className="text-xs mt-2 opacity-70">
                          {message.model} • {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      )}
                      {message.searchResults && message.searchResults.length > 0 && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs font-medium mb-2 text-gray-600">Search Results:</div>
                          {message.searchResults.slice(0, 3).map((result: SearchResult, index: number) => (
                            <div key={index} className="mb-2 p-2 bg-gray-50 rounded text-xs">
                              <div className="font-medium text-gray-900">{result.name}</div>
                              <div className="text-gray-600 mt-1">{result.snippet}</div>
                              <div className="text-gray-400 mt-1">{result.host_name}</div>
                            </div>
                          ))}
                        </div>
                      )}
                      {message.imageData && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs font-medium mb-2 text-gray-600">Generated Image:</div>
                          <div className="mt-2">
                            <img 
                              src={`data:image/png;base64,${message.imageData}`} 
                              alt={message.imagePrompt || "Generated image"}
                              className="max-w-full h-auto rounded-lg border border-gray-200"
                            />
                            {message.imagePrompt && (
                              <div className="text-xs text-gray-500 mt-2 italic">
                                Prompt: "{message.imagePrompt}"
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      {message.fullstackProject && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-xs font-medium mb-2 text-gray-600">Generated Full-Stack Project:</div>
                          <div className="mt-2">
                            <Button
                              size="sm"
                              onClick={() => {
                                setCurrentProject(message.fullstackProject);
                                setShowCodePreview(true);
                              }}
                              className="flex items-center gap-2"
                            >
                              <Play className="w-4 h-4" />
                              View Generated Code
                            </Button>
                            <div className="text-xs text-gray-500 mt-2">
                              Click to view the complete React + FastAPI project with frontend and backend code
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    {message.type === 'user' && (
                      <div className="w-8 h-8 bg-gray-500 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-white text-sm font-medium">U</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </section>

        {/* Input Area - This will NOT be blurred when focused */}
        <div className={`border-t border-gray-200 p-4 bg-white transition-all duration-300 ${isInputFocused ? 'z-50 shadow-lg' : ''}`}>
          <div className="flex items-center justify-between mb-4 pr-12">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-700">Mode:</span>
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModeOpen(!isModeOpen)}
                  className="flex items-center gap-1"
                >
                  {getModeIcon(chatMode)}
                  {getModeLabel(chatMode)}
                  <ChevronDown className={`w-3 h-3 transition-transform ${isModeOpen ? 'rotate-180' : ''}`} />
                </Button>
                {isModeOpen && (
                  <div className="absolute bottom-full left-0 mb-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="p-2">
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('search');
                          setIsModeOpen(false);
                        }}
                      >
                        <Search className="w-3 h-3" />
                        Web Search
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('code');
                          setIsModeOpen(false);
                        }}
                      >
                        <Code className="w-3 h-3" />
                        Code Generation
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('analysis');
                          setIsModeOpen(false);
                        }}
                      >
                        <BarChart3 className="w-3 h-3" />
                        Analysis
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('image');
                          setIsModeOpen(false);
                        }}
                      >
                        <ImageIcon className="w-3 h-3" />
                        Image Generation
                      </button>
                      <button
                        className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm flex items-center gap-2"
                        onClick={() => {
                          setChatMode('fullstack');
                          setIsModeOpen(false);
                        }}
                      >
                        <Layers className="w-3 h-3" />
                        Full Stack Development
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-2 pr-4">
              <span className="text-sm font-medium text-gray-700">Model:</span>
              <div className="relative">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsModelOpen(!isModelOpen)}
                  className="flex items-center gap-1 min-w-[120px]"
                >
                  {model || 'Select Model'}
                  <ChevronDown className={`w-3 h-3 transition-transform ${isModelOpen ? 'rotate-180' : ''}`} />
                </Button>
                {isModelOpen && (
                  <div className="absolute bottom-full left-0 mb-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                    <div className="p-2">
                      {filteredModels.map((m) => (
                        <button
                          key={m.id}
                          className="w-full text-left px-2 py-1 hover:bg-gray-100 rounded text-sm"
                          onClick={() => {
                            setModel(m.name);
                            setIsModelOpen(false);
                          }}
                        >
                          <div className="font-medium">{m.name}</div>
                          <div className="text-xs text-gray-500">{m.provider}</div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* File Uploader - Only show in fullstack mode */}
          {chatMode === 'fullstack' && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFileUploader(!showFileUploader)}
                  className="flex items-center gap-2"
                >
                  <Upload className="w-4 h-4" />
                  {showFileUploader ? 'Hide Files' : 'Upload Files'}
                </Button>
                {uploadedFiles.length > 0 && (
                  <Badge variant="secondary">
                    {uploadedFiles.length} file{uploadedFiles.length !== 1 ? 's' : ''} uploaded
                  </Badge>
                )}
              </div>
              
              {showFileUploader && (
                <FileUploader
                  onFilesChange={setUploadedFiles}
                  maxFiles={5}
                />
              )}
            </div>
          )}
          
          <div className="flex gap-2 mb-6">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyPress}
              onFocus={() => setIsInputFocused(true)}
              onBlur={() => setIsInputFocused(false)}
              placeholder={`Start ${getModeLabel(chatMode).toLowerCase()} with AI...`}
              className="flex-1 resize-none border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
              rows={1}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              size="icon"
              className="transition-all duration-300"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </Button>
          </div>
          
          {/* Current Mode Indicator */}
          <div className="flex items-center justify-center">
            <Badge variant="secondary" className="flex items-center gap-2">
              {getModeIcon(chatMode)}
              <span>Current Mode: {getModeLabel(chatMode)}</span>
            </Badge>
          </div>
        </div>
      </main>
      
      {/* Code Preview Modal */}
      <CodePreview
        project={currentProject}
        isVisible={showCodePreview}
        onClose={() => setShowCodePreview(false)}
      />
    </div>
  );
}