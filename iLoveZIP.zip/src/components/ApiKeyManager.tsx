'use client';

import React, { useState, useEffect } from 'react';
import { Key, Eye, EyeOff, Plus, Trash2, CheckCircle, XCircle, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AI_PROVIDERS, getProviderStats, getProvidersByFeature } from '@/lib/aiProviders';
import { multiProviderAI } from '@/lib/multiProviderAI';

interface ApiKey {
  providerId: string;
  key: string;
  isVisible: boolean;
  isValid: boolean;
  lastChecked?: string;
}

export default function ApiKeyManager() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [newKey, setNewKey] = useState({ providerId: '', key: '' });
  const [showAddForm, setShowAddForm] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [providerHealth, setProviderHealth] = useState<Record<string, boolean>>({});

  useEffect(() => {
    loadApiKeys();
    checkAllProvidersHealth();
  }, []);

  const loadApiKeys = () => {
    const keys: ApiKey[] = AI_PROVIDERS.map(provider => ({
      providerId: provider.id,
      key: getEnvKey(provider.id),
      isVisible: false,
      isValid: !!getEnvKey(provider.id)
    }));
    setApiKeys(keys);
  };

  const getEnvKey = (providerId: string): string => {
    const envMap: Record<string, string> = {
      'openai': 'VITE_OPENAI_API_KEY',
      'openrouter': 'VITE_OPENROUTER_API_KEY',
      'huggingface': 'VITE_HUGGINGFACE_API_KEY',
      'ollama': 'VITE_OLLAMA_API_KEY',
      'z-ai': 'integrated'
    };
    
    const envKey = envMap[providerId];
    return envKey === 'integrated' ? 'integrated' : (process.env[envKey] || '');
  };

  const checkAllProvidersHealth = async () => {
    const health: Record<string, boolean> = {};
    
    for (const provider of AI_PROVIDERS) {
      if (provider.apiKey) {
        try {
          health[provider.id] = await multiProviderAI.checkProviderHealth(provider.id);
        } catch (error) {
          health[provider.id] = false;
        }
      } else {
        health[provider.id] = false;
      }
    }
    
    setProviderHealth(health);
  };

  const handleAddKey = () => {
    if (!newKey.providerId || !newKey.key) return;
    
    // In a real app, you would save this to environment variables or secure storage
    // For now, we'll just update the state
    const updatedKeys = apiKeys.map(key => 
      key.providerId === newKey.providerId 
        ? { ...key, key: newKey.key, isValid: true }
        : key
    );
    
    setApiKeys(updatedKeys);
    setNewKey({ providerId: '', key: '' });
    setShowAddForm(false);
    
    // Check health after adding key
    setTimeout(checkAllProvidersHealth, 1000);
  };

  const handleDeleteKey = (providerId: string) => {
    const updatedKeys = apiKeys.map(key => 
      key.providerId === providerId 
        ? { ...key, key: '', isValid: false }
        : key
    );
    
    setApiKeys(updatedKeys);
    
    // Update health status
    setProviderHealth(prev => ({ ...prev, [providerId]: false }));
  };

  const toggleKeyVisibility = (providerId: string) => {
    setApiKeys(keys => 
      keys.map(key => 
        key.providerId === providerId 
          ? { ...key, isVisible: !key.isVisible }
          : key
      )
    );
  };

  const checkProviderHealth = async (providerId: string) => {
    setIsChecking(true);
    try {
      const isHealthy = await multiProviderAI.checkProviderHealth(providerId);
      setProviderHealth(prev => ({ ...prev, [providerId]: isHealthy }));
    } catch (error) {
      setProviderHealth(prev => ({ ...prev, [providerId]: false }));
    } finally {
      setIsChecking(false);
    }
  };

  const stats = getProviderStats();
  const providersByFeature = {
    chat: getProvidersByFeature('chat'),
    code: getProvidersByFeature('code'),
    analysis: getProvidersByFeature('analysis'),
    imageGeneration: getProvidersByFeature('imageGeneration'),
    vision: getProvidersByFeature('vision')
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Settings className="w-8 h-8 text-blue-500" />
            AI Provider Configuration
          </h1>
          <p className="text-gray-600 mt-2">
            Manage your AI API keys and configure multiple providers for enhanced capabilities
          </p>
        </div>
        <Button onClick={checkAllProvidersHealth} disabled={isChecking}>
          {isChecking ? 'Checking...' : 'Check All Health'}
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-500">{stats.availableProviders}/{stats.totalProviders}</div>
            <div className="text-sm text-gray-500">Providers Available</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-500">{stats.availableModels}</div>
            <div className="text-sm text-gray-500">Models Available</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-500">{stats.categories.chat}</div>
            <div className="text-sm text-gray-500">Chat Models</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-500">{stats.categories.code}</div>
            <div className="text-sm text-gray-500">Code Models</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="keys" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="keys">API Keys</TabsTrigger>
          <TabsTrigger value="providers">Providers</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="models">Models</TabsTrigger>
        </TabsList>

        {/* API Keys Tab */}
        <TabsContent value="keys" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>API Keys Management</CardTitle>
                <Button 
                  onClick={() => setShowAddForm(!showAddForm)}
                  variant={showAddForm ? "outline" : "default"}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Key
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Add Key Form */}
              {showAddForm && (
                <div className="border rounded-lg p-4 bg-gray-50">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="provider">Provider</Label>
                      <select
                        id="provider"
                        className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
                        value={newKey.providerId}
                        onChange={(e) => setNewKey(prev => ({ ...prev, providerId: e.target.value }))}
                      >
                        <option value="">Select Provider</option>
                        {AI_PROVIDERS.map(provider => (
                          <option key={provider.id} value={provider.id}>
                            {provider.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="apiKey">API Key</Label>
                      <Input
                        id="apiKey"
                        type="password"
                        placeholder="Enter API key"
                        value={newKey.key}
                        onChange={(e) => setNewKey(prev => ({ ...prev, key: e.target.value }))}
                        className="mt-1"
                      />
                    </div>
                    <div className="flex items-end gap-2">
                      <Button onClick={handleAddKey} disabled={!newKey.providerId || !newKey.key}>
                        Add
                      </Button>
                      <Button variant="outline" onClick={() => setShowAddForm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* API Keys List */}
              <div className="space-y-3">
                {apiKeys.map((apiKey) => {
                  const provider = AI_PROVIDERS.find(p => p.id === apiKey.providerId);
                  const isHealthy = providerHealth[apiKey.providerId];
                  
                  return (
                    <div key={apiKey.providerId} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          {isHealthy !== undefined && (
                            isHealthy ? 
                              <CheckCircle className="w-5 h-5 text-green-500" /> : 
                              <XCircle className="w-5 h-5 text-red-500" />
                          )}
                          <div>
                            <div className="font-medium">{provider?.name}</div>
                            <div className="text-sm text-gray-500">{provider?.description}</div>
                          </div>
                        </div>
                        <Badge variant={apiKey.isValid ? "default" : "secondary"}>
                          {apiKey.isValid ? "Active" : "Inactive"}
                        </Badge>
                        <Badge variant="outline">{provider?.category}</Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <div className="font-mono text-sm bg-gray-100 px-2 py-1 rounded">
                          {apiKey.isVisible ? apiKey.key : apiKey.key ? '•'.repeat(20) : 'No key'}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleKeyVisibility(apiKey.providerId)}
                          disabled={!apiKey.key}
                        >
                          {apiKey.isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => checkProviderHealth(apiKey.providerId)}
                          disabled={isChecking}
                        >
                          Check
                        </Button>
                        {apiKey.providerId !== 'z-ai' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteKey(apiKey.providerId)}
                            disabled={!apiKey.key}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Providers Tab */}
        <TabsContent value="providers" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {AI_PROVIDERS.map((provider) => {
              const isHealthy = providerHealth[provider.id];
              const keyCount = provider.models.length;
              
              return (
                <Card key={provider.id} className="relative">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{provider.name}</CardTitle>
                      {isHealthy !== undefined && (
                        isHealthy ? 
                          <CheckCircle className="w-5 h-5 text-green-500" /> : 
                          <XCircle className="w-5 h-5 text-red-500" />
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{provider.description}</p>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span>Status:</span>
                        <Badge variant={provider.apiKey ? "default" : "secondary"}>
                          {provider.apiKey ? "Configured" : "Not Configured"}
                        </Badge>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <span>Models:</span>
                        <span>{keyCount}</span>
                      </div>
                      
                      <div className="flex justify-between text-sm">
                        <span>Category:</span>
                        <Badge variant="outline">{provider.category}</Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="text-xs font-medium">Features:</div>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(provider.features).map(([feature, enabled]) => 
                            enabled ? (
                              <Badge key={feature} variant="secondary" className="text-xs">
                                {feature}
                              </Badge>
                            ) : null
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Features Tab */}
        <TabsContent value="features" className="space-y-4">
          {Object.entries(providersByFeature).map(([feature, providers]) => (
            <Card key={feature}>
              <CardHeader>
                <CardTitle className="capitalize">{feature}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {providers.map((provider) => (
                    <div key={provider.id} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className={`w-3 h-3 rounded-full ${
                        providerHealth[provider.id] ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <div>
                        <div className="font-medium">{provider.name}</div>
                        <div className="text-sm text-gray-500">
                          {provider.models.length} models
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Models Tab */}
        <TabsContent value="models" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {AI_PROVIDERS.map((provider) => (
              <Card key={provider.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{provider.name}</CardTitle>
                    <Badge variant={provider.apiKey ? "default" : "secondary"}>
                      {provider.apiKey ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {provider.models.map((model) => (
                      <div key={model.id} className="p-3 border rounded-lg">
                        <div className="font-medium">{model.name}</div>
                        <div className="text-sm text-gray-600 mt-1">{model.description}</div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          <Badge variant="outline" className="text-xs">
                            {model.category}
                          </Badge>
                          {model.supportsVision && (
                            <Badge variant="secondary" className="text-xs">Vision</Badge>
                          )}
                          {model.supportsCode && (
                            <Badge variant="secondary" className="text-xs">Code</Badge>
                          )}
                          {model.supportsAnalysis && (
                            <Badge variant="secondary" className="text-xs">Analysis</Badge>
                          )}
                        </div>
                        {model.costPer1kTokens && (
                          <div className="text-xs text-gray-500 mt-2">
                            ${model.costPer1kTokens}/1K tokens
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}