'use client';

import React, { useState } from 'react';
import { 
  Play, 
  Download, 
  Copy, 
  Check, 
  X, 
  Code, 
  Database, 
  Server, 
  Settings,
  FileText,
  FolderOpen,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface CodePreviewProps {
  project: any;
  isVisible: boolean;
  onClose: () => void;
}

export default function CodePreview({ project, isVisible, onClose }: CodePreviewProps) {
  const [copiedSection, setCopiedSection] = useState<string>('');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string>('');

  if (!isVisible || !project) return null;

  const copyToClipboard = async (content: string, section: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedSection(section);
      setTimeout(() => setCopiedSection(''), 2000);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  const downloadProject = () => {
    // Create a zip file-like structure
    const projectData = {
      name: project.name,
      description: project.description,
      architecture: project.architecture,
      code: project.code,
      setup: project.setup,
      features: project.features,
      timeline: project.timeline,
      documentation: project.documentation
    };

    const blob = new Blob([JSON.stringify(projectData, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.toLowerCase().replace(/\s+/g, '-')}-project.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const formatCode = (code: string, language: string) => {
    // Simple code formatting - in a real app, you'd use a proper code formatter
    return code.trim();
  };

  const getLanguageIcon = (section: string) => {
    switch (section) {
      case 'frontend': return <Code className="h-4 w-4" />;
      case 'backend': return <Server className="h-4 w-4" />;
      case 'database': return <Database className="h-4 w-4" />;
      case 'devops': return <Settings className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const modalClasses = `fixed inset-0 z-50 flex items-center justify-center ${
    isFullscreen ? 'p-0 bg-black' : 'p-4 bg-black/50'
  }`;

  const contentClasses = `bg-white dark:bg-gray-900 rounded-lg shadow-xl ${
    isFullscreen ? 'w-full h-full rounded-none' : 'max-w-6xl w-full max-h-[90vh]'
  }`;

  return (
    <div className={modalClasses} onClick={isFullscreen ? undefined : onClose}>
      <div 
        className={contentClasses} 
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b dark:border-gray-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
              <FolderOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {project.name}
              </h2>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Complete Full-Stack Project
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsFullscreen(!isFullscreen)}
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={downloadProject}
              className="flex items-center space-x-2"
            >
              <Download className="h-4 w-4" />
              <span>Download</span>
            </Button>
            
            {!isFullscreen && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Project Overview */}
        <div className="p-6 border-b dark:border-gray-800">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="pt-4">
                <div className="text-2xl font-bold text-blue-600 mb-1">
                  {project.features?.length || 0}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Features</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <div className="text-2xl font-bold text-green-600 mb-1">
                  {Object.keys(project.code || {}).length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Components</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-4">
                <div className="text-2xl font-bold text-purple-600 mb-1">
                  {project.timeline?.split(' ')[0] || 'N/A'}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Timeline</div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Technology Stack</h3>
            <div className="flex flex-wrap gap-2">
              {project.architecture?.techStack?.map((tech: string, index: number) => (
                <Badge key={index} variant="secondary">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Code Tabs */}
        <div className="flex-1 flex flex-col">
          <Tabs defaultValue="frontend" className="flex-1 flex flex-col">
            <div className="px-6 pt-4">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="frontend" className="flex items-center space-x-2">
                  <Code className="h-4 w-4" />
                  <span>Frontend</span>
                </TabsTrigger>
                <TabsTrigger value="backend" className="flex items-center space-x-2">
                  <Server className="h-4 w-4" />
                  <span>Backend</span>
                </TabsTrigger>
                <TabsTrigger value="database" className="flex items-center space-x-2">
                  <Database className="h-4 w-4" />
                  <span>Database</span>
                </TabsTrigger>
                <TabsTrigger value="devops" className="flex items-center space-x-2">
                  <Settings className="h-4 w-4" />
                  <span>DevOps</span>
                </TabsTrigger>
              </TabsList>
            </div>

            <div className="flex-1 p-6">
              <TabsContent value="frontend" className="h-full mt-0">
                <CodeSection
                  title="Frontend Code"
                  code={project.code?.frontend || '// Frontend code will be generated here'}
                  language="typescript"
                  section="frontend"
                  copiedSection={copiedSection}
                  onCopy={copyToClipboard}
                />
              </TabsContent>

              <TabsContent value="backend" className="h-full mt-0">
                <CodeSection
                  title="Backend Code"
                  code={project.code?.backend || '// Backend code will be generated here'}
                  language="typescript"
                  section="backend"
                  copiedSection={copiedSection}
                  onCopy={copyToClipboard}
                />
              </TabsContent>

              <TabsContent value="database" className="h-full mt-0">
                <CodeSection
                  title="Database Schema"
                  code={project.code?.database || '// Database schema will be generated here'}
                  language="sql"
                  section="database"
                  copiedSection={copiedSection}
                  onCopy={copyToClipboard}
                />
              </TabsContent>

              <TabsContent value="devops" className="h-full mt-0">
                <CodeSection
                  title="DevOps Configuration"
                  code={project.code?.devops || '// DevOps configuration will be generated here'}
                  language="yaml"
                  section="devops"
                  copiedSection={copiedSection}
                  onCopy={copyToClipboard}
                />
              </TabsContent>
            </div>
          </Tabs>
        </div>

        {/* Setup Instructions */}
        <div className="p-6 border-t dark:border-gray-800">
          <h3 className="text-lg font-semibold mb-3">Setup Instructions</h3>
          <Tabs defaultValue="installation" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="installation">Installation</TabsTrigger>
              <TabsTrigger value="configuration">Configuration</TabsTrigger>
              <TabsTrigger value="running">Running</TabsTrigger>
              <TabsTrigger value="deployment">Deployment</TabsTrigger>
            </TabsList>
            
            <TabsContent value="installation" className="mt-4">
              <ScrollArea className="h-32 w-full">
                <pre className="text-sm bg-gray-100 dark:bg-gray-800 p-3 rounded overflow-x-auto">
                  {project.setup?.installation || 'Installation instructions will be provided here.'}
                </pre>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="configuration" className="mt-4">
              <ScrollArea className="h-32 w-full">
                <pre className="text-sm bg-gray-100 dark:bg-gray-800 p-3 rounded overflow-x-auto">
                  {project.setup?.configuration || 'Configuration instructions will be provided here.'}
                </pre>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="running" className="mt-4">
              <ScrollArea className="h-32 w-full">
                <pre className="text-sm bg-gray-100 dark:bg-gray-800 p-3 rounded overflow-x-auto">
                  {project.setup?.running || 'Running instructions will be provided here.'}
                </pre>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="deployment" className="mt-4">
              <ScrollArea className="h-32 w-full">
                <pre className="text-sm bg-gray-100 dark:bg-gray-800 p-3 rounded overflow-x-auto">
                  {project.setup?.deployment || 'Deployment instructions will be provided here.'}
                </pre>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>

        {/* Features List */}
        <div className="p-6 border-t dark:border-gray-800">
          <h3 className="text-lg font-semibold mb-3">Features Included</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
            {project.features?.map((feature: string, index: number) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="text-sm text-gray-700 dark:text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

interface CodeSectionProps {
  title: string;
  code: string;
  language: string;
  section: string;
  copiedSection: string;
  onCopy: (content: string, section: string) => void;
}

function CodeSection({ title, code, language, section, copiedSection, onCopy }: CodeSectionProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onCopy(code, section)}
            className="flex items-center space-x-1"
          >
            {copiedSection === section ? (
              <>
                <Check className="h-4 w-4" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                <span>Copy</span>
              </>
            )}
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
          >
            {isExpanded ? 'Collapse' : 'Expand'}
          </Button>
        </div>
      </div>
      
      <ScrollArea className={`flex-1 border rounded-lg ${isExpanded ? 'max-h-[600px]' : 'max-h-[400px]'}`}>
        <pre className="p-4 text-sm overflow-x-auto">
          <code className={`language-${language}`}>
            {formatCode(code, language)}
          </code>
        </pre>
      </ScrollArea>
      
      {code.length > 1000 && !isExpanded && (
        <Alert className="mt-2">
          <AlertDescription>
            Showing first 1000 characters of {code.length} total characters. Click "Expand" to view the complete code.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}