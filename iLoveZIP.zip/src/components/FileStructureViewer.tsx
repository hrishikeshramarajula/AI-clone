'use client';
import { useState } from 'react';
import { 
  Download, 
  FileText, 
  Folder, 
  FolderOpen, 
  Code, 
  Database, 
  Settings, 
  Palette,
  Copy,
  Search,
  ChevronRight,
  ChevronDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface GeneratedFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'database' | 'config' | 'style';
  language: string;
}

interface FileStructureViewerProps {
  files: GeneratedFile[];
  projectName: string;
  onDownloadFile?: (file: GeneratedFile) => void;
  onDownloadAll?: () => void;
  onCopyCode?: (filePath: string, content: string) => void;
}

interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  file?: GeneratedFile;
  expanded?: boolean;
}

const typeIcons: Record<string, React.ReactNode> = {
  frontend: <FileText className="w-4 h-4 text-blue-600" />,
  backend: <Code className="w-4 h-4 text-green-600" />,
  database: <Database className="w-4 h-4 text-purple-600" />,
  config: <Settings className="w-4 h-4 text-orange-600" />,
  style: <Palette className="w-4 h-4 text-pink-600" />
};

const typeColors: Record<string, string> = {
  frontend: 'text-blue-600 bg-blue-50',
  backend: 'text-green-600 bg-green-50',
  database: 'text-purple-600 bg-purple-50',
  config: 'text-orange-600 bg-orange-50',
  style: 'text-pink-600 bg-pink-50'
};

export default function FileStructureViewer({
  files,
  projectName,
  onDownloadFile,
  onDownloadAll,
  onCopyCode
}: FileStructureViewerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFile, setSelectedFile] = useState<GeneratedFile | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set());

  // Build file tree structure
  const buildFileTree = (files: GeneratedFile[]): FileNode[] => {
    const root: FileNode[] = [];
    const folderMap = new Map<string, FileNode>();

    files.forEach(file => {
      const parts = file.path.split('/');
      let currentPath = '';
      let parentArray = root;

      parts.forEach((part, index) => {
        const isLast = index === parts.length - 1;
        currentPath = currentPath ? `${currentPath}/${part}` : part;

        if (isLast) {
          // This is a file
          parentArray.push({
            name: part,
            path: currentPath,
            type: 'file',
            file
          });
        } else {
          // This is a folder
          if (!folderMap.has(currentPath)) {
            const folderNode: FileNode = {
              name: part,
              path: currentPath,
              type: 'folder',
              children: [],
              expanded: expandedFolders.has(currentPath)
            };
            folderMap.set(currentPath, folderNode);
            parentArray.push(folderNode);
          }
          parentArray = folderMap.get(currentPath)!.children!;
        }
      });
    });

    return root;
  };

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const filteredFiles = files.filter(file => 
    file.path.toLowerCase().includes(searchTerm.toLowerCase()) ||
    file.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const fileTree = buildFileTree(filteredFiles);

  const renderFileTree = (nodes: FileNode[], level = 0) => {
    return nodes.map(node => {
      if (node.type === 'folder') {
        const isExpanded = expandedFolders.has(node.path);
        return (
          <div key={node.path}>
            <div
              className="flex items-center gap-2 py-1 px-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer"
              style={{ paddingLeft: `${level * 16 + 8}px` }}
              onClick={() => toggleFolder(node.path)}
            >
              {isExpanded ? (
                <ChevronDown className="w-3 h-3 text-slate-500" />
              ) : (
                <ChevronRight className="w-3 h-3 text-slate-500" />
              )}
              <Folder className={`w-4 h-4 ${isExpanded ? 'text-yellow-600' : 'text-slate-500'}`} />
              <span className="text-sm font-medium">{node.name}</span>
              <Badge variant="secondary" className="text-xs ml-auto">
                {node.children?.length || 0}
              </Badge>
            </div>
            {isExpanded && node.children && (
              <div>{renderFileTree(node.children, level + 1)}</div>
            )}
          </div>
        );
      } else {
        return (
          <div
            key={node.path}
            className={`flex items-center gap-2 py-1 px-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer ${
              selectedFile?.path === node.path ? 'bg-blue-100 dark:bg-blue-900' : ''
            }`}
            style={{ paddingLeft: `${level * 16 + 8}px` }}
            onClick={() => setSelectedFile(node.file!)}
          >
            <div className="w-4 h-4 flex items-center justify-center">
              {node.file && typeIcons[node.file.type]}
            </div>
            <span className="text-sm">{node.name}</span>
            {node.file && (
              <Badge 
                variant="outline" 
                className={`text-xs ml-auto ${typeColors[node.file.type] || ''}`}
              >
                {node.file.language}
              </Badge>
            )}
          </div>
        );
      }
    });
  };

  const handleDownloadFile = (file: GeneratedFile) => {
    const blob = new Blob([file.content], { 
      type: getMimeType(file.language) 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.path.split('/').pop() || 'file';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onDownloadFile?.(file);
  };

  const handleDownloadAll = () => {
    // Create a comprehensive download package
    const packageData = {
      projectName,
      generatedAt: new Date().toISOString(),
      files: files.map(file => ({
        path: file.path,
        content: file.content,
        type: file.type,
        language: file.language
      })),
      setup: {
        installation: generateSetupInstructions(),
        running: generateRunningInstructions()
      }
    };

    const blob = new Blob([JSON.stringify(packageData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${projectName.toLowerCase().replace(' ', '-')}-project.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onDownloadAll?.();
  };

  const handleCopyCode = (content: string) => {
    navigator.clipboard.writeText(content).then(() => {
      // You could add a toast notification here
      console.log('Code copied to clipboard');
    });
  };

  const getMimeType = (language: string): string => {
    const mimeTypes: Record<string, string> = {
      typescript: 'text/typescript',
      javascript: 'text/javascript',
      json: 'application/json',
      css: 'text/css',
      html: 'text/html',
      prisma: 'text/plain',
      sql: 'text/sql',
      markdown: 'text/markdown'
    };
    return mimeTypes[language] || 'text/plain';
  };

  const generateSetupInstructions = (): string => {
    return `# Setup Instructions for ${projectName}

## 1. Install Dependencies
npm install

## 2. Set Up Database
npm run db:push
npm run db:generate

## 3. Start Development Server
npm run dev

## 4. Access Application
Open http://localhost:3000 in your browser`;
  };

  const generateRunningInstructions = (): string => {
    return `# Running the Application

## Development Mode
npm run dev

## Production Mode
npm run build
npm start

## Features
- Live preview functionality
- Responsive design
- Modern tech stack
- Database integration`;
  };

  const getFileStats = () => {
    const stats = {
      total: files.length,
      frontend: files.filter(f => f.type === 'frontend').length,
      backend: files.filter(f => f.type === 'backend').length,
      database: files.filter(f => f.type === 'database').length,
      config: files.filter(f => f.type === 'config').length,
      style: files.filter(f => f.type === 'style').length
    };
    return stats;
  };

  const stats = getFileStats();

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FolderOpen className="w-5 h-5" />
                Project Structure - {projectName}
              </CardTitle>
              <CardDescription>
                Browse and download all generated files ({stats.total} files total)
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleDownloadAll} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* File Statistics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">File Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
              <div className="text-xs text-muted-foreground">Total Files</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.frontend}</div>
              <div className="text-xs text-muted-foreground">Frontend</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.backend}</div>
              <div className="text-xs text-muted-foreground">Backend</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.database}</div>
              <div className="text-xs text-muted-foreground">Database</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{stats.config}</div>
              <div className="text-xs text-muted-foreground">Config</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-pink-600">{stats.style}</div>
              <div className="text-xs text-muted-foreground">Style</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* File Tree */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">File Explorer</CardTitle>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search files..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96">
              {filteredFiles.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No files found matching "{searchTerm}"</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {renderFileTree(fileTree)}
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>

        {/* File Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center justify-between">
              <span>File Preview</span>
              {selectedFile && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleDownloadFile(selectedFile)}
                >
                  <Download className="w-4 h-4 mr-1" />
                  Download
                </Button>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedFile ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  {typeIcons[selectedFile.type]}
                  <span className="font-medium">{selectedFile.path}</span>
                  <Badge variant="outline" className={typeColors[selectedFile.type] || ''}>
                    {selectedFile.language}
                  </Badge>
                </div>
                
                <ScrollArea className="h-80">
                  <pre className="text-sm bg-slate-100 dark:bg-slate-900 p-4 rounded-lg overflow-x-auto">
                    <code className="text-slate-900 dark:text-slate-100">
                      {selectedFile.content}
                    </code>
                  </pre>
                </ScrollArea>
                
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopyCode(selectedFile.content)}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy Code
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDownloadFile(selectedFile)}
                  >
                    <Download className="w-4 h-4 mr-1" />
                    Download File
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-12">
                <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Select a file to preview its contents</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Bulk Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Bulk Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              variant="outline"
              onClick={() => {
                files.filter(f => f.type === 'frontend').forEach(handleDownloadFile);
              }}
              className="flex items-center gap-2"
            >
              <FileText className="w-4 h-4" />
              Download Frontend Files ({stats.frontend})
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                files.filter(f => f.type === 'backend').forEach(handleDownloadFile);
              }}
              className="flex items-center gap-2"
            >
              <Code className="w-4 h-4" />
              Download Backend Files ({stats.backend})
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                files.filter(f => f.type === 'config').forEach(handleDownloadFile);
              }}
              className="flex items-center gap-2"
            >
              <Settings className="w-4 h-4" />
              Download Config Files ({stats.config})
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}