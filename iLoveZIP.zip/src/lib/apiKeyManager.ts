// API Key Management System

export interface ApiKeyConfig {
  providerId: string;
  apiKey: string;
  baseUrl?: string;
  isActive: boolean;
  createdAt: string;
  lastUsed?: string;
}

export interface ProviderSettings {
  [providerId: string]: {
    apiKey?: string;
    baseUrl?: string;
    isActive: boolean;
    defaultModel?: string;
  };
}

class ApiKeyManager {
  private static STORAGE_KEY = 'ai_provider_settings';

  // Get all stored API keys
  static getStoredKeys(): ApiKeyConfig[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (!stored) return [];
      
      const parsed = JSON.parse(stored);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error('Error loading API keys:', error);
      return [];
    }
  }

  // Save API key for a provider
  static saveApiKey(config: Omit<ApiKeyConfig, 'createdAt'>): void {
    const existingKeys = this.getStoredKeys();
    
    // Remove existing key for this provider if it exists
    const filteredKeys = existingKeys.filter(key => key.providerId !== config.providerId);
    
    const newKey: ApiKeyConfig = {
      ...config,
      createdAt: new Date().toISOString()
    };
    
    const updatedKeys = [...filteredKeys, newKey];
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedKeys));
  }

  // Get API key for a specific provider
  static getApiKey(providerId: string): string | null {
    const keys = this.getStoredKeys();
    const keyConfig = keys.find(key => key.providerId === providerId && key.isActive);
    return keyConfig?.apiKey || null;
  }

  // Get base URL for a provider
  static getBaseUrl(providerId: string): string | null {
    const keys = this.getStoredKeys();
    const keyConfig = keys.find(key => key.providerId === providerId && key.isActive);
    return keyConfig?.baseUrl || null;
  }

  // Delete API key for a provider
  static deleteApiKey(providerId: string): void {
    const keys = this.getStoredKeys();
    const filteredKeys = keys.filter(key => key.providerId !== providerId);
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredKeys));
  }

  // Toggle API key active status
  static toggleApiKeyStatus(providerId: string): void {
    const keys = this.getStoredKeys();
    const keyIndex = keys.findIndex(key => key.providerId === providerId);
    
    if (keyIndex !== -1) {
      keys[keyIndex].isActive = !keys[keyIndex].isActive;
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(keys));
    }
  }

  // Update last used timestamp
  static updateLastUsed(providerId: string): void {
    const keys = this.getStoredKeys();
    const keyIndex = keys.findIndex(key => key.providerId === providerId);
    
    if (keyIndex !== -1) {
      keys[keyIndex].lastUsed = new Date().toISOString();
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(keys));
    }
  }

  // Get all provider settings
  static getProviderSettings(): ProviderSettings {
    const keys = this.getStoredKeys();
    const settings: ProviderSettings = {};
    
    keys.forEach(key => {
      settings[key.providerId] = {
        apiKey: key.apiKey,
        baseUrl: key.baseUrl,
        isActive: key.isActive
      };
    });
    
    return settings;
  }

  // Check if provider is configured
  static isProviderConfigured(providerId: string): boolean {
    return this.getApiKey(providerId) !== null;
  }

  // Get configured providers
  static getConfiguredProviders(): string[] {
    const keys = this.getStoredKeys();
    return keys
      .filter(key => key.isActive && key.apiKey)
      .map(key => key.providerId);
  }

  // Validate API key format (basic validation)
  static validateApiKeyFormat(providerId: string, apiKey: string): boolean {
    if (!apiKey || apiKey.trim().length === 0) return false;
    
    // Basic validation based on provider
    switch (providerId) {
      case 'openrouter':
        return apiKey.startsWith('sk-or-');
      case 'huggingface':
        return apiKey.startsWith('hf_');
      case 'groq':
        return apiKey.startsWith('gsk_');
      case 'together':
        return apiKey.length > 20; // Basic length check
      case 'replicate':
        return apiKey.startsWith('r8_');
      case 'ollama':
        return true; // Ollama doesn't require API key
      default:
        return apiKey.length > 10; // Generic validation
    }
  }

  // Clear all stored keys (for testing/reset)
  static clearAllKeys(): void {
    localStorage.removeItem(this.STORAGE_KEY);
  }

  // Export settings as JSON
  static exportSettings(): string {
    const settings = this.getProviderSettings();
    return JSON.stringify(settings, null, 2);
  }

  // Import settings from JSON
  static importSettings(jsonString: string): boolean {
    try {
      const settings = JSON.parse(jsonString);
      
      Object.entries(settings).forEach(([providerId, config]: [string, any]) => {
        if (config.apiKey) {
          this.saveApiKey({
            providerId,
            apiKey: config.apiKey,
            baseUrl: config.baseUrl,
            isActive: config.isActive !== false
          });
        }
      });
      
      return true;
    } catch (error) {
      console.error('Error importing settings:', error);
      return false;
    }
  }
}

export default ApiKeyManager;