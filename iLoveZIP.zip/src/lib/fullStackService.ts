// Full Stack Development Service
// Provides specialized prompts and templates for full-stack development tasks

export interface FullStackProjectTemplate {
  name: string;
  description: string;
  frontend: {
    framework: string;
    language: string;
    styling: string;
    stateManagement: string;
  };
  backend: {
    framework: string;
    language: string;
    database: string;
    auth: string;
  };
  deployment: {
    platform: string;
    ci_cd: string;
    monitoring: string;
  };
}

export interface FullStackPromptTemplate {
  category: 'web-app' | 'api' | 'database' | 'auth' | 'deployment' | 'architecture';
  title: string;
  description: string;
  template: string;
  examples: string[];
}

export const FULL_STACK_PROJECT_TEMPLATES: FullStackProjectTemplate[] = [
  {
    name: 'MERN Stack',
    description: 'MongoDB, Express.js, React, Node.js full-stack application',
    frontend: {
      framework: 'React',
      language: 'TypeScript',
      styling: 'Tailwind CSS',
      stateManagement: 'Redux Toolkit'
    },
    backend: {
      framework: 'Express.js',
      language: 'TypeScript',
      database: 'MongoDB',
      auth: 'JWT'
    },
    deployment: {
      platform: 'Vercel + Railway',
      ci_cd: 'GitHub Actions',
      monitoring: 'Sentry'
    }
  },
  {
    name: 'Next.js Full Stack',
    description: 'Next.js with API routes and database integration',
    frontend: {
      framework: 'Next.js',
      language: 'TypeScript',
      styling: 'Tailwind CSS',
      stateManagement: 'Zustand'
    },
    backend: {
      framework: 'Next.js API Routes',
      language: 'TypeScript',
      database: 'PostgreSQL',
      auth: 'NextAuth.js'
    },
    deployment: {
      platform: 'Vercel',
      ci_cd: 'Vercel Deployments',
      monitoring: 'Vercel Analytics'
    }
  },
  {
    name: 'JAMstack',
    description: 'JavaScript, APIs, and Markup modern web architecture',
    frontend: {
      framework: 'Next.js',
      language: 'TypeScript',
      styling: 'Tailwind CSS',
      stateManagement: 'React Context'
    },
    backend: {
      framework: 'Serverless Functions',
      language: 'TypeScript',
      database: 'Supabase',
      auth: 'Supabase Auth'
    },
    deployment: {
      platform: 'Netlify',
      ci_cd: 'Netlify Build',
      monitoring: 'Netlify Analytics'
    }
  }
];

export const FULL_STACK_PROMPT_TEMPLATES: FullStackPromptTemplate[] = [
  {
    category: 'web-app',
    title: 'Complete Web Application',
    description: 'Generate a complete full-stack web application with frontend, backend, and database',
    template: `Please create a complete full-stack web application for: {user_request}.

Requirements:
- Frontend: Modern React/Next.js application with responsive design
- Backend: RESTful API with proper error handling
- Database: Schema design with relationships and migrations
- Authentication: User registration, login, and authorization
- Features: CRUD operations, validation, and security best practices
- Deployment: Production-ready configuration

Please provide:
1. Project structure and setup instructions
2. Frontend components with code
3. Backend API endpoints with implementation
4. Database schema and migrations
5. Authentication flow implementation
6. Environment configuration
7. Deployment guide

Make the code production-ready with proper error handling, validation, and security measures.`,
    examples: [
      'Create a task management application with user authentication',
      'Build a blog platform with comments and user roles',
      'Develop an e-commerce site with cart and payment integration'
    ]
  },
  {
    category: 'api',
    title: 'RESTful API Design',
    description: 'Design and implement a RESTful API with best practices',
    template: `Please design and implement a comprehensive RESTful API for: {user_request}.

Requirements:
- RESTful endpoints following best practices
- Proper HTTP status codes and error handling
- Request/response validation
- Authentication and authorization middleware
- Rate limiting and security measures
- API documentation (OpenAPI/Swagger)
- Database integration with ORM
- Testing strategy

Please provide:
1. API endpoint design with methods and routes
2. Request/response schemas
3. Authentication and authorization implementation
4. Database models and relationships
5. Middleware implementation
6. Error handling strategy
7. Example requests and responses
8. Security considerations`,
    examples: [
      'Create a user management API with roles and permissions',
      'Design a product catalog API with search and filtering',
      'Build a payment processing API with webhooks'
    ]
  },
  {
    category: 'database',
    title: 'Database Schema Design',
    description: 'Design efficient database schemas with relationships and optimizations',
    template: `Please design a comprehensive database schema for: {user_request}.

Requirements:
- Normalized database design
- Proper relationships (one-to-many, many-to-many)
- Indexing strategy for performance
- Data integrity constraints
- Migration strategy
- Query optimization considerations
- Scalability planning

Please provide:
1. Entity-Relationship Diagram (ERD) description
2. Table schemas with columns, types, and constraints
3. Relationship definitions
4. Index design
5. Sample queries for common operations
6. Migration scripts
7. Performance considerations
8. Scaling strategy`,
    examples: [
      'Design a database for an e-commerce platform',
      'Create a schema for a social media application',
      'Build a database for a learning management system'
    ]
  },
  {
    category: 'auth',
    title: 'Authentication System',
    description: 'Implement secure authentication and authorization systems',
    template: `Please implement a comprehensive authentication and authorization system for: {user_request}.

Requirements:
- User registration and login
- JWT-based authentication
- Role-based access control (RBAC)
- Password security (hashing, salting)
- Session management
- OAuth integration options
- Security best practices
- Password reset functionality

Please provide:
1. Authentication flow diagrams
2. User model and schema
3. JWT implementation
4. Middleware for route protection
5. Role-based access control implementation
6. Password reset flow
7. OAuth integration examples
8. Security considerations and best practices`,
    examples: [
      'Implement authentication for a SaaS application',
      'Create a multi-tenant user management system',
      'Build social login integration with Google and GitHub'
    ]
  },
  {
    category: 'deployment',
    title: 'Deployment Strategy',
    description: 'Create comprehensive deployment and CI/CD pipelines',
    template: `Please design a comprehensive deployment strategy for: {user_request}.

Requirements:
- Containerization (Docker)
- CI/CD pipeline setup
- Environment management
- Monitoring and logging
- Scaling strategy
- Backup and disaster recovery
- Security configurations
- Performance optimization

Please provide:
1. Docker configuration files
2. CI/CD pipeline configuration (GitHub Actions/GitLab CI)
3. Environment configuration management
4. Monitoring and logging setup
5. Scaling and load balancing strategy
6. Backup and disaster recovery plan
7. Security configurations
8. Cost optimization strategies`,
    examples: [
      'Deploy a Next.js application with Docker',
      'Set up CI/CD for a MERN stack application',
      'Configure monitoring for a production web application'
    ]
  },
  {
    category: 'architecture',
    title: 'System Architecture',
    description: 'Design scalable and maintainable system architectures',
    template: `Please design a comprehensive system architecture for: {user_request}.

Requirements:
- Microservices or monolith architecture decision
- Service communication patterns
- Data flow and integration
- Scalability considerations
- Fault tolerance and reliability
- Security architecture
- Performance optimization
- Technology stack recommendations

Please provide:
1. High-level architecture diagram
2. Service/component breakdown
3. Data flow and communication patterns
4. Technology stack recommendations
5. Scalability strategy
6. Security architecture
7. Monitoring and observability plan
8. Deployment and infrastructure strategy`,
    examples: [
      'Design architecture for a real-time chat application',
      'Create microservices architecture for an e-commerce platform',
      'Plan system architecture for a data analytics platform'
    ]
  }
];

export function getFullStackPrompt(userRequest: string, category?: string): string {
  if (category) {
    const template = FULL_STACK_PROMPT_TEMPLATES.find(t => t.category === category);
    if (template) {
      return template.template.replace('{user_request}', userRequest);
    }
  }

  // Default comprehensive full-stack prompt
  return `Please provide a comprehensive full-stack development solution for: "${user_request}".

Your response should include:
1. **Project Overview**: High-level architecture and technology stack recommendations
2. **Frontend Implementation**: 
   - Framework choice and setup
   - Component architecture
   - State management strategy
   - UI/UX considerations
   - Responsive design approach
3. **Backend Implementation**:
   - API design and endpoints
   - Business logic implementation
   - Authentication and authorization
   - Error handling and validation
4. **Database Design**:
   - Schema design
   - Relationships and constraints
   - Query optimization
   - Data migration strategy
5. **DevOps and Deployment**:
   - Environment setup
   - CI/CD pipeline
   - Containerization
   - Monitoring and logging
6. **Security Considerations**:
   - Data protection
   - Authentication security
   - API security
   - Common vulnerability prevention
7. **Testing Strategy**:
   - Unit testing
   - Integration testing
   - End-to-end testing
8. **Performance Optimization**:
   - Caching strategies
   - Database optimization
   - Frontend performance
   - API optimization

Please provide complete, production-ready code examples for key components, explain architectural decisions, and include best practices throughout. Focus on creating a scalable, maintainable, and secure solution that follows modern development practices.`;
}

export function getFullStackTemplate(name: string): FullStackProjectTemplate | undefined {
  return FULL_STACK_PROJECT_TEMPLATES.find(template => 
    template.name.toLowerCase().includes(name.toLowerCase())
  );
}

export function getFullStackExamples(): string[] {
  return FULL_STACK_PROMPT_TEMPLATES.flatMap(template => template.examples);
}

export function getFullStackCategories(): string[] {
  return [...new Set(FULL_STACK_PROMPT_TEMPLATES.map(template => template.category))];
}