// Image utility functions for compression and storage optimization

export interface CompressedImage {
  id: string
  prompt: string
  negativePrompt: string
  style: string
  aspectRatio: string
  quality: number
  timestamp: string
  seed?: string
  imageSize: string
  // Store compressed data URL instead of full base64
  thumbnail: string // Low-res thumbnail for quick loading
  fullImage: string // Compressed full image
}

// Compress image data before storing
export async function compressImage(base64Data: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      
      if (!ctx) {
        reject(new Error('Could not get canvas context'))
        return
      }

      // Calculate new dimensions (max 800px for storage)
      const maxSize = 800
      let { width, height } = img
      
      if (width > height && width > maxSize) {
        height = (height * maxSize) / width
        width = maxSize
      } else if (height > maxSize) {
        width = (width * maxSize) / height
        height = maxSize
      }

      canvas.width = width
      canvas.height = height
      
      // Draw and compress
      ctx.drawImage(img, 0, 0, width, height)
      
      // Compress at 85% quality
      const compressed = canvas.toDataURL('image/jpeg', 0.85)
      resolve(compressed)
    }
    
    img.onerror = () => reject(new Error('Failed to load image'))
    img.src = `data:image/png;base64,${base64Data}`
  })
}

// Create thumbnail for quick loading
export async function createThumbnail(base64Data: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      
      if (!ctx) {
        reject(new Error('Could not get canvas context'))
        return
      }

      // Thumbnail size
      const size = 200
      canvas.width = size
      canvas.height = size
      
      // Draw thumbnail
      ctx.drawImage(img, 0, 0, size, size)
      
      // Low quality for thumbnail
      const thumbnail = canvas.toDataURL('image/jpeg', 0.6)
      resolve(thumbnail)
    }
    
    img.onerror = () => reject(new Error('Failed to load image'))
    img.src = `data:image/png;base64,${base64Data}`
  })
}

// Estimate storage usage
export function getStorageUsage(): { used: number; total: number; available: number } {
  try {
    const allData = JSON.stringify(localStorage)
    const used = new Blob([allData]).size
    const total = 5 * 1024 * 1024 // 5MB conservative estimate
    const available = total - used
    
    return {
      used,
      total,
      available
    }
  } catch {
    return { used: 0, total: 5 * 1024 * 1024, available: 5 * 1024 * 1024 }
  }
}

// Format bytes to human readable
export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes'
  
  const k = 1024
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// Clean old images if storage is getting full
export function cleanupOldStorage(history: any[], keepCount: number = 50): any[] {
  const storage = getStorageUsage()
  
  // If we're using more than 80% of storage, clean up
  if (storage.used / storage.total > 0.8) {
    // Keep only the most recent images
    return history.slice(0, keepCount)
  }
  
  return history
}

// Convert base64 to blob for download
export function base64ToBlob(base64Data: string, mimeType: string = 'image/png'): Blob {
  const byteCharacters = atob(base64Data)
  const byteNumbers = new Array(byteCharacters.length)
  
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i)
  }
  
  const byteArray = new Uint8Array(byteNumbers)
  return new Blob([byteArray], { type: mimeType })
}