import { AIProvider, AIModel, AI_CONFIG, getProvider, getModel } from './aiProviders';
import ZAI from 'z-ai-web-dev-sdk';

export interface AIRequest {
  message: string;
  providerId: string;
  modelId: string;
  mode: 'chat' | 'search' | 'code' | 'analysis' | 'image';
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
}

export interface AIResponse {
  content: string;
  model: string;
  provider: string;
  tokensUsed?: {
    input: number;
    output: number;
  };
  cost?: number;
  timestamp: string;
  searchResults?: any[];
  imageData?: string;
  imagePrompt?: string;
}

export interface ProviderError {
  provider: string;
  error: string;
  timestamp: string;
}

export class MultiProviderAI {
  private zaiInstance: any = null;

  constructor() {
    this.initializeZAI();
  }

  private async initializeZAI() {
    try {
      this.zaiInstance = await ZAI.create();
    } catch (error) {
      console.error('Failed to initialize Z-AI:', error);
    }
  }

  async generateResponse(request: AIRequest): Promise<AIResponse> {
    const { providerId, modelId, message, mode, temperature = 0.7, maxTokens, systemPrompt } = request;
    
    console.log(`Generating response with ${providerId}/${modelId} in ${mode} mode`);

    try {
      const provider = getProvider(providerId);
      const model = getModel(providerId, modelId);

      if (!provider || !model) {
        throw new Error(`Provider ${providerId} or model ${modelId} not found`);
      }

      if (!provider.apiKey) {
        throw new Error(`API key not configured for provider ${providerId}`);
      }

      // Route to appropriate provider handler
      switch (provider.id) {
        case 'openai':
          return await this.handleOpenAI(request, provider, model);
        case 'openrouter':
          return await this.handleOpenRouter(request, provider, model);
        case 'huggingface':
          return await this.handleHuggingFace(request, provider, model);
        case 'ollama':
          return await this.handleOllama(request, provider, model);
        case 'z-ai':
          return await this.handleZAI(request, provider, model);
        default:
          throw new Error(`Unsupported provider: ${provider.id}`);
      }
    } catch (error) {
      console.error(`Error with ${providerId}/${modelId}:`, error);
      
      // Try fallback providers
      return await this.tryFallbackProviders(request, providerId);
    }
  }

  private async handleOpenAI(request: AIRequest, provider: AIProvider, model: AIModel): Promise<AIResponse> {
    const { message, mode, temperature, maxTokens, systemPrompt } = request;
    
    try {
      const response = await fetch(`${provider.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model.id,
          messages: [
            {
              role: 'system',
              content: systemPrompt || this.getSystemPrompt(mode)
            },
            {
              role: 'user',
              content: message
            }
          ],
          temperature,
          max_tokens: maxTokens,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`OpenAI API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        content: data.choices[0]?.message?.content || 'No response',
        model: model.id,
        provider: provider.id,
        tokensUsed: {
          input: data.usage?.prompt_tokens || 0,
          output: data.usage?.completion_tokens || 0
        },
        cost: this.calculateCost(data.usage?.prompt_tokens || 0, data.usage?.completion_tokens || 0, provider),
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`OpenAI request failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleOpenRouter(request: AIRequest, provider: AIProvider, model: AIModel): Promise<AIResponse> {
    const { message, mode, temperature, maxTokens, systemPrompt } = request;
    
    try {
      const response = await fetch(`${provider.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://localhost:3000',
          'X-Title': 'AI Search Engine'
        },
        body: JSON.stringify({
          model: model.id,
          messages: [
            {
              role: 'system',
              content: systemPrompt || this.getSystemPrompt(mode)
            },
            {
              role: 'user',
              content: message
            }
          ],
          temperature,
          max_tokens: maxTokens,
          stream: false
        })
      });

      if (!response.ok) {
        throw new Error(`OpenRouter API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        content: data.choices[0]?.message?.content || 'No response',
        model: model.id,
        provider: provider.id,
        tokensUsed: {
          input: data.usage?.prompt_tokens || 0,
          output: data.usage?.completion_tokens || 0
        },
        cost: this.calculateCost(data.usage?.prompt_tokens || 0, data.usage?.completion_tokens || 0, provider),
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`OpenRouter request failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleHuggingFace(request: AIRequest, provider: AIProvider, model: AIModel): Promise<AIResponse> {
    const { message, mode } = request;
    
    try {
      if (model.supportsImageGeneration) {
        // Handle image generation
        const response = await fetch(`${provider.baseUrl}/${model.id}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${provider.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            inputs: message,
            parameters: {
              guidance_scale: 7.5,
              num_inference_steps: 50,
            }
          })
        });

        if (!response.ok) {
          throw new Error(`HuggingFace API error: ${response.status} ${response.statusText}`);
        }

        const imageData = await response.blob();
        const base64 = await this.blobToBase64(imageData);
        
        return {
          content: `Image generated using ${model.name}`,
          model: model.id,
          provider: provider.id,
          imageData: base64,
          imagePrompt: message,
          timestamp: new Date().toISOString()
        };
      } else {
        // Handle text generation
        const response = await fetch(`${provider.baseUrl}/${model.id}`, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${provider.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            inputs: this.getSystemPrompt(mode) + '\\n\\nUser: ' + message,
            parameters: {
              max_new_tokens: 500,
              temperature: 0.7,
              do_sample: true,
            }
          })
        });

        if (!response.ok) {
          throw new Error(`HuggingFace API error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        
        return {
          content: data[0]?.generated_text || 'No response',
          model: model.id,
          provider: provider.id,
          timestamp: new Date().toISOString()
        };
      }
    } catch (error) {
      throw new Error(`HuggingFace request failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleOllama(request: AIRequest, provider: AIProvider, model: AIModel): Promise<AIResponse> {
    const { message, mode, temperature } = request;
    
    try {
      const response = await fetch(`${provider.baseUrl}/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: model.id,
          prompt: this.getSystemPrompt(mode) + '\\n\\nUser: ' + message,
          stream: false,
          options: {
            temperature,
            num_predict: 500
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      return {
        content: data.response || 'No response',
        model: model.id,
        provider: provider.id,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      throw new Error(`Ollama request failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async handleZAI(request: AIRequest, provider: AIProvider, model: AIModel): Promise<AIResponse> {
    const { message, mode } = request;
    
    if (!this.zaiInstance) {
      throw new Error('Z-AI SDK not initialized');
    }

    try {
      if (mode === 'image' && model.supportsImageGeneration) {
        // Handle image generation
        const imageResponse = await this.zaiInstance.images.generations.create({
          prompt: message,
          size: '1024x1024'
        });

        const imageData = imageResponse.data[0].base64;
        
        return {
          content: `Image generated using ${model.name}`,
          model: model.id,
          provider: provider.id,
          imageData,
          imagePrompt: message,
          timestamp: new Date().toISOString()
        };
      } else if (mode === 'search' && model.supportsWebSearch) {
        // Handle web search
        const searchResult = await this.zaiInstance.functions.invoke("web_search", {
          query: message,
          num: 5
        });

        const searchContext = searchResult.map((result: any) => `${result.name}: ${result.snippet}`).join('\\n');
        
        const completion = await this.zaiInstance.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are a helpful AI assistant. Based on the following search results, provide a comprehensive answer to the user\'s question.'
            },
            {
              role: 'user',
              content: `Question: ${message}\\n\\nSearch Results:\\n${searchContext}`
            }
          ]
        });

        return {
          content: completion.choices[0]?.message?.content || 'No response',
          model: model.id,
          provider: provider.id,
          searchResults: searchResult,
          timestamp: new Date().toISOString()
        };
      } else {
        // Handle regular chat
        const completion = await this.zaiInstance.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: this.getSystemPrompt(mode)
            },
            {
              role: 'user',
              content: message
            }
          ]
        });

        return {
          content: completion.choices[0]?.message?.content || 'No response',
          model: model.id,
          provider: provider.id,
          timestamp: new Date().toISOString()
        };
      }
    } catch (error) {
      throw new Error(`Z-AI request failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private async tryFallbackProviders(request: AIRequest, failedProviderId: string): Promise<AIResponse> {
    const fallbackProviders = AI_CONFIG.fallbackProviders.filter(id => id !== failedProviderId);
    
    for (const providerId of fallbackProviders) {
      try {
        const provider = getProvider(providerId);
        if (provider && provider.apiKey) {
          console.log(`Trying fallback provider: ${providerId}`);
          
          // Use the first available model from the fallback provider
          const fallbackModel = provider.models[0];
          if (fallbackModel) {
            const fallbackRequest = { ...request, providerId, modelId: fallbackModel.id };
            return await this.generateResponse(fallbackRequest);
          }
        }
      } catch (error) {
        console.error(`Fallback provider ${providerId} failed:`, error);
        continue;
      }
    }
    
    throw new Error('All providers failed. Please check your API keys and try again.');
  }

  private getSystemPrompt(mode: string): string {
    switch (mode) {
      case 'chat':
        return 'You are a helpful AI assistant. Provide clear, concise, and accurate responses.';
      case 'search':
        return 'You are a helpful AI assistant with web search capabilities. Provide comprehensive answers based on search results.';
      case 'code':
        return 'You are an expert programmer. Provide clean, well-commented code solutions with explanations.';
      case 'analysis':
        return 'You are an analytical AI assistant. Provide detailed analysis, insights, and data-driven responses.';
      case 'image':
        return 'You are an AI assistant specializing in image generation and visual content creation.';
      default:
        return 'You are a helpful AI assistant.';
    }
  }

  private calculateCost(inputTokens: number, outputTokens: number, provider: AIProvider): number {
    if (!provider.pricing) return 0;
    
    const inputCost = (inputTokens / 1000) * provider.pricing.inputTokenCost;
    const outputCost = (outputTokens / 1000) * provider.pricing.outputTokenCost;
    
    return inputCost + outputCost;
  }

  private async blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  // Provider health check
  async checkProviderHealth(providerId: string): Promise<boolean> {
    try {
      const provider = getProvider(providerId);
      if (!provider || !provider.apiKey) return false;

      // Simple health check - try to list models or make a minimal request
      switch (provider.id) {
        case 'openai':
        case 'openrouter':
          const response = await fetch(`${provider.baseUrl}/models`, {
            headers: { 'Authorization': `Bearer ${provider.apiKey}` }
          });
          return response.ok;
        
        case 'ollama':
          const ollamaResponse = await fetch(`${provider.baseUrl}/tags`);
          return ollamaResponse.ok;
        
        case 'huggingface':
          // HuggingFace doesn't have a simple health check endpoint
          return true;
        
        case 'z-ai':
          return !!this.zaiInstance;
        
        default:
          return false;
      }
    } catch (error) {
      console.error(`Health check failed for ${providerId}:`, error);
      return false;
    }
  }
}

// Export singleton instance
export const multiProviderAI = new MultiProviderAI();