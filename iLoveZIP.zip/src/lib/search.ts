import { SearchResult } from '../types/ai';
import { safeZAIFunctionCall } from './zaiHelper';

export async function performWebSearch(query: string): Promise<SearchResult[]> {
  try {
    console.log('Performing web search for:', query);

    // Use the safe ZAI function call helper
    const searchResult = await safeZAIFunctionCall("web_search", {
      query: query,
      num: 8
    });
    
    console.log('Web search completed successfully, results:', searchResult?.length || 0);
    return searchResult || [];
    
  } catch (error) {
    console.error('Web search error:', error);
    // Return empty array instead of throwing - the AI will still provide helpful responses
    return [];
  }
}