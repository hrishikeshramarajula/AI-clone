# Production-Hardened NSE Options Agent

This package is a safer refactor of your original NSE options agent.

## What changed
- env-based config instead of hard-coded secrets
- rotating logs and heartbeat file
- SQLite journal instead of fragile CSV-only state
- daily risk guardrails and duplicate-signal suppression
- paper broker adapter by default so it cannot accidentally place live orders
- circuit-breaker + retry/backoff around NSE fetches
- position sizing based on rupee risk and lot size
- clearer separation: provider, signal engine, risk engine, broker, notifier, journal

## Important truth
No code can guarantee survival in the real market. What this package does is improve operational robustness and reduce common bot failure modes.

## Install
```bash
pip install -r requirements.txt
cp .env.example .env
```

## Run
```bash
python run_agent.py
```

## Runtime outputs
- `runtime_data/logs/agent.log`
- `runtime_data/heartbeat.json`
- `runtime_data/journal.sqlite3`
- `runtime_data/risk_state.json`

## Safety defaults
- live orders are blocked intentionally
- signals run in paper mode
- daily trade cap, daily loss cap, and consecutive-loss cap are enforced

## To make it truly live
You still need to add:
1. a broker adapter for your broker API
2. order reconciliation
3. open-position polling
4. exit execution and stop management
5. broker-side kill switch and manual override
6. slippage, latency, and rejected-order handling
