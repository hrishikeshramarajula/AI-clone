from __future__ import annotations

import logging
from abc import ABC, abstractmethod

from app.models import OrderResult, TradeIdea

logger = logging.getLogger(__name__)


class BrokerAdapter(ABC):
    @abstractmethod
    def place_order(self, idea: TradeIdea) -> OrderResult:
        raise NotImplementedError


class PaperBroker(BrokerAdapter):
    def place_order(self, idea: TradeIdea) -> OrderResult:
        logger.info(
            "PAPER ORDER | %s %s %s %s qty=%s entry=%.2f",
            idea.symbol,
            idea.direction,
            idea.option_type,
            idea.strike,
            idea.quantity,
            idea.entry_price,
        )
        return OrderResult(
            broker_order_id="PAPER",
            status="ACCEPTED",
            message="Paper trade recorded. Wire your broker adapter before enabling live orders.",
        )
