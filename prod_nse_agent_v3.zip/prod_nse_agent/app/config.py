from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List

try:
    from dotenv import load_dotenv
except ImportError:  # pragma: no cover
    def load_dotenv() -> None:
        return None


load_dotenv()



def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}



def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    return int(raw) if raw not in (None, "") else default



def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    return float(raw) if raw not in (None, "") else default


@dataclass(frozen=True)
class SymbolConfig:
    url_symbol: str
    lot_size: int
    strike_gap: int
    atm_range: int = 10


INDEX_CONFIG: Dict[str, SymbolConfig] = {
    "NIFTY": SymbolConfig("NIFTY", 50, 50, 10),
    "BANKNIFTY": SymbolConfig("BANKNIFTY", 15, 100, 10),
    "MIDCAPNIFTY": SymbolConfig("MIDCPNIFTY", 75, 25, 10),
}


@dataclass
class Settings:
    timezone: str = field(default_factory=lambda: os.getenv("APP_TIMEZONE", "Asia/Kolkata"))
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO").upper())
    data_dir: Path = field(default_factory=lambda: Path(os.getenv("DATA_DIR", "runtime_data")))
    cycle_seconds: int = field(default_factory=lambda: _env_int("CYCLE_SECONDS", 45))
    history_size: int = field(default_factory=lambda: _env_int("HISTORY_SIZE", 180))
    min_history: int = field(default_factory=lambda: _env_int("MIN_HISTORY", 8))
    min_trade_confidence: float = field(default_factory=lambda: _env_float("MIN_TRADE_CONFIDENCE", 0.68))
    max_trades_per_day: int = field(default_factory=lambda: _env_int("MAX_TRADES_PER_DAY", 6))
    max_daily_losses: int = field(default_factory=lambda: _env_int("MAX_DAILY_LOSSES", 2))
    max_consecutive_losses: int = field(default_factory=lambda: _env_int("MAX_CONSECUTIVE_LOSSES", 2))
    cooldown_minutes: int = field(default_factory=lambda: _env_int("COOLDOWN_MINUTES", 20))
    per_trade_risk_rupees: float = field(default_factory=lambda: _env_float("PER_TRADE_RISK_RUPEES", 2000.0))
    max_lots_per_trade: int = field(default_factory=lambda: _env_int("MAX_LOTS_PER_TRADE", 3))
    max_option_iv: float = field(default_factory=lambda: _env_float("MAX_OPTION_IV", 45.0))
    min_option_oi: int = field(default_factory=lambda: _env_int("MIN_OPTION_OI", 1000))
    min_option_ltp: float = field(default_factory=lambda: _env_float("MIN_OPTION_LTP", 10.0))
    duplicate_signal_window_minutes: int = field(default_factory=lambda: _env_int("DUPLICATE_SIGNAL_WINDOW_MINUTES", 30))
    allow_live_orders: bool = field(default_factory=lambda: _env_bool("ALLOW_LIVE_ORDERS", False))
    telegram_bot_token: str = field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    telegram_chat_id: str = field(default_factory=lambda: os.getenv("TELEGRAM_CHAT_ID", ""))
    enabled_symbols: List[str] = field(default_factory=lambda: [
        s.strip().upper() for s in os.getenv("ENABLED_SYMBOLS", "NIFTY,BANKNIFTY,MIDCAPNIFTY").split(",") if s.strip()
    ])

    def __post_init__(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        if self.min_history < 3:
            raise ValueError("MIN_HISTORY must be >= 3")
        if not (0.0 < self.min_trade_confidence <= 1.0):
            raise ValueError("MIN_TRADE_CONFIDENCE must be in (0, 1]")
        unknown = [s for s in self.enabled_symbols if s not in INDEX_CONFIG]
        if unknown:
            raise ValueError(f"Unknown symbols in ENABLED_SYMBOLS: {unknown}")
