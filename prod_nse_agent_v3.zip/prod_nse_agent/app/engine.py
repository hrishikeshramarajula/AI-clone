from __future__ import annotations

import json
import logging
import time
from collections import deque
from pathlib import Path
from typing import Dict, List

from app.broker import PaperBroker
from app.config import Settings
from app.journal import Journal
from app.models import Snapshot
from app.notifier import TelegramNotifier
from app.nse_provider import NseDataProvider
from app.risk import RiskManager
from app.pdh_pdl import PdhPdlProvider
from app.signals import calculate_atr, generate_signal

logger = logging.getLogger(__name__)


class ProductionNseAgent:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.provider = NseDataProvider(settings)
        self.risk = RiskManager(settings)
        self.journal = Journal(settings.data_dir)
        self.notifier = TelegramNotifier(settings)
        self.broker = PaperBroker()
        self.pdh_pdl = PdhPdlProvider(settings, self.provider.scraper)
        self.history: Dict[str, deque] = {
            symbol: deque(maxlen=settings.history_size) for symbol in settings.enabled_symbols
        }
        self.heartbeat_path = settings.data_dir / "heartbeat.json"

        if settings.allow_live_orders:
            raise RuntimeError(
                "ALLOW_LIVE_ORDERS is intentionally blocked in this package until you add a real broker adapter with auth, reconciliation, and kill-switch logic."
            )

    def _write_heartbeat(self, state: Dict) -> None:
        self.heartbeat_path.write_text(json.dumps(state, indent=2))

    def run_once(self) -> Dict:
        now = self.provider.now()
        summary = {"timestamp": now.isoformat(), "signals": []}
        self.risk.reset_if_new_day()

        if not self.provider.is_market_open(now):
            summary["market"] = "closed"
            self._write_heartbeat(summary)
            return summary

        snapshots = self.provider.fetch_all()
        summary["market"] = "open"

        for symbol, snapshot in snapshots.items():
            if snapshot is None:
                summary["signals"].append({"symbol": symbol, "status": "fetch_failed"})
                continue
            self.history[symbol].append(snapshot)
            if len(self.history[symbol]) < self.settings.min_history:
                summary["signals"].append({"symbol": symbol, "status": "warming_up", "history": len(self.history[symbol])})
                continue

            series: List[Snapshot] = list(self.history[symbol])

            # Fetch (cached) PDH/PDL for the liquidity sweep FSM
            levels = self.pdh_pdl.get(symbol)
            if levels is None:
                # Fallback: seed approximation from current history
                self.pdh_pdl.seed_from_snapshots(symbol, series)
                levels = self.pdh_pdl.get(symbol)
            pdh = levels["pdh"] if levels else None
            pdl = levels["pdl"] if levels else None

            signal = generate_signal(symbol, series, now, pdh=pdh, pdl=pdl)
            can_trade, reason = self.risk.can_trade(signal, now)
            if not can_trade:
                summary["signals"].append({
                    "symbol": symbol,
                    "status": "blocked",
                    "reason": reason,
                    "direction": signal.direction,
                    "confidence": signal.confidence,
                })
                continue

            atr = calculate_atr(series)
            idea = self.risk.build_trade_idea(signal, snapshot, atr)
            if idea is None:
                summary["signals"].append({"symbol": symbol, "status": "no_tradeable_strike"})
                continue

            trade_id = self.journal.record_trade(idea)
            broker_result = self.broker.place_order(idea)
            self.notifier.trade_alert(trade_id, idea)
            self.risk.register_signal(signal, now)
            summary["signals"].append({
                "symbol": symbol,
                "status": broker_result.status.lower(),
                "trade_id": trade_id,
                "direction": idea.direction,
                "strike": idea.strike,
                "option_type": idea.option_type,
                "entry_price": idea.entry_price,
                "confidence": idea.confidence,
            })

        summary["journal"] = self.journal.summary()
        self._write_heartbeat(summary)
        return summary

    def run_forever(self) -> None:
        logger.info("Starting production-hardened NSE agent in paper mode")
        while True:
            try:
                summary = self.run_once()
                logger.info("Cycle summary: %s", summary)
            except KeyboardInterrupt:
                logger.info("Stopped by user")
                break
            except Exception as exc:
                logger.exception("Fatal cycle error: %s", exc)
            time.sleep(self.settings.cycle_seconds)
