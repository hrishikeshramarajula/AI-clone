from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Dict

from app.models import TradeIdea


class Journal:
    def __init__(self, data_dir: Path):
        self.db_path = data_dir / "journal.sqlite3"
        self._init_db()

    def _conn(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    direction TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    phase TEXT NOT NULL,
                    strike REAL NOT NULL,
                    option_type TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    sl REAL NOT NULL,
                    target1 REAL NOT NULL,
                    target2 REAL NOT NULL,
                    risk_reward REAL NOT NULL,
                    qty_lots INTEGER NOT NULL,
                    quantity INTEGER NOT NULL,
                    rationale_json TEXT NOT NULL,
                    diagnostics_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'OPEN',
                    exit_price REAL,
                    pnl_rupees REAL,
                    note TEXT
                )
                """
            )

    def record_trade(self, idea: TradeIdea) -> int:
        with self._conn() as conn:
            cur = conn.execute(
                """
                INSERT INTO trades (
                    created_at, symbol, direction, confidence, phase, strike, option_type,
                    entry_price, sl, target1, target2, risk_reward, qty_lots, quantity,
                    rationale_json, diagnostics_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
                """,
                (
                    datetime.utcnow().isoformat(), idea.symbol, idea.direction, idea.confidence, idea.phase,
                    idea.strike, idea.option_type, idea.entry_price, idea.sl, idea.target1, idea.target2,
                    idea.risk_reward, idea.qty_lots, idea.quantity,
                    json.dumps(idea.rationale), json.dumps(idea.diagnostics),
                ),
            )
            return int(cur.lastrowid)

    def close_trade(self, trade_id: int, exit_price: float, pnl_rupees: float, note: str = "") -> None:
        status = "WIN" if pnl_rupees > 0 else "LOSS" if pnl_rupees < 0 else "FLAT"
        with self._conn() as conn:
            conn.execute(
                "UPDATE trades SET status = ?, exit_price = ?, pnl_rupees = ?, note = ? WHERE id = ?",
                (status, exit_price, pnl_rupees, note, trade_id),
            )

    def summary(self) -> Dict:
        with self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]
            closed = conn.execute("SELECT COUNT(*) FROM trades WHERE status IN ('WIN','LOSS','FLAT')").fetchone()[0]
            wins = conn.execute("SELECT COUNT(*) FROM trades WHERE status='WIN'").fetchone()[0]
            losses = conn.execute("SELECT COUNT(*) FROM trades WHERE status='LOSS'").fetchone()[0]
            pnl = conn.execute("SELECT COALESCE(SUM(pnl_rupees),0) FROM trades WHERE status IN ('WIN','LOSS','FLAT')").fetchone()[0]
        hit_rate = round((wins / closed) * 100, 2) if closed else 0.0
        return {
            "total_signals": total,
            "closed_trades": closed,
            "wins": wins,
            "losses": losses,
            "hit_rate_pct": hit_rate,
            "net_pnl_rupees": round(float(pnl or 0.0), 2),
        }
