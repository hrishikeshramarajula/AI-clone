"""
liquidity_sweep.py — Liquidity Sweep / False Breakout FSM.

Strategy recap
──────────────
Institutions push price past yesterday's High or Low to hunt retail
stop-losses (liquidity grab), then reverse hard.  We catch the reversal
on the first M1 confirmation candle and enter when the *next* candle
breaks the signal candle's high/low.

Because the agent runs on option-chain OI snapshots (not a true 1-minute
OHLC feed) we build a synthetic "candle" from consecutive spot prints:
  • open  = first spot in the window
  • high  = max spot
  • low   = min spot
  • close = latest spot

This is a good-enough approximation for the reversal signal.  Each
engine cycle (default 45 s) is treated as one "bar".

State machine
─────────────
Per-symbol states (LiquiditySweepState):

  WAIT_FOR_LEVELS   — no PDH/PDL yet, or first bar of the day
  WATCH_LOW_BREAK   — PDL known; watching for a close < PDL
  WATCH_HIGH_BREAK  — PDH known; watching for a close > PDH
  WAIT_BUY_SIGNAL   — close < PDL confirmed; hunting for green reversal candle
  WAIT_SELL_SIGNAL  — close > PDH confirmed; hunting for red  reversal candle
  BUY_READY         — green candle found; wait for next bar to break its high
  SELL_READY        — red  candle found; wait for next bar to break its low
  POSITION_OPEN     — signal fired; waiting for TP or SL (handled externally)

Transitions that don't fire within MAX_SIGNAL_BARS bars expire back to
WATCH_LOW_BREAK / WATCH_HIGH_BREAK so the machine self-heals.

Output
──────
LiquiditySweepResult is appended to Signal.diagnostics["liquidity_sweep"]
and, when action == "FIRE", generate_signal() upgrades the signal to
confidence=0.85 and action="TRADE" regardless of OI/VWAP scores.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from typing import Dict, List, Optional

from app.models import Snapshot

logger = logging.getLogger(__name__)

# ── tunables ────────────────────────────────────────────────────────────── #
MAX_SIGNAL_BARS  = 4    # bars to wait for breakout before expiry
SWEEP_THRESHOLD  = 0.0  # spot must close strictly beyond PDH/PDL (0 = exact)
FIRE_CONFIDENCE  = 0.85 # confidence injected into Signal when FSM fires
# ─────────────────────────────────────────────────────────────────────────── #


class FSMState(Enum):
    WAIT_FOR_LEVELS  = auto()
    WATCH_LOW_BREAK  = auto()
    WATCH_HIGH_BREAK = auto()
    WAIT_BUY_SIGNAL  = auto()
    WAIT_SELL_SIGNAL = auto()
    BUY_READY        = auto()
    SELL_READY       = auto()
    POSITION_OPEN    = auto()


@dataclass
class SyntheticCandle:
    open:  float
    high:  float
    low:   float
    close: float

    @property
    def is_green(self) -> bool:
        return self.close >= self.open

    @property
    def is_red(self) -> bool:
        return self.close < self.open


@dataclass
class LiquiditySweepResult:
    state:          str
    action:         str           # "HOLD" | "FIRE_BUY" | "FIRE_SELL"
    direction:      str           # "BULLISH" | "BEARISH" | "NEUTRAL"
    confidence:     float
    pdh:            Optional[float]
    pdl:            Optional[float]
    signal_candle_high: Optional[float]
    signal_candle_low:  Optional[float]
    detail:         str
    bars_waited:    int


@dataclass
class SymbolFSM:
    """Per-symbol state machine instance."""
    state:     FSMState           = FSMState.WAIT_FOR_LEVELS
    pdh:       Optional[float]    = None
    pdl:       Optional[float]    = None
    signal_candle: Optional[SyntheticCandle] = None
    bars_in_state: int            = 0
    last_date: Optional[str]      = None   # YYYY-MM-DD — reset daily

    # ── helpers ──────────────────────────────────────────────────────── #
    def _reset_to_watch(self) -> None:
        self.state         = FSMState.WATCH_LOW_BREAK
        self.signal_candle = None
        self.bars_in_state = 0

    def _transition(self, new_state: FSMState) -> None:
        logger.debug("FSM → %s", new_state.name)
        self.state         = new_state
        self.bars_in_state = 0


class LiquiditySweepFSM:
    """
    One FSM per symbol, all managed here.

    Usage (called from signals.py::generate_signal):
        result = fsm_manager.evaluate(symbol, snapshots, pdh, pdl, now)
    """

    def __init__(self) -> None:
        self._machines: Dict[str, SymbolFSM] = {}

    def _get(self, symbol: str) -> SymbolFSM:
        if symbol not in self._machines:
            self._machines[symbol] = SymbolFSM()
        return self._machines[symbol]

    # ── public API ──────────────────────────────────────────────────── #
    def evaluate(
        self,
        symbol:    str,
        snapshots: List[Snapshot],
        pdh:       Optional[float],
        pdl:       Optional[float],
        now:       datetime,
    ) -> LiquiditySweepResult:

        fsm       = self._get(symbol)
        today_str = now.strftime("%Y-%m-%d")

        # ── daily reset ─────────────────────────────────────────────── #
        if fsm.last_date != today_str:
            logger.info("FSM daily reset for %s", symbol)
            self._machines[symbol] = SymbolFSM(last_date=today_str)
            fsm = self._machines[symbol]

        fsm.bars_in_state += 1

        # ── update PDH/PDL whenever provider gives us fresh values ──── #
        if pdh is not None:
            fsm.pdh = pdh
        if pdl is not None:
            fsm.pdl = pdl

        # ── build synthetic candle from recent snapshots ─────────────── #
        candle = self._build_candle(snapshots)
        if candle is None:
            return self._result(fsm, "HOLD", "insufficient data")

        # ── run the FSM ──────────────────────────────────────────────── #
        return self._step(fsm, candle, symbol)

    # ── FSM transition logic ─────────────────────────────────────────── #
    def _step(self, fsm: SymbolFSM, candle: SyntheticCandle, symbol: str) -> LiquiditySweepResult:

        # ── WAIT_FOR_LEVELS ────────────────────────────────────────── #
        if fsm.state == FSMState.WAIT_FOR_LEVELS:
            if fsm.pdh is not None and fsm.pdl is not None:
                fsm._transition(FSMState.WATCH_LOW_BREAK)
                # fall through immediately
            else:
                return self._result(fsm, "HOLD", "waiting for PDH/PDL levels")

        # ── WATCH_LOW_BREAK ────────────────────────────────────────── #
        if fsm.state == FSMState.WATCH_LOW_BREAK:
            if candle.close < (fsm.pdl - SWEEP_THRESHOLD):
                logger.info("%s: price broke below PDL %.2f (close=%.2f) — WAIT_BUY_SIGNAL", symbol, fsm.pdl, candle.close)
                fsm._transition(FSMState.WAIT_BUY_SIGNAL)
            elif candle.close > (fsm.pdh + SWEEP_THRESHOLD):
                logger.info("%s: price broke above PDH %.2f (close=%.2f) — WAIT_SELL_SIGNAL", symbol, fsm.pdh, candle.close)
                fsm._transition(FSMState.WAIT_SELL_SIGNAL)
            else:
                return self._result(fsm, "HOLD", f"watching levels PDH={fsm.pdh:.0f} PDL={fsm.pdl:.0f}")

        # ── WATCH_HIGH_BREAK (same node, reached via else above) ────── #
        if fsm.state == FSMState.WATCH_HIGH_BREAK:
            if candle.close > (fsm.pdh + SWEEP_THRESHOLD):
                logger.info("%s: price broke above PDH %.2f — WAIT_SELL_SIGNAL", symbol, fsm.pdh)
                fsm._transition(FSMState.WAIT_SELL_SIGNAL)
            elif candle.close < (fsm.pdl - SWEEP_THRESHOLD):
                logger.info("%s: price broke below PDL %.2f — WAIT_BUY_SIGNAL", symbol, fsm.pdl)
                fsm._transition(FSMState.WAIT_BUY_SIGNAL)
            else:
                return self._result(fsm, "HOLD", f"watching levels PDH={fsm.pdh:.0f} PDL={fsm.pdl:.0f}")

        # ── WAIT_BUY_SIGNAL ────────────────────────────────────────── #
        if fsm.state == FSMState.WAIT_BUY_SIGNAL:
            if fsm.bars_in_state > MAX_SIGNAL_BARS:
                logger.info("%s: WAIT_BUY_SIGNAL expired after %d bars", symbol, fsm.bars_in_state)
                fsm._reset_to_watch()
                return self._result(fsm, "HOLD", "signal expired — reset to WATCH")

            if candle.is_green:
                fsm.signal_candle = candle
                fsm._transition(FSMState.BUY_READY)
                return self._result(fsm, "HOLD", f"green reversal candle found H={candle.high:.2f} L={candle.low:.2f} — waiting for break")
            else:
                return self._result(fsm, "HOLD", f"waiting for green candle (bar {fsm.bars_in_state}/{MAX_SIGNAL_BARS})")

        # ── WAIT_SELL_SIGNAL ───────────────────────────────────────── #
        if fsm.state == FSMState.WAIT_SELL_SIGNAL:
            if fsm.bars_in_state > MAX_SIGNAL_BARS:
                logger.info("%s: WAIT_SELL_SIGNAL expired after %d bars", symbol, fsm.bars_in_state)
                fsm._reset_to_watch()
                return self._result(fsm, "HOLD", "signal expired — reset to WATCH")

            if candle.is_red:
                fsm.signal_candle = candle
                fsm._transition(FSMState.SELL_READY)
                return self._result(fsm, "HOLD", f"red reversal candle found H={candle.high:.2f} L={candle.low:.2f} — waiting for break")
            else:
                return self._result(fsm, "HOLD", f"waiting for red candle (bar {fsm.bars_in_state}/{MAX_SIGNAL_BARS})")

        # ── BUY_READY ──────────────────────────────────────────────── #
        if fsm.state == FSMState.BUY_READY:
            if fsm.bars_in_state > MAX_SIGNAL_BARS:
                logger.info("%s: BUY_READY expired — no break of signal candle high", symbol)
                fsm._reset_to_watch()
                return self._result(fsm, "HOLD", "BUY breakout expired — reset")

            sc = fsm.signal_candle
            if candle.high > sc.high:
                logger.info("%s: 🔥 BUY FIRE — broke signal candle high %.2f", symbol, sc.high)
                fsm._transition(FSMState.POSITION_OPEN)
                return LiquiditySweepResult(
                    state=fsm.state.name,
                    action="FIRE_BUY",
                    direction="BULLISH",
                    confidence=FIRE_CONFIDENCE,
                    pdh=fsm.pdh, pdl=fsm.pdl,
                    signal_candle_high=sc.high,
                    signal_candle_low=sc.low,
                    detail=f"Broke signal candle H={sc.high:.2f}; SL below {sc.low:.2f}",
                    bars_waited=fsm.bars_in_state,
                )
            return self._result(fsm, "HOLD", f"waiting for break above {sc.high:.2f} (bar {fsm.bars_in_state}/{MAX_SIGNAL_BARS})")

        # ── SELL_READY ─────────────────────────────────────────────── #
        if fsm.state == FSMState.SELL_READY:
            if fsm.bars_in_state > MAX_SIGNAL_BARS:
                logger.info("%s: SELL_READY expired — no break of signal candle low", symbol)
                fsm._reset_to_watch()
                return self._result(fsm, "HOLD", "SELL breakout expired — reset")

            sc = fsm.signal_candle
            if candle.low < sc.low:
                logger.info("%s: 🔥 SELL FIRE — broke signal candle low %.2f", symbol, sc.low)
                fsm._transition(FSMState.POSITION_OPEN)
                return LiquiditySweepResult(
                    state=fsm.state.name,
                    action="FIRE_SELL",
                    direction="BEARISH",
                    confidence=FIRE_CONFIDENCE,
                    pdh=fsm.pdh, pdl=fsm.pdl,
                    signal_candle_high=sc.high,
                    signal_candle_low=sc.low,
                    detail=f"Broke signal candle L={sc.low:.2f}; SL above {sc.high:.2f}",
                    bars_waited=fsm.bars_in_state,
                )
            return self._result(fsm, "HOLD", f"waiting for break below {sc.low:.2f} (bar {fsm.bars_in_state}/{MAX_SIGNAL_BARS})")

        # ── POSITION_OPEN ──────────────────────────────────────────── #
        if fsm.state == FSMState.POSITION_OPEN:
            return self._result(fsm, "HOLD", "position already open — managed externally")

        # fallback
        return self._result(fsm, "HOLD", f"unknown state {fsm.state}")

    # ── builders ────────────────────────────────────────────────────── #
    @staticmethod
    def _build_candle(snapshots: List[Snapshot], window: int = 3) -> Optional[SyntheticCandle]:
        """
        Build a synthetic candle from the last `window` spot prices.
        Requires at least 2 snapshots.
        """
        if len(snapshots) < 2:
            return None
        recent = snapshots[-window:]
        spots  = [s.spot for s in recent if s.spot > 0]
        if not spots:
            return None
        return SyntheticCandle(
            open  = spots[0],
            high  = max(spots),
            low   = min(spots),
            close = spots[-1],
        )

    @staticmethod
    def _result(fsm: SymbolFSM, action: str, detail: str) -> LiquiditySweepResult:
        sc = fsm.signal_candle
        return LiquiditySweepResult(
            state=fsm.state.name,
            action=action,
            direction="NEUTRAL",
            confidence=0.0,
            pdh=fsm.pdh,
            pdl=fsm.pdl,
            signal_candle_high=sc.high if sc else None,
            signal_candle_low=sc.low  if sc else None,
            detail=detail,
            bars_waited=fsm.bars_in_state,
        )

    # ── manual reset (e.g. after TP/SL hit) ─────────────────────────── #
    def reset_after_trade(self, symbol: str) -> None:
        """Call this when a position opened by the FSM is closed."""
        fsm = self._get(symbol)
        fsm._reset_to_watch()
        logger.info("FSM reset after trade close for %s", symbol)
