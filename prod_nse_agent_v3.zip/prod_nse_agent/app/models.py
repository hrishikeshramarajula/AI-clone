from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Snapshot:
    symbol: str
    timestamp: str
    expiry: str
    spot: float
    atm_strike: float
    total_ce_oi: int
    total_pe_oi: int
    total_ce_vol: int
    total_pe_vol: int
    oi_pcr: float
    vol_pcr: float
    support: float
    resistance: float
    max_pain: float
    strike_data: Dict[float, Dict]


@dataclass
class Signal:
    symbol: str
    direction: str
    confidence: float
    action: str
    phase: str
    rationale: List[str] = field(default_factory=list)
    diagnostics: Dict = field(default_factory=dict)


@dataclass
class TradeIdea:
    symbol: str
    direction: str
    confidence: float
    strike: float
    option_type: str
    entry_price: float
    sl: float
    target1: float
    target2: float
    risk_reward: float
    score: float
    qty_lots: int
    quantity: int
    phase: str
    rationale: List[str]
    diagnostics: Dict


@dataclass
class OrderResult:
    broker_order_id: str
    status: str
    message: str
