from __future__ import annotations

import logging
from typing import Optional

import requests

from app.config import Settings
from app.models import TradeIdea

logger = logging.getLogger(__name__)


class TelegramNotifier:
    def __init__(self, settings: Settings):
        self.token = settings.telegram_bot_token
        self.chat_id = settings.telegram_chat_id
        self.enabled = bool(self.token and self.chat_id)
        self.url = f"https://api.telegram.org/bot{self.token}/sendMessage" if self.enabled else ""

    def send(self, text: str) -> bool:
        if not self.enabled:
            return False
        try:
            response = requests.post(
                self.url,
                data={"chat_id": self.chat_id, "text": text, "parse_mode": "HTML"},
                timeout=10,
            )
            return response.status_code == 200
        except Exception as exc:
            logger.error("Telegram send failed: %s", exc)
            return False

    def trade_alert(self, trade_id: int, idea: TradeIdea) -> None:
        text = (
            f"<b>NSE Trade Signal</b>\n"
            f"ID: <code>{trade_id}</code>\n"
            f"{idea.symbol} {idea.direction} {idea.option_type} {int(idea.strike)}\n"
            f"Entry ₹{idea.entry_price:.2f} | SL ₹{idea.sl:.2f} | T1 ₹{idea.target1:.2f} | T2 ₹{idea.target2:.2f}\n"
            f"Confidence {idea.confidence*100:.0f}% | Lots {idea.qty_lots} | Qty {idea.quantity}\n"
            f"R:R {idea.risk_reward:.2f}"
        )
        self.send(text)
