from __future__ import annotations

import logging
import random
import time
from datetime import datetime, time as dt_time
from zoneinfo import ZoneInfo
from typing import Dict, List, Optional

try:
    import cloudscraper as _cloudscraper_module
except ImportError:  # pragma: no cover
    _cloudscraper_module = None

from app.config import INDEX_CONFIG, Settings
from app.models import Snapshot
from app.resilience import CircuitBreaker, backoff_sleep

logger = logging.getLogger(__name__)


class NseDataProvider:
    MARKET_OPEN = dt_time(9, 15)
    MARKET_CLOSE = dt_time(15, 30)

    def __init__(self, settings: Settings):
        self.settings = settings
        self.tz = ZoneInfo(settings.timezone)
        self.breaker = CircuitBreaker()
        self.scraper = self._build_scraper()
        self.last_good_fetch: Dict[str, datetime] = {}

    def now(self) -> datetime:
        return datetime.now(self.tz)

    def is_market_open(self, now: Optional[datetime] = None) -> bool:
        current = (now or self.now()).time()
        return self.MARKET_OPEN <= current <= self.MARKET_CLOSE

    def _build_scraper(self):
        if _cloudscraper_module is None:
            raise ImportError("cloudscraper is required")
        sc = _cloudscraper_module.create_scraper(
            browser={"browser": "chrome", "platform": "windows", "mobile": False}
        )
        sc.headers.update({
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": "https://www.nseindia.com/option-chain",
            "Origin": "https://www.nseindia.com",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/127.0 Safari/537.36"
            ),
        })
        return sc

    def _warm_session(self) -> None:
        try:
            self.scraper.get("https://www.nseindia.com", timeout=15)
            time.sleep(random.uniform(1.5, 3.0))
        except Exception as exc:
            logger.warning("NSE warm-up failed: %s", exc)

    def fetch_option_chain_raw(self, symbol: str, max_retries: int = 4) -> Optional[Dict]:
        if not self.breaker.allow():
            logger.error("Circuit breaker open, skipping fetch for %s", symbol)
            return None

        cfg = INDEX_CONFIG[symbol]
        url = f"https://www.nseindia.com/api/option-chain-indices?symbol={cfg.url_symbol}"

        for attempt in range(1, max_retries + 1):
            try:
                if attempt == 1:
                    self._warm_session()
                response = self.scraper.get(url, timeout=15)
                if response.status_code in (401, 403):
                    self._warm_session()
                    response = self.scraper.get(url, timeout=15)
                response.raise_for_status()
                payload = response.json()
                if "records" not in payload or not payload["records"].get("data"):
                    raise ValueError("Unexpected NSE payload structure")
                self.breaker.record_success()
                self.last_good_fetch[symbol] = self.now()
                return payload
            except Exception as exc:
                logger.warning("Fetch %s attempt %s failed: %s", symbol, attempt, exc)
                self.breaker.record_failure()
                if attempt < max_retries:
                    backoff_sleep(attempt)
                    if attempt >= 2:
                        self.scraper = self._build_scraper()
        return None

    def parse_option_chain(self, payload: Dict, symbol: str) -> Optional[Snapshot]:
        try:
            records = payload["records"]
            expiry = records["expiryDates"][0]
            spot = float(records["underlyingValue"])
            if spot <= 0:
                return None
            rows = records["data"]
            cfg = INDEX_CONFIG[symbol]
            atm_strike = round(spot / cfg.strike_gap) * cfg.strike_gap

            total_ce_oi = total_pe_oi = total_ce_vol = total_pe_vol = 0
            max_ce_oi = max_pe_oi = 0
            resistance = support = atm_strike
            strike_data: Dict[float, Dict] = {}

            for row in rows:
                if row.get("expiryDate") != expiry or "CE" not in row or "PE" not in row:
                    continue
                strike = float(row["strikePrice"])
                ce, pe = row["CE"], row["PE"]
                c_oi = max(int(ce.get("openInterest", 0) or 0), 0)
                p_oi = max(int(pe.get("openInterest", 0) or 0), 0)
                c_vol = max(int(ce.get("totalTradedVolume", 0) or 0), 0)
                p_vol = max(int(pe.get("totalTradedVolume", 0) or 0), 0)
                c_ltp = float(ce.get("lastPrice", 0.0) or 0.0)
                p_ltp = float(pe.get("lastPrice", 0.0) or 0.0)
                c_iv = max(float(ce.get("impliedVolatility", 0.0) or 0.0), 0.0)
                p_iv = max(float(pe.get("impliedVolatility", 0.0) or 0.0), 0.0)

                total_ce_oi += c_oi
                total_pe_oi += p_oi
                total_ce_vol += c_vol
                total_pe_vol += p_vol

                if c_oi > max_ce_oi:
                    max_ce_oi = c_oi
                    resistance = strike
                if p_oi > max_pe_oi:
                    max_pe_oi = p_oi
                    support = strike

                if abs(strike - atm_strike) <= cfg.atm_range * cfg.strike_gap:
                    strike_data[strike] = {
                        "CE_OI": c_oi,
                        "PE_OI": p_oi,
                        "CE_VOL": c_vol,
                        "PE_VOL": p_vol,
                        "CE_LTP": c_ltp,
                        "PE_LTP": p_ltp,
                        "CE_IV": c_iv,
                        "PE_IV": p_iv,
                        "DELTA_PROXY": self._approx_delta(strike, spot),
                    }

            if total_ce_oi <= 0 or total_pe_oi <= 0 or not strike_data:
                return None

            max_pain = self._calculate_max_pain(strike_data)
            ts = self.now().strftime("%Y-%m-%d %H:%M:%S")
            return Snapshot(
                symbol=symbol,
                timestamp=ts,
                expiry=expiry,
                spot=spot,
                atm_strike=atm_strike,
                total_ce_oi=total_ce_oi,
                total_pe_oi=total_pe_oi,
                total_ce_vol=total_ce_vol,
                total_pe_vol=total_pe_vol,
                oi_pcr=round(total_pe_oi / total_ce_oi, 4),
                vol_pcr=round(total_pe_vol / total_ce_vol, 4) if total_ce_vol > 0 else 1.0,
                support=support,
                resistance=resistance,
                max_pain=max_pain,
                strike_data=strike_data,
            )
        except Exception as exc:
            logger.error("Parse error for %s: %s", symbol, exc)
            return None

    @staticmethod
    def _approx_delta(strike: float, spot: float) -> float:
        diff_pct = (spot - strike) / max(spot, 1) * 100
        if diff_pct > 3:
            return 0.85
        if diff_pct > 1.5:
            return 0.70
        if diff_pct > 0:
            return 0.55
        if diff_pct > -1.5:
            return 0.45
        if diff_pct > -3:
            return 0.30
        return 0.15

    @staticmethod
    def _calculate_max_pain(strike_data: Dict[float, Dict]) -> float:
        strikes = sorted(strike_data)
        best_strike = strikes[0]
        min_pain = float("inf")
        for test_strike in strikes:
            pain = sum(
                max(test_strike - sk, 0) * values["CE_OI"] + max(sk - test_strike, 0) * values["PE_OI"]
                for sk, values in strike_data.items()
            )
            if pain < min_pain:
                min_pain = pain
                best_strike = test_strike
        return best_strike

    def fetch_snapshot(self, symbol: str) -> Optional[Snapshot]:
        payload = self.fetch_option_chain_raw(symbol)
        return self.parse_option_chain(payload, symbol) if payload else None

    def fetch_all(self) -> Dict[str, Optional[Snapshot]]:
        output: Dict[str, Optional[Snapshot]] = {}
        for symbol in self.settings.enabled_symbols:
            output[symbol] = self.fetch_snapshot(symbol)
            time.sleep(random.uniform(1.0, 2.0))
        return output
