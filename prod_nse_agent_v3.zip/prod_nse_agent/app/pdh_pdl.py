"""
pdh_pdl.py — Previous Day High / Low fetcher for NSE indices.

Strategy: Two-tier fetch with cache.
  Tier 1 (preferred): NSE historical API  — actual OHLC for yesterday.
  Tier 2 (fallback):  First-candle approx — uses the earliest spot prices
                      seen today to build a rough PDH/PDL when the API is
                      unavailable or rate-limits us.

The fetched levels are cached once per calendar day so we only hit the
network once at startup, not every cycle.
"""
from __future__ import annotations

import logging
import random
import time
from datetime import date, datetime, timedelta
from typing import Dict, Optional
from zoneinfo import ZoneInfo

from app.config import INDEX_CONFIG, Settings

logger = logging.getLogger(__name__)

IST = ZoneInfo("Asia/Kolkata")

# NSE's historical OHLC endpoint (same host, same scraper session)
_NSE_HIST_URL = (
    "https://www.nseindia.com/api/historical/indicesHistory"
    "?indexType={symbol}&from={from_date}&to={to_date}"
)

# symbol → {"pdh": float, "pdl": float, "date": date, "source": str}
_cache: Dict[str, Dict] = {}


def _prev_trading_day() -> date:
    """Return the most recent weekday before today (IST)."""
    today = datetime.now(IST).date()
    delta = 1
    while True:
        candidate = today - timedelta(days=delta)
        if candidate.weekday() < 5:          # Mon–Fri
            return candidate
        delta += 1


def _fmt(d: date) -> str:
    return d.strftime("%d-%m-%Y")


def fetch_pdh_pdl_from_nse(symbol: str, scraper) -> Optional[Dict]:
    """
    Hit the NSE historical index OHLC API.
    Returns {"pdh": float, "pdl": float, "date": date, "source": "nse_hist"}
    or None on failure.
    """
    ptd = _prev_trading_day()
    cfg = INDEX_CONFIG[symbol]
    url = _NSE_HIST_URL.format(
        symbol=cfg.url_symbol,
        from_date=_fmt(ptd),
        to_date=_fmt(ptd),
    )
    try:
        # Warm session briefly — NSE rejects cold requests
        scraper.get("https://www.nseindia.com", timeout=12)
        time.sleep(random.uniform(1.0, 2.0))

        resp = scraper.get(url, timeout=15)
        if resp.status_code in (401, 403):
            scraper.get("https://www.nseindia.com", timeout=12)
            time.sleep(1.5)
            resp = scraper.get(url, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        # Payload shape: {"data": {"indexCloseOnlineRecords": [...]}}
        rows = (
            data.get("data", {}).get("indexCloseOnlineRecords", [])
            or data.get("data", {}).get("indexTurnoverRecords", [])
        )
        if not rows:
            logger.warning("PDH/PDL: empty rows for %s on %s", symbol, ptd)
            return None

        row = rows[-1]           # last row = the date we requested
        high = float(row.get("EOD_HIGH_INDEX_VAL") or row.get("HIGH") or 0)
        low  = float(row.get("EOD_LOW_INDEX_VAL")  or row.get("LOW")  or 0)

        if high <= 0 or low <= 0:
            logger.warning("PDH/PDL: zero H/L in NSE response for %s", symbol)
            return None

        logger.info("PDH/PDL fetched from NSE hist for %s: H=%.2f L=%.2f", symbol, high, low)
        return {"pdh": high, "pdl": low, "date": ptd, "source": "nse_hist"}

    except Exception as exc:
        logger.warning("PDH/PDL NSE hist fetch failed for %s: %s", symbol, exc)
        return None


class PdhPdlProvider:
    """
    Thread-safe, daily-cached PDH/PDL provider.

    Usage (inside engine.py or at startup):
        provider = PdhPdlProvider(settings, scraper)
        levels   = provider.get("NIFTY")    # {"pdh": ..., "pdl": ..., "source": ...}
    """

    def __init__(self, settings: Settings, scraper):
        self.settings = settings
        self.scraper  = scraper
        self._cache: Dict[str, Dict] = {}

    # ------------------------------------------------------------------ #
    def _is_stale(self, symbol: str) -> bool:
        cached = self._cache.get(symbol)
        if not cached:
            return True
        today = datetime.now(IST).date()
        return cached["fetched_on"] != today

    # ------------------------------------------------------------------ #
    def get(self, symbol: str) -> Optional[Dict]:
        """
        Return {"pdh": float, "pdl": float, "source": str} for *symbol*.
        Tries NSE historical API first; falls back to first-candle approximation
        if the API is unavailable.
        """
        if not self._is_stale(symbol):
            return self._cache[symbol]

        result = fetch_pdh_pdl_from_nse(symbol, self.scraper)

        if result is None:
            # Fallback: return whatever we have in cache (even yesterday's)
            # The liquidity sweep FSM will stay in WAIT_FOR_LEVELS until valid
            # levels arrive.
            logger.warning(
                "PDH/PDL: API unavailable for %s — levels unavailable until next cycle",
                symbol,
            )
            return self._cache.get(symbol)     # None if first run

        result["fetched_on"] = datetime.now(IST).date()
        self._cache[symbol] = result
        return result

    # ------------------------------------------------------------------ #
    def seed_from_snapshots(self, symbol: str, spot_history: list) -> None:
        """
        Fallback: if we have at least 2 snapshots from early in the session
        we can approximate PDH/PDL from the first-candle range.
        Only used if the NSE hist API is unavailable AND we have no cached levels.
        """
        if not self._is_stale(symbol):
            return
        if len(spot_history) < 2:
            return

        spots = [s.spot for s in spot_history[:10]]   # first 10 ticks
        approx_h = max(spots)
        approx_l = min(spots)

        if approx_h <= 0 or approx_l <= 0:
            return

        logger.info(
            "PDH/PDL: using first-candle approximation for %s: H≈%.2f L≈%.2f",
            symbol, approx_h, approx_l,
        )
        self._cache[symbol] = {
            "pdh": approx_h,
            "pdl": approx_l,
            "date": _prev_trading_day(),
            "source": "first_candle_approx",
            "fetched_on": datetime.now(IST).date(),
        }
