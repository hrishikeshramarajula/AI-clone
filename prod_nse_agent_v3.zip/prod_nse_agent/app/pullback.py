"""
pullback.py
-----------
PullbackValidator — 7-filter scoring engine that separates real pullbacks
from fake bounces before the signal engine fires a trade.

All 7 filters described in the strategy doc are implemented here:
  1. Volume profile on the pullback candles (shrinking = real)
  2. Max candle count of the pullback (≤ 4 bars = real)
  3. Fibonacci retracement depth (must stay within 61.8%)
  4. EMA-9 position during pullback
  5. Bounce candle structure (strong body, closes above/below pivot)
  6. OI / PCR confirmation
  7. Pivot touch count awareness (2nd/3rd touch = higher confidence)

Score: 0–100.  Entry only allowed above MIN_SCORE (default 55).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import List, Optional

import numpy as np

from app.models import Snapshot

logger = logging.getLogger(__name__)

# ── Tunable constants ──────────────────────────────────────────────────────
MIN_SCORE: int        = 55      # minimum score to allow entry
PULLBACK_MAX_BARS: int = 4      # more bars = likely reversal, not pullback
FIB_618_LEVEL: float  = 0.618   # deepest acceptable retracement
EMA_PERIOD: int       = 9
PIVOT_PROXIMITY_PCT: float = 0.25  # % distance to consider "at pivot"


# ── EMA helper ─────────────────────────────────────────────────────────────
def _ema(prices: List[float], period: int) -> List[float]:
    """Compute EMA of a price series. Returns same-length list."""
    if len(prices) < 2:
        return prices[:]
    k = 2.0 / (period + 1)
    result = [prices[0]]
    for p in prices[1:]:
        result.append(p * k + result[-1] * (1 - k))
    return result


# ── Pivot helpers ──────────────────────────────────────────────────────────
def _pivot_levels(prev_high: float, prev_low: float, prev_close: float) -> dict:
    """Classic Floor pivot levels from previous bar's H/L/C."""
    pp = (prev_high + prev_low + prev_close) / 3.0
    r1 = 2 * pp - prev_low
    s1 = 2 * pp - prev_high
    r2 = pp + (prev_high - prev_low)
    s2 = pp - (prev_high - prev_low)
    return {"PP": pp, "R1": r1, "S1": s1, "R2": r2, "S2": s2}


def _nearest_pivot(spot: float, levels: dict) -> tuple[float, str]:
    """Return (level_price, level_name) of the nearest pivot to spot."""
    best_name = "PP"
    best_dist = float("inf")
    for name, price in levels.items():
        d = abs(spot - price)
        if d < best_dist:
            best_dist = d
            best_name = name
    return levels[best_name], best_name


def _at_pivot(spot: float, pivot: float) -> bool:
    return abs(spot - pivot) / max(spot, 1) * 100 <= PIVOT_PROXIMITY_PCT


# ── Touch count ────────────────────────────────────────────────────────────
def _count_touches(snapshots: List[Snapshot], pivot: float) -> int:
    """Count how many past snapshots were within PIVOT_PROXIMITY_PCT of a pivot."""
    count = 0
    for s in snapshots:
        if _at_pivot(s.spot, pivot):
            count += 1
    return max(count, 1)


# ── Fibonacci depth ────────────────────────────────────────────────────────
def _fib_retracement(move_start: float, move_end: float, pullback_end: float, direction: str) -> float:
    """Return 0.0–1.0 retracement ratio (0 = no retracement, 1 = full reversal)."""
    move_range = abs(move_end - move_start)
    if move_range < 0.001:
        return 0.0
    if direction == "BULLISH":
        retrace = move_end - pullback_end   # how much it pulled back from the top
    else:
        retrace = pullback_end - move_end   # how much it bounced from the bottom
    return max(0.0, min(1.0, retrace / move_range))


# ── Bounce candle structure ────────────────────────────────────────────────
def _bounce_candle_strength(snap: Snapshot, pivot: float, direction: str) -> float:
    """
    Score the last candle as a bounce candle.
    Uses spot as close approximation; returns 0.0–1.0.
    """
    # We approximate body/range from support-resistance spread as a proxy
    # since the Snapshot does not carry OHLC. Score what we can.
    closes_above = snap.spot > pivot if direction == "BULLISH" else snap.spot < pivot
    if not closes_above:
        return 0.0   # candle didn't close on the right side — hard fail

    # Distance above/below pivot as proxy for candle conviction
    gap_pct = abs(snap.spot - pivot) / max(pivot, 1) * 100
    if gap_pct >= 0.30:
        return 1.0
    elif gap_pct >= 0.15:
        return 0.70
    elif gap_pct >= 0.05:
        return 0.45
    return 0.20   # barely above — weak confirmation


# ── Main dataclass ─────────────────────────────────────────────────────────

@dataclass
class PullbackResult:
    score: int                  # 0–100
    allow_entry: bool           # True when score >= MIN_SCORE
    direction: str              # BULLISH / BEARISH / NEUTRAL
    pivot_level: float
    pivot_name: str
    touch_count: int
    fib_retracement: float
    ema9_ok: bool
    volume_ok: bool
    candle_ok: bool
    oi_ok: bool
    pullback_bars: int
    filter_scores: dict = field(default_factory=dict)
    detail: str = ""


class PullbackValidator:
    """
    Scores an incoming snapshot series against all 7 pullback filters.

    Usage:
        validator = PullbackValidator()
        result = validator.validate(snapshots, direction="BULLISH")
        if result.allow_entry:
            # proceed to trade signal
    """

    def __init__(self, min_score: int = MIN_SCORE):
        self.min_score = min_score

    # ── Public entry point ─────────────────────────────────────────────────
    def validate(self, snapshots: List[Snapshot], direction: str) -> PullbackResult:
        """
        Run all 7 filters. Returns PullbackResult with score and per-filter breakdown.
        Requires at least 5 snapshots.
        """
        if len(snapshots) < 5 or direction not in ("BULLISH", "BEARISH"):
            return PullbackResult(
                score=0, allow_entry=False, direction=direction,
                pivot_level=0.0, pivot_name="", touch_count=0,
                fib_retracement=0.0, ema9_ok=False, volume_ok=False,
                candle_ok=False, oi_ok=False, pullback_bars=0,
                detail="Insufficient history for pullback validation",
            )

        latest  = snapshots[-1]
        spots   = [s.spot for s in snapshots]

        # ── Pivot levels from oldest snapshot H/L/C approximation ─────────
        oldest  = snapshots[0]
        prev_high = max(s.spot for s in snapshots[:-1])
        prev_low  = min(s.spot for s in snapshots[:-1])
        prev_close = snapshots[-2].spot
        pivot_map = _pivot_levels(prev_high, prev_low, prev_close)

        # Use support/resistance from the snapshot as primary pivot reference
        if direction == "BULLISH":
            pivot_price = latest.support
            pivot_name  = "SUPPORT"
        else:
            pivot_price = latest.resistance
            pivot_name  = "RESISTANCE"

        # Fall back to nearest classical pivot if S/R is too far
        nearest_p, nearest_name = _nearest_pivot(latest.spot, pivot_map)
        if not _at_pivot(latest.spot, pivot_price):
            if _at_pivot(latest.spot, nearest_p):
                pivot_price = nearest_p
                pivot_name  = nearest_name

        # ── EMA 9 ──────────────────────────────────────────────────────────
        ema9_series = _ema(spots, EMA_PERIOD)
        ema9_now    = ema9_series[-1]
        if direction == "BULLISH":
            ema9_ok = latest.spot >= ema9_now    # price must stay above EMA 9
        else:
            ema9_ok = latest.spot <= ema9_now    # price must stay below EMA 9

        # ── Pullback bar count ─────────────────────────────────────────────
        # Count consecutive bars moving against the primary direction
        pullback_bars = 0
        for s in reversed(snapshots[:-1]):
            if direction == "BULLISH" and s.spot < snapshots[-1].spot:
                break
            elif direction == "BEARISH" and s.spot > snapshots[-1].spot:
                break
            pullback_bars += 1
        pullback_bars = max(pullback_bars, 1)
        bars_ok = pullback_bars <= PULLBACK_MAX_BARS

        # ── Fibonacci retracement ──────────────────────────────────────────
        # Find the swing move: oldest → peak (for BULLISH) or oldest → trough
        if direction == "BULLISH":
            move_start   = oldest.spot
            move_end     = max(spots[:-1])   # swing high before pullback
            pullback_end = latest.spot
        else:
            move_start   = oldest.spot
            move_end     = min(spots[:-1])   # swing low before pullback
            pullback_end = latest.spot

        fib_ratio = _fib_retracement(move_start, move_end, pullback_end, direction)
        fib_ok    = fib_ratio <= FIB_618_LEVEL

        # ── Volume filter ──────────────────────────────────────────────────
        # Pullback candles should have shrinking volume; bounce candle expanding
        vols = np.array([s.total_ce_vol + s.total_pe_vol for s in snapshots], dtype=float)
        if len(vols) >= 3 and vols.mean() > 0:
            pullback_vols   = vols[-pullback_bars-1:-1]   # bars during pullback
            bounce_vol      = vols[-1]                     # latest (bounce) bar
            avg_pullback_v  = float(np.mean(pullback_vols)) if len(pullback_vols) else float(bounce_vol)
            avg_baseline    = float(np.mean(vols[:-1]))
            volume_shrinking = avg_pullback_v <= avg_baseline * 1.05
            volume_expanding = bounce_vol >= avg_pullback_v * 1.10
            volume_ok = volume_shrinking and volume_expanding
        else:
            volume_ok = False

        # ── Bounce candle structure ────────────────────────────────────────
        candle_strength = _bounce_candle_strength(latest, pivot_price, direction)
        candle_ok       = candle_strength >= 0.45

        # ── OI / PCR confirmation ──────────────────────────────────────────
        pcr_now  = latest.oi_pcr
        pcr_prev = snapshots[-2].oi_pcr if len(snapshots) >= 2 else pcr_now
        if direction == "BULLISH":
            oi_ok = pcr_now >= 1.0 or (pcr_now > pcr_prev and pcr_now >= 0.85)
        else:
            oi_ok = pcr_now <= 1.0 or (pcr_now < pcr_prev and pcr_now <= 1.15)

        # ── Touch count / level quality ────────────────────────────────────
        touch_count = _count_touches(snapshots[:-1], pivot_price)

        # ── Scoring ────────────────────────────────────────────────────────
        # Each filter contributes a weighted max score. Total = 100.
        # Weights mirror the qualitative importance described in the doc.
        filter_scores: dict = {}

        # F1: Volume profile — 20 pts
        f1 = 20 if volume_ok else 0
        filter_scores["volume_profile"] = f1

        # F2: Pullback bar count — 15 pts (fewer bars = higher score)
        if pullback_bars == 1:   f2 = 15
        elif pullback_bars == 2: f2 = 13
        elif pullback_bars == 3: f2 = 9
        elif pullback_bars == 4: f2 = 4
        else:                    f2 = 0
        filter_scores["pullback_bars"] = f2

        # F3: Fibonacci depth — 20 pts
        if fib_ratio <= 0.382:   f3 = 20    # shallow = strong trend
        elif fib_ratio <= 0.500: f3 = 16
        elif fib_ratio <= 0.618: f3 = 10
        else:                    f3 = 0
        filter_scores["fibonacci"] = f3

        # F4: EMA 9 position — 15 pts
        f4 = 15 if ema9_ok else 0
        filter_scores["ema9"] = f4

        # F5: Bounce candle structure — 15 pts
        f5 = round(candle_strength * 15)
        filter_scores["candle_structure"] = f5

        # F6: OI / PCR confirmation — 10 pts
        f6 = 10 if oi_ok else 0
        filter_scores["oi_pcr"] = f6

        # F7: Touch count quality — 5 pts
        if touch_count == 1:   f7 = 2    # first touch — lower confidence
        elif touch_count == 2: f7 = 5    # second touch — sweet spot
        elif touch_count == 3: f7 = 4    # third touch — still strong
        else:                  f7 = 0    # 4th+ — level about to break
        filter_scores["touch_count"] = f7

        total_score = f1 + f2 + f3 + f4 + f5 + f6 + f7

        details = []
        if not volume_ok:     details.append("volume not confirming")
        if not bars_ok:       details.append(f"{pullback_bars} bars in pullback (max {PULLBACK_MAX_BARS})")
        if not fib_ok:        details.append(f"fib {fib_ratio:.1%} > 61.8% — trend may be broken")
        if not ema9_ok:       details.append("price crossed EMA9")
        if not candle_ok:     details.append("bounce candle weak")
        if not oi_ok:         details.append("OI/PCR not confirming")
        if touch_count >= 4:  details.append(f"level tested {touch_count}x — likely to break")

        logger.info(
            "PullbackValidator | %s | score=%d/%d | %s",
            direction, total_score, self.min_score,
            " | ".join(details) if details else "all filters OK"
        )

        return PullbackResult(
            score=total_score,
            allow_entry=total_score >= self.min_score,
            direction=direction,
            pivot_level=round(pivot_price, 2),
            pivot_name=pivot_name,
            touch_count=touch_count,
            fib_retracement=round(fib_ratio, 4),
            ema9_ok=ema9_ok,
            volume_ok=volume_ok,
            candle_ok=candle_ok,
            oi_ok=oi_ok,
            pullback_bars=pullback_bars,
            filter_scores=filter_scores,
            detail="; ".join(details) if details else "All 7 filters passed",
        )
