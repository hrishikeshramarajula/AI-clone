from __future__ import annotations

import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional


@dataclass
class CircuitBreaker:
    failure_threshold: int = 5
    recovery_seconds: int = 90
    failures: int = 0
    opened_at: Optional[datetime] = None

    def allow(self) -> bool:
        if self.opened_at is None:
            return True
        return datetime.utcnow() >= self.opened_at + timedelta(seconds=self.recovery_seconds)

    def record_success(self) -> None:
        self.failures = 0
        self.opened_at = None

    def record_failure(self) -> None:
        self.failures += 1
        if self.failures >= self.failure_threshold:
            self.opened_at = datetime.utcnow()



def backoff_sleep(attempt: int, base: float = 1.5, jitter: float = 0.8) -> None:
    delay = min(20.0, base * (2 ** max(attempt - 1, 0))) + random.uniform(0.0, jitter)
    time.sleep(delay)
