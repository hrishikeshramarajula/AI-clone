from __future__ import annotations

import json
import logging
import math
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Optional, Tuple
from zoneinfo import ZoneInfo

from app.config import INDEX_CONFIG, Settings
from app.models import Signal, Snapshot, TradeIdea

logger = logging.getLogger(__name__)


@dataclass
class RiskState:
    trading_day: str = ""
    trades_today: int = 0
    losses_today: int = 0
    consecutive_losses: int = 0
    last_signal_time: Dict[str, str] = None

    def to_dict(self) -> Dict:
        return {
            "trading_day": self.trading_day,
            "trades_today": self.trades_today,
            "losses_today": self.losses_today,
            "consecutive_losses": self.consecutive_losses,
            "last_signal_time": self.last_signal_time or {},
        }


class RiskManager:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.tz = ZoneInfo(settings.timezone)
        self.state_path = settings.data_dir / "risk_state.json"
        self.state = self._load_state()

    def _today_key(self) -> str:
        return datetime.now(self.tz).strftime("%Y-%m-%d")

    def _load_state(self) -> RiskState:
        if self.state_path.exists():
            raw = json.loads(self.state_path.read_text())
            return RiskState(
                trading_day=raw.get("trading_day", ""),
                trades_today=int(raw.get("trades_today", 0)),
                losses_today=int(raw.get("losses_today", 0)),
                consecutive_losses=int(raw.get("consecutive_losses", 0)),
                last_signal_time=dict(raw.get("last_signal_time", {})),
            )
        return RiskState(last_signal_time={})

    def _save(self) -> None:
        self.state_path.write_text(json.dumps(self.state.to_dict(), indent=2))

    def reset_if_new_day(self) -> None:
        today = self._today_key()
        if self.state.trading_day != today:
            self.state = RiskState(trading_day=today, last_signal_time={})
            self._save()

    def can_trade(self, signal: Signal, now: datetime) -> Tuple[bool, str]:
        self.reset_if_new_day()
        if signal.action != "TRADE":
            return False, "No-trade signal"
        if signal.confidence < self.settings.min_trade_confidence:
            return False, f"Confidence {signal.confidence:.2f} below threshold"
        if self.state.trades_today >= self.settings.max_trades_per_day:
            return False, "Daily trade cap reached"
        if self.state.losses_today >= self.settings.max_daily_losses:
            return False, "Daily loss cap reached"
        if self.state.consecutive_losses >= self.settings.max_consecutive_losses:
            return False, "Consecutive loss cap reached"

        key = f"{signal.symbol}:{signal.direction}"
        raw = (self.state.last_signal_time or {}).get(key)
        if raw:
            last = datetime.fromisoformat(raw)
            if now - last < timedelta(minutes=self.settings.duplicate_signal_window_minutes):
                return False, "Duplicate signal suppression window active"
        return True, "OK"

    def register_signal(self, signal: Signal, now: datetime) -> None:
        self.reset_if_new_day()
        key = f"{signal.symbol}:{signal.direction}"
        self.state.trades_today += 1
        self.state.last_signal_time[key] = now.isoformat()
        self._save()

    def register_outcome(self, win: bool) -> None:
        self.reset_if_new_day()
        if win:
            self.state.consecutive_losses = 0
        else:
            self.state.losses_today += 1
            self.state.consecutive_losses += 1
        self._save()

    def build_trade_idea(self, signal: Signal, snapshot: Snapshot, atr: float) -> Optional[TradeIdea]:
        candidate = self._select_best_strike(snapshot, signal.direction, atr)
        if candidate is None:
            return None
        lot_size = INDEX_CONFIG[snapshot.symbol].lot_size
        risk_per_unit = max(candidate["entry_price"] - candidate["sl"], 0.01)
        rupee_risk_per_lot = risk_per_unit * lot_size
        qty_lots = max(1, min(self.settings.max_lots_per_trade, math.floor(self.settings.per_trade_risk_rupees / rupee_risk_per_lot)))
        quantity = qty_lots * lot_size
        return TradeIdea(
            symbol=snapshot.symbol,
            direction=signal.direction,
            confidence=signal.confidence,
            strike=candidate["strike"],
            option_type=candidate["option_type"],
            entry_price=candidate["entry_price"],
            sl=candidate["sl"],
            target1=candidate["target1"],
            target2=candidate["target2"],
            risk_reward=candidate["risk_reward"],
            score=candidate["score"],
            qty_lots=qty_lots,
            quantity=quantity,
            phase=signal.phase,
            rationale=signal.rationale,
            diagnostics=signal.diagnostics,
        )

    def _select_best_strike(self, snapshot: Snapshot, direction: str, atr: float) -> Optional[Dict]:
        if direction not in {"BULLISH", "BEARISH"}:
            return None
        cfg = INDEX_CONFIG[snapshot.symbol]
        opt_type = "CE" if direction == "BULLISH" else "PE"
        best = None
        best_score = -1.0
        for strike, info in snapshot.strike_data.items():
            score = self._score_strike(strike, info, snapshot.atm_strike, cfg.strike_gap, opt_type)
            if score > best_score:
                best_score = score
                best = (strike, info)
        if not best or best_score <= 0:
            return None

        strike, info = best
        entry = float(info[f"{opt_type}_LTP"])
        delta = abs(float(info.get("DELTA_PROXY", 0.45)))
        if entry < self.settings.min_option_ltp:
            return None

        atr_valid = 0 < atr <= max(snapshot.spot * 0.05, 1.0)
        if atr_valid:
            sl_distance = min(entry * 0.40, max(entry * 0.18, delta * 0.65 * atr))
        else:
            sl_distance = entry * 0.22
        sl = round(max(entry - sl_distance, entry * 0.55), 2)
        risk = max(entry - sl, 0.01)
        target1 = round(entry + 1.4 * risk, 2)
        target2 = round(entry + 2.2 * risk, 2)
        rr = round((target2 - entry) / risk, 2)

        return {
            "strike": float(strike),
            "option_type": opt_type,
            "entry_price": round(entry, 2),
            "sl": sl,
            "target1": target1,
            "target2": target2,
            "risk_reward": rr,
            "score": round(best_score, 4),
        }

    def _score_strike(self, strike: float, info: Dict, atm_strike: float, strike_gap: int, opt_type: str) -> float:
        oi = int(info.get(f"{opt_type}_OI", 0))
        ltp = float(info.get(f"{opt_type}_LTP", 0.0))
        iv = float(info.get(f"{opt_type}_IV", 0.0))
        delta = abs(float(info.get("DELTA_PROXY", 0.5)))

        if oi < self.settings.min_option_oi or ltp < self.settings.min_option_ltp or iv > self.settings.max_option_iv:
            return 0.0

        dist = abs(strike - atm_strike) / max(strike_gap, 1)
        if dist == 0:
            prox = 0.90
        elif dist == 1:
            prox = 1.00
        elif dist == 2:
            prox = 0.72
        else:
            prox = 0.35

        oi_score = min(math.log10(max(oi, 1)) / 6.0, 1.0)
        iv_score = max(0.0, 1.0 - max(iv - 10.0, 0.0) / 40.0)
        delta_score = max(0.0, 1.0 - abs(delta - 0.45) / 0.45)
        return oi_score * 0.30 + iv_score * 0.20 + prox * 0.30 + delta_score * 0.20
