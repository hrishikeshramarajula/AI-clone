from __future__ import annotations

from datetime import datetime, time as dt_time
from typing import Dict, List

import numpy as np

from app.liquidity_sweep import LiquiditySweepFSM
from app.models import Signal, Snapshot
from app.pullback import PullbackValidator


SESSION_PHASES = [
    ((dt_time(9, 15), dt_time(9, 30)),   "OPENING",   0.85),
    ((dt_time(9, 30), dt_time(10, 15)),  "GOLDEN",    0.95),
    ((dt_time(10, 15), dt_time(11, 30)), "MORNING",   0.75),
    ((dt_time(11, 30), dt_time(13, 0)),  "LUNCH",     0.20),
    ((dt_time(13, 0), dt_time(14, 30)),  "AFTERNOON", 0.60),
    ((dt_time(14, 30), dt_time(15, 15)), "PRE_CLOSE", 0.70),
    ((dt_time(15, 15), dt_time(15, 30)), "CLOSING",   0.30),
]

_pullback_validator  = PullbackValidator()
_liquidity_sweep_fsm = LiquiditySweepFSM()


def get_session_phase(now: datetime) -> Dict:
    t = now.time()
    for (start, end), phase, weight in SESSION_PHASES:
        if start <= t < end:
            return {"phase": phase, "weight": weight, "tradeable": weight >= 0.50}
    return {"phase": "CLOSED", "weight": 0.0, "tradeable": False}


def calculate_vwap(snapshots: List[Snapshot]) -> float:
    pv = 0.0
    vol = 0.0
    for s in snapshots:
        total_vol = s.total_ce_vol + s.total_pe_vol
        if total_vol > 0:
            pv += s.spot * total_vol
            vol += total_vol
    return round(pv / vol, 2) if vol > 0 else (snapshots[-1].spot if snapshots else 0.0)


def calculate_atr(snapshots: List[Snapshot], lookback: int = 14) -> float:
    if len(snapshots) < 3:
        return 0.0
    window = snapshots[-lookback:]
    trs = []
    prev_close = window[0].spot
    for s in window[1:]:
        high = max(s.spot, s.resistance)
        low  = min(s.spot, s.support)
        tr   = max(high - low, abs(high - prev_close), abs(low - prev_close))
        trs.append(tr)
        prev_close = s.spot
    return round(float(np.mean(trs)), 2) if trs else 0.0


def analyse_oi(snapshots: List[Snapshot]) -> Dict:
    if len(snapshots) < 3:
        return {"bias": "NEUTRAL", "strength": 0.0, "detail": "insufficient history"}
    first, prev, latest = snapshots[0], snapshots[-2], snapshots[-1]
    ce_chg    = (latest.total_ce_oi - first.total_ce_oi) / max(first.total_ce_oi, 1) * 100
    pe_chg    = (latest.total_pe_oi - first.total_pe_oi) / max(first.total_pe_oi, 1) * 100
    price_chg = (latest.spot - first.spot) / max(first.spot, 1) * 100
    pcr_now   = latest.oi_pcr
    pcr_prev  = prev.oi_pcr

    bull = bear = 0.0
    reasons = []
    if price_chg > 0.15 and pe_chg > ce_chg + 0.25:
        bull += 0.75; reasons.append("Price rising with stronger PE OI build")
    if price_chg > 0.15 and ce_chg < -0.25:
        bull += 0.65; reasons.append("Price rising with CE OI unwind")
    if price_chg < -0.15 and pe_chg > 0.35:
        bear += 0.80; reasons.append("Price falling with PE OI build")
    if price_chg < -0.15 and ce_chg > 0.35:
        bear += 0.60; reasons.append("Price falling with CE OI build")
    if pcr_now > 1.15 and pcr_now > pcr_prev:
        bull += 0.45; reasons.append(f"PCR strong at {pcr_now:.2f}")
    if pcr_now < 0.90 and pcr_now < pcr_prev:
        bear += 0.45; reasons.append(f"PCR weak at {pcr_now:.2f}")

    if bull == bear:
        bias, strength = "NEUTRAL", 0.25
    elif bull > bear:
        bias, strength = "BULLISH", min(0.95, bull / (bull + bear + 0.01))
    else:
        bias, strength = "BEARISH", min(0.95, bear / (bull + bear + 0.01))

    return {
        "bias": bias,
        "strength": round(strength, 3),
        "ce_oi_chg_pct": round(ce_chg, 2),
        "pe_oi_chg_pct": round(pe_chg, 2),
        "price_chg_pct": round(price_chg, 2),
        "pcr": round(pcr_now, 3),
        "detail": " | ".join(reasons) if reasons else "No dominant OI edge",
    }


def volume_signal(snapshots: List[Snapshot]) -> Dict:
    if len(snapshots) < 5:
        return {"direction": "NEUTRAL", "strength": 0.0, "detail": "insufficient history"}
    vols     = np.array([s.total_ce_vol + s.total_pe_vol for s in snapshots[-5:]], dtype=float)
    baseline = float(np.mean(vols[:-1])) if len(vols) > 1 else float(vols[-1])
    latest   = float(vols[-1])
    if baseline <= 0:
        return {"direction": "NEUTRAL", "strength": 0.0, "detail": "zero baseline"}
    ratio    = latest / baseline
    spot_chg = snapshots[-1].spot - snapshots[-2].spot
    if ratio >= 1.35 and spot_chg > 0:
        return {"direction": "BULLISH", "strength": 0.60, "detail": f"Volume spike {ratio:.2f}x rising"}
    if ratio >= 1.35 and spot_chg < 0:
        return {"direction": "BEARISH", "strength": 0.60, "detail": f"Volume spike {ratio:.2f}x falling"}
    return {"direction": "NEUTRAL", "strength": 0.20, "detail": f"Volume ratio {ratio:.2f}x"}


def sr_signal(snapshot: Snapshot) -> Dict:
    if snapshot.spot <= 0:
        return {"direction": "NEUTRAL", "strength": 0.0, "detail": "invalid spot"}
    dist_support    = abs(snapshot.spot - snapshot.support)    / snapshot.spot * 100
    dist_resistance = abs(snapshot.resistance - snapshot.spot) / snapshot.spot * 100
    if dist_support <= 0.25 and snapshot.oi_pcr >= 1.0:
        return {"direction": "BULLISH", "strength": 0.55, "detail": "Near support with neutral/positive PCR"}
    if dist_resistance <= 0.25 and snapshot.oi_pcr <= 1.0:
        return {"direction": "BEARISH", "strength": 0.55, "detail": "Near resistance with neutral/negative PCR"}
    return {"direction": "NEUTRAL", "strength": 0.20, "detail": "Away from actionable S/R"}


def vwap_signal(snapshot: Snapshot, vwap: float) -> Dict:
    dev = (snapshot.spot - vwap) / max(vwap, 1) * 100 if vwap > 0 else 0.0
    if dev > 0.25:
        return {"direction": "BULLISH", "strength": 0.65 if dev < 0.50 else 0.85, "detail": f"Spot above VWAP by {dev:.2f}%"}
    if dev < -0.25:
        return {"direction": "BEARISH", "strength": 0.65 if dev > -0.50 else 0.85, "detail": f"Spot below VWAP by {abs(dev):.2f}%"}
    return {"direction": "NEUTRAL", "strength": 0.20, "detail": f"VWAP flat ({dev:.2f}%)"}


def generate_signal(
    symbol: str,
    snapshots: List[Snapshot],
    now: datetime,
    pdh: float | None = None,
    pdl: float | None = None,
) -> Signal:
    phase   = get_session_phase(now)
    latest  = snapshots[-1]
    oi      = analyse_oi(snapshots)
    vwap    = calculate_vwap(snapshots)
    vwap_sig = vwap_signal(latest, vwap)
    vol_sig  = volume_signal(snapshots)
    sr_sig   = sr_signal(latest)

    bullish = 0.0
    bearish = 0.0
    rationale = []

    for sig in (oi, vwap_sig, vol_sig, sr_sig):
        direction = sig.get("direction") or sig.get("bias")
        strength  = float(sig.get("strength", 0.0))
        detail    = sig.get("detail", "")
        if direction == "BULLISH":
            bullish += strength; rationale.append(f"BULL: {detail}")
        elif direction == "BEARISH":
            bearish += strength; rationale.append(f"BEAR: {detail}")

    if bullish == bearish:
        direction  = "NEUTRAL"
        confidence = 0.25
    elif bullish > bearish:
        direction  = "BULLISH"
        confidence = bullish / (bullish + bearish + 0.01)
    else:
        direction  = "BEARISH"
        confidence = bearish / (bullish + bearish + 0.01)

    confidence = round(min(0.97, confidence * phase["weight"]), 3)

    # ── Pullback validation gate ───────────────────────────────────────────
    # Only runs when we have a directional signal AND the session is tradeable.
    # A failing pullback score downgrades action to NO_TRADE without changing
    # direction or confidence so the rationale log stays clean.
    pullback_result = None
    pullback_blocked = False

    if phase["tradeable"] and direction != "NEUTRAL" and len(snapshots) >= 5:
        pullback_result = _pullback_validator.validate(snapshots, direction)
        if not pullback_result.allow_entry:
            pullback_blocked = True
            rationale.append(
                f"PULLBACK_BLOCKED(score={pullback_result.score}/100): {pullback_result.detail}"
            )

    action = (
        "TRADE"
        if (
            phase["tradeable"]
            and direction != "NEUTRAL"
            and confidence >= 0.55
            and not pullback_blocked
        )
        else "NO_TRADE"
    )

    # ── Liquidity Sweep FSM ───────────────────────────────────────────────
    # Runs unconditionally (even outside tradeable hours) so the state
    # machine can track the breakout as it develops.  When the FSM fires
    # it overrides direction + confidence and forces action to TRADE.
    sweep_result = _liquidity_sweep_fsm.evaluate(symbol, snapshots, pdh, pdl, now)

    if sweep_result.action in ("FIRE_BUY", "FIRE_SELL"):
        # Hard override — structural signal, bypass OI/VWAP scoring
        direction  = sweep_result.direction
        confidence = sweep_result.confidence
        action     = "TRADE"
        rationale.insert(0, f"LIQUIDITY_SWEEP({sweep_result.action}): {sweep_result.detail}")
        pullback_blocked = False   # don't let pullback gate block a structural setup

    diagnostics = {
        "oi":          oi,
        "vwap":        {**vwap_sig, "vwap": vwap},
        "volume":      vol_sig,
        "sr":          sr_sig,
        "phase_weight": phase["weight"],
        "liquidity_sweep": {
            "state":              sweep_result.state,
            "action":             sweep_result.action,
            "direction":          sweep_result.direction,
            "confidence":         sweep_result.confidence,
            "pdh":                sweep_result.pdh,
            "pdl":                sweep_result.pdl,
            "signal_candle_high": sweep_result.signal_candle_high,
            "signal_candle_low":  sweep_result.signal_candle_low,
            "bars_waited":        sweep_result.bars_waited,
            "detail":             sweep_result.detail,
        },
    }

    if pullback_result is not None:
        diagnostics["pullback"] = {
            "score":           pullback_result.score,
            "allow_entry":     pullback_result.allow_entry,
            "pivot_level":     pullback_result.pivot_level,
            "pivot_name":      pullback_result.pivot_name,
            "touch_count":     pullback_result.touch_count,
            "fib_retracement": pullback_result.fib_retracement,
            "ema9_ok":         pullback_result.ema9_ok,
            "volume_ok":       pullback_result.volume_ok,
            "candle_ok":       pullback_result.candle_ok,
            "oi_ok":           pullback_result.oi_ok,
            "pullback_bars":   pullback_result.pullback_bars,
            "filter_scores":   pullback_result.filter_scores,
            "detail":          pullback_result.detail,
        }

    return Signal(
        symbol=symbol,
        direction=direction,
        confidence=confidence,
        action=action,
        phase=phase["phase"],
        rationale=rationale,
        diagnostics=diagnostics,
    )
