from app.config import Settings
from app.engine import ProductionNseAgent
from app.logging_utils import setup_logging


def main() -> None:
    settings = Settings()
    setup_logging(settings.data_dir, settings.log_level)
    agent = ProductionNseAgent(settings)
    agent.run_forever()


if __name__ == "__main__":
    main()
