"""
tests/test_liquidity_sweep.py

Tests for:
  • LiquiditySweepFSM  (all 7 states + expiry + daily reset)
  • PdhPdlProvider.seed_from_snapshots (fallback approximation)
  • generate_signal() override when FSM fires
"""
from __future__ import annotations

from datetime import datetime
from typing import List
from unittest.mock import MagicMock, patch
from zoneinfo import ZoneInfo

import pytest

from app.liquidity_sweep import (
    FIRE_CONFIDENCE,
    MAX_SIGNAL_BARS,
    FSMState,
    LiquiditySweepFSM,
    SyntheticCandle,
)
from app.models import Snapshot
from app.pdh_pdl import PdhPdlProvider

IST = ZoneInfo("Asia/Kolkata")

# ── helpers ──────────────────────────────────────────────────────────────── #

def _now(hour: int = 10, minute: int = 0) -> datetime:
    return datetime(2024, 1, 15, hour, minute, 0, tzinfo=IST)


def _snap(spot: float) -> Snapshot:
    """Minimal Snapshot for FSM tests."""
    return Snapshot(
        symbol="NIFTY",
        timestamp="2024-01-15 10:00:00",
        expiry="15-Feb-2024",
        spot=spot,
        atm_strike=round(spot / 50) * 50,
        total_ce_oi=100_000,
        total_pe_oi=100_000,
        total_ce_vol=10_000,
        total_pe_vol=10_000,
        oi_pcr=1.0,
        vol_pcr=1.0,
        support=spot - 200,
        resistance=spot + 200,
        max_pain=spot,
        strike_data={},
    )


def _snaps(spots: List[float]) -> List[Snapshot]:
    return [_snap(s) for s in spots]


PDH = 22_100.0
PDL = 21_800.0

# ── SyntheticCandle ──────────────────────────────────────────────────────── #

class TestSyntheticCandle:
    def test_green(self):
        c = SyntheticCandle(open=100, high=110, low=95, close=105)
        assert c.is_green
        assert not c.is_red

    def test_red(self):
        c = SyntheticCandle(open=100, high=105, low=90, close=95)
        assert c.is_red
        assert not c.is_green

    def test_doji_is_green(self):
        c = SyntheticCandle(open=100, high=102, low=98, close=100)
        assert c.is_green     # close == open → counts as green


# ── WAIT_FOR_LEVELS ─────────────────────────────────────────────────────── #

class TestWaitForLevels:
    def test_stays_waiting_without_levels(self):
        fsm = LiquiditySweepFSM()
        snaps = _snaps([22_000, 22_010])
        r = fsm.evaluate("NIFTY", snaps, None, None, _now())
        assert r.state == FSMState.WAIT_FOR_LEVELS.name
        assert r.action == "HOLD"

    def test_transitions_when_levels_given(self):
        fsm = LiquiditySweepFSM()
        snaps = _snaps([22_000, 22_010, 22_020])
        r = fsm.evaluate("NIFTY", snaps, PDH, PDL, _now())
        # Spot inside range → WATCH_LOW_BREAK
        assert r.state in (FSMState.WATCH_LOW_BREAK.name, FSMState.WATCH_HIGH_BREAK.name)


# ── LOW BREAK → BUY path ─────────────────────────────────────────────────── #

class TestBuyPath:
    def _fresh_fsm(self) -> LiquiditySweepFSM:
        fsm = LiquiditySweepFSM()
        # Prime with levels — spot inside range
        fsm.evaluate("NIFTY", _snaps([22_000, 22_010, 22_020]), PDH, PDL, _now())
        return fsm

    def _fsm_in_wait_buy_signal(self) -> LiquiditySweepFSM:
        """
        Drive the FSM into WAIT_BUY_SIGNAL.
        The PDL break candle is RED (open > close) so the FSM stops at
        WAIT_BUY_SIGNAL instead of falling through to BUY_READY.
        """
        fsm = self._fresh_fsm()
        # Red candle that closes below PDL: open high → close low
        r = fsm.evaluate("NIFTY", _snaps([PDL + 10, PDL - 30, PDL - 50]), PDH, PDL, _now())
        return fsm

    def test_low_break_detected(self):
        """A red candle closing below PDL leaves FSM in WAIT_BUY_SIGNAL."""
        fsm = self._fresh_fsm()
        # Red candle (open=PDL+10, close=PDL-50) closes below PDL
        r = fsm.evaluate("NIFTY", _snaps([PDL + 10, PDL - 30, PDL - 50]), PDH, PDL, _now())
        assert r.state == FSMState.WAIT_BUY_SIGNAL.name

    def test_green_candle_triggers_buy_ready(self):
        fsm = self._fsm_in_wait_buy_signal()
        # Green candle: open < close
        r = fsm.evaluate("NIFTY", _snaps([PDL - 20, PDL - 10, PDL + 5]), PDH, PDL, _now())
        assert r.state == FSMState.BUY_READY.name

    def test_fire_buy_on_break_of_signal_candle_high(self):
        fsm = self._fsm_in_wait_buy_signal()
        # Green candle (signal candle): open=PDL-20, high=PDL+5
        fsm.evaluate("NIFTY", _snaps([PDL - 20, PDL - 10, PDL + 5]), PDH, PDL, _now())
        # Next bar's HIGH must exceed signal candle's HIGH (≈PDL+5)
        r = fsm.evaluate("NIFTY", _snaps([PDL + 5, PDL + 20, PDL + 30]), PDH, PDL, _now())
        assert r.action == "FIRE_BUY"
        assert r.direction == "BULLISH"
        assert r.confidence == FIRE_CONFIDENCE

    def test_red_candle_ignored_during_wait_buy_signal(self):
        fsm = self._fsm_in_wait_buy_signal()
        # Red candle (open > close) — should NOT advance to BUY_READY
        r = fsm.evaluate("NIFTY", _snaps([PDL + 5, PDL - 5, PDL - 15]), PDH, PDL, _now())
        assert r.state == FSMState.WAIT_BUY_SIGNAL.name


# ── HIGH BREAK → SELL path ───────────────────────────────────────────────── #

class TestSellPath:
    def _fresh_fsm(self) -> LiquiditySweepFSM:
        fsm = LiquiditySweepFSM()
        fsm.evaluate("NIFTY", _snaps([22_000, 22_010, 22_020]), PDH, PDL, _now())
        return fsm

    def test_high_break_detected(self):
        fsm = self._fresh_fsm()
        r = fsm.evaluate("NIFTY", _snaps([PDH + 10, PDH + 20, PDH + 30]), PDH, PDL, _now())
        assert r.state == FSMState.WAIT_SELL_SIGNAL.name

    def test_red_candle_triggers_sell_ready(self):
        fsm = self._fresh_fsm()
        fsm.evaluate("NIFTY", _snaps([PDH + 10, PDH + 20, PDH + 30]), PDH, PDL, _now())
        # Red candle: open > close
        r = fsm.evaluate("NIFTY", _snaps([PDH + 20, PDH + 10, PDH + 5]), PDH, PDL, _now())
        assert r.state == FSMState.SELL_READY.name

    def test_fire_sell_on_break_of_signal_candle_low(self):
        fsm = self._fresh_fsm()
        # Break PDH
        fsm.evaluate("NIFTY", _snaps([PDH + 10, PDH + 20, PDH + 30]), PDH, PDL, _now())
        # Red candle (low≈PDH+5)
        fsm.evaluate("NIFTY", _snaps([PDH + 20, PDH + 10, PDH + 5]), PDH, PDL, _now())
        # Next bar breaks signal candle's low downward
        r = fsm.evaluate("NIFTY", _snaps([PDH + 5, PDH - 5, PDH - 20]), PDH, PDL, _now())
        assert r.action == "FIRE_SELL"
        assert r.direction == "BEARISH"
        assert r.confidence == FIRE_CONFIDENCE

    def test_green_candle_ignored_during_wait_sell_signal(self):
        fsm = self._fresh_fsm()
        fsm.evaluate("NIFTY", _snaps([PDH + 10, PDH + 20, PDH + 30]), PDH, PDL, _now())
        # Green candle — should NOT advance to SELL_READY
        r = fsm.evaluate("NIFTY", _snaps([PDH + 10, PDH + 20, PDH + 30]), PDH, PDL, _now())
        assert r.state == FSMState.WAIT_SELL_SIGNAL.name


# ── Expiry / timeout ──────────────────────────────────────────────────────── #

class TestExpiry:
    def _fsm_in_wait_buy_signal(self) -> LiquiditySweepFSM:
        """Return an FSM stopped at WAIT_BUY_SIGNAL (red PDL-break candle)."""
        fsm = LiquiditySweepFSM()
        fsm.evaluate("NIFTY", _snaps([22_000, 22_010, 22_020]), PDH, PDL, _now())
        # Red candle below PDL → WAIT_BUY_SIGNAL (doesn't fall through)
        fsm.evaluate("NIFTY", _snaps([PDL + 10, PDL - 20, PDL - 50]), PDH, PDL, _now())
        return fsm

    def test_wait_buy_signal_expires(self):
        fsm = self._fsm_in_wait_buy_signal()
        # Keep sending red candles beyond MAX_SIGNAL_BARS
        for _ in range(MAX_SIGNAL_BARS + 1):
            r = fsm.evaluate("NIFTY", _snaps([PDL - 10, PDL - 20, PDL - 30]), PDH, PDL, _now())
        # Should have reset to WATCH_*
        assert r.state in (FSMState.WATCH_LOW_BREAK.name, FSMState.WATCH_HIGH_BREAK.name)

    def test_buy_ready_expires(self):
        fsm = self._fsm_in_wait_buy_signal()
        # Green candle → BUY_READY; signal candle high ≈ PDL+5
        fsm.evaluate("NIFTY", _snaps([PDL - 20, PDL - 10, PDL + 5]), PDH, PDL, _now())
        # Bars that stay BELOW signal candle high (PDL+5) → no FIRE, should expire
        # Use spots strictly below PDL+5 so candle.high never exceeds sc.high
        for _ in range(MAX_SIGNAL_BARS + 1):
            r = fsm.evaluate("NIFTY", _snaps([PDL + 1, PDL + 2, PDL + 3]), PDH, PDL, _now())
        assert r.state in (FSMState.WATCH_LOW_BREAK.name, FSMState.WATCH_HIGH_BREAK.name)


# ── Daily reset ───────────────────────────────────────────────────────────── #

class TestDailyReset:
    def test_resets_on_new_date(self):
        fsm = LiquiditySweepFSM()
        day1 = datetime(2024, 1, 15, 10, 0, tzinfo=IST)
        day2 = datetime(2024, 1, 16, 9, 20, tzinfo=IST)

        # Advance to BUY_READY on day 1
        # 1) Prime levels
        fsm.evaluate("NIFTY", _snaps([22_000, 22_010, 22_020]), PDH, PDL, day1)
        # 2) Red PDL-break candle → WAIT_BUY_SIGNAL
        fsm.evaluate("NIFTY", _snaps([PDL + 10, PDL - 20, PDL - 50]), PDH, PDL, day1)
        # 3) Green candle → BUY_READY
        fsm.evaluate("NIFTY", _snaps([PDL - 20, PDL - 10, PDL + 3]), PDH, PDL, day1)
        m = fsm._get("NIFTY")
        assert m.state == FSMState.BUY_READY

        # New day → full reset
        r = fsm.evaluate("NIFTY", _snaps([22_000, 22_010, 22_020]), PDH, PDL, day2)
        assert r.state in (
            FSMState.WAIT_FOR_LEVELS.name,
            FSMState.WATCH_LOW_BREAK.name,
            FSMState.WATCH_HIGH_BREAK.name,
        )


# ── reset_after_trade ─────────────────────────────────────────────────────── #

class TestResetAfterTrade:
    def test_reset_clears_position_open(self):
        fsm = LiquiditySweepFSM()
        m = fsm._get("NIFTY")
        m.state = FSMState.POSITION_OPEN
        m.pdh, m.pdl = PDH, PDL
        fsm.reset_after_trade("NIFTY")
        m2 = fsm._get("NIFTY")
        assert m2.state in (FSMState.WATCH_LOW_BREAK, FSMState.WATCH_HIGH_BREAK)


# ── PdhPdlProvider fallback ───────────────────────────────────────────────── #

class TestPdhPdlFallback:
    def test_seed_from_snapshots(self):
        mock_settings = MagicMock()
        mock_scraper  = MagicMock()
        provider = PdhPdlProvider(mock_settings, mock_scraper)

        snaps = _snaps([22_050, 21_950, 22_000, 22_100, 21_900])
        provider.seed_from_snapshots("NIFTY", snaps)
        levels = provider.get("NIFTY")
        assert levels is not None
        assert levels["pdh"] == pytest.approx(22_100)
        assert levels["pdl"] == pytest.approx(21_900)
        assert levels["source"] == "first_candle_approx"

    def test_no_seed_if_insufficient_snaps(self):
        mock_settings = MagicMock()
        mock_scraper  = MagicMock()
        provider = PdhPdlProvider(mock_settings, mock_scraper)
        # Patch fetch_pdh_pdl_from_nse so get() doesn't hit the network
        with patch("app.pdh_pdl.fetch_pdh_pdl_from_nse", return_value=None):
            provider.seed_from_snapshots("NIFTY", _snaps([22_000]))   # only 1 snap
            assert provider.get("NIFTY") is None

    def test_cache_not_overwritten_if_already_set(self):
        from datetime import date
        mock_settings = MagicMock()
        mock_scraper  = MagicMock()
        provider = PdhPdlProvider(mock_settings, mock_scraper)
        # Pre-seed with NSE-quality data
        from datetime import datetime
        from zoneinfo import ZoneInfo
        provider._cache["NIFTY"] = {
            "pdh": 22_200.0,
            "pdl": 21_700.0,
            "source": "nse_hist",
            "fetched_on": datetime.now(ZoneInfo("Asia/Kolkata")).date(),
        }
        # seed_from_snapshots should NOT overwrite because cache is fresh
        provider.seed_from_snapshots("NIFTY", _snaps([22_050, 21_950]))
        assert provider.get("NIFTY")["source"] == "nse_hist"


# ── generate_signal integration ───────────────────────────────────────────── #

class TestGenerateSignalIntegration:
    """
    Smoke test: generate_signal with FSM wired in.
    We mock the FSM to return FIRE_BUY and verify the signal is upgraded.
    """

    def test_fire_buy_overrides_signal(self):
        from app.liquidity_sweep import LiquiditySweepResult
        from app import signals as sig_module

        fire_result = LiquiditySweepResult(
            state="POSITION_OPEN",
            action="FIRE_BUY",
            direction="BULLISH",
            confidence=FIRE_CONFIDENCE,
            pdh=PDH, pdl=PDL,
            signal_candle_high=PDL + 20,
            signal_candle_low=PDL - 10,
            detail="Test fire",
            bars_waited=2,
        )

        with patch.object(sig_module._liquidity_sweep_fsm, "evaluate", return_value=fire_result):
            snaps = _snaps([22_000] * 10)
            now   = _now(10, 0)
            signal = sig_module.generate_signal("NIFTY", snaps, now, pdh=PDH, pdl=PDL)

        assert signal.direction == "BULLISH"
        assert signal.confidence == FIRE_CONFIDENCE
        assert signal.action == "TRADE"
        assert any("LIQUIDITY_SWEEP" in r for r in signal.rationale)
        assert "liquidity_sweep" in signal.diagnostics

    def test_neutral_fsm_does_not_override(self):
        from app.liquidity_sweep import LiquiditySweepResult
        from app import signals as sig_module

        hold_result = LiquiditySweepResult(
            state="WATCH_LOW_BREAK",
            action="HOLD",
            direction="NEUTRAL",
            confidence=0.0,
            pdh=PDH, pdl=PDL,
            signal_candle_high=None,
            signal_candle_low=None,
            detail="watching",
            bars_waited=1,
        )

        with patch.object(sig_module._liquidity_sweep_fsm, "evaluate", return_value=hold_result):
            snaps = _snaps([22_000] * 10)
            now   = _now(9, 45)    # GOLDEN phase, weight 0.95
            signal = sig_module.generate_signal("NIFTY", snaps, now, pdh=PDH, pdl=PDL)

        # FSM didn't fire — signal direction comes from OI/VWAP/volume
        assert signal.action in ("TRADE", "NO_TRADE")   # either is fine
        assert "liquidity_sweep" in signal.diagnostics
        # FSM detail should appear in diagnostics, not as a LIQUIDITY_SWEEP override
        assert not any("LIQUIDITY_SWEEP(FIRE" in r for r in signal.rationale)
