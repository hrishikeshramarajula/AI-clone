"""
test_pullback.py
----------------
Comprehensive tests for PullbackValidator and its integration into generate_signal.
"""
from __future__ import annotations

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

from app.config import Settings
from app.models import Snapshot, Signal
from app.pullback import (
    PullbackValidator, PullbackResult,
    _ema, _pivot_levels, _nearest_pivot, _at_pivot,
    _count_touches, _fib_retracement, _bounce_candle_strength,
    MIN_SCORE, EMA_PERIOD, FIB_618_LEVEL,
)
from app.signals import generate_signal, calculate_atr
from app.risk import RiskManager


# ── Fixtures ───────────────────────────────────────────────────────────────

def make_snap(
    spot: float,
    ce_oi: int = 5_000_000,
    pe_oi: int = 5_500_000,
    ce_vol: int = 200_000,
    pe_vol: int = 220_000,
    support: float = None,
    resistance: float = None,
) -> Snapshot:
    support    = support    or spot - 100
    resistance = resistance or spot + 100
    atm = round(spot / 50) * 50
    strike_data = {}
    for d in (-2, -1, 0, 1, 2):
        sk = atm + d * 50
        oi_val = 2_000_000 - abs(d) * 300_000
        ltp_ce = max(10.0, 120 - d * 20)
        ltp_pe = max(10.0, 120 + d * 20)
        strike_data[float(sk)] = {
            "CE_OI": oi_val, "PE_OI": oi_val,
            "CE_VOL": 60_000, "PE_VOL": 55_000,
            "CE_LTP": ltp_ce, "PE_LTP": ltp_pe,
            "CE_IV": 16.0, "PE_IV": 16.0,
            "DELTA_PROXY": 0.50 - d * 0.08,
        }
    return Snapshot(
        symbol="NIFTY", timestamp="2026-08-30 10:00:00", expiry="30-Dec-2026",
        spot=spot, atm_strike=float(atm),
        total_ce_oi=ce_oi, total_pe_oi=pe_oi,
        total_ce_vol=ce_vol, total_pe_vol=pe_vol,
        oi_pcr=round(pe_oi / ce_oi, 4), vol_pcr=1.1,
        support=support, resistance=resistance,
        max_pain=float(atm), strike_data=strike_data,
    )


def bullish_series(n: int = 12) -> list:
    """Rising price, building PE OI, shrinking pullback with volume."""
    base = 24000
    snaps = []
    for i in range(n):
        spot   = base + i * 8          # steadily rising
        pe_oi  = 5_500_000 + i * 30_000
        ce_oi  = 5_000_000 - i * 5_000
        # volume: low in middle bars (pullback), high on first & last (bounce)
        ce_vol = 180_000 if 3 < i < n - 1 else 280_000
        pe_vol = 200_000 if 3 < i < n - 1 else 310_000
        snaps.append(make_snap(spot, ce_oi=ce_oi, pe_oi=pe_oi,
                               ce_vol=ce_vol, pe_vol=pe_vol,
                               support=base - 50, resistance=base + 200))
    return snaps


def bearish_series(n: int = 12) -> list:
    base = 24200
    snaps = []
    for i in range(n):
        spot  = base - i * 8
        pe_oi = 4_800_000 + i * 40_000
        ce_oi = 5_300_000 - i * 10_000
        ce_vol = 180_000 if 3 < i < n - 1 else 280_000
        pe_vol = 200_000 if 3 < i < n - 1 else 310_000
        snaps.append(make_snap(spot, ce_oi=ce_oi, pe_oi=pe_oi,
                               ce_vol=ce_vol, pe_vol=pe_vol,
                               support=base - 300, resistance=base + 50))
    return snaps


def flat_series(n: int = 10) -> list:
    return [make_snap(24000) for _ in range(n)]


# ═══════════════════════════════════════════════════════════════════════════
# 1. EMA HELPER
# ═══════════════════════════════════════════════════════════════════════════

class TestEMA:
    def test_single_value(self):
        assert _ema([100.0], 9) == [100.0]

    def test_length_preserved(self):
        prices = [float(i) for i in range(20)]
        result = _ema(prices, EMA_PERIOD)
        assert len(result) == 20

    def test_rising_prices_ema_below_latest(self):
        prices = [float(i * 10) for i in range(1, 30)]
        ema = _ema(prices, 9)
        assert ema[-1] < prices[-1]   # lagging indicator

    def test_flat_prices_ema_equals_price(self):
        prices = [100.0] * 20
        ema = _ema(prices, 9)
        assert abs(ema[-1] - 100.0) < 0.01


# ═══════════════════════════════════════════════════════════════════════════
# 2. PIVOT LEVEL HELPERS
# ═══════════════════════════════════════════════════════════════════════════

class TestPivotHelpers:
    def test_pivot_levels_structure(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        for k in ("PP", "R1", "S1", "R2", "S2"):
            assert k in lvls

    def test_pp_calculation(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        expected_pp = (24200 + 23800 + 24000) / 3
        assert abs(lvls["PP"] - expected_pp) < 0.01

    def test_r1_above_pp(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        assert lvls["R1"] > lvls["PP"]

    def test_s1_below_pp(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        assert lvls["S1"] < lvls["PP"]

    def test_r2_above_r1(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        assert lvls["R2"] > lvls["R1"]

    def test_s2_below_s1(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        assert lvls["S2"] < lvls["S1"]

    def test_nearest_pivot_exact_hit(self):
        lvls = _pivot_levels(24200, 23800, 24000)
        price, name = _nearest_pivot(lvls["PP"], lvls)
        assert name == "PP"

    def test_at_pivot_within_threshold(self):
        assert _at_pivot(24000, 24000) is True
        assert _at_pivot(24060, 24000) is True   # 0.25% of 24000 = 60

    def test_at_pivot_outside_threshold(self):
        assert _at_pivot(24062, 24000) is False


# ═══════════════════════════════════════════════════════════════════════════
# 3. FIBONACCI RETRACEMENT
# ═══════════════════════════════════════════════════════════════════════════

class TestFibRetracement:
    def test_no_move_returns_zero(self):
        r = _fib_retracement(100, 100, 100, "BULLISH")
        assert r == 0.0

    def test_bullish_38pct_retracement(self):
        # move 100→200, pullback to ~162 (38.2% of 100 pts from top)
        r = _fib_retracement(100, 200, 162, "BULLISH")
        assert abs(r - 0.38) < 0.02

    def test_bullish_618pct_retracement(self):
        r = _fib_retracement(100, 200, 138, "BULLISH")
        assert abs(r - 0.62) < 0.02

    def test_bearish_50pct_retracement(self):
        # move 200→100, bounce back to 150 (50% of 100 pts from bottom)
        r = _fib_retracement(200, 100, 150, "BEARISH")
        assert abs(r - 0.50) < 0.02

    def test_full_reversal_clamped_to_1(self):
        r = _fib_retracement(100, 200, 50, "BULLISH")   # blew past start
        assert r == 1.0

    def test_no_retracement_returns_zero(self):
        r = _fib_retracement(100, 200, 200, "BULLISH")
        assert r == 0.0

    def test_within_618_is_ok(self):
        r = _fib_retracement(0, 100, 40, "BULLISH")  # 60% retrace ≤ 61.8%
        assert r <= FIB_618_LEVEL


# ═══════════════════════════════════════════════════════════════════════════
# 4. BOUNCE CANDLE STRENGTH
# ═══════════════════════════════════════════════════════════════════════════

class TestBounceCandleStrength:
    def test_spot_above_pivot_bullish(self):
        snap = make_snap(24070, support=24000)
        s = _bounce_candle_strength(snap, pivot=24000, direction="BULLISH")
        assert s > 0.0

    def test_spot_below_pivot_bullish_fails(self):
        snap = make_snap(23990, support=24000)
        s = _bounce_candle_strength(snap, pivot=24000, direction="BULLISH")
        assert s == 0.0

    def test_spot_below_pivot_bearish(self):
        snap = make_snap(23930, resistance=24000)
        s = _bounce_candle_strength(snap, pivot=24000, direction="BEARISH")
        assert s > 0.0

    def test_spot_above_pivot_bearish_fails(self):
        snap = make_snap(24050, resistance=24000)
        s = _bounce_candle_strength(snap, pivot=24000, direction="BEARISH")
        assert s == 0.0

    def test_strong_move_gives_max_score(self):
        snap = make_snap(24080, support=24000)   # 0.33% above pivot
        s = _bounce_candle_strength(snap, pivot=24000, direction="BULLISH")
        assert s == 1.0

    def test_strength_0_to_1(self):
        for offset in (0, 5, 20, 40, 80):
            snap = make_snap(24000 + offset, support=24000)
            s = _bounce_candle_strength(snap, pivot=24000, direction="BULLISH")
            assert 0.0 <= s <= 1.0


# ═══════════════════════════════════════════════════════════════════════════
# 5. TOUCH COUNT
# ═══════════════════════════════════════════════════════════════════════════

class TestTouchCount:
    def test_single_touch(self):
        snaps = [make_snap(24000 + i * 50) for i in range(5)]
        count = _count_touches(snaps, pivot=24000)
        assert count >= 1

    def test_multiple_touches(self):
        snaps = [make_snap(24000)] * 3 + [make_snap(24100)] * 2
        count = _count_touches(snaps, pivot=24000)
        assert count >= 3

    def test_no_touches_returns_1(self):
        snaps = [make_snap(25000) for _ in range(5)]
        count = _count_touches(snaps, pivot=24000)
        assert count == 1  # clamped to min 1


# ═══════════════════════════════════════════════════════════════════════════
# 6. PULLBACK VALIDATOR — CORE
# ═══════════════════════════════════════════════════════════════════════════

class TestPullbackValidator:
    pv = PullbackValidator(min_score=MIN_SCORE)

    def test_insufficient_history(self):
        r = self.pv.validate([make_snap(24000)] * 3, "BULLISH")
        assert r.allow_entry is False
        assert r.score == 0

    def test_neutral_direction_rejected(self):
        r = self.pv.validate(bullish_series(), "NEUTRAL")
        assert r.allow_entry is False

    def test_result_has_required_fields(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        assert hasattr(r, "score")
        assert hasattr(r, "allow_entry")
        assert hasattr(r, "filter_scores")
        assert hasattr(r, "fib_retracement")
        assert hasattr(r, "ema9_ok")
        assert hasattr(r, "volume_ok")
        assert hasattr(r, "candle_ok")
        assert hasattr(r, "oi_ok")
        assert hasattr(r, "pullback_bars")

    def test_score_in_valid_range(self):
        for series, direction in [(bullish_series(), "BULLISH"), (bearish_series(), "BEARISH")]:
            r = self.pv.validate(series, direction)
            assert 0 <= r.score <= 100, f"score {r.score} out of range"

    def test_filter_scores_sum_leq_100(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        total = sum(r.filter_scores.values())
        assert total <= 100

    def test_bullish_series_produces_result(self):
        r = self.pv.validate(bullish_series(15), "BULLISH")
        assert isinstance(r, PullbackResult)
        assert r.direction == "BULLISH"

    def test_bearish_series_produces_result(self):
        r = self.pv.validate(bearish_series(15), "BEARISH")
        assert isinstance(r, PullbackResult)
        assert r.direction == "BEARISH"

    def test_allow_entry_is_bool(self):
        r = self.pv.validate(flat_series(), "BULLISH")
        assert isinstance(r.allow_entry, bool)

    def test_flat_series_low_score(self):
        # Flat price: volume not confirming bounce, no real move to retrace
        r = self.pv.validate(flat_series(12), "BULLISH")
        assert r.score < 90   # shouldn't max out on flat data

    def test_touch_count_in_result(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        assert r.touch_count >= 1

    def test_ema9_ok_field_bullish_rising(self):
        # Rising series: spot at end should be above EMA9
        snaps = bullish_series(20)
        r = self.pv.validate(snaps, "BULLISH")
        assert r.ema9_ok is True

    def test_ema9_ok_field_bearish_falling(self):
        snaps = bearish_series(20)
        r = self.pv.validate(snaps, "BEARISH")
        assert r.ema9_ok is True

    def test_fib_retracement_in_result(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        assert 0.0 <= r.fib_retracement <= 1.0

    def test_pullback_bars_non_negative(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        assert r.pullback_bars >= 0

    def test_filter_scores_all_non_negative(self):
        for series, direction in [(bullish_series(), "BULLISH"), (bearish_series(), "BEARISH")]:
            r = self.pv.validate(series, direction)
            for k, v in r.filter_scores.items():
                assert v >= 0, f"filter_scores[{k}] = {v} < 0"

    def test_detail_string_present(self):
        r = self.pv.validate(bullish_series(), "BULLISH")
        assert isinstance(r.detail, str) and len(r.detail) > 0

    def test_high_volume_spike_on_bounce_helps(self):
        """Series where bounce bar has 3x volume → volume_ok more likely."""
        snaps = bullish_series(12)
        # Make last bar have very high volume = bounce spike
        last = snaps[-1]
        boosted = Snapshot(
            **{**last.__dict__,
               "total_ce_vol": last.total_ce_vol * 4,
               "total_pe_vol": last.total_pe_vol * 4}
        )
        snaps[-1] = boosted
        r = self.pv.validate(snaps, "BULLISH")
        # volume_ok may be True — score should be meaningful
        assert r.score >= 0

    def test_custom_min_score_threshold(self):
        """Validator with higher threshold blocks entries that lower one allows."""
        strict = PullbackValidator(min_score=95)
        lenient = PullbackValidator(min_score=10)
        snaps = bullish_series(12)
        r_strict  = strict.validate(snaps, "BULLISH")
        r_lenient = lenient.validate(snaps, "BULLISH")
        assert r_lenient.allow_entry is True   # 10 is trivially low
        # strict may or may not block depending on score — just check it ran
        assert isinstance(r_strict.allow_entry, bool)

    def test_many_touches_penalised(self):
        """4th+ touch of same level should score 0 on touch filter."""
        snaps = [make_snap(24000, support=24000)] * 12   # always at support
        r = self.pv.validate(snaps, "BULLISH")
        # 12 touches → touch_count filter should be 0
        assert r.filter_scores.get("touch_count", 0) == 0

    def test_3rd_touch_scores_4(self):
        snaps = [make_snap(24000, support=24000)] * 3 + [make_snap(24200, support=24000)] * 5
        # Exactly 3 touches on support=24000
        r = self.pv.validate(snaps + [make_snap(24000, support=24000)], "BULLISH")
        # touch_count filter should be 4 (3rd touch)
        tc = r.filter_scores.get("touch_count", -1)
        assert tc in (4, 5)   # 3rd touch → 4 pts; could be 2nd = 5 pts depending on count

    def test_deep_retracement_beyond_618_blocked(self):
        """Pullback deeper than 61.8% → fib filter = 0."""
        # Build a series that goes up then reverses more than 61.8%
        snaps = []
        # Up leg: 24000 → 24100
        for i in range(6):
            snaps.append(make_snap(24000 + i * 20, support=23900))
        # Deep retrace back to 24030 from 24100 (70pts retrace of 100pts move = 70%)
        snaps.append(make_snap(24030, support=23900))
        r = self.pv.validate(snaps, "BULLISH")
        assert r.filter_scores["fibonacci"] == 0

    def test_shallow_retracement_gives_max_fib_score(self):
        """Pullback ≤ 38.2% → fib filter = 20 pts."""
        snaps = []
        for i in range(7):
            snaps.append(make_snap(24000 + i * 30, support=23900))
        # Only 1 bar of very shallow pullback
        snaps.append(make_snap(24180, support=23900))   # barely dipped from 24210
        r = self.pv.validate(snaps, "BULLISH")
        assert r.filter_scores["fibonacci"] == 20


# ═══════════════════════════════════════════════════════════════════════════
# 7. INTEGRATION — generate_signal includes pullback diagnostics
# ═══════════════════════════════════════════════════════════════════════════

class TestSignalIntegration:

    def _now(self, hour=10, minute=5):
        return datetime(2026, 8, 30, hour, minute, tzinfo=ZoneInfo("Asia/Kolkata"))

    def test_signal_has_pullback_in_diagnostics(self):
        snaps = bullish_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        assert "pullback" in sig.diagnostics

    def test_pullback_diagnostics_fields(self):
        snaps = bullish_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        pb = sig.diagnostics["pullback"]
        for key in ("score", "allow_entry", "pivot_level", "fib_retracement",
                    "ema9_ok", "volume_ok", "candle_ok", "oi_ok",
                    "pullback_bars", "filter_scores", "detail"):
            assert key in pb, f"Missing pullback diagnostic key: {key}"

    def test_pullback_blocked_downgrades_to_no_trade(self):
        """When pullback score is below threshold, action must be NO_TRADE."""
        # Use flat series — no clear pullback signal → low score expected
        snaps = flat_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        # If signal happened to be NEUTRAL, action is NO_TRADE anyway.
        # If it's directional but pullback blocked, also NO_TRADE.
        assert sig.action in ("TRADE", "NO_TRADE")   # valid state machine

    def test_pullback_not_in_diagnostics_insufficient_history(self):
        """With only 3 snapshots, no pullback validation runs."""
        snaps = bullish_series(3)
        sig = generate_signal("NIFTY", snaps, self._now())
        # Either not in diagnostics or allow_entry=False
        if "pullback" in sig.diagnostics:
            assert sig.diagnostics["pullback"]["allow_entry"] is False

    def test_signal_action_no_trade_during_lunch(self):
        snaps = bullish_series(12)
        now = self._now(hour=12, minute=0)  # LUNCH phase
        sig = generate_signal("NIFTY", snaps, now)
        assert sig.action == "NO_TRADE"
        assert "pullback" not in sig.diagnostics   # not run during non-tradeable phases

    def test_signal_direction_unaffected_by_pullback_block(self):
        """Pullback gate must not change direction or confidence."""
        snaps = flat_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        # direction is still set by OI/VWAP/volume/SR — not by pullback
        assert sig.direction in ("BULLISH", "BEARISH", "NEUTRAL")
        assert 0.0 <= sig.confidence <= 1.0

    def test_pullback_block_adds_to_rationale(self):
        """When blocked, PULLBACK_BLOCKED should appear in rationale."""
        snaps = flat_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        if "pullback" in sig.diagnostics and not sig.diagnostics["pullback"]["allow_entry"]:
            assert any("PULLBACK_BLOCKED" in r for r in sig.rationale)

    def test_full_pipeline_with_risk_manager(self, tmp_path):
        """Golden path: signal → risk → trade idea, all with pullback validation."""
        settings = Settings(data_dir=tmp_path)
        snaps = bullish_series(12)
        now = self._now()
        sig = generate_signal("NIFTY", snaps, now)
        atr = calculate_atr(snaps)
        risk = RiskManager(settings)
        ok, reason = risk.can_trade(sig, now)
        if ok:
            idea = risk.build_trade_idea(sig, snaps[-1], atr)
            assert idea is not None
            assert idea.quantity > 0
        # Even if can't trade, pipeline must not crash
        assert sig.direction in ("BULLISH", "BEARISH", "NEUTRAL")

    def test_pullback_score_exposed_in_diagnostics(self):
        snaps = bullish_series(15)
        sig = generate_signal("NIFTY", snaps, self._now())
        if "pullback" in sig.diagnostics:
            score = sig.diagnostics["pullback"]["score"]
            assert isinstance(score, int)
            assert 0 <= score <= 100

    def test_filter_scores_dict_in_diagnostics(self):
        snaps = bullish_series(12)
        sig = generate_signal("NIFTY", snaps, self._now())
        if "pullback" in sig.diagnostics:
            fs = sig.diagnostics["pullback"]["filter_scores"]
            assert isinstance(fs, dict)
            for key in ("volume_profile", "pullback_bars", "fibonacci",
                        "ema9", "candle_structure", "oi_pcr", "touch_count"):
                assert key in fs

    def test_trade_signal_requires_pullback_pass(self):
        """If action=TRADE, pullback must have been allowed."""
        snaps = bullish_series(20)
        now = self._now()
        sig = generate_signal("NIFTY", snaps, now)
        if sig.action == "TRADE" and "pullback" in sig.diagnostics:
            assert sig.diagnostics["pullback"]["allow_entry"] is True


# ═══════════════════════════════════════════════════════════════════════════
# 8. EDGE CASES & STRESS
# ═══════════════════════════════════════════════════════════════════════════

class TestEdgeCases:

    def test_all_same_spot(self):
        """Flat price series — must not crash."""
        pv = PullbackValidator()
        r = pv.validate([make_snap(24000)] * 10, "BULLISH")
        assert isinstance(r, PullbackResult)

    def test_single_large_price_gap(self):
        """Extreme move: 24000 → 30000 in one step."""
        snaps = [make_snap(24000)] * 6 + [make_snap(30000)]
        pv = PullbackValidator()
        r = pv.validate(snaps, "BULLISH")
        assert 0 <= r.score <= 100

    def test_zero_volume_snapshots(self):
        snaps = [make_snap(24000 + i, ce_vol=0, pe_vol=0) for i in range(10)]
        pv = PullbackValidator()
        r = pv.validate(snaps, "BULLISH")
        assert r.volume_ok is False    # can't confirm volume with zeros

    def test_very_deep_series_100_snaps(self):
        snaps = bullish_series(100)
        pv = PullbackValidator()
        r = pv.validate(snaps, "BULLISH")
        assert 0 <= r.score <= 100

    def test_bearish_then_bullish_direction_mismatch(self):
        """Bearish price series validated as BULLISH → EMA9 filter should fail."""
        snaps = bearish_series(12)
        pv = PullbackValidator()
        r = pv.validate(snaps, "BULLISH")
        # spot is below EMA9 in a falling series → ema9_ok should be False
        assert r.ema9_ok is False

    def test_bullish_then_bearish_direction_mismatch(self):
        snaps = bullish_series(12)
        pv = PullbackValidator()
        r = pv.validate(snaps, "BEARISH")
        assert r.ema9_ok is False

    def test_score_never_negative(self):
        for series in [flat_series(), bullish_series(), bearish_series()]:
            for direction in ("BULLISH", "BEARISH"):
                r = PullbackValidator().validate(series, direction)
                assert r.score >= 0

    def test_score_never_exceeds_100(self):
        for series in [flat_series(), bullish_series(), bearish_series()]:
            for direction in ("BULLISH", "BEARISH"):
                r = PullbackValidator().validate(series, direction)
                assert r.score <= 100

    def test_generate_signal_100_snaps_no_crash(self):
        snaps = bullish_series(100)
        now = datetime(2026, 8, 30, 10, 5, tzinfo=ZoneInfo("Asia/Kolkata"))
        sig = generate_signal("NIFTY", snaps, now)
        assert sig.action in ("TRADE", "NO_TRADE")
