from datetime import datetime
from zoneinfo import ZoneInfo

from app.config import Settings
from app.models import Snapshot
from app.risk import RiskManager
from app.signals import calculate_atr, generate_signal



def make_snapshot(spot: float, ce_oi: int, pe_oi: int, vol_mult: int = 1) -> Snapshot:
    strike_data = {
        24000.0: {
            "CE_OI": 2500000,
            "PE_OI": 2700000,
            "CE_VOL": 100000 * vol_mult,
            "PE_VOL": 120000 * vol_mult,
            "CE_LTP": 125.0,
            "PE_LTP": 118.0,
            "CE_IV": 18.0,
            "PE_IV": 18.0,
            "DELTA_PROXY": 0.45,
        },
        24050.0: {
            "CE_OI": 2800000,
            "PE_OI": 2600000,
            "CE_VOL": 140000 * vol_mult,
            "PE_VOL": 100000 * vol_mult,
            "CE_LTP": 110.0,
            "PE_LTP": 135.0,
            "CE_IV": 19.0,
            "PE_IV": 20.0,
            "DELTA_PROXY": 0.45,
        },
    }
    return Snapshot(
        symbol="NIFTY",
        timestamp="2026-08-30 10:00:00",
        expiry="31-Dec-2099",
        spot=spot,
        atm_strike=24000.0,
        total_ce_oi=ce_oi,
        total_pe_oi=pe_oi,
        total_ce_vol=200000 * vol_mult,
        total_pe_vol=220000 * vol_mult,
        oi_pcr=round(pe_oi / ce_oi, 4),
        vol_pcr=1.1,
        support=23950.0,
        resistance=24100.0,
        max_pain=24000.0,
        strike_data=strike_data,
    )



def test_signal_and_risk_pipeline(tmp_path):
    settings = Settings(data_dir=tmp_path)
    snapshots = [
        make_snapshot(23940.0, 5000000, 5050000, 1),
        make_snapshot(23980.0, 4980000, 5200000, 1),
        make_snapshot(24025.0, 4940000, 5400000, 2),
        make_snapshot(24045.0, 4920000, 5480000, 2),
        make_snapshot(24070.0, 4900000, 5560000, 3),
        make_snapshot(24090.0, 4880000, 5640000, 3),
        make_snapshot(24110.0, 4860000, 5720000, 4),
        make_snapshot(24130.0, 4840000, 5820000, 4),
    ]
    now = datetime(2026, 8, 30, 10, 5, tzinfo=ZoneInfo(settings.timezone))
    signal = generate_signal("NIFTY", snapshots, now)
    assert signal.direction in {"BULLISH", "BEARISH", "NEUTRAL"}
    atr = calculate_atr(snapshots)
    risk = RiskManager(settings)
    ok, _ = risk.can_trade(signal, now)
    if ok:
        idea = risk.build_trade_idea(signal, snapshots[-1], atr)
        assert idea is not None
        assert idea.quantity > 0
