import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { gameName, gameGenre, gameDescription } = await request.json()

    if (!gameName || !gameGenre) {
      return NextResponse.json(
        { error: 'Game name and genre are required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const prompt = `Generate a comprehensive game design document for a ${gameGenre} game called "${gameName}". 
    
    Game Description: ${gameDescription || 'No specific description provided'}
    
    Please provide:
    1. Core game mechanics and gameplay systems
    2. Visual style and art direction
    3. Story and narrative elements (if applicable)
    4. Technical requirements and architecture
    5. Asset requirements (characters, environments, UI, etc.)
    6. AI systems and behaviors
    7. Multiplayer features (if applicable)
    8. Monetization strategy
    
    Format the response as a structured JSON object with the following keys:
    - mechanics: array of core gameplay mechanics
    - visualStyle: object describing art direction
    - story: object containing narrative elements
    - technical: object with technical specifications
    - assets: array of required asset types
    - aiSystems: array of AI components
    - multiplayer: object with multiplayer features
    - monetization: object with monetization strategy
    - codeStructure: object with suggested code architecture
    - databaseSchema: object with database design suggestions`

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an expert game designer and developer. Provide detailed, professional game design documents with technical specifications.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    })

    const responseContent = completion.choices[0]?.message?.content
    
    if (!responseContent) {
      throw new Error('No response from AI')
    }

    // Parse the JSON response
    let gameDesign
    try {
      gameDesign = JSON.parse(responseContent)
    } catch (parseError) {
      console.warn('JSON parsing failed, creating structured response from text:', parseError)
      // If JSON parsing fails, create a structured response from the text
      gameDesign = {
        mechanics: extractArrayFromText(responseContent, ['mechanics', 'gameplay', 'systems']),
        visualStyle: {
          style: extractFromText(responseContent, ['style', 'art direction', 'visual']) || 'Modern',
          theme: extractFromText(responseContent, ['theme', 'setting']) || gameGenre.toLowerCase(),
          colorScheme: extractFromText(responseContent, ['colors', 'palette']) || 'Dynamic'
        },
        story: {
          hasStory: responseContent.toLowerCase().includes('story') || responseContent.toLowerCase().includes('narrative'),
          description: extractFromText(responseContent, ['story', 'narrative', 'plot']) || 'Engaging narrative',
          setting: extractFromText(responseContent, ['setting', 'world', 'environment']) || 'Immersive world'
        },
        technical: {
          engine: extractFromText(responseContent, ['engine', 'technology']) || 'WebGL/Three.js',
          platform: extractFromText(responseContent, ['platform', 'target']) || 'Web',
          complexity: extractFromText(responseContent, ['complexity', 'difficulty']) || 'Medium'
        },
        assets: extractArrayFromText(responseContent, ['assets', 'resources', 'content']),
        aiSystems: extractArrayFromText(responseContent, ['ai', 'artificial intelligence', 'npc']),
        multiplayer: {
          enabled: responseContent.toLowerCase().includes('multiplayer') || responseContent.toLowerCase().includes('online'),
          maxPlayers: extractNumber(responseContent) || 8,
          features: extractArrayFromText(responseContent, ['multiplayer', 'online', 'co-op'])
        },
        monetization: {
          strategy: extractFromText(responseContent, ['monetization', 'business model']) || 'Free to play',
          features: extractArrayFromText(responseContent, ['monetization', 'revenue', 'payment'])
        },
        codeStructure: {
          architecture: extractFromText(responseContent, ['architecture', 'structure']) || 'Component-based',
          patterns: extractArrayFromText(responseContent, ['patterns', 'design patterns'])
        },
        databaseSchema: {
          tables: extractArrayFromText(responseContent, ['database', 'tables', 'schema'])
        }
      }
    }

    return NextResponse.json({
      success: true,
      gameDesign,
      rawResponse: responseContent,
      message: `Game design for "${gameName}" generated successfully using AI!`
    })

  } catch (error) {
    console.error('Game generation error:', error)
    return NextResponse.json(
      { 
        error: 'Failed to generate game design', 
        details: error.message,
        fallback: {
          mechanics: ['Basic movement system', 'Interactive objects', 'Score system'],
          visualStyle: { style: 'Modern', theme: gameGenre.toLowerCase(), colorScheme: 'Vibrant' },
          story: { hasStory: false, description: 'Basic game experience' },
          technical: { engine: 'Custom', platform: 'Web', complexity: 'Medium' },
          assets: ['Characters', 'Environment', 'UI Elements', 'Sound Effects'],
          aiSystems: ['Basic NPC behavior', 'Pathfinding'],
          multiplayer: { enabled: false, maxPlayers: 1 },
          monetization: { strategy: 'Free to play' },
          codeStructure: { architecture: 'Component-based', patterns: ['Observer', 'Factory'] },
          databaseSchema: { tables: ['users', 'game_state', 'assets'] }
        }
      },
      { status: 500 }
    )
  }
}

// Helper functions to extract information from text
function extractArrayFromText(text: string, keywords: string[]): string[] {
  const lines = text.split('\n')
  const result: string[] = []
  
  for (const line of lines) {
    if (keywords.some(keyword => line.toLowerCase().includes(keyword))) {
      // Extract items that look like list items or bullet points
      const items = line.match(/[-*•]\s*([^-\n]+)/g) || line.match(/\d+\.\s*([^\n]+)/g)
      if (items) {
        result.push(...items.map(item => item.replace(/^[-*•\d.\s]*/, '').trim()))
      }
    }
  }
  
  return result.length > 0 ? result : ['Default system']
}

function extractFromText(text: string, keywords: string[]): string {
  for (const line of text.split('\n')) {
    if (keywords.some(keyword => line.toLowerCase().includes(keyword))) {
      // Extract the value after the keyword
      const match = line.match(/:\s*([^,\n]+)/)
      if (match) {
        return match[1].trim()
      }
    }
  }
  return 'Default'
}

function extractNumber(text: string): number {
  const numbers = text.match(/\b(\d+)\b/g)
  return numbers ? parseInt(numbers[0]) : 8
}