"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { 
  Gamepad2, 
  Wand2, 
  Monitor, 
  Settings, 
  Users, 
  Zap, 
  Palette, 
  Code,
  Play,
  Pause,
  RotateCcw,
  Download,
  Share2,
  Sparkles
} from "lucide-react"

export default function Home() {
  const [selectedGenre, setSelectedGenre] = useState<string>("")
  const [gameName, setGameName] = useState<string>("")
  const [gameDescription, setGameDescription] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState<boolean>(false)
  const [generationProgress, setGenerationProgress] = useState<number>(0)
  const [activeTab, setActiveTab] = useState<string>("overview")
  const [generatedGame, setGeneratedGame] = useState<any>(null)
  const [isPlayingDemo, setIsPlayingDemo] = useState<boolean>(false)
  const [gameScore, setGameScore] = useState<number>(0)
  const [gameLevel, setGameLevel] = useState<number>(1)

  // Load generated game data from localStorage on component mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedGame = localStorage.getItem('generatedGame')
      if (savedGame) {
        try {
          setGeneratedGame(JSON.parse(savedGame))
          setGenerationProgress(100)
        } catch (error) {
          console.error('Failed to load saved game:', error)
        }
      }
    }
  }, [])

  // Game demo logic
  const startGameDemo = () => {
    setIsPlayingDemo(true)
    setGameScore(0)
    setGameLevel(1)
  }

  const endGameDemo = () => {
    setIsPlayingDemo(false)
    setGameScore(0)
    setGameLevel(1)
  }

  const handleGameAction = (action: string) => {
    if (!generatedGame) return
    
    const genre = generatedGame.gameGenre.toLowerCase()
    
    switch (genre) {
      case 'rpg':
        handleRPGAction(action)
        break
      case 'fps':
        handleFPSAction(action)
        break
      case 'puzzle':
        handlePuzzleAction(action)
        break
      case 'strategy':
        handleStrategyAction(action)
        break
      default:
        handleGenericAction(action)
    }
  }

  const handleRPGAction = (action: string) => {
    switch (action) {
      case 'attack':
        setGameScore(prev => prev + Math.floor(Math.random() * 20) + 10)
        break
      case 'defend':
        setGameScore(prev => prev + Math.floor(Math.random() * 10) + 5)
        break
      case 'magic':
        setGameScore(prev => prev + Math.floor(Math.random() * 30) + 15)
        break
      case 'levelup':
        if (gameScore >= gameLevel * 100) {
          setGameLevel(prev => prev + 1)
          setGameScore(0)
        }
        break
    }
  }

  const handleFPSAction = (action: string) => {
    switch (action) {
      case 'shoot':
        setGameScore(prev => prev + Math.floor(Math.random() * 15) + 5)
        break
      case 'reload':
        setGameScore(prev => prev + 2)
        break
      case 'headshot':
        setGameScore(prev => prev + Math.floor(Math.random() * 50) + 25)
        break
      case 'spree':
        if (gameScore >= 100) {
          setGameLevel(prev => prev + 1)
          setGameScore(0)
        }
        break
    }
  }

  const handlePuzzleAction = (action: string) => {
    switch (action) {
      case 'solve':
        setGameScore(prev => prev + Math.floor(Math.random() * 25) + 10)
        break
      case 'hint':
        setGameScore(prev => prev + 5)
        break
      case 'bonus':
        setGameScore(prev => prev + Math.floor(Math.random() * 40) + 20)
        break
      case 'complete':
        if (gameScore >= gameLevel * 50) {
          setGameLevel(prev => prev + 1)
          setGameScore(0)
        }
        break
    }
  }

  const handleStrategyAction = (action: string) => {
    switch (action) {
      case 'build':
        setGameScore(prev => prev + Math.floor(Math.random() * 20) + 10)
        break
      case 'attack':
        setGameScore(prev => prev + Math.floor(Math.random() * 15) + 8)
        break
      case 'defend':
        setGameScore(prev => prev + Math.floor(Math.random() * 12) + 6)
        break
      case 'expand':
        if (gameScore >= gameLevel * 80) {
          setGameLevel(prev => prev + 1)
          setGameScore(0)
        }
        break
    }
  }

  const handleGenericAction = (action: string) => {
    setGameScore(prev => prev + Math.floor(Math.random() * 10) + 5)
    if (gameScore >= gameLevel * 60) {
      setGameLevel(prev => prev + 1)
      setGameScore(0)
    }
  }

  // Helper functions for game demo
  const getGameActions = () => {
    if (!generatedGame) return []
    
    const genre = generatedGame.gameGenre.toLowerCase()
    
    switch (genre) {
      case 'rpg':
        return [
          { id: 'attack', label: 'Attack', icon: '⚔️ ' },
          { id: 'defend', label: 'Defend', icon: '🛡️ ' },
          { id: 'magic', label: 'Magic', icon: '✨ ' },
          { id: 'levelup', label: 'Level Up', icon: '⬆️ ' }
        ]
      case 'fps':
        return [
          { id: 'shoot', label: 'Shoot', icon: '🔫 ' },
          { id: 'reload', label: 'Reload', icon: '🔄 ' },
          { id: 'headshot', label: 'Headshot', icon: '🎯 ' },
          { id: 'spree', label: 'Spree', icon: '🔥 ' }
        ]
      case 'puzzle':
        return [
          { id: 'solve', label: 'Solve', icon: '🧩 ' },
          { id: 'hint', label: 'Hint', icon: '💡 ' },
          { id: 'bonus', label: 'Bonus', icon: '⭐ ' },
          { id: 'complete', label: 'Complete', icon: '✅ ' }
        ]
      case 'strategy':
        return [
          { id: 'build', label: 'Build', icon: '🏗️ ' },
          { id: 'attack', label: 'Attack', icon: '⚔️ ' },
          { id: 'defend', label: 'Defend', icon: '🛡️ ' },
          { id: 'expand', label: 'Expand', icon: '📈 ' }
        ]
      default:
        return [
          { id: 'action1', label: 'Action 1', icon: '🎮 ' },
          { id: 'action2', label: 'Action 2', icon: '🎯 ' },
          { id: 'action3', label: 'Action 3', icon: '⚡ ' },
          { id: 'action4', label: 'Action 4', icon: '🌟 ' }
        ]
    }
  }

  const getProgressToNextLevel = () => {
    if (!generatedGame) return 0
    
    const genre = generatedGame.gameGenre.toLowerCase()
    let targetScore
    
    switch (genre) {
      case 'rpg':
        targetScore = gameLevel * 100
        break
      case 'fps':
        targetScore = 100
        break
      case 'puzzle':
        targetScore = gameLevel * 50
        break
      case 'strategy':
        targetScore = gameLevel * 80
        break
      default:
        targetScore = gameLevel * 60
    }
    
    return Math.min((gameScore / targetScore) * 100, 100)
  }

  const gameGenres = [
    { id: "rpg", name: "RPG", description: "Role-playing games with deep narratives" },
    { id: "fps", name: "FPS", description: "First-person shooter games" },
    { id: "strategy", name: "Strategy", description: "Turn-based and real-time strategy" },
    { id: "puzzle", name: "Puzzle", description: "Brain-teasing puzzle games" },
    { id: "platformer", name: "Platformer", description: "Side-scrolling adventure games" },
    { id: "racing", name: "Racing", description: "High-speed racing games" },
    { id: "simulation", name: "Simulation", description: "Real-world simulation games" },
    { id: "sports", name: "Sports", description: "Various sports games" }
  ]

  const handleGenerateGame = async () => {
    if (!selectedGenre || !gameName) return
    
    setIsGenerating(true)
    setGenerationProgress(0)
    
    try {
      // Step 1: Generate game design
      setGenerationProgress(10)
      const gameResponse = await fetch('/api/game/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameName,
          gameGenre: selectedGenre,
          gameDescription
        })
      })
      
      if (!gameResponse.ok) {
        const errorData = await gameResponse.json()
        throw new Error(errorData.error || 'Failed to generate game design')
      }
      
      const gameData = await gameResponse.json()
      console.log('Game design generated:', gameData)
      
      // Step 2: Generate assets
      setGenerationProgress(40)
      const assetTypes = ['character', 'environment', 'ui']
      const assetResults = []
      
      for (const assetType of assetTypes) {
        try {
          const assetResponse = await fetch('/api/assets/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              assetType,
              gameGenre: selectedGenre,
              gameName,
              description: gameDescription
            })
          })
          
          if (assetResponse.ok) {
            const assetData = await assetResponse.json()
            assetResults.push(assetData)
            console.log(`${assetType} assets generated:`, assetData)
          }
        } catch (assetError) {
          console.warn(`Failed to generate ${assetType} assets:`, assetError)
          // Continue with other assets even if one fails
        }
      }
      
      // Step 3: Generate mechanics
      setGenerationProgress(70)
      try {
        const mechanicsResponse = await fetch('/api/mechanics/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            gameGenre: selectedGenre,
            gameName,
            gameDescription
          })
        })
        
        if (mechanicsResponse.ok) {
          const mechanicsData = await mechanicsResponse.json()
          console.log('Game mechanics generated:', mechanicsData)
        }
      } catch (mechanicsError) {
        console.warn('Failed to generate mechanics:', mechanicsError)
        // Continue even if mechanics generation fails
      }
      
      // Step 4: Finalize
      setGenerationProgress(95)
      await new Promise(resolve => setTimeout(resolve, 1000))
      setGenerationProgress(100)
      
      // Store the generated game data for preview
      const gameDataToStore = {
        gameName,
        gameGenre: selectedGenre,
        gameDescription,
        gameData,
        assetResults,
        generatedAt: new Date().toISOString()
      }
      
      localStorage.setItem('generatedGame', JSON.stringify(gameDataToStore))
      setGeneratedGame(gameDataToStore)
      
    } catch (error) {
      console.error('Game generation failed:', error)
      alert(`Failed to generate game: ${error.message}. Please try again.`)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Gamepad2 className="h-12 w-12 text-purple-400" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              GameForge AI
            </h1>
          </div>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Professional AI-powered game development tool. Create complete games from concept to playable prototype in minutes.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6 mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="create" className="flex items-center gap-2">
              <Wand2 className="h-4 w-4" />
              Create
            </TabsTrigger>
            <TabsTrigger value="preview" className="flex items-center gap-2">
              <Play className="h-4 w-4" />
              Preview
            </TabsTrigger>
            <TabsTrigger value="assets" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Assets
            </TabsTrigger>
            <TabsTrigger value="mechanics" className="flex items-center gap-2">
              <Code className="h-4 w-4" />
              Mechanics
            </TabsTrigger>
            <TabsTrigger value="multiplayer" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Multiplayer
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-400">
                    <Zap className="h-5 w-5" />
                    Rapid Development
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Generate complete games in minutes with AI-powered automation. From concept to playable prototype.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-400">
                    <Palette className="h-5 w-5" />
                    Asset Generation
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    AI-generated 2D/3D assets, animations, sounds, and music tailored to your game's style.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-400">
                    <Code className="h-5 w-5" />
                    Smart Mechanics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Intelligent game mechanics, AI systems, and balanced gameplay automatically generated.
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-purple-400">Supported Game Genres</CardTitle>
                <CardDescription>Choose from various game types to get started</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {gameGenres.map((genre) => (
                    <Card 
                      key={genre.id} 
                      className="bg-slate-700/50 border-slate-600 hover:bg-slate-700/70 cursor-pointer transition-all"
                      onClick={() => {
                        setSelectedGenre(genre.id)
                        setActiveTab("create")
                      }}
                    >
                      <CardContent className="p-4 text-center">
                        <h3 className="font-semibold text-purple-300 mb-2">{genre.name}</h3>
                        <p className="text-sm text-gray-400">{genre.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Create Tab */}
          <TabsContent value="create" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <Wand2 className="h-5 w-5" />
                    Game Configuration
                  </CardTitle>
                  <CardDescription>Configure your game settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Game Name</label>
                    <Input
                      value={gameName}
                      onChange={(e) => setGameName(e.target.value)}
                      placeholder="Enter your game name"
                      className="bg-slate-700 border-slate-600"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Game Genre</label>
                    <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                      <SelectTrigger className="bg-slate-700 border-slate-600">
                        <SelectValue placeholder="Select a genre" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-700 border-slate-600">
                        {gameGenres.map((genre) => (
                          <SelectItem key={genre.id} value={genre.id}>
                            {genre.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-300 mb-2 block">Game Description</label>
                    <Textarea
                      value={gameDescription}
                      onChange={(e) => setGameDescription(e.target.value)}
                      placeholder="Describe your game concept, features, and vision"
                      className="bg-slate-700 border-slate-600 min-h-[100px]"
                    />
                  </div>
                  
                  <Button 
                    onClick={handleGenerateGame}
                    disabled={isGenerating || !selectedGenre || !gameName}
                    className="w-full bg-purple-600 hover:bg-purple-700 flex items-center gap-2"
                  >
                    {isGenerating ? (
                      <>
                        <Pause className="h-4 w-4" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-4 w-4" />
                        Generate Game
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800/50 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-purple-400 flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Generation Progress
                  </CardTitle>
                  <CardDescription>Track your game creation progress</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {isGenerating ? (
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm text-gray-300 mb-2">
                          <span>Progress</span>
                          <span>{generationProgress}%</span>
                        </div>
                        <Progress value={generationProgress} className="h-2" />
                      </div>
                      
                      <div className="space-y-2">
                        <Badge variant="outline" className="bg-slate-700 border-slate-600">
                          {generationProgress < 10 && "Initializing..."}
                          {generationProgress >= 10 && generationProgress < 25 && "Analyzing requirements..."}
                          {generationProgress >= 25 && generationProgress < 40 && "Generating mechanics..."}
                          {generationProgress >= 40 && generationProgress < 60 && "Creating assets..."}
                          {generationProgress >= 60 && generationProgress < 80 && "Building world..."}
                          {generationProgress >= 80 && generationProgress < 95 && "Implementing AI..."}
                          {generationProgress >= 95 && "Finalizing..."}
                        </Badge>
                        
                        <div className="text-sm text-gray-400">
                          {generationProgress < 10 && "Setting up game framework..."}
                          {generationProgress >= 10 && generationProgress < 25 && "Understanding your game vision..."}
                          {generationProgress >= 25 && generationProgress < 40 && "Creating core gameplay systems..."}
                          {generationProgress >= 40 && generationProgress < 60 && "Generating visual and audio assets..."}
                          {generationProgress >= 60 && generationProgress < 80 && "Designing game levels and world..."}
                          {generationProgress >= 80 && generationProgress < 95 && "Implementing AI behaviors..."}
                          {generationProgress >= 95 && "Polishing and optimizing..."}
                        </div>
                      </div>
                    </div>
                  ) : generationProgress === 100 ? (
                    <div className="text-center space-y-4">
                      <div className="text-green-400 font-semibold">Game Generated Successfully!</div>
                      <div className="flex gap-2 justify-center">
                        <Button 
                          onClick={() => setActiveTab("preview")}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Play Game
                        </Button>
                        <Button variant="outline" className="border-slate-600">
                          <Download className="h-4 w-4 mr-2" />
                          Export
                        </Button>
                        <Button variant="outline" className="border-slate-600">
                          <Share2 className="h-4 w-4 mr-2" />
                          Share
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center text-gray-400">
                      <Gamepad2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Configure your game settings and click "Generate Game" to start creating</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-purple-400 flex items-center gap-2">
                  <Monitor className="h-5 w-5" />
                  Game Preview
                </CardTitle>
                <CardDescription>Test and play your generated game</CardDescription>
              </CardHeader>
              <CardContent>
                {generationProgress === 100 && generatedGame ? (
                  <div className="space-y-4">
                    <div className="bg-slate-900 rounded-lg p-4 min-h-[400px] flex items-center justify-center">
                      <div className="text-center">
                        <div className="mb-4">
                          <div className="w-32 h-32 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                            <Gamepad2 className="h-16 w-16 text-white" />
                          </div>
                        </div>
                        <h3 className="text-xl font-semibold text-white mb-2">{generatedGame.gameName}</h3>
                        <p className="text-gray-400 mb-4">
                          {gameGenres.find(g => g.id === generatedGame.gameGenre)?.name} Game
                        </p>
                        <p className="text-gray-500 text-sm mb-4 max-w-md">
                          {generatedGame.gameDescription || 'No description provided'}
                        </p>
                        <div className="flex gap-2 justify-center">
                          <Button 
                            onClick={startGameDemo}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Play className="h-4 w-4 mr-2" />
                            Start Playing
                          </Button>
                          <Button variant="outline" className="border-slate-600">
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Restart
                          </Button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <h4 className="font-semibold text-purple-300 mb-2">Game Stats</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-400">Genre:</span>
                              <span>{gameGenres.find(g => g.id === generatedGame.gameGenre)?.name}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Status:</span>
                              <span className="text-green-400">Ready to Play</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Assets:</span>
                              <span>{generatedGame.assetResults?.length || 0} Generated</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Created:</span>
                              <span>{new Date(generatedGame.generatedAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <h4 className="font-semibold text-purple-300 mb-2">Controls</h4>
                          <div className="space-y-2 text-sm text-gray-400">
                            <div>WASD - Move</div>
                            <div>Space - Action</div>
                            <div>ESC - Menu</div>
                            <div>Mouse - Look</div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <h4 className="font-semibold text-purple-300 mb-2">Features</h4>
                          <div className="space-y-2 text-sm text-gray-400">
                            <div>✓ AI-Powered NPCs</div>
                            <div>✓ Dynamic World</div>
                            <div>✓ Procedural Content</div>
                            <div>✓ Adaptive Difficulty</div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Gamepad2 className="h-16 w-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">Generate a game first to see the preview</p>
                    <Button 
                      onClick={() => setActiveTab("create")}
                      className="mt-4 bg-purple-600 hover:bg-purple-700"
                    >
                      Create Game
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Game Demo Modal */}
          {isPlayingDemo && generatedGame && (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
              <Card className="bg-slate-800 border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-purple-400 flex items-center gap-2">
                      <Gamepad2 className="h-5 w-5" />
                      {generatedGame.gameName} - Demo
                    </CardTitle>
                    <Button 
                      onClick={endGameDemo}
                      variant="outline"
                      className="border-slate-600"
                    >
                      ✕
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Game Stats */}
                  <div className="flex justify-between items-center bg-slate-700 p-3 rounded-lg">
                    <div>
                      <div className="text-sm text-gray-400">Score</div>
                      <div className="text-xl font-bold text-yellow-400">{gameScore}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Level</div>
                      <div className="text-xl font-bold text-blue-400">{gameLevel}</div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-400">Genre</div>
                      <div className="text-lg font-semibold text-purple-400">
                        {gameGenres.find(g => g.id === generatedGame.gameGenre)?.name}
                      </div>
                    </div>
                  </div>

                  {/* Game Area */}
                  <div className="bg-slate-900 rounded-lg p-6 min-h-[300px] flex flex-col items-center justify-center">
                    <div className="text-center mb-4">
                      <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
                        <Gamepad2 className="h-10 w-10 text-white" />
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-2">Game in Progress</h3>
                      <p className="text-gray-400 text-sm">
                        Playing {generatedGame.gameName} - Level {gameLevel}
                      </p>
                    </div>

                    {/* Genre-specific game actions */}
                    <div className="grid grid-cols-2 gap-3 w-full max-w-sm">
                      {getGameActions().map((action, index) => (
                        <Button
                          key={index}
                          onClick={() => handleGameAction(action.id)}
                          className="bg-purple-600 hover:bg-purple-700"
                        >
                          {action.icon}
                          {action.label}
                        </Button>
                      ))}
                    </div>

                    {/* Progress bar */}
                    <div className="w-full max-w-sm mt-4">
                      <div className="flex justify-between text-sm text-gray-400 mb-1">
                        <span>Progress to Next Level</span>
                        <span>{getProgressToNextLevel()}%</span>
                      </div>
                      <Progress 
                        value={getProgressToNextLevel()} 
                        className="h-2"
                      />
                    </div>
                  </div>

                  {/* Game Instructions */}
                  <div className="text-sm text-gray-400 text-center">
                    <p>Click the action buttons to play! Each action increases your score.</p>
                    <p>Reach the target score to advance to the next level.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Assets Tab */}
          <TabsContent value="assets" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-purple-400 flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Asset Generation
                </CardTitle>
                <CardDescription>Generate and manage game assets</CardDescription>
              </CardHeader>
              <CardContent>
                {generationProgress === 100 && generatedGame ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">Character Models</h4>
                          <p className="text-sm text-gray-400">AI-generated 3D characters</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-green-600 to-blue-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">Environment Assets</h4>
                          <p className="text-sm text-gray-400">Buildings, terrain, props</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-red-600 to-orange-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">Animations</h4>
                          <p className="text-sm text-gray-400">Character and object animations</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-yellow-600 to-red-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">Sound Effects</h4>
                          <p className="text-sm text-gray-400">Game audio and effects</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">Music</h4>
                          <p className="text-sm text-gray-400">Background music and themes</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardContent className="p-4">
                          <div className="w-full h-32 bg-gradient-to-br from-indigo-600 to-blue-600 rounded-lg mb-3"></div>
                          <h4 className="font-semibold text-white mb-1">UI Elements</h4>
                          <p className="text-sm text-gray-400">Menus, HUD, icons</p>
                          <Badge className="mt-2 bg-green-600">Generated</Badge>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Card className="bg-slate-700/50 border-slate-600">
                      <CardHeader>
                        <CardTitle className="text-purple-300 text-lg">Generated Assets Summary</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                          <div>
                            <div className="text-2xl font-bold text-blue-400">{generatedGame.assetResults?.length || 3}</div>
                            <div className="text-sm text-gray-400">Asset Types</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-green-400">100%</div>
                            <div className="text-sm text-gray-400">Complete</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-purple-400">HD</div>
                            <div className="text-sm text-gray-400">Quality</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-yellow-400">6</div>
                            <div className="text-sm text-gray-400">Categories</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Palette className="h-16 w-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">Generate a game first to see assets</p>
                    <Button 
                      onClick={() => setActiveTab("create")}
                      className="mt-4 bg-purple-600 hover:bg-purple-700"
                    >
                      Create Game
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mechanics Tab */}
          <TabsContent value="mechanics" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-purple-400 flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Game Mechanics
                </CardTitle>
                <CardDescription>Configure game mechanics and systems</CardDescription>
              </CardHeader>
              <CardContent>
                {generationProgress === 100 && generatedGame ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardHeader>
                          <CardTitle className="text-purple-300 text-lg">Core Mechanics</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Movement System</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Combat System</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Progression System</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Inventory System</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardHeader>
                          <CardTitle className="text-purple-300 text-lg">AI Systems</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">NPC Behavior</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Pathfinding</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Decision Making</span>
                            <Badge className="bg-green-600">Active</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Adaptive Difficulty</span>
                            <Badge className="bg-yellow-600">Balanced</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Separator className="bg-slate-600" />
                    
                    <Card className="bg-slate-700/50 border-slate-600">
                      <CardHeader>
                        <CardTitle className="text-purple-300 text-lg">Game Balance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-400">85%</div>
                            <div className="text-sm text-gray-400">Difficulty Balance</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-400">92%</div>
                            <div className="text-sm text-gray-400">Progression Curve</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-400">78%</div>
                            <div className="text-sm text-gray-400">Reward Balance</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card className="bg-slate-700/50 border-slate-600">
                      <CardHeader>
                        <CardTitle className="text-purple-300 text-lg">Generated Mechanics</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="text-sm text-gray-400">
                          <p className="mb-2">Game mechanics have been automatically generated based on the {generatedGame.gameGenre} genre.</p>
                          <p>The system has created balanced gameplay systems including player abilities, progression mechanics, and AI behaviors tailored to your game concept.</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Code className="h-16 w-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">Generate a game first to see mechanics</p>
                    <Button 
                      onClick={() => setActiveTab("create")}
                      className="mt-4 bg-purple-600 hover:bg-purple-700"
                    >
                      Create Game
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Multiplayer Tab */}
          <TabsContent value="multiplayer" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="text-purple-400 flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Multiplayer Settings
                </CardTitle>
                <CardDescription>Configure multiplayer and networking features</CardDescription>
              </CardHeader>
              <CardContent>
                {generationProgress === 100 && generatedGame ? (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardHeader>
                          <CardTitle className="text-purple-300 text-lg">Network Configuration</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Server Type</span>
                            <span className="text-sm text-blue-400">Dedicated</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Max Players</span>
                            <span className="text-sm text-blue-400">32</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Region</span>
                            <span className="text-sm text-blue-400">Global</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Latency</span>
                            <span className="text-sm text-green-400">&lt;50ms</span>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Card className="bg-slate-700/50 border-slate-600">
                        <CardHeader>
                          <CardTitle className="text-purple-300 text-lg">Multiplayer Features</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Co-op Mode</span>
                            <Badge className="bg-green-600">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">PvP Mode</span>
                            <Badge className="bg-green-600">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Matchmaking</span>
                            <Badge className="bg-green-600">Enabled</Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-gray-300">Voice Chat</span>
                            <Badge className="bg-yellow-600">Optional</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                    
                    <Separator className="bg-slate-600" />
                    
                    <Card className="bg-slate-700/50 border-slate-600">
                      <CardHeader>
                        <CardTitle className="text-purple-300 text-lg">Server Status</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-400">Online</div>
                            <div className="text-sm text-gray-400">Status</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-400">24/7</div>
                            <div className="text-sm text-gray-400">Uptime</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-400">0</div>
                            <div className="text-sm text-gray-400">Active Players</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-yellow-400">3</div>
                            <div className="text-sm text-gray-400">Regions</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Users className="h-16 w-16 mx-auto mb-4 text-gray-500" />
                    <p className="text-gray-400">Generate a game first to configure multiplayer</p>
                    <Button 
                      onClick={() => setActiveTab("create")}
                      className="mt-4 bg-purple-600 hover:bg-purple-700"
                    >
                      Create Game
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}