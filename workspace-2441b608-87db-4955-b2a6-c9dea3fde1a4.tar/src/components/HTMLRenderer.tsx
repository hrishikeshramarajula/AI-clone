'use client';

import React from 'react';

interface HTMLRendererProps {
  content: string;
  className?: string;
}

export default function HTMLRenderer({ content, className = '' }: HTMLRendererProps) {
  // Simple HTML rendering for code blocks and inline code
  const renderContent = () => {
    let htmlContent = content;
    
    // Convert markdown-style code blocks to HTML
    htmlContent = htmlContent.replace(
      /```([\s\S]*?)```/g, 
      '<pre class="bg-gray-100 p-3 rounded-md overflow-x-auto my-2"><code>$1</code></pre>'
    );
    
    // Convert inline code to HTML
    htmlContent = htmlContent.replace(
      /`([^`]+)`/g, 
      '<code class="bg-gray-100 px-1 py-0.5 rounded text-sm">$1</code>'
    );
    
    // Convert bold text
    htmlContent = htmlContent.replace(
      /\*\*(.*?)\*\*/g, 
      '<strong>$1</strong>'
    );
    
    // Convert italic text
    htmlContent = htmlContent.replace(
      /\*(.*?)\*/g, 
      '<em>$1</em>'
    );
    
    // Convert headers
    htmlContent = htmlContent.replace(
      /^### (.*$)/gm, 
      '<h3 class="text-lg font-semibold mt-4 mb-2">$1</h3>'
    );
    htmlContent = htmlContent.replace(
      /^## (.*$)/gm, 
      '<h2 class="text-xl font-semibold mt-4 mb-2">$1</h2>'
    );
    htmlContent = htmlContent.replace(
      /^# (.*$)/gm, 
      '<h1 class="text-2xl font-bold mt-4 mb-2">$1</h1>'
    );
    
    // Convert line breaks
    htmlContent = htmlContent.replace(/\n\n/g, '</p><p class="mb-2">');
    htmlContent = htmlContent.replace(/\n/g, '<br />');
    
    return { __html: htmlContent };
  };

  return (
    <div 
      className={`prose prose-sm max-w-none ${className}`}
      dangerouslySetInnerHTML={renderContent()}
    />
  );
}