import { AIMessage } from '../../types/ai';

export async function callOpenRouter(
  messages: AIMessage[],
  modelName: string = 'anthropic/claude-3-sonnet'
): Promise<string> {
  try {
    // India-friendly model mappings
    const modelMap: Record<string, string> = {
      '🇮🇳 GLM-4.5 (India)': 'zhipuai/glm-4-9b-chat',
      'GLM-4.5': 'zhipuai/glm-4-9b-chat',
      '🇮🇳 Claude 3 Sonnet (India)': 'anthropic/claude-3-sonnet',
      'Claude 3 Sonnet': 'anthropic/claude-3-sonnet',
      '🇮🇳 Mixtral 8x7B (India)': 'mistralai/mixtral-8x7b-instruct',
      'Mixtral 8x7B': 'mistralai/mixtral-8x7b-instruct',
      'Claude 3 Opus': 'anthropic/claude-3-opus',
      'Command R+': 'cohere/command-r-plus',
      'Gemini Pro': 'google/gemini-pro-1.5',
      'Llama 3 70B': 'meta-llama/llama-3-70b-instruct',
      'GPT-4': 'openai/gpt-4',
      'GPT-3.5 Turbo': 'openai/gpt-3.5-turbo'
    };

    const selectedModel = modelMap[modelName] || 'anthropic/claude-3-sonnet';
    console.log(`OpenRouter: Using model ${selectedModel} for request from India`);

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
        'X-Title': 'AI Agent India',
        'X-Country': 'IN',
        'X-Region': 'India'
      },
      body: JSON.stringify({
        model: selectedModel,
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        temperature: 0.7,
        max_tokens: 2000
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('OpenRouter API Error:', response.status, errorData);
      
      if (response.status === 401) {
        throw new Error('OpenRouter API key invalid. Please check your credentials.');
      } else if (response.status === 402) {
        throw new Error('Insufficient OpenRouter credits. Please add credits to your account.');
      } else if (response.status === 429) {
        throw new Error('OpenRouter rate limit hit. Please wait before retrying.');
      } else if (response.status === 403) {
        throw new Error('OpenRouter access denied. Trying alternative provider...');
      }
      
      throw new Error(`OpenRouter API error: ${response.status} - ${errorData}`);
    }

    const data = await response.json();
    return data.choices[0]?.message?.content || 'No response generated';
  } catch (error: any) {
    console.error('OpenRouter Error:', error);
    throw error;
  }
}

export async function callHuggingFaceText(prompt: string, model: string = 'microsoft/DialoGPT-medium'): Promise<string> {
  try {
    console.log(`HuggingFace: Using model ${model} for text generation from India`);

    const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Country': 'IN'
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_new_tokens: 1000,
          temperature: 0.7,
          do_sample: true,
          top_p: 0.9,
          top_k: 50
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('HuggingFace API Error:', response.status, errorData);
      throw new Error(`HuggingFace API error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    
    // Handle different response formats
    if (Array.isArray(result) && result.length > 0) {
      return result[0]?.generated_text || result[0]?.text || 'No response generated';
    } else if (result.generated_text) {
      return result.generated_text;
    } else if (result.text) {
      return result.text;
    }
    
    return 'No response generated';
  } catch (error: any) {
    console.error('HuggingFace Text Error:', error);
    
    // Try fallback model
    if (model !== 'facebook/blenderbot-400M-distill') {
      console.log('Trying fallback model for text generation...');
      return callHuggingFaceText(prompt, 'facebook/blenderbot-400M-distill');
    }
    
    throw error;
  }
}