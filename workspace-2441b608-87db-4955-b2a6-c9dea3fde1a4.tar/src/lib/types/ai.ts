export interface AIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface AIResponse {
  success: boolean;
  response: string;
  searchResults?: any[];
  imageData?: string;
  imagePrompt?: string;
  model: string;
  error?: string;
}

export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  apiModel?: string;
  intelligence?: string;
  contextLength?: string;
  inputCredits?: string;
  outputCredits?: string;
  specialty?: 'chat' | 'image' | 'code' | 'search' | 'analysis' | 'fullstack';
}