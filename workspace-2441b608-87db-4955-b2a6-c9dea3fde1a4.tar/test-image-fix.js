const axios = require('axios');

async function testImageGeneration() {
  console.log('🇮🇳 Testing Image Generation Fix...\n');

  // Test HuggingFace image generation
  try {
    console.log('Testing HuggingFace Stable Diffusion...');
    const response = await axios.post('http://localhost:3000/api/image', {
      prompt: 'A beautiful sunset over mountains',
      model: '🇮🇳 Stable Diffusion (India)',
      size: '512x512'
    }, {
      headers: {
        'Content-Type': 'application/json'
      },
      timeout: 30000 // 30 second timeout
    });

    if (response.data && response.data.imageData) {
      console.log('✅ Image generation successful!');
      console.log(`Model: ${response.data.model}`);
      console.log(`Prompt: ${response.data.prompt}`);
      console.log(`Image data length: ${response.data.imageData.length} characters`);
    } else {
      console.log('❌ No image data in response');
    }
  } catch (error) {
    if (error.response) {
      console.log('❌ Image generation failed:');
      console.log(`Status: ${error.response.status}`);
      console.log(`Error: ${error.response.data.error}`);
      console.log(`Details: ${error.response.data.details}`);
      console.log(`Suggestion: ${error.response.data.suggestion}`);
    } else {
      console.log('❌ Network error:', error.message);
    }
  }
}

testImageGeneration();