'use client';
import { useState, useEffect, useRef } from 'react';
import { Play, Pause, RefreshCw, Maximize2, Minimize2, Eye, Code, Smartphone, Monitor, Tablet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';

interface LivePreviewProps {
  html: string;
  css: string;
  javascript: string;
  componentPreview: string;
  projectName: string;
  autoRefresh?: boolean;
}

type PreviewMode = 'desktop' | 'tablet' | 'mobile';
type PreviewState = 'loading' | 'ready' | 'error';

export default function LivePreview({
  html,
  css,
  javascript,
  componentPreview,
  projectName,
  autoRefresh = false
}: LivePreviewProps) {
  const [previewMode, setPreviewMode] = useState<PreviewMode>('desktop');
  const [previewState, setPreviewState] = useState<PreviewState>('loading');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const dimensions = {
    desktop: { width: '100%', height: '600px' },
    tablet: { width: '768px', height: '1024px' },
    mobile: { width: '375px', height: '667px' }
  };

  const getPreviewContent = () => {
    return `
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>${projectName} - Live Preview</title>
          <style>
              ${css}
              
              /* Base styles for preview */
              * {
                  margin: 0;
                  padding: 0;
                  box-sizing: border-box;
              }
              
              body {
                  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                  line-height: 1.6;
                  color: #333;
                  background: #f8fafc;
              }
              
              .preview-container {
                  min-height: 100vh;
                  padding: 2rem;
              }
              
              .preview-header {
                  text-align: center;
                  margin-bottom: 2rem;
                  padding: 1rem;
                  background: white;
                  border-radius: 0.5rem;
                  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
              }
              
              .preview-header h1 {
                  color: #1e293b;
                  margin-bottom: 0.5rem;
              }
              
              .preview-header p {
                  color: #64748b;
              }
              
              .preview-content {
                  background: white;
                  border-radius: 0.5rem;
                  padding: 2rem;
                  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
              }
              
              /* Loading animation */
              .loading {
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  height: 200px;
                  font-size: 1.2rem;
                  color: #64748b;
              }
              
              .loading::after {
                  content: '';
                  width: 20px;
                  height: 20px;
                  border: 2px solid #e2e8f0;
                  border-top: 2px solid #3b82f6;
                  border-radius: 50%;
                  animation: spin 1s linear infinite;
                  margin-left: 10px;
              }
              
              @keyframes spin {
                  0% { transform: rotate(0deg); }
                  100% { transform: rotate(360deg); }
              }
              
              /* Responsive utilities */
              @media (max-width: 768px) {
                  .preview-container {
                      padding: 1rem;
                  }
                  .preview-content {
                      padding: 1rem;
                  }
              }
          </style>
      </head>
      <body>
          <div class="preview-container">
              <div class="preview-header">
                  <h1>${projectName}</h1>
                  <p>Live Preview - AI Generated Application</p>
              </div>
              <div class="preview-content">
                  ${html}
              </div>
          </div>
          
          <script>
              ${javascript}
              
              // Auto-refresh functionality
              ${autoRefresh ? `
              // Set up auto-refresh every 30 seconds
              setInterval(() => {
                  if (window.parent !== window) {
                      window.parent.postMessage({ type: 'preview-refresh' }, '*');
                  }
              }, 30000);
              ` : ''}
              
              // Notify parent that preview is loaded
              window.addEventListener('load', () => {
                  if (window.parent !== window) {
                      window.parent.postMessage({ type: 'preview-loaded' }, '*');
                  }
              });
              
              // Handle errors
              window.addEventListener('error', (event) => {
                  console.error('Preview error:', event.error);
                  if (window.parent !== window) {
                      window.parent.postMessage({ 
                          type: 'preview-error', 
                          error: event.error?.message || 'Unknown error' 
                      }, '*');
                  }
              });
          </script>
      </body>
      </html>
    `;
  };

  const refreshPreview = () => {
    setPreviewState('loading');
    setRefreshKey(prev => prev + 1);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    
    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
    setIsFullscreen(!isFullscreen);
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'preview-loaded') {
        setPreviewState('ready');
      } else if (event.data.type === 'preview-error') {
        setPreviewState('error');
        console.error('Preview error:', event.data.error);
      } else if (event.data.type === 'preview-refresh' && autoRefresh) {
        refreshPreview();
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [autoRefresh]);

  useEffect(() => {
    // Set loading state when refreshKey changes
    setPreviewState('loading');
    
    // Set a timeout to handle cases where the preview never loads
    const timeout = setTimeout(() => {
      if (previewState === 'loading') {
        setPreviewState('error');
      }
    }, 10000);

    return () => clearTimeout(timeout);
  }, [refreshKey]);

  return (
    <div className="w-full space-y-6" ref={containerRef}>
      {/* Preview Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Live Preview
              </CardTitle>
              <CardDescription>
                Interactive preview of your generated application
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={previewState === 'ready' ? 'default' : 'secondary'}>
                {previewState === 'loading' && 'Loading...'}
                {previewState === 'ready' && 'Ready'}
                {previewState === 'error' && 'Error'}
              </Badge>
              
              <Button
                variant="outline"
                size="sm"
                onClick={refreshPreview}
                disabled={previewState === 'loading'}
              >
                <RefreshCw className={`w-4 h-4 ${previewState === 'loading' ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                onClick={toggleFullscreen}
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Device Mode Selector */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center gap-2">
            <Button
              variant={previewMode === 'desktop' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPreviewMode('desktop')}
              className="flex items-center gap-2"
            >
              <Monitor className="w-4 h-4" />
              Desktop
            </Button>
            <Button
              variant={previewMode === 'tablet' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPreviewMode('tablet')}
              className="flex items-center gap-2"
            >
              <Tablet className="w-4 h-4" />
              Tablet
            </Button>
            <Button
              variant={previewMode === 'mobile' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setPreviewMode('mobile')}
              className="flex items-center gap-2"
            >
              <Smartphone className="w-4 h-4" />
              Mobile
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Preview Container */}
      <Card>
        <CardContent className="p-6">
          <div className="flex justify-center">
            <div 
              className="border-2 border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden bg-white shadow-lg"
              style={{
                width: dimensions[previewMode].width,
                height: dimensions[previewMode].height,
                maxWidth: '100%'
              }}
            >
              {previewState === 'loading' && (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
                    <p className="text-slate-600">Loading preview...</p>
                  </div>
                </div>
              )}
              
              {previewState === 'error' && (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center p-6">
                    <div className="text-red-600 mb-2">⚠️</div>
                    <h3 className="text-lg font-semibold mb-2">Preview Error</h3>
                    <p className="text-slate-600 mb-4">
                      There was an error loading the preview. This might be due to JavaScript errors or network issues.
                    </p>
                    <Button onClick={refreshPreview} variant="outline">
                      Try Again
                    </Button>
                  </div>
                </div>
              )}
              
              <iframe
                ref={iframeRef}
                key={refreshKey}
                srcDoc={getPreviewContent()}
                className="w-full h-full border-0"
                title={`${projectName} Live Preview`}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                style={{
                  display: previewState === 'ready' ? 'block' : 'none'
                }}
                onLoad={() => setPreviewState('ready')}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Interactive Features Demo */}
      <Card>
        <CardHeader>
          <CardTitle>Interactive Features</CardTitle>
          <CardDescription>
            Test the interactive capabilities of your generated application
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="demo" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="demo">Live Demo</TabsTrigger>
              <TabsTrigger value="component">React Component</TabsTrigger>
              <TabsTrigger value="console">Console Output</TabsTrigger>
            </TabsList>
            
            <TabsContent value="demo" className="space-y-4">
              <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Demo Controls</h4>
                <div className="flex gap-2 flex-wrap">
                  <Button 
                    size="sm" 
                    onClick={() => {
                      // Send message to iframe to trigger demo action
                      iframeRef.current?.contentWindow?.postMessage({ type: 'demo-action' }, '*');
                    }}
                  >
                    Trigger Demo Action
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => {
                      // Send message to iframe to add sample data
                      iframeRef.current?.contentWindow?.postMessage({ type: 'add-sample-data' }, '*');
                    }}
                  >
                    Add Sample Data
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => {
                      // Send message to iframe to clear data
                      iframeRef.current?.contentWindow?.postMessage({ type: 'clear-data' }, '*');
                    }}
                  >
                    Clear Data
                  </Button>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="component" className="space-y-4">
              <ScrollArea className="h-64">
                <div className="bg-slate-900 text-slate-100 p-4 rounded-lg">
                  <pre className="text-sm">
                    <code>{componentPreview}</code>
                  </pre>
                </div>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="console" className="space-y-4">
              <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-64 overflow-y-auto">
                <div>🚀 Preview Console Output</div>
                <div>─────────────────────────────────</div>
                <div>[Preview] Initializing application...</div>
                <div>[Preview] Loading components...</div>
                <div>[Preview] Setting up event listeners...</div>
                <div>[Preview] Application ready ✓</div>
                <div>[Preview] Waiting for user interactions...</div>
                <div className="text-slate-400">💡 Interact with the preview above to see console output here</div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Preview Info */}
      <Card>
        <CardHeader>
          <CardTitle>Preview Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">
                {previewState === 'ready' ? '✓' : '⏳'}
              </div>
              <div className="text-sm text-muted-foreground">Status</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">
                {previewMode === 'desktop' ? '🖥️' : previewMode === 'tablet' ? '📱' : '📱'}
              </div>
              <div className="text-sm text-muted-foreground">Device Mode</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600 mb-1">
                {autoRefresh ? '🔄' : '⏸️'}
              </div>
              <div className="text-sm text-muted-foreground">Auto Refresh</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}