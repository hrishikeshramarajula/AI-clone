import { NextRequest, NextResponse } from 'next/server';
import {
  webSearch,
  fetchAndScrape,
  embed,
  rankPassages,
  aiComplete
} from '@/lib/deepSearch';

type Result = {
  success: boolean;
  answer?: string;
  sources?: { url: string; snippet: string }[];
  error?: string;
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const searchQuery = body.query as string;
    
    if (!searchQuery) {
      return NextResponse.json({ success: false, error: 'Query is required' }, { status: 400 });
    }

    // 1. Search
    const results = await webSearch(searchQuery);
    
    if (!results || results.length === 0) {
      // Fallback to AI completion without web search
      try {
        const fallbackAnswer = await aiComplete(
          `You are a research assistant. Provide a comprehensive answer to the user's question based on your knowledge. Include relevant code examples, implementation details, and practical applications.`,
          `Question: ${searchQuery}\n\nPlease provide a detailed response including:\n1. Comprehensive explanation\n2. Relevant code examples\n3. Implementation details\n4. Practical applications\n5. Code snippets for key concepts`
        );
        
        return NextResponse.json({
          success: true,
          answer: `🔍 **Research Results**: "${searchQuery}"

${fallbackAnswer}

**Note**: Web search was unavailable, so this response is based on AI knowledge. For the most current information, please try again later.`,
          sources: []
        });
      } catch (fallbackError) {
        console.error('Fallback AI completion failed:', fallbackError);
        return NextResponse.json({ 
          success: false, 
          error: 'Web search unavailable and AI fallback failed. Please try again later.' 
        }, { status: 500 });
      }
    }

    // 2. Scrape & segment
    const passages: { text: string; url: string; vector?: number[]; }[] = [];
    let successfulScrapes = 0;
    
    for (const r of results) {
      try {
        const text = await fetchAndScrape(r.url);
        if (text && text.trim().length > 100) { // Only use substantial content
          const segments = text.match(/.{1,500}/g) || [];
          segments.forEach(seg => passages.push({ text: seg, url: r.url }));
          successfulScrapes++;
        }
      } catch (error) {
        console.error(`Error scraping ${r.url}:`, error);
      }
    }

    // If we couldn't scrape any content, fallback to AI with search results as context
    if (passages.length === 0) {
      try {
        const searchContext = results.map(r => `Source: ${r.url}\nTitle: ${r.name}\nSnippet: ${r.snippet}`).join('\n\n');
        
        const fallbackAnswer = await aiComplete(
          `You are a research assistant. Use the search results below to answer the user's question. Include relevant code examples and implementation details.`,
          `Question: ${query}\n\nSearch Results:\n${searchContext}\n\nPlease include:\n1. Analysis of search results\n2. Relevant code examples\n3. Implementation details\n4. Practical code snippets`
        );
        
        return NextResponse.json({
          success: true,
          answer: `🔍 **Research Results**: "${query}"

${fallbackAnswer}

**Sources:**\n${results.map((r, i) => `${i + 1}. [${r.name}](${r.url}) - ${r.snippet}`).join('\n')}`,
          sources: results.map(r => ({ url: r.url, snippet: r.snippet }))
        });
      } catch (fallbackError) {
        console.error('Search results fallback failed:', fallbackError);
        return NextResponse.json({ 
          success: false, 
          error: 'Unable to scrape content and process search results. Please try a different query.' 
        }, { status: 500 });
      }
    }

    // 3. Embeddings
    const queryVec = await embed(query);
    for (const p of passages) {
      try {
        p.vector = await embed(p.text);
      } catch (error) {
        console.error('Error creating embedding for passage:', error);
        // Use a zero vector as fallback
        p.vector = new Array(100).fill(0);
      }
    }

    // 4. Rank top passages
    const top = rankPassages(passages, queryVec);

    // 5. Build context
    const context = top
      .map((p, i) => `Source${i+1} (${p.url}):\n${p.text}`)
      .join('\n\n');

    const systemPrompt = `You are a research assistant. Use the context below to answer the question accurately and cite sources. Additionally, provide relevant code examples that support the key concepts and techniques discussed. Include code snippets for important algorithms, model implementations, or practical applications.`;
    const userPrompt = `Question: ${query}\n\nContext:\n${context}\n\nPlease include relevant code examples for the key concepts discussed, such as:
- Model architectures
- Implementation examples
- Practical code snippets
- API usage examples
- Algorithm implementations`;

    // 6. AI completion
    const answer = await aiComplete(systemPrompt, userPrompt);

    // 7. Respond
    return NextResponse.json({
      success: true,
      answer,
      sources: top.map(p => ({ url: p.url, snippet: p.text.slice(0, 200) }))
    });
  } catch (e: any) {
    console.error('Deep search error:', e);
    
    // Final fallback - try to answer with AI knowledge
    try {
      const fallbackAnswer = await aiComplete(
        `You are a research assistant. Provide a comprehensive answer to the user's question based on your knowledge. Include relevant code examples, implementation details, and practical applications.`,
        `Question: ${searchQuery}\n\nPlease provide a detailed response including:\n1. Comprehensive explanation\n2. Relevant code examples\n3. Implementation details\n4. Practical applications\n5. Code snippets for key concepts`
      );
      
      return NextResponse.json({
        success: true,
        answer: `🔍 **Research Results**: "${searchQuery}"

${fallbackAnswer}

**Note**: Due to technical difficulties, this response is based on AI knowledge rather than live web search. For the most current information, please try again later.`,
        sources: []
      });
    } catch (finalFallbackError) {
      console.error('Final fallback failed:', finalFallbackError);
      return NextResponse.json({ 
        success: false, 
        error: `Research failed: ${e.message || 'Unknown error'}. Please try again later.` 
      }, { status: 500 });
    }
  }
}