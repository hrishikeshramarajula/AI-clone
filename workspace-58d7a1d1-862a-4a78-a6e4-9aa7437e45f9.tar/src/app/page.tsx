'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Loader2, Download, History, Settings, Sparkles, Copy, RefreshCw, Trash2, Save, Upload, 
  Database, AlertTriangle, Film, Play, Pause, Volume2, VolumeX, Clock, Zap
} from 'lucide-react'
import { 
  compressImage, 
  createThumbnail, 
  getStorageUsage, 
  formatBytes, 
  cleanupOldStorage,
  base64ToBlob,
  type CompressedImage 
} from '@/lib/imageUtils'

interface VideoGenerationRequest {
  prompt: string
  negativePrompt?: string
  style: string
  duration: number // in seconds
  resolution: string
  fps: number
  quality: number
  includeAudio: boolean
  cameraMovement?: string
  lighting?: string
}

interface GeneratedVideo {
  id: string
  prompt: string
  videoUrl?: string
  thumbnailUrl?: string
  duration: number
  resolution: string
  fps: number
  timestamp: string
  isProcessing: boolean
  progress: number
  isPlaying?: boolean
  currentTime?: number
  volume?: number
  isMuted?: boolean
}

export default function Home() {
  // Image generation states
  const [prompt, setPrompt] = useState('')
  const [negativePrompt, setNegativePrompt] = useState('')
  const [style, setStyle] = useState('photorealistic')
  const [aspectRatio, setAspectRatio] = useState('1:1')
  const [quality, setQuality] = useState([80])
  const [numImages, setNumImages] = useState([1])
  const [seed, setSeed] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImages, setGeneratedImages] = useState<string[]>([])
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [imageSize, setImageSize] = useState('1024x1024')
  const [history, setHistory] = useState<CompressedImage[]>([])
  
  // Video generation states
  const [videoPrompt, setVideoPrompt] = useState('')
  const [videoNegativePrompt, setVideoNegativePrompt] = useState('')
  const [videoStyle, setVideoStyle] = useState('cinematic')
  const [videoDuration, setVideoDuration] = useState([10]) // seconds
  const [videoResolution, setVideoResolution] = useState('720p')
  const [videoFps, setVideoFps] = useState([24])
  const [videoQuality, setVideoQuality] = useState([80])
  const [includeAudio, setIncludeAudio] = useState(false)
  const [cameraMovement, setCameraMovement] = useState('static')
  const [lighting, setLighting] = useState('natural')
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false)
  const [generatedVideos, setGeneratedVideos] = useState<GeneratedVideo[]>([])
  const [showVideoAdvanced, setShowVideoAdvanced] = useState(false)
  const [videoProgress, setVideoProgress] = useState(0)
  
  // Common states
  const [activeTab, setActiveTab] = useState('generate')
  const [storageUsage, setStorageUsage] = useState({ used: 0, total: 5 * 1024 * 1024, available: 5 * 1024 * 1024 })
  const [isCompressing, setIsCompressing] = useState(false)
  
  // Video playback refs
  const videoRefs = useRef<{ [key: string]: HTMLVideoElement }>({})

  // Load history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('ai-image-generator-history')
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory))
      } catch (error) {
        console.error('Failed to load history:', error)
      }
    }
    
    // Update storage usage
    updateStorageUsage()
  }, [])

  // Update storage usage periodically
  useEffect(() => {
    const interval = setInterval(updateStorageUsage, 5000) // Update every 5 seconds
    return () => clearInterval(interval)
  }, [])

  // Save history to localStorage whenever it changes
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('ai-image-generator-history', JSON.stringify(history))
      updateStorageUsage()
    }
  }, [history])

  const updateStorageUsage = () => {
    const usage = getStorageUsage()
    setStorageUsage(usage)
    
    // Auto-clean if storage is getting full
    if (usage.used / usage.total > 0.8) {
      const cleanedHistory = cleanupOldStorage(history, 30)
      if (cleanedHistory.length !== history.length) {
        setHistory(cleanedHistory)
      }
    }
  }

  const handleGenerate = async () => {
    if (!prompt.trim()) return
    
    setIsGenerating(true)
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          negativePrompt: showAdvanced ? negativePrompt : '',
          style,
          aspectRatio,
          quality: quality[0],
          numImages: numImages[0],
          seed: seed || undefined,
          imageSize
        })
      })
      
      const data = await response.json()
      if (data.success && data.images) {
        setGeneratedImages(prev => [...data.images, ...prev])
        
        // Compress and save to history
        setIsCompressing(true)
        try {
          const compressedImages: CompressedImage[] = []
          
          for (let i = 0; i < data.images.length; i++) {
            const imageData = data.images[i]
            
            // Compress the image
            const compressedFullImage = await compressImage(imageData)
            const thumbnail = await createThumbnail(imageData)
            
            const compressedItem: CompressedImage = {
              id: `${Date.now()}-${i}`,
              prompt: data.prompt,
              negativePrompt: negativePrompt,
              style,
              aspectRatio,
              quality: quality[0],
              timestamp: new Date().toISOString(),
              seed: seed || undefined,
              imageSize,
              thumbnail,
              fullImage: compressedFullImage
            }
            
            compressedImages.push(compressedItem)
          }
          
          setHistory(prev => [...compressedImages, ...prev])
        } catch (compressionError) {
          console.error('Compression failed:', compressionError)
          // Fallback: save original images without compression
          const fallbackItems: CompressedImage[] = data.images.map((imageData: string, index: number) => ({
            id: `${Date.now()}-${index}`,
            prompt: data.prompt,
            negativePrompt: negativePrompt,
            style,
            aspectRatio,
            quality: quality[0],
            timestamp: new Date().toISOString(),
            seed: seed || undefined,
            imageSize,
            thumbnail: `data:image/png;base64,${imageData}`, // Use original as thumbnail
            fullImage: `data:image/png;base64,${imageData}` // Use original as full image
          }))
          setHistory(prev => [...fallbackItems, ...prev])
        } finally {
          setIsCompressing(false)
        }
      }
    } catch (error) {
      console.error('Generation failed:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const downloadImage = (imageData: string, index: number, isFullImage: boolean = true) => {
    // Extract base64 data from data URL if needed
    const base64Data = imageData.startsWith('data:') ? imageData.split(',')[1] : imageData
    
    const link = document.createElement('a')
    link.download = `generated-image-${Date.now()}-${index}.${isFullImage ? 'jpg' : 'png'}`
    link.href = `data:image/${isFullImage ? 'jpeg' : 'png'};base64,${base64Data}`
    link.click()
  }

  const downloadFromHistory = (item: CompressedImage) => {
    // Extract base64 from data URL
    const base64Data = item.fullImage.split(',')[1]
    const blob = base64ToBlob(base64Data, 'image/jpeg')
    
    const link = document.createElement('a')
    link.download = `ai-image-${item.id}.jpg`
    link.href = URL.createObjectURL(blob)
    link.click()
    URL.revokeObjectURL(link.href)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const generateRandomSeed = () => {
    setSeed(Math.floor(Math.random() * 1000000).toString())
  }

  const clearAll = () => {
    setGeneratedImages([])
  }

  const deleteFromHistory = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id))
  }

  const clearHistory = () => {
    setHistory([])
    localStorage.removeItem('ai-image-generator-history')
  }

  const exportHistory = () => {
    const dataStr = JSON.stringify(history, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `ai-image-history-${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const importHistory = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const importedHistory = JSON.parse(e.target?.result as string)
        if (Array.isArray(importedHistory)) {
          setHistory(prev => [...importedHistory, ...prev])
        }
      } catch (error) {
        console.error('Failed to import history:', error)
        alert('Invalid history file')
      }
    }
    reader.readAsText(file)
    // Reset file input
    event.target.value = ''
  }

  const loadFromHistory = (item: CompressedImage) => {
    setPrompt(item.prompt)
    setNegativePrompt(item.negativePrompt)
    setStyle(item.style)
    setAspectRatio(item.aspectRatio)
    setQuality([item.quality])
    setImageSize(item.imageSize)
    if (item.seed) setSeed(item.seed)
    setActiveTab('generate')
  }

  // Video generation handlers
  const handleVideoGenerate = async () => {
    if (!videoPrompt.trim()) return
    
    setIsGeneratingVideo(true)
    setVideoProgress(0)
    
    try {
      // Create a new video entry
      const newVideo: GeneratedVideo = {
        id: `video-${Date.now()}`,
        prompt: videoPrompt,
        duration: videoDuration[0],
        resolution: videoResolution,
        fps: videoFps[0],
        timestamp: new Date().toISOString(),
        isProcessing: true,
        progress: 0
      }
      
      setGeneratedVideos(prev => [newVideo, ...prev])
      
      // Simulate video generation progress
      const progressInterval = setInterval(() => {
        setVideoProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 15, 95)
          
          // Update the video progress in the list
          setGeneratedVideos(prevVideos => 
            prevVideos.map(video => 
              video.id === newVideo.id 
                ? { ...video, progress: newProgress }
                : video
            )
          )
          
          if (newProgress >= 95) {
            clearInterval(progressInterval)
            // Complete the generation
            setTimeout(() => {
              setGeneratedVideos(prevVideos => 
                prevVideos.map(video => 
                  video.id === newVideo.id 
                    ? { 
                        ...video, 
                        isProcessing: false, 
                        progress: 100,
                        // Use a sample video for demonstration
                        videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
                        thumbnailUrl: '#'
                      }
                    : video
                )
              )
              setIsGeneratingVideo(false)
              setVideoProgress(0)
            }, 1000)
          }
          
          return newProgress
        })
      }, 500)
      
      // TODO: Replace with actual API call when video generation is available
      // const response = await fetch('/api/generate-video', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({
      //     prompt: videoPrompt,
      //     negativePrompt: showVideoAdvanced ? videoNegativePrompt : '',
      //     style: videoStyle,
      //     duration: videoDuration[0],
      //     resolution: videoResolution,
      //     fps: videoFps[0],
      //     quality: videoQuality[0],
      //     includeAudio,
      //     cameraMovement,
      //     lighting
      //   })
      // })
      
    } catch (error) {
      console.error('Video generation failed:', error)
      setIsGeneratingVideo(false)
      setVideoProgress(0)
    }
  }

  const downloadVideo = (video: GeneratedVideo) => {
    if (video.videoUrl && video.videoUrl !== '#') {
      const link = document.createElement('a')
      link.download = `ai-video-${video.id}.mp4`
      link.href = video.videoUrl
      link.click()
    } else {
      alert('Video processing not complete yet')
    }
  }

  const deleteVideo = (id: string) => {
    setGeneratedVideos(prev => prev.filter(video => video.id !== id))
  }

  // Video playback controls
  const togglePlayPause = (videoId: string) => {
    const video = videoRefs.current[videoId]
    if (!video) return

    if (video.paused) {
      // Pause all other videos
      Object.values(videoRefs.current).forEach(v => {
        if (v && v !== video && !v.paused) {
          v.pause()
        }
      })
      
      video.play()
      setGeneratedVideos(prev => 
        prev.map(v => 
          v.id === videoId 
            ? { ...v, isPlaying: true }
            : { ...v, isPlaying: false }
        )
      )
    } else {
      video.pause()
      setGeneratedVideos(prev => 
        prev.map(v => 
          v.id === videoId 
            ? { ...v, isPlaying: false }
            : v
        )
      )
    }
  }

  const handleTimeUpdate = (videoId: string, currentTime: number) => {
    setGeneratedVideos(prev => 
      prev.map(v => 
        v.id === videoId 
          ? { ...v, currentTime }
          : v
      )
    )
  }

  const handleVideoEnded = (videoId: string) => {
    setGeneratedVideos(prev => 
      prev.map(v => 
        v.id === videoId 
          ? { ...v, isPlaying: false, currentTime: 0 }
          : v
      )
    )
  }

  const handleVolumeChange = (videoId: string, volume: number) => {
    const video = videoRefs.current[videoId]
    if (video) {
      video.volume = volume
      setGeneratedVideos(prev => 
        prev.map(v => 
          v.id === videoId 
            ? { ...v, volume }
            : v
        )
      )
    }
  }

  const toggleMute = (videoId: string) => {
    const video = videoRefs.current[videoId]
    if (video) {
      video.muted = !video.muted
      setGeneratedVideos(prev => 
        prev.map(v => 
          v.id === videoId 
            ? { ...v, isMuted: video.muted }
            : v
        )
      )
    }
  }

  const seekVideo = (videoId: string, time: number) => {
    const video = videoRefs.current[videoId]
    if (video) {
      video.currentTime = time
    }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              AI Creative Studio
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-4">
            Transform your ideas into stunning images and videos with advanced AI. Create professional-quality content in seconds.
          </p>
          
          {/* Storage Usage Indicator */}
          <div className="max-w-md mx-auto">
            <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
              <span className="flex items-center gap-1">
                <Database className="w-4 h-4" />
                Storage Usage
              </span>
              <span>{formatBytes(storageUsage.used)} / {formatBytes(storageUsage.total)}</span>
            </div>
            <Progress 
              value={(storageUsage.used / storageUsage.total) * 100} 
              className="h-2"
            />
            {storageUsage.used / storageUsage.total > 0.8 && (
              <Alert className="mt-2" variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Storage almost full! Old images will be automatically removed.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 max-w-lg mx-auto">
            <TabsTrigger value="generate" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Images
            </TabsTrigger>
            <TabsTrigger value="video" className="gap-2">
              <Film className="w-4 h-4" />
              Videos
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              History ({history.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="generate" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Control Panel */}
              <div className="lg:col-span-1">
                <Card className="sticky top-8">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      Generation Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Prompt Input */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Prompt</label>
                      <Textarea
                        placeholder="Describe the image you want to create..."
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="min-h-24 resize-none"
                      />
                      <p className="text-xs text-muted-foreground">
                        Be descriptive and specific for best results
                      </p>
                    </div>

                    {/* Basic Controls */}
                    <div className="grid grid-cols-1 gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Style</label>
                          <Select value={style} onValueChange={setStyle}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="photorealistic">📸 Photorealistic</SelectItem>
                              <SelectItem value="digital-art">🎨 Digital Art</SelectItem>
                              <SelectItem value="anime">🀄 Anime</SelectItem>
                              <SelectItem value="oil-painting">🖼️ Oil Painting</SelectItem>
                              <SelectItem value="watercolor">💧 Watercolor</SelectItem>
                              <SelectItem value="sketch">✏️ Sketch</SelectItem>
                              <SelectItem value="3d-render">🎲 3D Render</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium">Image Size</label>
                          <Select value={imageSize} onValueChange={setImageSize}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="512x512">512×512 (Fast)</SelectItem>
                              <SelectItem value="1024x1024">1024×1024 (Standard)</SelectItem>
                              <SelectItem value="1024x1792">1024×1792 (Portrait)</SelectItem>
                              <SelectItem value="1792x1024">1792×1024 (Landscape)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Aspect Ratio</label>
                        <Select value={aspectRatio} onValueChange={setAspectRatio}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1:1">⬜ Square (1:1)</SelectItem>
                            <SelectItem value="16:9">▬ Landscape (16:9)</SelectItem>
                            <SelectItem value="9:16">▮ Portrait (9:16)</SelectItem>
                            <SelectItem value="4:3">▭ Classic (4:3)</SelectItem>
                            <SelectItem value="3:2">▬ Photo (3:2)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Advanced Controls Toggle */}
                    <Button
                      variant="outline"
                      onClick={() => setShowAdvanced(!showAdvanced)}
                      className="w-full"
                    >
                      {showAdvanced ? 'Hide' : 'Show'} Advanced Options
                    </Button>

                    {/* Advanced Controls */}
                    {showAdvanced && (
                      <div className="space-y-6 pt-4 border-t">
                        {/* Negative Prompt */}
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Negative Prompt</label>
                          <Textarea
                            placeholder="What you don't want in the image..."
                            value={negativePrompt}
                            onChange={(e) => setNegativePrompt(e.target.value)}
                            className="min-h-16 resize-none"
                          />
                          <p className="text-xs text-muted-foreground">
                            Describe elements to avoid in the generated image
                          </p>
                        </div>

                        <Separator />

                        {/* Quality Settings */}
                        <div className="space-y-3">
                          <label className="text-sm font-medium">Quality: {quality[0]}%</label>
                          <Slider
                            value={quality}
                            onValueChange={setQuality}
                            max={100}
                            min={50}
                            step={10}
                            className="w-full"
                          />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Faster</span>
                            <span>Better Quality</span>
                          </div>
                        </div>

                        {/* Number of Images */}
                        <div className="space-y-3">
                          <label className="text-sm font-medium">Number of Images: {numImages[0]}</label>
                          <Slider
                            value={numImages}
                            onValueChange={setNumImages}
                            max={4}
                            min={1}
                            step={1}
                            className="w-full"
                          />
                          <p className="text-xs text-muted-foreground">
                            Generate multiple variations at once
                          </p>
                        </div>

                        {/* Seed Control */}
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Seed (Optional)</label>
                          <div className="flex gap-2">
                            <Input
                              placeholder="Random"
                              value={seed}
                              onChange={(e) => setSeed(e.target.value)}
                              className="flex-1"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={generateRandomSeed}
                              className="px-3"
                            >
                              <RefreshCw className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            Use the same seed for reproducible results
                          </p>
                        </div>
                      </div>
                    )}

                    {/* Generate Button */}
                    <Button
                      onClick={handleGenerate}
                      disabled={!prompt.trim() || isGenerating || isCompressing}
                      className="w-full h-12 text-lg"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Generating {numImages[0]} {numImages[0] === 1 ? 'Image' : 'Images'}...
                        </>
                      ) : isCompressing ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Compressing & Saving...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-5 h-5 mr-2" />
                          Generate {numImages[0]} {numImages[0] === 1 ? 'Image' : 'Images'}
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Results Area */}
              <div className="lg:col-span-2">
                <div className="space-y-6">
                  {/* Generated Images Grid */}
                  {generatedImages.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <Sparkles className="w-5 h-5" />
                            Generated Images ({generatedImages.length})
                          </span>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">
                              {generatedImages.length} generated
                            </Badge>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={clearAll}
                              className="gap-2"
                            >
                              Clear All
                            </Button>
                          </div>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {generatedImages.map((imageData, index) => (
                            <div key={index} className="relative group">
                              <div className="aspect-square overflow-hidden rounded-lg border bg-muted">
                                <img
                                  src={`data:image/png;base64,${imageData}`}
                                  alt={`Generated image ${index + 1}`}
                                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                />
                              </div>
                              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => downloadImage(imageData, index)}
                                  className="gap-2"
                                >
                                  <Download className="w-4 h-4" />
                                  Download
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => copyToClipboard(`data:image/png;base64,${imageData}`)}
                                  className="gap-2"
                                >
                                  <Copy className="w-4 h-4" />
                                  Copy
                                </Button>
                              </div>
                              <div className="absolute top-2 left-2">
                                <Badge variant="secondary" className="text-xs">
                                  #{generatedImages.length - index}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Empty State */}
                  {generatedImages.length === 0 && (
                    <Card className="border-dashed">
                      <CardContent className="flex flex-col items-center justify-center py-16">
                        <Sparkles className="w-16 h-16 text-muted-foreground/50 mb-4" />
                        <h3 className="text-xl font-semibold mb-2">Ready to Create</h3>
                        <p className="text-muted-foreground text-center max-w-sm">
                          Enter a prompt above and click "Generate Image" to create your first AI masterpiece
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="video" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Video Control Panel */}
              <div className="lg:col-span-1">
                <Card className="sticky top-8">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Film className="w-5 h-5" />
                      Video Generation Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Video Prompt Input */}
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Video Prompt</label>
                      <Textarea
                        placeholder="Describe the video scene you want to create..."
                        value={videoPrompt}
                        onChange={(e) => setVideoPrompt(e.target.value)}
                        className="min-h-24 resize-none"
                      />
                      <p className="text-xs text-muted-foreground">
                        Describe the scene, action, and mood for your video
                      </p>
                    </div>

                    {/* Basic Video Controls */}
                    <div className="grid grid-cols-1 gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Style</label>
                          <Select value={videoStyle} onValueChange={setVideoStyle}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="cinematic">🎬 Cinematic</SelectItem>
                              <SelectItem value="anime">🀄 Anime</SelectItem>
                              <SelectItem value="cartoon">🎨 Cartoon</SelectItem>
                              <SelectItem value="realistic">📹 Realistic</SelectItem>
                              <SelectItem value="documentary">📽️ Documentary</SelectItem>
                              <SelectItem value="animation">🎭 Animation</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div className="space-y-2">
                          <label className="text-sm font-medium">Resolution</label>
                          <Select value={videoResolution} onValueChange={setVideoResolution}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="480p">480p (Fast)</SelectItem>
                              <SelectItem value="720p">720p (HD)</SelectItem>
                              <SelectItem value="1080p">1080p (Full HD)</SelectItem>
                              <SelectItem value="4k">4K (Ultra HD)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <label className="text-sm font-medium">Duration: {videoDuration[0]}s</label>
                        <Slider
                          value={videoDuration}
                          onValueChange={setVideoDuration}
                          max={30}
                          min={5}
                          step={5}
                          className="w-full"
                        />
                        <p className="text-xs text-muted-foreground">
                          Longer videos take more time to generate
                        </p>
                      </div>

                      <div className="space-y-3">
                        <label className="text-sm font-medium">Frame Rate: {videoFps[0]} fps</label>
                        <Slider
                          value={videoFps}
                          onValueChange={setVideoFps}
                          max={60}
                          min={15}
                          step={1}
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Cinematic</span>
                          <span>Smooth</span>
                        </div>
                      </div>
                    </div>

                    {/* Advanced Video Controls Toggle */}
                    <Button
                      variant="outline"
                      onClick={() => setShowVideoAdvanced(!showVideoAdvanced)}
                      className="w-full"
                    >
                      {showVideoAdvanced ? 'Hide' : 'Show'} Advanced Options
                    </Button>

                    {/* Advanced Video Controls */}
                    {showVideoAdvanced && (
                      <div className="space-y-6 pt-4 border-t">
                        {/* Negative Prompt */}
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Negative Prompt</label>
                          <Textarea
                            placeholder="What you don't want in the video..."
                            value={videoNegativePrompt}
                            onChange={(e) => setVideoNegativePrompt(e.target.value)}
                            className="min-h-16 resize-none"
                          />
                          <p className="text-xs text-muted-foreground">
                            Describe elements to avoid in the generated video
                          </p>
                        </div>

                        <Separator />

                        {/* Video Quality */}
                        <div className="space-y-3">
                          <label className="text-sm font-medium">Quality: {videoQuality[0]}%</label>
                          <Slider
                            value={videoQuality}
                            onValueChange={setVideoQuality}
                            max={100}
                            min={50}
                            step={10}
                            className="w-full"
                          />
                          <div className="flex justify-between text-xs text-muted-foreground">
                            <span>Faster</span>
                            <span>Better Quality</span>
                          </div>
                        </div>

                        {/* Audio Toggle */}
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="include-audio"
                            checked={includeAudio}
                            onChange={(e) => setIncludeAudio(e.target.checked)}
                            className="rounded"
                          />
                          <Label htmlFor="include-audio" className="text-sm font-medium">
                            Include Audio Generation
                          </Label>
                        </div>

                        {/* Camera Movement */}
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Camera Movement</label>
                          <Select value={cameraMovement} onValueChange={setCameraMovement}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="static">📷 Static</SelectItem>
                              <SelectItem value="pan">↔️ Pan</SelectItem>
                              <SelectItem value="tilt">↕️ Tilt</SelectItem>
                              <SelectItem value="zoom">🔍 Zoom</SelectItem>
                              <SelectItem value="tracking">🎯 Tracking</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Lighting */}
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Lighting</label>
                          <Select value={lighting} onValueChange={setLighting}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="natural">☀️ Natural</SelectItem>
                              <SelectItem value="dramatic">🎭 Dramatic</SelectItem>
                              <SelectItem value="soft">💡 Soft</SelectItem>
                              <SelectItem value="neon">⚡ Neon</SelectItem>
                              <SelectItem value="sunset">🌅 Sunset</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    )}

                    {/* Generate Video Button */}
                    <Button
                      onClick={handleVideoGenerate}
                      disabled={!videoPrompt.trim() || isGeneratingVideo}
                      className="w-full h-12 text-lg"
                    >
                      {isGeneratingVideo ? (
                        <>
                          <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                          Generating Video... {videoProgress}%
                        </>
                      ) : (
                        <>
                          <Film className="w-5 h-5 mr-2" />
                          Generate Video
                        </>
                      )}
                    </Button>

                    {/* Progress Bar */}
                    {isGeneratingVideo && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Generation Progress</span>
                          <span>{videoProgress}%</span>
                        </div>
                        <Progress value={videoProgress} className="w-full" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Video Results Area */}
              <div className="lg:col-span-2">
                <div className="space-y-6">
                  {/* Generated Videos Grid */}
                  {generatedVideos.length > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span className="flex items-center gap-2">
                            <Film className="w-5 h-5" />
                            Generated Videos ({generatedVideos.length})
                          </span>
                          <Badge variant="secondary">
                            {generatedVideos.filter(v => !v.isProcessing).length} ready
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {generatedVideos.map((video) => (
                            <div key={video.id} className="relative group">
                              <div className="aspect-video overflow-hidden rounded-lg border bg-muted relative">
                                {video.isProcessing ? (
                                  <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                                    <div className="text-center">
                                      <Loader2 className="w-12 h-12 mx-auto mb-2 animate-spin" />
                                      <p className="text-sm text-muted-foreground">
                                        Processing... {video.progress}%
                                      </p>
                                      <Progress value={video.progress} className="w-32 mt-2" />
                                    </div>
                                  </div>
                                ) : (
                                  <>
                                    {/* Video Player */}
                                    <video
                                      ref={(el) => {
                                        if (el) videoRefs.current[video.id] = el
                                      }}
                                      className="w-full h-full object-cover"
                                      onTimeUpdate={() => handleTimeUpdate(video.id, video.currentTime || 0)}
                                      onEnded={() => handleVideoEnded(video.id)}
                                      onLoadedMetadata={() => {
                                        // Initialize video state
                                        setGeneratedVideos(prev => 
                                          prev.map(v => 
                                            v.id === video.id 
                                              ? { 
                                                  ...v, 
                                                  volume: 1,
                                                  isMuted: false,
                                                  isPlaying: false,
                                                  currentTime: 0
                                                }
                                              : v
                                          )
                                        )
                                      }}
                                      preload="metadata"
                                    >
                                      {/* Use actual video URL if available, otherwise placeholder */}
                                      {video.videoUrl && video.videoUrl !== '#' ? (
                                        <source src={video.videoUrl} type="video/mp4" />
                                      ) : (
                                        <source src="#" type="video/mp4" />
                                      )}
                                      Your browser does not support the video tag.
                                    </video>
                                    
                                    {/* Video Controls Overlay */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
                                      {/* Play/Pause Button */}
                                      <div className="absolute inset-0 flex items-center justify-center">
                                        <Button
                                          size="lg"
                                          variant="secondary"
                                          className="w-16 h-16 rounded-full opacity-90 hover:opacity-100"
                                          onClick={() => togglePlayPause(video.id)}
                                        >
                                          {video.isPlaying ? (
                                            <Pause className="w-6 h-6" />
                                          ) : (
                                            <Play className="w-6 h-6 ml-1" />
                                          )}
                                        </Button>
                                      </div>
                                      
                                      {/* Bottom Controls */}
                                      <div className="absolute bottom-0 left-0 right-0 p-3">
                                        {/* Progress Bar */}
                                        <div className="mb-2">
                                          <div className="flex items-center gap-2 text-white text-xs">
                                            <span>{formatTime(video.currentTime || 0)}</span>
                                            <div 
                                              className="flex-1 h-1 bg-white/30 rounded-full cursor-pointer relative"
                                              onClick={(e) => {
                                                const rect = e.currentTarget.getBoundingClientRect()
                                                const clickX = e.clientX - rect.left
                                                const progress = clickX / rect.width
                                                seekVideo(video.id, progress * video.duration)
                                              }}
                                            >
                                              <div 
                                                className="h-full bg-white rounded-full relative"
                                                style={{ width: `${((video.currentTime || 0) / video.duration) * 100}%` }}
                                              >
                                                <div className="absolute right-0 top-1/2 transform translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full"></div>
                                              </div>
                                            </div>
                                            <span>{formatTime(video.duration)}</span>
                                          </div>
                                        </div>
                                        
                                        {/* Control Buttons */}
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-2">
                                            <Button
                                              size="sm"
                                              variant="ghost"
                                              className="text-white hover:text-white hover:bg-white/20"
                                              onClick={() => toggleMute(video.id)}
                                            >
                                              {video.isMuted ? (
                                                <VolumeX className="w-4 h-4" />
                                              ) : (
                                                <Volume2 className="w-4 h-4" />
                                              )}
                                            </Button>
                                            <input
                                              type="range"
                                              min="0"
                                              max="1"
                                              step="0.1"
                                              value={video.volume || 1}
                                              onChange={(e) => handleVolumeChange(video.id, parseFloat(e.target.value))}
                                              className="w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer"
                                              style={{
                                                WebkitAppearance: 'none',
                                                background: `linear-gradient(to right, white 0%, white ${(video.volume || 1) * 100}%, rgba(255,255,255,0.3) ${(video.volume || 1) * 100}%, rgba(255,255,255,0.3) 100%)`
                                              }}
                                            />
                                          </div>
                                          
                                          <div className="flex items-center gap-2">
                                            <Button
                                              size="sm"
                                              variant="ghost"
                                              className="text-white hover:text-white hover:bg-white/20"
                                              onClick={() => downloadVideo(video)}
                                            >
                                              <Download className="w-4 h-4" />
                                            </Button>
                                            <Button
                                              size="sm"
                                              variant="ghost"
                                              className="text-white hover:text-white hover:bg-white/20"
                                              onClick={() => deleteVideo(video.id)}
                                            >
                                              <Trash2 className="w-4 h-4" />
                                            </Button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    
                                    {/* Simulation Mode Overlay */}
                                    {(!video.videoUrl || video.videoUrl === '#') && (
                                      <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                                        <div className="text-center text-white">
                                          <Play className="w-12 h-12 mx-auto mb-2 opacity-80" />
                                          <p className="text-sm">Simulation Mode</p>
                                          <p className="text-xs opacity-75">Real video coming soon</p>
                                        </div>
                                      </div>
                                    )}
                                  </>
                                )}
                              </div>
                              <div className="absolute top-2 left-2">
                                <Badge variant="secondary" className="text-xs">
                                  {video.resolution} • {video.duration}s
                                </Badge>
                              </div>
                              <div className="absolute bottom-2 left-2 right-2">
                                <div className="bg-black/80 text-white text-xs p-1 rounded truncate">
                                  {video.prompt.substring(0, 50)}...
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Empty State */}
                  {generatedVideos.length === 0 && (
                    <Card className="border-dashed">
                      <CardContent className="flex flex-col items-center justify-center py-16">
                        <Film className="w-16 h-16 text-muted-foreground/50 mb-4" />
                        <h3 className="text-xl font-semibold mb-2">Ready to Create Videos</h3>
                        <p className="text-muted-foreground text-center max-w-sm">
                          Enter a prompt above and click "Generate Video" to create your first AI masterpiece
                        </p>
                        <Alert className="mt-4 max-w-sm">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription className="text-xs">
                            Video generation is currently in simulation mode. Real video generation will be available when the AI service supports it.
                          </AlertDescription>
                        </Alert>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <History className="w-5 h-5" />
                    Generation History ({history.length})
                  </span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={exportHistory}
                      className="gap-2"
                      disabled={history.length === 0}
                    >
                      <Save className="w-4 h-4" />
                      Export
                    </Button>
                    <Label htmlFor="import-history" className="cursor-pointer">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-2"
                        asChild
                      >
                        <span>
                          <Upload className="w-4 h-4" />
                          Import
                        </span>
                      </Button>
                    </Label>
                    <input
                      id="import-history"
                      type="file"
                      accept=".json"
                      onChange={importHistory}
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearHistory}
                      className="gap-2"
                      disabled={history.length === 0}
                    >
                      <Trash2 className="w-4 h-4" />
                      Clear All
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {history.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {history.map((item) => (
                      <div key={item.id} className="relative group">
                        <div className="aspect-square overflow-hidden rounded-lg border bg-muted">
                          <img
                            src={item.thumbnail}
                            alt={`Generated image`}
                            className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          />
                        </div>
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex flex-col items-center justify-center gap-2 p-2">
                          <Button
                            size="sm"
                            onClick={() => downloadFromHistory(item)}
                            className="gap-2 w-full"
                          >
                            <Download className="w-4 h-4" />
                            Download
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => loadFromHistory(item)}
                            className="gap-2 w-full"
                          >
                            <Settings className="w-4 h-4" />
                            Use Settings
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => deleteFromHistory(item.id)}
                            className="gap-2 w-full"
                          >
                            <Trash2 className="w-4 h-4" />
                            Delete
                          </Button>
                        </div>
                        <div className="absolute top-2 left-2">
                          <Badge variant="secondary" className="text-xs">
                            {new Date(item.timestamp).toLocaleDateString()}
                          </Badge>
                        </div>
                        <div className="absolute bottom-2 left-2 right-2">
                          <div className="bg-black/80 text-white text-xs p-1 rounded truncate">
                            {item.prompt.substring(0, 50)}...
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16">
                    <History className="w-16 h-16 text-muted-foreground/50 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No History Yet</h3>
                    <p className="text-muted-foreground text-center max-w-sm">
                      Your generated images will appear here. Start creating to build your gallery!
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}