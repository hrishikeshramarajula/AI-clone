import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { prompt, provider = 'auto', model = 'auto', size = '1024x1024', optimize = true, saveToFile = false } = body;

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    console.log('Generating image with params:', { prompt, provider, model, size, optimize, saveToFile });

    const zai = await ZAI.create();

    const response = await zai.images.generations.create({
      prompt,
      size: size as any,
    });

    const imageData = response.data[0].base64;

    return NextResponse.json({
      success: true,
      imageData,
      provider: provider === 'auto' ? 'ZAI' : provider,
      model: model === 'auto' ? 'Default' : model,
      metadata: {
        size,
        optimized: optimize,
        timestamp: new Date().toISOString()
      }
    });

  } catch (error) {
    console.error('Image generation error:', error);
    return NextResponse.json(
      { 
        error: error instanceof Error ? error.message : 'Failed to generate image',
        details: error instanceof Error ? error.stack : undefined
      },
      { status: 500 }
    );
  }
}