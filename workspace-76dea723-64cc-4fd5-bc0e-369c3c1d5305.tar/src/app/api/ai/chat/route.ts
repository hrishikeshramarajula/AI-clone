import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { messages, files, activeFile } = await request.json()

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json(
        { error: 'Messages array is required' },
        { status: 400 }
      )
    }

    // Create ZAI instance
    const zai = await ZAI.create()

    // Prepare system message with context about files
    let systemMessage = {
      role: 'system' as const,
      content: `You are an expert web developer assistant. You help users with coding, debugging, and web development tasks. 

Current project context:
- Total files: ${files?.length || 0}
${files?.map((file: any) => `- ${file.name} (${file.language})`).join('\n') || ''}

${activeFile ? `Currently active file: ${activeFile.name} (${activeFile.language})` : ''}

Guidelines:
1. Provide clear, helpful code examples
2. Explain concepts in simple terms
3. Suggest best practices
4. When generating code, specify the language
5. Be concise but thorough
6. Focus on modern web development practices

Available languages: HTML, CSS, JavaScript, TypeScript, React, Vue, Angular, Node.js, etc.`
    }

    // Format messages for ZAI
    const formattedMessages = [systemMessage, ...messages.map((msg: any) => ({
      role: msg.role,
      content: msg.content
    }))]

    // Get AI completion
    const completion = await zai.chat.completions.create({
      messages: formattedMessages,
      temperature: 0.7,
      max_tokens: 1000
    })

    const response = completion.choices[0]?.message?.content || 'Sorry, I encountered an error.'

    return NextResponse.json({
      content: response,
      role: 'assistant'
    })

  } catch (error) {
    console.error('Error in AI chat:', error)
    return NextResponse.json(
      { error: 'Failed to get AI response' },
      { status: 500 }
    )
  }
}