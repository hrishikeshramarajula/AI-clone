import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const files = await db.file.findMany({
      where: { projectId: params.id },
      orderBy: { name: 'asc' }
    })

    return NextResponse.json(files)
  } catch (error) {
    console.error('Error fetching files:', error)
    return NextResponse.json(
      { error: 'Failed to fetch files' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { name, content, language, path } = await request.json()

    if (!name || !content || !language) {
      return NextResponse.json(
        { error: 'Name, content, and language are required' },
        { status: 400 }
      )
    }

    const file = await db.file.create({
      data: {
        name,
        content,
        language,
        path: path || name,
        projectId: params.id
      }
    })

    return NextResponse.json(file, { status: 201 })
  } catch (error) {
    console.error('Error creating file:', error)
    return NextResponse.json(
      { error: 'Failed to create file' },
      { status: 500 }
    )
  }
}