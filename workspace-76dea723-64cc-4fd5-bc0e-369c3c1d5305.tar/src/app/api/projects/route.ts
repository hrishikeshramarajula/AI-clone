import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const authorId = searchParams.get('authorId')

    if (!authorId) {
      return NextResponse.json(
        { error: 'Author ID is required' },
        { status: 400 }
      )
    }

    const projects = await db.project.findMany({
      where: { authorId },
      include: {
        files: true,
        author: {
          select: { id: true, name: true, email: true }
        }
      },
      orderBy: { updatedAt: 'desc' }
    })

    return NextResponse.json(projects)
  } catch (error) {
    console.error('Error fetching projects:', error)
    return NextResponse.json(
      { error: 'Failed to fetch projects' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, description, template, authorId, files = [] } = await request.json()

    if (!name || !authorId) {
      return NextResponse.json(
        { error: 'Name and author ID are required' },
        { status: 400 }
      )
    }

    const project = await db.project.create({
      data: {
        name,
        description,
        template,
        authorId,
        files: {
          create: files.map((file: any) => ({
            name: file.name,
            content: file.content,
            language: file.language,
            path: file.path || file.name
          }))
        }
      },
      include: {
        files: true,
        author: {
          select: { id: true, name: true, email: true }
        }
      }
    })

    return NextResponse.json(project, { status: 201 })
  } catch (error) {
    console.error('Error creating project:', error)
    return NextResponse.json(
      { error: 'Failed to create project' },
      { status: 500 }
    )
  }
}