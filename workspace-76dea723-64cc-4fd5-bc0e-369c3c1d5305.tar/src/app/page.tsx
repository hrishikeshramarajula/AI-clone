'use client'

import { useState, useEffect } from 'react'
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable'
import { Sidebar } from '@/components/sidebar'
import { FileExplorer } from '@/components/file-explorer'
import { CodeEditor } from '@/components/code-editor'
import { LivePreview } from '@/components/live-preview'
import { Terminal } from '@/components/terminal'
import { TopToolbar } from '@/components/top-toolbar'
import { StatusBar } from '@/components/status-bar'
import { ProjectManager } from '@/components/project-manager'
import { AIAssistant } from '@/components/ai-assistant'
import { ApiTester } from '@/components/api-tester'
import { CssTools } from '@/components/css-tools'
import { ColorPalette } from '@/components/color-palette'
import { ComponentLibrary } from '@/components/component-library'
import { PerformanceAnalyzer } from '@/components/performance-analyzer'
import { Button } from '@/components/ui/button'
import { FolderIcon } from 'lucide-react'

interface File {
  id: string
  name: string
  content: string
  language: string
  path: string
  projectId: string
}

interface Project {
  id: string
  name: string
  description?: string
  template?: string
  isPublic: boolean
  createdAt: string
  updatedAt: string
  files: File[]
  author: {
    id: string
    name?: string
    email: string
  }
}

export default function Home() {
  const [activeFile, setActiveFile] = useState<string | null>(null)
  const [files, setFiles] = useState<File[]>([])
  const [currentProject, setCurrentProject] = useState<Project | null>(null)
  const [showProjectManager, setShowProjectManager] = useState(false)
  const [activeTool, setActiveTool] = useState('explorer')
  const [authorId] = useState('demo-user') // In a real app, this would come from authentication

  // Load demo project on initial mount
  useEffect(() => {
    loadDemoProject()
  }, [])

  const loadDemoProject = () => {
    const demoProject: Project = {
      id: 'demo',
      name: 'Demo Project',
      description: 'A sample project to get you started',
      template: 'html-css-js',
      isPublic: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      files: [
        { 
          id: '1', 
          name: 'index.html', 
          content: '<!DOCTYPE html>\n<html>\n<head>\n  <title>My Project</title>\n  <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n  <div class="container">\n    <h1>Hello World!</h1>\n    <p>Welcome to the Web Developer Tool</p>\n    <button id="myButton">Click Me!</button>\n  </div>\n  <script src="script.js"></script>\n</body>\n</html>', 
          language: 'html',
          path: 'index.html',
          projectId: 'demo'
        },
        { 
          id: '2', 
          name: 'styles.css', 
          content: '* {\n  margin: 0;\n  padding: 0;\n  box-sizing: border-box;\n}\n\nbody {\n  font-family: Arial, sans-serif;\n  line-height: 1.6;\n  background-color: #f4f4f4;\n}\n\n.container {\n  max-width: 800px;\n  margin: 50px auto;\n  padding: 20px;\n  background-color: white;\n  border-radius: 8px;\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);\n}\n\nh1 {\n  color: #333;\n  text-align: center;\n  margin-bottom: 20px;\n}\n\np {\n  color: #666;\n  text-align: center;\n  margin-bottom: 20px;\n}\n\nbutton {\n  display: block;\n  margin: 0 auto;\n  padding: 10px 20px;\n  background-color: #007bff;\n  color: white;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 16px;\n}\n\nbutton:hover {\n  background-color: #0056b3;\n}', 
          language: 'css',
          path: 'styles.css',
          projectId: 'demo'
        },
        { 
          id: '3', 
          name: 'script.js', 
          content: 'document.getElementById(\'myButton\').addEventListener(\'click\', function() {\n  alert(\'Hello from JavaScript!\');\n  console.log(\'Button clicked!\');\n});\n\n// Add more JavaScript functionality here\ndocument.addEventListener(\'DOMContentLoaded\', function() {\n  console.log(\'DOM fully loaded\');\n});', 
          language: 'javascript',
          path: 'script.js',
          projectId: 'demo'
        }
      ],
      author: {
        id: authorId,
        name: 'Demo User',
        email: 'demo@example.com'
      }
    }
    
    setCurrentProject(demoProject)
    setFiles(demoProject.files)
    setActiveFile('1')
  }

  const handleLoadProject = (project: Project) => {
    setCurrentProject(project)
    setFiles(project.files)
    setActiveFile(project.files[0]?.id || null)
    setShowProjectManager(false)
  }

  const handleFileSelect = (fileId: string) => {
    setActiveFile(fileId)
  }

  const handleFileContentChange = async (fileId: string, content: string) => {
    setFiles(prev => prev.map(file => 
      file.id === fileId ? { ...file, content } : file
    ))

    // Auto-save to database if it's a real project
    if (currentProject && currentProject.id !== 'demo') {
      try {
        await fetch(`/api/projects/${currentProject.id}/files`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: files.find(f => f.id === fileId)?.name,
            content,
            language: files.find(f => f.id === fileId)?.language,
            path: files.find(f => f.id === fileId)?.path
          }),
        })
      } catch (error) {
        console.error('Error auto-saving file:', error)
      }
    }
  }

  const handleInsertCode = (code: string) => {
    if (activeFile) {
      const currentContent = files.find(f => f.id === activeFile)?.content || ''
      const newContent = currentContent + '\n\n' + code
      handleFileContentChange(activeFile, newContent)
    }
  }

  const activeFileContent = files.find(f => f.id === activeFile)

  return (
    <div className="h-screen flex flex-col bg-background">
      <TopToolbar onOpenProjectManager={() => setShowProjectManager(true)} />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar onToolSelect={setActiveTool} />
        
        {activeTool === 'api' ? (
          <div className="flex-1">
            <ApiTester />
          </div>
        ) : activeTool === 'css' ? (
          <div className="flex-1">
            <CssTools />
          </div>
        ) : activeTool === 'colors' ? (
          <div className="flex-1">
            <ColorPalette />
          </div>
        ) : activeTool === 'components' ? (
          <div className="flex-1">
            <ComponentLibrary />
          </div>
        ) : activeTool === 'performance' ? (
          <div className="flex-1">
            <PerformanceAnalyzer />
          </div>
        ) : (
          <ResizablePanelGroup direction="horizontal" className="flex-1">
            <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
              <FileExplorer 
                files={files} 
                activeFile={activeFile}
                onFileSelect={handleFileSelect}
                projectName={currentProject?.name}
              />
            </ResizablePanel>
            
            <ResizableHandle withHandle />
            
            <ResizablePanel defaultSize={40}>
              <div className="h-full flex flex-col">
                {activeFileContent ? (
                  <CodeEditor
                    file={activeFileContent}
                    onContentChange={(content) => handleFileContentChange(activeFileContent.id, content)}
                  />
                ) : (
                  <div className="flex-1 flex items-center justify-center text-muted-foreground">
                    <div className="text-center">
                      <FolderIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>Select a file to start editing</p>
                      {files.length === 0 && (
                        <Button 
                          variant="outline" 
                          className="mt-4"
                          onClick={() => setShowProjectManager(true)}
                        >
                          Open or Create Project
                        </Button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </ResizablePanel>
            
            <ResizableHandle withHandle />
            
            <ResizablePanel defaultSize={40}>
              <div className="h-full flex flex-col">
                <LivePreview files={files} />
              </div>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}
      </div>
      
      <Terminal />
      <StatusBar files={files} activeFile={activeFileContent} />
      
      <ProjectManager
        open={showProjectManager}
        onOpenChange={setShowProjectManager}
        onLoadProject={handleLoadProject}
        authorId={authorId}
      />
      
      <AIAssistant
        files={files}
        activeFile={activeFileContent}
        onInsertCode={handleInsertCode}
      />
    </div>
  )
}