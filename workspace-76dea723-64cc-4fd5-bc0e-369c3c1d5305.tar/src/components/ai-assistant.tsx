'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { 
  SendIcon, 
  BotIcon, 
  UserIcon, 
  CopyIcon, 
  ThumbsUpIcon,
  ThumbsDownIcon,
  RefreshCwIcon,
  CodeIcon,
  LightbulbIcon,
  BookOpenIcon,
  ZapIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  type?: 'text' | 'code' | 'suggestion'
  code?: string
  language?: string
}

interface AIAssistantProps {
  files: Array<{
    id: string
    name: string
    content: string
    language: string
  }>
  activeFile?: {
    id: string
    name: string
    content: string
    language: string
  } | null
  onInsertCode: (code: string) => void
}

const aiPrompts = [
  { 
    icon: CodeIcon, 
    label: 'Generate Code', 
    prompt: 'Generate JavaScript code for a function that:',
    description: 'Create functions, classes, or components'
  },
  { 
    icon: LightbulbIcon, 
    label: 'Explain Code', 
    prompt: 'Explain what this code does:',
    description: 'Get explanations for code snippets'
  },
  { 
    icon: BookOpenIcon, 
    label: 'Debug Help', 
    prompt: 'Help me debug this issue:',
    description: 'Get help with debugging problems'
  },
  { 
    icon: ZapIcon, 
    label: 'Optimize', 
    prompt: 'Optimize this code for better performance:',
    description: 'Improve code performance and readability'
  }
]

export function AIAssistant({ files, activeFile, onInsertCode }: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your AI coding assistant. I can help you with code generation, debugging, explanations, and more. What would you like to work on today?",
      timestamp: new Date(),
      type: 'text'
    }
  ])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
      type: 'text'
    }

    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsLoading(true)

    try {
      // Call real AI API
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messages: messages.map(msg => ({
            role: msg.role,
            content: msg.content
          })),
          files,
          activeFile
        }),
      })

      if (response.ok) {
        const aiData = await response.json()
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: aiData.content,
          timestamp: new Date(),
          type: 'text'
        }

        setMessages(prev => [...prev, assistantMessage])
      } else {
        throw new Error('AI API request failed')
      }
    } catch (error) {
      console.error('Error getting AI response:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: new Date(),
        type: 'text'
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handlePromptClick = (prompt: string) => {
    setInput(prompt)
  }

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code)
  }

  const handleInsertCode = (code: string) => {
    onInsertCode(code)
  }

  return (
    <Card className={cn(
      "fixed bottom-20 right-4 w-96 transition-all duration-200 z-40",
      isMinimized ? "h-12" : "h-[600px]"
    )}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BotIcon className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">AI Assistant</CardTitle>
            {isLoading && (
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
            )}
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setIsMinimized(!isMinimized)}
            >
              {isMinimized ? (
                <div className="w-4 h-0.5 bg-current" />
              ) : (
                <div className="w-4 h-0.5 bg-current mb-1" />
              )}
            </Button>
          </div>
        </div>
      </CardHeader>

      {!isMinimized && (
        <>
          <CardContent className="p-0 flex flex-col h-[calc(100%-4rem)]">
            {/* Quick Actions */}
            <div className="p-3 border-b">
              <div className="grid grid-cols-2 gap-2">
                {aiPrompts.map((prompt) => (
                  <Button
                    key={prompt.label}
                    variant="outline"
                    size="sm"
                    className="h-auto p-2 text-left flex flex-col items-start gap-1"
                    onClick={() => handlePromptClick(prompt.prompt)}
                  >
                    <div className="flex items-center gap-1 w-full">
                      <prompt.icon className="h-3 w-3" />
                      <span className="text-xs font-medium">{prompt.label}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {prompt.description}
                    </span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-3" ref={scrollRef}>
              <div className="space-y-3">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={cn(
                      "flex gap-2",
                      message.role === 'user' ? "justify-end" : "justify-start"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[80%] rounded-lg p-3",
                        message.role === 'user'
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {message.role === 'user' ? (
                          <UserIcon className="h-3 w-3" />
                        ) : (
                          <BotIcon className="h-3 w-3" />
                        )}
                        <span className="text-xs opacity-70">
                          {message.role === 'user' ? 'You' : 'AI Assistant'}
                        </span>
                        {message.type && (
                          <Badge variant="secondary" className="text-xs">
                            {message.type}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="text-sm whitespace-pre-wrap">
                        {message.content}
                      </div>
                      
                      {message.code && (
                        <div className="mt-2">
                          <div className="bg-background border rounded p-2 font-mono text-xs">
                            <pre className="whitespace-pre-wrap overflow-x-auto">
                              {message.code}
                            </pre>
                          </div>
                          <div className="flex gap-1 mt-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2 text-xs"
                              onClick={() => handleCopyCode(message.code!)}
                            >
                              <CopyIcon className="h-3 w-3 mr-1" />
                              Copy
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 px-2 text-xs"
                              onClick={() => handleInsertCode(message.code!)}
                            >
                              <CodeIcon className="h-3 w-3 mr-1" />
                              Insert
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex gap-2">
                    <div className="bg-muted rounded-lg p-3 max-w-[80%]">
                      <div className="flex items-center gap-2 mb-1">
                        <BotIcon className="h-3 w-3" />
                        <span className="text-xs opacity-70">AI Assistant</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" />
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                        <div className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="p-3 border-t">
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  handleSendMessage(input)
                }}
                className="flex gap-2"
              >
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask me anything about your code..."
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={isLoading || !input.trim()}
                >
                  <SendIcon className="h-4 w-4" />
                </Button>
              </form>
            </div>
          </CardContent>
        </>
      )}
    </Card>
  )
}