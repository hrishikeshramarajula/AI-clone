'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  SendIcon, 
  CopyIcon, 
  TrashIcon, 
  PlusIcon,
  SaveIcon,
  PlayIcon,
  FileTextIcon,
  CodeIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface ApiRequest {
  id: string
  name: string
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  url: string
  headers: Record<string, string>
  body?: string
  response?: {
    status: number
    statusText: string
    headers: Record<string, string>
    body: string
    time: number
  }
  timestamp: Date
}

export function ApiTester() {
  const [requests, setRequests] = useState<ApiRequest[]>([
    {
      id: '1',
      name: 'GET Example',
      method: 'GET',
      url: 'https://jsonplaceholder.typicode.com/posts/1',
      headers: {
        'Content-Type': 'application/json'
      },
      timestamp: new Date()
    }
  ])
  const [activeRequest, setActiveRequest] = useState<string>('1')
  const [isLoading, setIsLoading] = useState(false)

  const currentRequest = requests.find(r => r.id === activeRequest)

  const handleSendRequest = async () => {
    if (!currentRequest) return

    setIsLoading(true)
    const startTime = Date.now()

    try {
      const headers = new Headers(currentRequest.headers)
      
      const options: RequestInit = {
        method: currentRequest.method,
        headers,
      }

      if (currentRequest.body && ['POST', 'PUT', 'PATCH'].includes(currentRequest.method)) {
        options.body = currentRequest.body
      }

      const response = await fetch(currentRequest.url, options)
      const endTime = Date.now()
      const responseTime = endTime - startTime

      const responseHeaders: Record<string, string> = {}
      response.headers.forEach((value, key) => {
        responseHeaders[key] = value
      })

      const responseBody = await response.text()

      const updatedRequest: ApiRequest = {
        ...currentRequest,
        response: {
          status: response.status,
          statusText: response.statusText,
          headers: responseHeaders,
          body: responseBody,
          time: responseTime
        }
      }

      setRequests(prev => prev.map(r => r.id === activeRequest ? updatedRequest : r))
    } catch (error) {
      const endTime = Date.now()
      const responseTime = endTime - startTime

      const updatedRequest: ApiRequest = {
        ...currentRequest,
        response: {
          status: 0,
          statusText: 'Network Error',
          headers: {},
          body: error instanceof Error ? error.message : 'Unknown error occurred',
          time: responseTime
        }
      }

      setRequests(prev => prev.map(r => r.id === activeRequest ? updatedRequest : r))
    } finally {
      setIsLoading(false)
    }
  }

  const handleUpdateRequest = (updates: Partial<ApiRequest>) => {
    if (!currentRequest) return

    const updatedRequest = { ...currentRequest, ...updates }
    setRequests(prev => prev.map(r => r.id === activeRequest ? updatedRequest : r))
  }

  const handleAddRequest = () => {
    const newRequest: ApiRequest = {
      id: Date.now().toString(),
      name: `Request ${requests.length + 1}`,
      method: 'GET',
      url: '',
      headers: {
        'Content-Type': 'application/json'
      },
      timestamp: new Date()
    }

    setRequests(prev => [...prev, newRequest])
    setActiveRequest(newRequest.id)
  }

  const handleDeleteRequest = (id: string) => {
    if (requests.length === 1) return
    
    setRequests(prev => prev.filter(r => r.id !== id))
    if (activeRequest === id) {
      setActiveRequest(requests[0].id)
    }
  }

  const handleCopyResponse = () => {
    if (!currentRequest?.response) return
    navigator.clipboard.writeText(currentRequest.response.body)
  }

  const formatBody = (body: string) => {
    try {
      const parsed = JSON.parse(body)
      return JSON.stringify(parsed, null, 2)
    } catch {
      return body
    }
  }

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return 'bg-green-500'
    if (status >= 300 && status < 400) return 'bg-yellow-500'
    if (status >= 400 && status < 500) return 'bg-orange-500'
    if (status >= 500) return 'bg-red-500'
    return 'bg-gray-500'
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">API Tester</h3>
          <Button onClick={handleAddRequest} size="sm">
            <PlusIcon className="h-4 w-4 mr-2" />
            New Request
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Request List */}
        <div className="w-64 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-medium mb-2">Requests</h4>
            <ScrollArea className="h-48">
              <div className="space-y-1">
                {requests.map((request) => (
                  <div
                    key={request.id}
                    className={cn(
                      "p-2 rounded cursor-pointer hover:bg-muted transition-colors",
                      activeRequest === request.id && "bg-muted"
                    )}
                    onClick={() => setActiveRequest(request.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium truncate">{request.name}</span>
                      {requests.length > 1 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-4 w-4"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDeleteRequest(request.id)
                          }}
                        >
                          <TrashIcon className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {request.method}
                      </Badge>
                      {request.response && (
                        <Badge 
                          variant="outline" 
                          className={cn("text-xs", getStatusColor(request.response.status))}
                        >
                          {request.response.status}
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Request Builder */}
        <div className="flex-1 flex flex-col">
          {currentRequest && (
            <>
              {/* Request Header */}
              <div className="border-b border-border p-3">
                <div className="flex items-center gap-2 mb-2">
                  <Input
                    value={currentRequest.name}
                    onChange={(e) => handleUpdateRequest({ name: e.target.value })}
                    className="flex-1"
                    placeholder="Request name"
                  />
                  <Select
                    value={currentRequest.method}
                    onValueChange={(value: any) => handleUpdateRequest({ method: value })}
                  >
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="GET">GET</SelectItem>
                      <SelectItem value="POST">POST</SelectItem>
                      <SelectItem value="PUT">PUT</SelectItem>
                      <SelectItem value="DELETE">DELETE</SelectItem>
                      <SelectItem value="PATCH">PATCH</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={handleSendRequest}
                    disabled={isLoading || !currentRequest.url}
                  >
                    <PlayIcon className={cn("h-4 w-4", isLoading && "animate-spin")} />
                  </Button>
                </div>
                <Input
                  value={currentRequest.url}
                  onChange={(e) => handleUpdateRequest({ url: e.target.value })}
                  placeholder="https://api.example.com/endpoint"
                />
              </div>

              {/* Request Details */}
              <div className="flex-1 overflow-hidden">
                <Tabs defaultValue="headers" className="h-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="headers">Headers</TabsTrigger>
                    <TabsTrigger value="body">Body</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="headers" className="h-full p-3">
                    <ScrollArea className="h-full">
                      <div className="space-y-2">
                        {Object.entries(currentRequest.headers).map(([key, value]) => (
                          <div key={key} className="flex gap-2">
                            <Input
                              value={key}
                              onChange={(e) => {
                                const newHeaders = { ...currentRequest.headers }
                                delete newHeaders[key]
                                newHeaders[e.target.value] = value
                                handleUpdateRequest({ headers: newHeaders })
                              }}
                              placeholder="Header name"
                              className="flex-1"
                            />
                            <Input
                              value={value}
                              onChange={(e) => {
                                const newHeaders = { ...currentRequest.headers, [key]: e.target.value }
                                handleUpdateRequest({ headers: newHeaders })
                              }}
                              placeholder="Header value"
                              className="flex-1"
                            />
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => {
                                const newHeaders = { ...currentRequest.headers }
                                delete newHeaders[key]
                                handleUpdateRequest({ headers: newHeaders })
                              }}
                            >
                              <TrashIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const newHeaders = { ...currentRequest.headers, '': '' }
                            handleUpdateRequest({ headers: newHeaders })
                          }}
                        >
                          <PlusIcon className="h-4 w-4 mr-2" />
                          Add Header
                        </Button>
                      </div>
                    </ScrollArea>
                  </TabsContent>
                  
                  <TabsContent value="body" className="h-full p-3">
                    {['POST', 'PUT', 'PATCH'].includes(currentRequest.method) ? (
                      <Textarea
                        value={currentRequest.body || ''}
                        onChange={(e) => handleUpdateRequest({ body: e.target.value })}
                        placeholder="Request body (JSON, XML, etc.)"
                        className="h-full resize-none"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full text-muted-foreground">
                        <p>Body is not available for {currentRequest.method} requests</p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </div>

              {/* Response */}
              {currentRequest.response && (
                <div className="border-t border-border">
                  <div className="p-3 border-b border-border">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline" 
                          className={cn(getStatusColor(currentRequest.response.status))}
                        >
                          {currentRequest.response.status} {currentRequest.response.statusText}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {currentRequest.response.time}ms
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleCopyResponse}
                      >
                        <CopyIcon className="h-4 w-4 mr-2" />
                        Copy
                      </Button>
                    </div>
                  </div>
                  
                  <Tabs defaultValue="body" className="h-48">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="body">Body</TabsTrigger>
                      <TabsTrigger value="headers">Headers</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="body" className="p-3">
                      <ScrollArea className="h-32">
                        <pre className="text-sm whitespace-pre-wrap">
                          {formatBody(currentRequest.response.body)}
                        </pre>
                      </ScrollArea>
                    </TabsContent>
                    
                    <TabsContent value="headers" className="p-3">
                      <ScrollArea className="h-32">
                        <div className="space-y-1 text-sm">
                          {Object.entries(currentRequest.response.headers).map(([key, value]) => (
                            <div key={key} className="flex justify-between">
                              <span className="font-medium">{key}:</span>
                              <span className="text-muted-foreground">{value}</span>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </TabsContent>
                  </Tabs>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}