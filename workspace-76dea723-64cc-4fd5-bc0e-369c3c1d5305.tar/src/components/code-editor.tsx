'use client'

import { useState, useEffect } from 'react'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  CopyIcon, 
  DownloadIcon, 
  SaveIcon,
  UndoIcon,
  RedoIcon,
  SearchIcon
} from 'lucide-react'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism'

interface File {
  id: string
  name: string
  content: string
  language: string
}

interface CodeEditorProps {
  file: File
  onContentChange: (content: string) => void
}

const languageMap: Record<string, string> = {
  'javascript': 'javascript',
  'typescript': 'typescript',
  'html': 'html',
  'css': 'css',
  'json': 'json',
  'jsx': 'jsx',
  'tsx': 'tsx'
}

export function CodeEditor({ file, onContentChange }: CodeEditorProps) {
  const [content, setContent] = useState(file.content)
  const [language, setLanguage] = useState(file.language)
  const [isEditing, setIsEditing] = useState(false)
  const [history, setHistory] = useState<string[]>([file.content])
  const [historyIndex, setHistoryIndex] = useState(0)

  useEffect(() => {
    setContent(file.content)
    setLanguage(file.language)
    setHistory([file.content])
    setHistoryIndex(0)
  }, [file])

  const handleContentChange = (newContent: string) => {
    setContent(newContent)
    if (historyIndex === history.length - 1) {
      setHistory([...history, newContent])
      setHistoryIndex(history.length)
    } else {
      const newHistory = history.slice(0, historyIndex + 1)
      setHistory([...newHistory, newContent])
      setHistoryIndex(newHistory.length)
    }
    onContentChange(newContent)
  }

  const undo = () => {
    if (historyIndex > 0) {
      const newIndex = historyIndex - 1
      setHistoryIndex(newIndex)
      setContent(history[newIndex])
      onContentChange(history[newIndex])
    }
  }

  const redo = () => {
    if (historyIndex < history.length - 1) {
      const newIndex = historyIndex + 1
      setHistoryIndex(newIndex)
      setContent(history[newIndex])
      onContentChange(history[newIndex])
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(content)
    } catch (err) {
      console.error('Failed to copy text: ', err)
    }
  }

  const downloadFile = () => {
    const blob = new Blob([content], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = file.name
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const syntaxLanguage = languageMap[language] || 'text'

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">{file.name}</span>
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-24 h-6 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="javascript">JS</SelectItem>
              <SelectItem value="typescript">TS</SelectItem>
              <SelectItem value="html">HTML</SelectItem>
              <SelectItem value="css">CSS</SelectItem>
              <SelectItem value="json">JSON</SelectItem>
              <SelectItem value="jsx">JSX</SelectItem>
              <SelectItem value="tsx">TSX</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={undo}
            disabled={historyIndex === 0}
          >
            <UndoIcon className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={redo}
            disabled={historyIndex === history.length - 1}
          >
            <RedoIcon className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={copyToClipboard}
          >
            <CopyIcon className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={downloadFile}
          >
            <DownloadIcon className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => setIsEditing(!isEditing)}
          >
            <SearchIcon className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="h-full">
          <SyntaxHighlighter
            language={syntaxLanguage}
            style={vscDarkPlus}
            customStyle={{
              margin: 0,
              height: '100%',
              fontSize: '14px',
              lineHeight: '1.5',
              backgroundColor: 'var(--background)'
            }}
            wrapLongLines
          >
            {content}
          </SyntaxHighlighter>
        </div>
      </ScrollArea>
      
      {isEditing && (
        <div className="border-t border-border p-2">
          <textarea
            value={content}
            onChange={(e) => handleContentChange(e.target.value)}
            className="w-full h-32 p-2 text-sm bg-muted rounded border border-border resize-none focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="Start typing..."
          />
        </div>
      )}
    </div>
  )
}