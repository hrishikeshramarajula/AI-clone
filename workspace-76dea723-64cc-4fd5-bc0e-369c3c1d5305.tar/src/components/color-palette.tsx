'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Slider } from '@/components/ui/slider'
import { 
  CopyIcon, 
  RotateCcwIcon, 
  DownloadIcon,
  PaletteIcon,
  EyeIcon,
  CodeIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface Color {
  hex: string
  rgb: string
  hsl: string
  name: string
}

interface Palette {
  id: string
  name: string
  colors: Color[]
  type: 'complementary' | 'analogous' | 'triadic' | 'split-complementary' | 'tetradic' | 'monochromatic'
}

const predefinedPalettes: Palette[] = [
  {
    id: 'ocean',
    name: 'Ocean Breeze',
    type: 'analogous',
    colors: [
      { hex: '#006994', rgb: 'rgb(0, 105, 148)', hsl: 'hsl(200, 100%, 29%)', name: 'Deep Ocean' },
      { hex: '#0099cc', rgb: 'rgb(0, 153, 204)', hsl: 'hsl(200, 100%, 40%)', name: 'Ocean Blue' },
      { hex: '#66b3ff', rgb: 'rgb(102, 179, 255)', hsl: 'hsl(210, 100%, 70%)', name: 'Sky Blue' },
      { hex: '#b3d9ff', rgb: 'rgb(179, 217, 255)', hsl: 'hsl(210, 100%, 85%)', name: 'Light Sky' },
      { hex: '#e6f3ff', rgb: 'rgb(230, 243, 255)', hsl: 'hsl(210, 100%, 95%)', name: 'Pale Sky' }
    ]
  },
  {
    id: 'sunset',
    name: 'Sunset Glow',
    type: 'analogous',
    colors: [
      { hex: '#ff6b35', rgb: 'rgb(255, 107, 53)', hsl: 'hsl(16, 100%, 60%)', name: 'Sunset Orange' },
      { hex: '#ff8c42', rgb: 'rgb(255, 140, 66)', hsl: 'hsl(24, 100%, 63%)', name: 'Warm Orange' },
      { hex: '#ffd23f', rgb: 'rgb(255, 210, 63)', hsl: 'hsl(45, 100%, 62%)', name: 'Golden Yellow' },
      { hex: '#06ffa5', rgb: 'rgb(6, 255, 165)', hsl: 'hsl(156, 100%, 51%)', name: 'Mint Green' },
      { hex: '#118ab2', rgb: 'rgb(17, 138, 178)', hsl: 'hsl(195, 83%, 38%)', name: 'Ocean Teal' }
    ]
  },
  {
    id: 'forest',
    name: 'Forest Green',
    type: 'monochromatic',
    colors: [
      { hex: '#1b4332', rgb: 'rgb(27, 67, 50)', hsl: 'hsl(155, 42%, 18%)', name: 'Dark Forest' },
      { hex: '#2d6a4f', rgb: 'rgb(45, 106, 79)', hsl: 'hsl(155, 40%, 30%)', name: 'Forest Green' },
      { hex: '#40916c', rgb: 'rgb(64, 145, 108)', hsl: 'hsl(155, 39%, 41%)', name: 'Medium Green' },
      { hex: '#52b788', rgb: 'rgb(82, 183, 136)', hsl: 'hsl(155, 41%, 52%)', name: 'Sage Green' },
      { hex: '#74c69d', rgb: 'rgb(116, 198, 157)', hsl: 'hsl(155, 41%, 62%)', name: 'Light Sage' }
    ]
  },
  {
    id: 'royal',
    name: 'Royal Purple',
    type: 'complementary',
    colors: [
      { hex: '#4c1d95', rgb: 'rgb(76, 29, 149)', hsl: 'hsl(260, 67%, 35%)', name: 'Royal Purple' },
      { hex: '#6d28d9', rgb: 'rgb(109, 40, 217)', hsl: 'hsl(260, 70%, 50%)', name: 'Purple' },
      { hex: '#8b5cf6', rgb: 'rgb(139, 92, 246)', hsl: 'hsl(260, 90%, 66%)', name: 'Violet' },
      { hex: '#fbbf24', rgb: 'rgb(251, 191, 36)', hsl: 'hsl(45, 96%, 56%)', name: 'Amber' },
      { hex: '#f59e0b', rgb: 'rgb(245, 158, 11)', hsl: 'hsl(32, 92%, 50%)', name: 'Orange' }
    ]
  }
]

export function ColorPalette() {
  const [palettes, setPalettes] = useState<Palette[]>(predefinedPalettes)
  const [activePalette, setActivePalette] = useState<Palette>(predefinedPalettes[0])
  const [baseColor, setBaseColor] = useState('#3b82f6')
  const [paletteType, setPaletteType] = useState<Palette['type']>('complementary')

  const hexToRgb = (hex: string): string => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
    return result 
      ? `rgb(${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)})`
      : 'rgb(0, 0, 0)'
  }

  const hexToHsl = (hex: string): string => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
    if (!result) return 'hsl(0, 0%, 0%)'
    
    let r = parseInt(result[1], 16) / 255
    let g = parseInt(result[2], 16) / 255
    let b = parseInt(result[3], 16) / 255

    const max = Math.max(r, g, b)
    const min = Math.min(r, g, b)
    let h = 0, s, l = (max + min) / 2

    if (max === min) {
      h = s = 0
    } else {
      const d = max - min
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break
        case g: h = (b - r) / d + 2; break
        case b: h = (r - g) / d + 4; break
      }
      h! /= 6
    }

    return `hsl(${Math.round(h! * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`
  }

  const generatePalette = (baseHex: string, type: Palette['type']): Color[] => {
    const baseRgb = hexToRgb(baseHex)
    const baseHsl = hexToHsl(baseHex)
    
    // Extract HSL values
    const hslMatch = baseHsl.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/)
    if (!hslMatch) return []
    
    let h = parseInt(hslMatch[1])
    const s = parseInt(hslMatch[2])
    const l = parseInt(hslMatch[3])

    const colors: Color[] = []

    switch (type) {
      case 'complementary':
        colors.push(
          { hex: baseHex, rgb: baseRgb, hsl: baseHsl, name: 'Base Color' },
          { hex: adjustHue(baseHex, 180), rgb: hexToRgb(adjustHue(baseHex, 180)), hsl: hexToHsl(adjustHue(baseHex, 180)), name: 'Complementary' }
        )
        break
      
      case 'analogous':
        for (let i = -2; i <= 2; i++) {
          const hue = (h + i * 30 + 360) % 360
          const hex = hslToHex(hue, s, l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: `hsl(${hue}, ${s}%, ${l}%)`,
            name: i === 0 ? 'Base Color' : `Analogous ${i > 0 ? '+' : ''}${i}`
          })
        }
        break
      
      case 'triadic':
        for (let i = 0; i < 3; i++) {
          const hue = (h + i * 120) % 360
          const hex = hslToHex(hue, s, l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: `hsl(${hue}, ${s}%, ${l}%)`,
            name: `Triadic ${i + 1}`
          })
        }
        break
      
      case 'monochromatic':
        for (let i = 0; i < 5; i++) {
          const lightness = Math.max(10, Math.min(90, l + (i - 2) * 20))
          const hex = hslToHex(h, s, lightness)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: `hsl(${h}, ${s}%, ${lightness}%)`,
            name: `Monochromatic ${i + 1}`
          })
        }
        break
      
      default:
        colors.push({ hex: baseHex, rgb: baseRgb, hsl: baseHsl, name: 'Base Color' })
    }

    return colors
  }

  const adjustHue = (hex: string, degrees: number): string => {
    const hsl = hexToHsl(hex)
    const hslMatch = hsl.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/)
    if (!hslMatch) return hex
    
    let h = parseInt(hslMatch[1])
    const s = parseInt(hslMatch[2])
    const l = parseInt(hslMatch[3])
    
    h = (h + degrees + 360) % 360
    return hslToHex(h, s, l)
  }

  const hslToHex = (h: number, s: number, l: number): string => {
    l /= 100
    const a = s * Math.min(l, 1 - l) / 100
    const f = (n: number) => {
      const k = (n + h / 30) % 12
      const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1)
      return Math.round(255 * color).toString(16).padStart(2, '0')
    }
    return `#${f(0)}${f(8)}${f(4)}`
  }

  const handleGeneratePalette = () => {
    const colors = generatePalette(baseColor, paletteType)
    const newPalette: Palette = {
      id: Date.now().toString(),
      name: `Custom ${paletteType}`,
      colors,
      type: paletteType
    }
    
    setPalettes(prev => [newPalette, ...prev])
    setActivePalette(newPalette)
  }

  const handleCopyColor = (color: string) => {
    navigator.clipboard.writeText(color)
  }

  const handleExportPalette = () => {
    const cssVariables = activePalette.colors.map((color, index) => 
      `--color-${index + 1}: ${color.hex};`
    ).join('\n')

    const tailwindConfig = `module.exports = {
  theme: {
    extend: {
      colors: {
${activePalette.colors.map((color, index) => 
        `        'color-${index + 1}': '${color.hex}',`
      ).join('\n')}
      }
    }
  }
}`

    const exportData = {
      name: activePalette.name,
      type: activePalette.type,
      colors: activePalette.colors,
      cssVariables,
      tailwindConfig
    }

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${activePalette.name.toLowerCase().replace(/\s+/g, '-')}-palette.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Color Palette Generator</h3>
          <Button onClick={handleExportPalette} variant="outline" size="sm">
            <DownloadIcon className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Palette List */}
        <div className="w-80 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-medium mb-2">Color Palettes</h4>
            <ScrollArea className="h-96">
              <div className="space-y-2">
                {palettes.map((palette) => (
                  <Card 
                    key={palette.id}
                    className={cn(
                      "cursor-pointer hover:shadow-md transition-shadow",
                      activePalette.id === palette.id && "ring-2 ring-primary"
                    )}
                    onClick={() => setActivePalette(palette)}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">{palette.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="flex h-8 rounded overflow-hidden">
                        {palette.colors.slice(0, 5).map((color, index) => (
                          <div
                            key={index}
                            className="flex-1"
                            style={{ backgroundColor: color.hex }}
                            title={color.name}
                          />
                        ))}
                      </div>
                      <Badge variant="secondary" className="text-xs mt-2">
                        {palette.type}
                      </Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Palette Details */}
        <div className="flex-1 flex flex-col">
          <Tabs defaultValue="colors" className="h-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="colors">Colors</TabsTrigger>
              <TabsTrigger value="generator">Generator</TabsTrigger>
              <TabsTrigger value="export">Export</TabsTrigger>
            </TabsList>
            
            <TabsContent value="colors" className="flex-1 p-3">
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{activePalette.name}</h4>
                  <Badge variant="outline">{activePalette.type}</Badge>
                </div>
                
                <ScrollArea className="flex-1">
                  <div className="space-y-4">
                    {activePalette.colors.map((color, index) => (
                      <Card key={index}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div
                              className="w-20 h-20 rounded-lg shadow-md"
                              style={{ backgroundColor: color.hex }}
                            />
                            <div className="flex-1">
                              <h5 className="font-medium mb-2">{color.name}</h5>
                              <div className="space-y-1 text-sm">
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">HEX:</span>
                                  <div className="flex items-center gap-2">
                                    <code className="bg-muted px-2 py-1 rounded text-xs">{color.hex}</code>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6"
                                      onClick={() => handleCopyColor(color.hex)}
                                    >
                                      <CopyIcon className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">RGB:</span>
                                  <div className="flex items-center gap-2">
                                    <code className="bg-muted px-2 py-1 rounded text-xs">{color.rgb}</code>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6"
                                      onClick={() => handleCopyColor(color.rgb)}
                                    >
                                      <CopyIcon className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                                <div className="flex items-center justify-between">
                                  <span className="text-muted-foreground">HSL:</span>
                                  <div className="flex items-center gap-2">
                                    <code className="bg-muted px-2 py-1 rounded text-xs">{color.hsl}</code>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6"
                                      onClick={() => handleCopyColor(color.hsl)}
                                    >
                                      <CopyIcon className="h-3 w-3" />
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </TabsContent>
            
            <TabsContent value="generator" className="flex-1 p-3">
              <div className="h-full max-w-md mx-auto space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Base Color</h4>
                  <div className="flex items-center gap-2">
                    <Input
                      type="color"
                      value={baseColor}
                      onChange={(e) => setBaseColor(e.target.value)}
                      className="w-16 h-10 p-1"
                    />
                    <Input
                      value={baseColor}
                      onChange={(e) => setBaseColor(e.target.value)}
                      placeholder="#3b82f6"
                      className="flex-1"
                    />
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Palette Type</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: 'complementary', label: 'Complementary' },
                      { value: 'analogous', label: 'Analogous' },
                      { value: 'triadic', label: 'Triadic' },
                      { value: 'monochromatic', label: 'Monochromatic' }
                    ].map((type) => (
                      <Button
                        key={type.value}
                        variant={paletteType === type.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setPaletteType(type.value as Palette['type'])}
                      >
                        {type.label}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <Button onClick={handleGeneratePalette} className="w-full">
                  <RefreshIcon className="h-4 w-4 mr-2" />
                  Generate Palette
                </Button>
                
                <div className="p-4 bg-muted rounded-lg">
                  <h5 className="font-medium mb-2">Preview</h5>
                  <div className="flex h-12 rounded overflow-hidden">
                    {generatePalette(baseColor, paletteType).map((color, index) => (
                      <div
                        key={index}
                        className="flex-1"
                        style={{ backgroundColor: color.hex }}
                        title={color.hex}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="export" className="flex-1 p-3">
              <div className="h-full max-w-2xl mx-auto space-y-6">
                <div>
                  <h4 className="font-medium mb-2">CSS Variables</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      <code>{`:root {\n${activePalette.colors.map((color, index) => 
                        `  --color-${index + 1}: ${color.hex};`
                      ).join('\n')}\n}`}</code>
                    </pre>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Tailwind CSS Config</h4>
                  <div className="bg-muted p-4 rounded-lg">
                    <pre className="text-sm overflow-x-auto">
                      <code>{`module.exports = {
  theme: {
    extend: {
      colors: {
${activePalette.colors.map((color, index) => 
        `        'color-${index + 1}': '${color.hex}',`
                      ).join('\n')}
      }
    }
  }
}`}</code>
                    </pre>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      const css = `:root {\n${activePalette.colors.map((color, index) => 
                        `  --color-${index + 1}: ${color.hex};`
                      ).join('\n')}\n}`
                      navigator.clipboard.writeText(css)
                    }}
                  >
                    <CopyIcon className="h-4 w-4 mr-2" />
                    Copy CSS
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      const tailwind = `module.exports = {
  theme: {
    extend: {
      colors: {
${activePalette.colors.map((color, index) => 
        `        'color-${index + 1}': '${color.hex}',`
                      ).join('\n')}
      }
    }
  }
}`
                      navigator.clipboard.writeText(tailwind)
                    }}
                  >
                    <CopyIcon className="h-4 w-4 mr-2" />
                    Copy Tailwind
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}