'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  CopyIcon, 
  EyeIcon, 
  CodeIcon,
  LayoutIcon,
  FormIcon,
  NavigationIcon,
  DisplayIcon,
  MediaIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface ComponentItem {
  id: string
  name: string
  category: string
  description: string
  preview: string
  code: string
  dependencies?: string[]
}

const components: ComponentItem[] = [
  {
    id: 'button-group',
    name: 'Button Group',
    category: 'Forms',
    description: 'Group of related buttons with different styles',
    preview: `<div class="flex gap-2">
  <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Primary</button>
  <button class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Secondary</button>
  <button class="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50">Outline</button>
</div>`,
    code: `<div class="flex gap-2">
  <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">
    Primary
  </button>
  <button class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors">
    Secondary
  </button>
  <button class="px-4 py-2 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
    Outline
  </button>
</div>`
  },
  {
    id: 'card-layout',
    name: 'Card Layout',
    category: 'Layout',
    description: 'Responsive card layout with image and content',
    preview: `<div class="max-w-sm rounded-lg shadow-md overflow-hidden">
  <img src="https://via.placeholder.com/400x200" alt="Card image" class="w-full h-48 object-cover">
  <div class="p-6">
    <h3 class="text-xl font-semibold mb-2">Card Title</h3>
    <p class="text-gray-600 mb-4">This is a card component with an image and description text.</p>
    <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Read More</button>
  </div>
</div>`,
    code: `<div class="max-w-sm rounded-lg shadow-md overflow-hidden">
  <img src="https://via.placeholder.com/400x200" alt="Card image" class="w-full h-48 object-cover">
  <div class="p-6">
    <h3 class="text-xl font-semibold mb-2">Card Title</h3>
    <p class="text-gray-600 mb-4">This is a card component with an image and description text.</p>
    <button class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors">
      Read More
    </button>
  </div>
</div>`
  },
  {
    id: 'form-input',
    name: 'Form Input',
    category: 'Forms',
    description: 'Styled form input with label and validation',
    preview: `<div class="space-y-2">
  <label class="block text-sm font-medium text-gray-700">Email Address</label>
  <input type="email" placeholder="you@example.com" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
  <p class="text-xs text-gray-500">We'll never share your email with anyone else.</p>
</div>`,
    code: `<div class="space-y-2">
  <label class="block text-sm font-medium text-gray-700">Email Address</label>
  <input 
    type="email" 
    placeholder="you@example.com" 
    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
  >
  <p class="text-xs text-gray-500">We'll never share your email with anyone else.</p>
</div>`
  },
  {
    id: 'navigation-bar',
    name: 'Navigation Bar',
    category: 'Navigation',
    description: 'Responsive navigation bar with logo and menu',
    preview: `<nav class="bg-white shadow-md">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex justify-between items-center h-16">
      <div class="flex items-center">
        <div class="text-xl font-bold text-blue-600">Logo</div>
      </div>
      <div class="hidden md:block">
        <div class="ml-10 flex items-baseline space-x-4">
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Home</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">About</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Services</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
        </div>
      </div>
    </div>
  </div>
</nav>`,
    code: `<nav class="bg-white shadow-md">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex justify-between items-center h-16">
      <div class="flex items-center">
        <div class="text-xl font-bold text-blue-600">Logo</div>
      </div>
      <div class="hidden md:block">
        <div class="ml-10 flex items-baseline space-x-4">
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Home</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">About</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Services</a>
          <a href="#" class="text-gray-700 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Contact</a>
        </div>
      </div>
    </div>
  </div>
</nav>`
  },
  {
    id: 'modal-dialog',
    name: 'Modal Dialog',
    category: 'Display',
    description: 'Modal dialog overlay with content and actions',
    preview: `<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
  <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
    <h3 class="text-lg font-semibold mb-4">Confirm Action</h3>
    <p class="text-gray-600 mb-6">Are you sure you want to perform this action? This cannot be undone.</p>
    <div class="flex justify-end space-x-3">
      <button class="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50">Cancel</button>
      <button class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600">Delete</button>
    </div>
  </div>
</div>`,
    code: `<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
  <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
    <h3 class="text-lg font-semibold mb-4">Confirm Action</h3>
    <p class="text-gray-600 mb-6">Are you sure you want to perform this action? This cannot be undone.</p>
    <div class="flex justify-end space-x-3">
      <button class="px-4 py-2 text-gray-600 border border-gray-300 rounded hover:bg-gray-50 transition-colors">
        Cancel
      </button>
      <button class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors">
        Delete
      </button>
    </div>
  </div>
</div>`
  },
  {
    id: 'badge-list',
    name: 'Badge List',
    category: 'Display',
    description: 'Collection of badges with different colors and styles',
    preview: `<div class="flex flex-wrap gap-2">
  <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">Primary</span>
  <span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">Success</span>
  <span class="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs font-medium rounded-full">Warning</span>
  <span class="px-2 py-1 bg-red-100 text-red-800 text-xs font-medium rounded-full">Danger</span>
  <span class="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full">Default</span>
</div>`,
    code: `<div class="flex flex-wrap gap-2">
  <span class="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">Primary</span>
  <span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">Success</span>
  <span class="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs font-medium rounded-full">Warning</span>
  <span class="px-2 py-1 bg-red-100 text-red-800 text-xs font-medium rounded-full">Danger</span>
  <span class="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full">Default</span>
</div>`
  },
  {
    id: 'progress-bar',
    name: 'Progress Bar',
    category: 'Display',
    description: 'Progress bar showing completion status',
    preview: `<div class="space-y-4">
  <div>
    <div class="flex justify-between text-sm text-gray-600 mb-1">
      <span>Progress</span>
      <span>75%</span>
    </div>
    <div class="w-full bg-gray-200 rounded-full h-2">
      <div class="bg-blue-500 h-2 rounded-full" style="width: 75%"></div>
    </div>
  </div>
  <div>
    <div class="flex justify-between text-sm text-gray-600 mb-1">
      <span>Loading</span>
      <span>45%</span>
    </div>
    <div class="w-full bg-gray-200 rounded-full h-2">
      <div class="bg-green-500 h-2 rounded-full" style="width: 45%"></div>
    </div>
  </div>
</div>`,
    code: `<div class="space-y-4">
  <div>
    <div class="flex justify-between text-sm text-gray-600 mb-1">
      <span>Progress</span>
      <span>75%</span>
    </div>
    <div class="w-full bg-gray-200 rounded-full h-2">
      <div class="bg-blue-500 h-2 rounded-full" style="width: 75%"></div>
    </div>
  </div>
  <div>
    <div class="flex justify-between text-sm text-gray-600 mb-1">
      <span>Loading</span>
      <span>45%</span>
    </div>
    <div class="w-full bg-gray-200 rounded-full h-2">
      <div class="bg-green-500 h-2 rounded-full" style="width: 45%"></div>
    </div>
  </div>
</div>`
  },
  {
    id: 'image-gallery',
    name: 'Image Gallery',
    category: 'Media',
    description: 'Responsive image gallery with grid layout',
    preview: `<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 1" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 2" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 3" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 4" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
</div>`,
    code: `<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 1" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 2" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 3" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
  <div class="aspect-square bg-gray-200 rounded-lg overflow-hidden">
    <img src="https://via.placeholder.com/300x300" alt="Gallery image 4" class="w-full h-full object-cover hover:scale-105 transition-transform">
  </div>
</div>`
  }
]

export function ComponentLibrary() {
  const [activeComponent, setActiveComponent] = useState<ComponentItem>(components[0])
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')

  const categories = ['all', ...new Set(components.map(c => c.category))]
  
  const filteredComponents = components.filter(component => {
    const matchesCategory = selectedCategory === 'all' || component.category === selectedCategory
    const matchesSearch = component.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         component.description.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code)
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Layout': return LayoutIcon
      case 'Forms': return FormIcon
      case 'Navigation': return NavigationIcon
      case 'Display': return DisplayIcon
      case 'Media': return MediaIcon
      default: return CodeIcon
    }
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Component Library</h3>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Search components..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-48"
            />
            <div className="flex items-center gap-2">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Component List */}
        <div className="w-80 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-medium mb-2">Components</h4>
            <ScrollArea className="h-96">
              <div className="space-y-2">
                {filteredComponents.map((component) => {
                  const IconComponent = getCategoryIcon(component.category)
                  return (
                    <Card 
                      key={component.id}
                      className={cn(
                        "cursor-pointer hover:shadow-md transition-shadow",
                        activeComponent.id === component.id && "ring-2 ring-primary"
                      )}
                      onClick={() => setActiveComponent(component)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <IconComponent className="h-4 w-4" />
                          <CardTitle className="text-sm">{component.name}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-xs text-muted-foreground mb-2">
                          {component.description}
                        </p>
                        <Badge variant="secondary" className="text-xs">
                          {component.category}
                        </Badge>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Component Details */}
        <div className="flex-1 flex flex-col">
          <Tabs defaultValue="preview" className="h-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="code">Code</TabsTrigger>
              <TabsTrigger value="info">Info</TabsTrigger>
            </TabsList>
            
            <TabsContent value="preview" className="flex-1 p-3">
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{activeComponent.name}</h4>
                  <Badge variant="outline">{activeComponent.category}</Badge>
                </div>
                <div className="flex-1 flex items-center justify-center bg-muted/20 rounded-lg p-8">
                  <div 
                    className="max-w-2xl w-full"
                    dangerouslySetInnerHTML={{ __html: activeComponent.preview }}
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="code" className="flex-1 p-3">
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">Source Code</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopyCode(activeComponent.code)}
                  >
                    <CopyIcon className="h-4 w-4 mr-2" />
                    Copy Code
                  </Button>
                </div>
                <div className="flex-1 bg-muted rounded-lg p-4">
                  <pre className="h-full overflow-auto">
                    <code className="text-sm">{activeComponent.code}</code>
                  </pre>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="info" className="flex-1 p-3">
              <div className="h-full max-w-2xl mx-auto space-y-6">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground">
                    {activeComponent.description}
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Category</h4>
                  <Badge variant="secondary">{activeComponent.category}</Badge>
                </div>
                
                {activeComponent.dependencies && activeComponent.dependencies.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Dependencies</h4>
                    <div className="space-y-1">
                      {activeComponent.dependencies.map((dep, index) => (
                        <div key={index} className="text-sm bg-muted px-2 py-1 rounded">
                          {dep}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                <div>
                  <h4 className="font-medium mb-2">Features</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Responsive design</li>
                    <li>• Hover effects</li>
                    <li>• Accessible markup</li>
                    <li>• Easy to customize</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Usage Tips</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>• Copy the code and paste it into your project</p>
                    <p>• Customize colors and spacing to match your design</p>
                    <p>• Test across different screen sizes</p>
                    <p>• Add accessibility attributes as needed</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}