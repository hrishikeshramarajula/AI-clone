'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Slider } from '@/components/ui/slider'
import { 
  CopyIcon, 
  TrashIcon, 
  PlusIcon,
  PlayIcon,
  FileTextIcon,
  CodeIcon,
  LayoutIcon,
  PaletteIcon,
  ZapIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface CssPattern {
  id: string
  name: string
  category: string
  description: string
  code: string
  preview: string
}

const cssPatterns: CssPattern[] = [
  {
    id: 'flex-center',
    name: 'Flex Center',
    category: 'Layout',
    description: 'Center content using flexbox',
    code: `.container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}`,
    preview: `<div class="bg-gray-100 p-8 rounded text-center">
  <div class="bg-white p-4 rounded shadow inline-block">
    Centered Content
  </div>
</div>`
  },
  {
    id: 'grid-layout',
    name: 'Grid Layout',
    category: 'Layout',
    description: 'Responsive grid layout',
    code: `.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  padding: 1rem;
}

.grid-item {
  background: #f3f4f6;
  padding: 1rem;
  border-radius: 0.5rem;
}`,
    preview: `<div class="bg-gray-100 p-4 rounded">
  <div class="grid grid-cols-3 gap-2">
    <div class="bg-white p-2 rounded text-sm">Item 1</div>
    <div class="bg-white p-2 rounded text-sm">Item 2</div>
    <div class="bg-white p-2 rounded text-sm">Item 3</div>
  </div>
</div>`
  },
  {
    id: 'gradient-bg',
    name: 'Gradient Background',
    category: 'Colors',
    description: 'Beautiful gradient backgrounds',
    code: `.gradient-bg {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
}`,
    preview: `<div class="bg-gradient-to-br from-purple-400 to-pink-400 p-8 rounded text-white text-center">
  Gradient Background
</div>`
  },
  {
    id: 'card-shadow',
    name: 'Card Shadow',
    category: 'Effects',
    description: 'Modern card shadow effects',
    code: `.card {
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 
              0 2px 4px -1px rgba(0, 0, 0, 0.06);
  padding: 1.5rem;
  transition: transform 0.2s, box-shadow 0.2s;
}

.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 
              0 4px 6px -2px rgba(0, 0, 0, 0.05);
}`,
    preview: `<div class="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow">
  <h3 class="font-bold mb-2">Card Title</h3>
  <p class="text-sm text-gray-600">Card with shadow effect</p>
</div>`
  },
  {
    id: 'button-styles',
    name: 'Button Styles',
    category: 'Components',
    description: 'Modern button styles',
    code: `.btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 0.375rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-primary {
  background: #3b82f6;
  color: white;
}

.btn-primary:hover {
  background: #2563eb;
  transform: translateY(-1px);
}

.btn-secondary {
  background: #e5e7eb;
  color: #374151;
}

.btn-secondary:hover {
  background: #d1d5db;
}`,
    preview: `<div class="space-x-2">
  <button class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors">
    Primary
  </button>
  <button class="bg-gray-200 text-gray-700 px-4 py-2 rounded hover:bg-gray-300 transition-colors">
    Secondary
  </button>
</div>`
  },
  {
    id: 'animation-fade',
    name: 'Fade Animation',
    category: 'Animations',
    description: 'Smooth fade in/out animation',
    code: `@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.fade-in {
  animation: fadeIn 0.6s ease-out;
}

.fade-out {
  animation: fadeIn 0.6s ease-out reverse;
}`,
    preview: `<div class="bg-gray-100 p-8 rounded text-center">
  <div class="bg-white p-4 rounded shadow inline-block animate-pulse">
    Fade Animation
  </div>
</div>`
  }
]

export function CssTools() {
  const [activePattern, setActivePattern] = useState<CssPattern>(cssPatterns[0])
  const [customCode, setCustomCode] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [customizer, setCustomizer] = useState({
    borderRadius: 8,
    padding: 16,
    margin: 0,
    fontSize: 16,
    backgroundColor: '#ffffff',
    textColor: '#000000'
  })

  const categories = ['all', ...new Set(cssPatterns.map(p => p.category))]
  
  const filteredPatterns = selectedCategory === 'all' 
    ? cssPatterns 
    : cssPatterns.filter(p => p.category === selectedCategory)

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code)
  }

  const generateCustomCSS = () => {
    return `.custom-element {
  border-radius: ${customizer.borderRadius}px;
  padding: ${customizer.padding}px;
  margin: ${customizer.margin}px;
  font-size: ${customizer.fontSize}px;
  background-color: ${customizer.backgroundColor};
  color: ${customizer.textColor};
  transition: all 0.3s ease;
}

.custom-element:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}`
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Layout': return LayoutIcon
      case 'Colors': return PaletteIcon
      case 'Effects': return ZapIcon
      case 'Components': return FileTextIcon
      case 'Animations': return PlayIcon
      default: return CodeIcon
    }
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">CSS Tools</h3>
          <div className="flex items-center gap-2">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Pattern List */}
        <div className="w-80 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-medium mb-2">CSS Patterns</h4>
            <ScrollArea className="h-96">
              <div className="space-y-2">
                {filteredPatterns.map((pattern) => {
                  const IconComponent = getCategoryIcon(pattern.category)
                  return (
                    <Card 
                      key={pattern.id}
                      className={cn(
                        "cursor-pointer hover:shadow-md transition-shadow",
                        activePattern.id === pattern.id && "ring-2 ring-primary"
                      )}
                      onClick={() => setActivePattern(pattern)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <IconComponent className="h-4 w-4" />
                          <CardTitle className="text-sm">{pattern.name}</CardTitle>
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <p className="text-xs text-muted-foreground mb-2">
                          {pattern.description}
                        </p>
                        <Badge variant="secondary" className="text-xs">
                          {pattern.category}
                        </Badge>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Pattern Details */}
        <div className="flex-1 flex flex-col">
          <Tabs defaultValue="code" className="h-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="code">Code</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
              <TabsTrigger value="customizer">Customizer</TabsTrigger>
            </TabsList>
            
            <TabsContent value="code" className="flex-1 p-3">
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">{activePattern.name}</h4>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleCopyCode(activePattern.code)}
                  >
                    <CopyIcon className="h-4 w-4 mr-2" />
                    Copy CSS
                  </Button>
                </div>
                <Textarea
                  value={activePattern.code}
                  readOnly
                  className="flex-1 font-mono text-sm resize-none"
                />
              </div>
            </TabsContent>
            
            <TabsContent value="preview" className="flex-1 p-3">
              <div className="h-full flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-medium">Live Preview</h4>
                  <Badge variant="outline">{activePattern.category}</Badge>
                </div>
                <div className="flex-1 flex items-center justify-center bg-muted/20 rounded-lg p-8">
                  <div 
                    className="max-w-md w-full"
                    dangerouslySetInnerHTML={{ __html: activePattern.preview }}
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="customizer" className="flex-1 p-3">
              <div className="h-full grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <h4 className="font-medium">Customize Properties</h4>
                  
                  <div className="space-y-3">
                    <div>
                      <label className="text-sm font-medium">Border Radius: {customizer.borderRadius}px</label>
                      <Slider
                        value={[customizer.borderRadius]}
                        onValueChange={(value) => setCustomizer(prev => ({ ...prev, borderRadius: value[0] }))}
                        max={50}
                        step={1}
                        className="mt-2"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Padding: {customizer.padding}px</label>
                      <Slider
                        value={[customizer.padding]}
                        onValueChange={(value) => setCustomizer(prev => ({ ...prev, padding: value[0] }))}
                        max={50}
                        step={1}
                        className="mt-2"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Font Size: {customizer.fontSize}px</label>
                      <Slider
                        value={[customizer.fontSize]}
                        onValueChange={(value) => setCustomizer(prev => ({ ...prev, fontSize: value[0] }))}
                        max={32}
                        step={1}
                        className="mt-2"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Background Color</label>
                      <Input
                        type="color"
                        value={customizer.backgroundColor}
                        onChange={(e) => setCustomizer(prev => ({ ...prev, backgroundColor: e.target.value }))}
                        className="mt-2 h-8"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Text Color</label>
                      <Input
                        type="color"
                        value={customizer.textColor}
                        onChange={(e) => setCustomizer(prev => ({ ...prev, textColor: e.target.value }))}
                        className="mt-2 h-8"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Generated CSS</h4>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleCopyCode(generateCustomCSS())}
                    >
                      <CopyIcon className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                  
                  <Textarea
                    value={generateCustomCSS()}
                    readOnly
                    className="flex-1 font-mono text-sm resize-none"
                  />
                  
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Preview</h4>
                  </div>
                  
                  <div className="flex items-center justify-center bg-muted/20 rounded-lg p-8">
                    <div 
                      className="text-center"
                      style={{
                        borderRadius: `${customizer.borderRadius}px`,
                        padding: `${customizer.padding}px`,
                        margin: `${customizer.margin}px`,
                        fontSize: `${customizer.fontSize}px`,
                        backgroundColor: customizer.backgroundColor,
                        color: customizer.textColor,
                        transition: 'all 0.3s ease'
                      }}
                    >
                      Custom Element
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}