'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  FileIcon, 
  FolderIcon, 
  FolderOpenIcon, 
  PlusIcon,
  MoreVerticalIcon,
  FileTextIcon
} from 'lucide-react'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { cn } from '@/lib/utils'

interface File {
  id: string
  name: string
  content: string
  language: string
}

interface FileExplorerProps {
  files: File[]
  activeFile: string | null
  onFileSelect: (fileId: string) => void
  projectName?: string
}

export function FileExplorer({ files, activeFile, onFileSelect, projectName }: FileExplorerProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['src']))
  
  const toggleFolder = (folderPath: string) => {
    const newExpanded = new Set(expandedFolders)
    if (newExpanded.has(folderPath)) {
      newExpanded.delete(folderPath)
    } else {
      newExpanded.add(folderPath)
    }
    setExpandedFolders(newExpanded)
  }

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase()
    switch (extension) {
      case 'js':
      case 'jsx':
      case 'ts':
      case 'tsx':
        return <FileTextIcon className="h-4 w-4 text-blue-500" />
      case 'css':
        return <FileTextIcon className="h-4 w-4 text-purple-500" />
      case 'html':
        return <FileTextIcon className="h-4 w-4 text-orange-500" />
      case 'json':
        return <FileTextIcon className="h-4 w-4 text-yellow-500" />
      default:
        return <FileIcon className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="h-full flex flex-col bg-muted/50">
      <div className="p-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">EXPLORER</h3>
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <PlusIcon className="h-3 w-3" />
          </Button>
        </div>
        {projectName && (
          <div className="mt-2 text-xs text-muted-foreground">
            Project: {projectName}
          </div>
        )}
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {/* Root folder */}
          <div className="space-y-1">
            <div
              className="flex items-center gap-1 p-1 hover:bg-accent rounded cursor-pointer"
              onClick={() => toggleFolder('src')}
            >
              {expandedFolders.has('src') ? (
                <FolderOpenIcon className="h-4 w-4" />
              ) : (
                <FolderIcon className="h-4 w-4" />
              )}
              <span className="text-sm">my-project</span>
            </div>
            
            {expandedFolders.has('src') && (
              <div className="ml-4 space-y-1">
                {files.map((file) => (
                  <div key={file.id} className="flex items-center group">
                    <div
                      className={cn(
                        "flex items-center gap-1 p-1 hover:bg-accent rounded cursor-pointer flex-1",
                        activeFile === file.id && "bg-accent"
                      )}
                      onClick={() => onFileSelect(file.id)}
                    >
                      {getFileIcon(file.name)}
                      <span className="text-sm">{file.name}</span>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-6 w-6 opacity-0 group-hover:opacity-100"
                        >
                          <MoreVerticalIcon className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>Rename</DropdownMenuItem>
                        <DropdownMenuItem>Delete</DropdownMenuItem>
                        <DropdownMenuItem>Duplicate</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}