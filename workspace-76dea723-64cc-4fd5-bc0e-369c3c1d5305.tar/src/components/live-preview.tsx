'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  RefreshCwIcon, 
  ExternalLinkIcon, 
  MaximizeIcon,
  MinimizeIcon,
  SmartphoneIcon,
  TabletIcon,
  MonitorIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface File {
  id: string
  name: string
  content: string
  language: string
}

interface LivePreviewProps {
  files: File[]
}

const previewSizes = [
  { name: 'Desktop', value: 'desktop', icon: MonitorIcon, width: '100%' },
  { name: 'Tablet', value: 'tablet', icon: TabletIcon, width: '768px' },
  { name: 'Mobile', value: 'mobile', icon: SmartphoneIcon, width: '375px' }
]

export function LivePreview({ files }: LivePreviewProps) {
  const [html, setHtml] = useState('')
  const [css, setCss] = useState('')
  const [js, setJs] = useState('')
  const [previewSize, setPreviewSize] = useState('desktop')
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  useEffect(() => {
    const htmlFile = files.find(f => f.name.endsWith('.html'))
    const cssFile = files.find(f => f.name.endsWith('.css'))
    const jsFile = files.find(f => f.name.endsWith('.js'))

    setHtml(htmlFile?.content || '')
    setCss(cssFile?.content || '')
    setJs(jsFile?.content || '')
  }, [files])

  const updatePreview = () => {
    if (!iframeRef.current) return

    setIsLoading(true)
    
    const combinedHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          ${css}
        </style>
      </head>
      <body>
        ${html}
        <script>
          ${js}
        </script>
      </body>
      </html>
    `

    const iframe = iframeRef.current
    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document
    
    if (iframeDoc) {
      iframeDoc.open()
      iframeDoc.write(combinedHtml)
      iframeDoc.close()
      
      setTimeout(() => {
        setIsLoading(false)
      }, 100)
    }
  }

  useEffect(() => {
    updatePreview()
  }, [html, css, js])

  const refreshPreview = () => {
    updatePreview()
  }

  const openInNewTab = () => {
    const combinedHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          ${css}
        </style>
      </head>
      <body>
        ${html}
        <script>
          ${js}
        </script>
      </body>
      </html>
    `

    const blob = new Blob([combinedHtml], { type: 'text/html' })
    const url = URL.createObjectURL(blob)
    window.open(url, '_blank')
  }

  const selectedSize = previewSizes.find(size => size.value === previewSize)
  const IconComponent = selectedSize?.icon || MonitorIcon

  return (
    <div className={cn(
      "h-full flex flex-col bg-background",
      isFullscreen && "fixed inset-0 z-50 bg-background"
    )}>
      <div className="border-b border-border p-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-semibold">Live Preview</h3>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={refreshPreview}
            disabled={isLoading}
          >
            <RefreshCwIcon className={cn("h-3 w-3", isLoading && "animate-spin")} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={openInNewTab}
          >
            <ExternalLinkIcon className="h-3 w-3" />
          </Button>
        </div>
        
        <div className="flex items-center gap-2">
          <Select value={previewSize} onValueChange={setPreviewSize}>
            <SelectTrigger className="w-24 h-6 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {previewSizes.map((size) => (
                <SelectItem key={size.value} value={size.value}>
                  <div className="flex items-center gap-1">
                    <size.icon className="h-3 w-3" />
                    {size.name}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6"
            onClick={() => setIsFullscreen(!isFullscreen)}
          >
            {isFullscreen ? (
              <MinimizeIcon className="h-3 w-3" />
            ) : (
              <MaximizeIcon className="h-3 w-3" />
            )}
          </Button>
        </div>
      </div>
      
      <div className="flex-1 flex items-center justify-center bg-muted/20 p-4 overflow-auto">
        <div 
          className="bg-white border border-border shadow-lg rounded overflow-hidden"
          style={{ 
            width: selectedSize?.width,
            height: selectedSize?.value === 'mobile' ? '667px' : '100%',
            maxHeight: selectedSize?.value === 'mobile' ? '667px' : 'none'
          }}
        >
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <iframe
              ref={iframeRef}
              className="w-full h-full border-0"
              title="Live Preview"
              sandbox="allow-scripts allow-same-origin"
            />
          )}
        </div>
      </div>
    </div>
  )
}