'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Progress } from '@/components/ui/progress'
import { 
  CopyIcon, 
  RefreshIcon, 
  DownloadIcon,
  ZapIcon,
  AlertTriangleIcon,
  CheckCircleIcon,
  ClockIcon,
  DatabaseIcon,
  MonitorIcon,
  GlobeIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface PerformanceMetric {
  name: string
  value: number
  unit: string
  description: string
  status: 'good' | 'warning' | 'poor'
  threshold: { good: number; poor: number }
}

interface PerformanceReport {
  url: string
  timestamp: Date
  metrics: PerformanceMetric[]
  score: number
  grade: 'A' | 'B' | 'C' | 'D' | 'F'
  recommendations: string[]
}

const defaultMetrics: PerformanceMetric[] = [
  {
    name: 'First Contentful Paint',
    value: 0,
    unit: 'ms',
    description: 'Time when the first content is painted on the screen',
    status: 'good',
    threshold: { good: 1800, poor: 3000 }
  },
  {
    name: 'Largest Contentful Paint',
    value: 0,
    unit: 'ms',
    description: 'Time when the largest content element is painted',
    status: 'good',
    threshold: { good: 2500, poor: 4000 }
  },
  {
    name: 'First Input Delay',
    value: 0,
    unit: 'ms',
    description: 'Time from user first interaction to browser response',
    status: 'good',
    threshold: { good: 100, poor: 300 }
  },
  {
    name: 'Cumulative Layout Shift',
    value: 0,
    unit: '',
    description: 'Visual stability of the page',
    status: 'good',
    threshold: { good: 0.1, poor: 0.25 }
  },
  {
    name: 'Time to Interactive',
    value: 0,
    unit: 'ms',
    description: 'Time when page becomes fully interactive',
    status: 'good',
    threshold: { good: 3800, poor: 7300 }
  },
  {
    name: 'Total Blocking Time',
    value: 0,
    unit: 'ms',
    description: 'Total time main thread is blocked',
    status: 'good',
    threshold: { good: 200, poor: 600 }
  }
]

export function PerformanceAnalyzer() {
  const [url, setUrl] = useState('https://example.com')
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [report, setReport] = useState<PerformanceReport | null>(null)
  const [history, setHistory] = useState<PerformanceReport[]>([])

  const simulatePerformanceAnalysis = async (targetUrl: string): Promise<PerformanceReport> => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Generate realistic performance metrics
    const metrics = defaultMetrics.map(metric => ({
      ...metric,
      value: Math.floor(Math.random() * (metric.threshold.poor * 1.2)) + metric.threshold.good * 0.5
    }))

    // Calculate status for each metric
    metrics.forEach(metric => {
      if (metric.value <= metric.threshold.good) {
        metric.status = 'good'
      } else if (metric.value <= metric.threshold.poor) {
        metric.status = 'warning'
      } else {
        metric.status = 'poor'
      }
    })

    // Calculate overall score
    const goodCount = metrics.filter(m => m.status === 'good').length
    const warningCount = metrics.filter(m => m.status === 'warning').length
    const poorCount = metrics.filter(m => m.status === 'poor').length
    
    const score = Math.round((goodCount * 100 + warningCount * 50 + poorCount * 0) / metrics.length)
    
    // Determine grade
    let grade: 'A' | 'B' | 'C' | 'D' | 'F' = 'F'
    if (score >= 90) grade = 'A'
    else if (score >= 80) grade = 'B'
    else if (score >= 70) grade = 'C'
    else if (score >= 60) grade = 'D'

    // Generate recommendations
    const recommendations: string[] = []
    if (poorCount > 0) {
      recommendations.push('Optimize images and reduce file sizes')
      recommendations.push('Minimize JavaScript execution time')
      recommendations.push('Reduce server response time')
    }
    if (warningCount > 0) {
      recommendations.push('Consider lazy loading non-critical resources')
      recommendations.push('Optimize CSS delivery')
    }
    if (goodCount === metrics.length) {
      recommendations.push('Excellent performance! Maintain current optimizations')
    }

    return {
      url: targetUrl,
      timestamp: new Date(),
      metrics,
      score,
      grade,
      recommendations
    }
  }

  const handleAnalyze = async () => {
    if (!url.trim()) return

    setIsAnalyzing(true)
    try {
      const newReport = await simulatePerformanceAnalysis(url)
      setReport(newReport)
      setHistory(prev => [newReport, ...prev.slice(0, 9)]) // Keep last 10 reports
    } catch (error) {
      console.error('Error analyzing performance:', error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const getStatusColor = (status: 'good' | 'warning' | 'poor') => {
    switch (status) {
      case 'good': return 'text-green-600'
      case 'warning': return 'text-yellow-600'
      case 'poor': return 'text-red-600'
    }
  }

  const getStatusIcon = (status: 'good' | 'warning' | 'poor') => {
    switch (status) {
      case 'good': return CheckCircleIcon
      case 'warning': return AlertTriangleIcon
      case 'poor': return AlertTriangleIcon
    }
  }

  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return 'bg-green-500'
      case 'B': return 'bg-blue-500'
      case 'C': return 'bg-yellow-500'
      case 'D': return 'bg-orange-500'
      case 'F': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  return (
    <div className="h-full flex flex-col bg-background">
      <div className="border-b border-border p-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Performance Analyzer</h3>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Enter URL to analyze..."
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-64"
            />
            <Button onClick={handleAnalyze} disabled={isAnalyzing || !url.trim()}>
              <ZapIcon className={cn("h-4 w-4 mr-2", isAnalyzing && "animate-spin")} />
              Analyze
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* History Sidebar */}
        <div className="w-64 border-r border-border flex flex-col">
          <div className="p-3 border-b border-border">
            <h4 className="text-sm font-medium mb-2">Analysis History</h4>
            <ScrollArea className="h-96">
              <div className="space-y-2">
                {history.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    No analysis history yet
                  </p>
                ) : (
                  history.map((item, index) => (
                    <Card 
                      key={index}
                      className={cn(
                        "cursor-pointer hover:shadow-md transition-shadow",
                        report?.url === item.url && "ring-2 ring-primary"
                      )}
                      onClick={() => setReport(item)}
                    >
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <div className={cn(
                            "w-6 h-6 rounded-full text-white text-xs font-bold flex items-center justify-center",
                            getGradeColor(item.grade)
                          )}>
                            {item.grade}
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {item.score}
                          </span>
                        </div>
                        <p className="text-xs font-medium truncate">{item.url}</p>
                        <p className="text-xs text-muted-foreground">
                          {item.timestamp.toLocaleTimeString()}
                        </p>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {report ? (
            <Tabs defaultValue="overview" className="h-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="metrics">Metrics</TabsTrigger>
                <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
                <TabsTrigger value="export">Export</TabsTrigger>
              </TabsList>
              
              <TabsContent value="overview" className="flex-1 p-3">
                <div className="h-full max-w-4xl mx-auto space-y-6">
                  {/* Score Overview */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>Performance Overview</span>
                        <Badge variant="outline">{report.url}</Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-center space-x-8">
                        <div className="text-center">
                          <div className={cn(
                            "w-24 h-24 rounded-full flex items-center justify-center text-white text-3xl font-bold",
                            getGradeColor(report.grade)
                          )}>
                            {report.grade}
                          </div>
                          <p className="text-sm text-muted-foreground mt-2">Grade</p>
                        </div>
                        <div className="text-center">
                          <div className="text-4xl font-bold">{report.score}</div>
                          <p className="text-sm text-muted-foreground">Performance Score</p>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">
                            {report.metrics.filter(m => m.status === 'good').length}
                          </div>
                          <p className="text-sm text-muted-foreground">Good Metrics</p>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-yellow-600">
                            {report.metrics.filter(m => m.status === 'warning').length}
                          </div>
                          <p className="text-sm text-muted-foreground">Warnings</p>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-red-600">
                            {report.metrics.filter(m => m.status === 'poor').length}
                          </div>
                          <p className="text-sm text-muted-foreground">Poor Metrics</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Metric Summary */}
                  <div className="grid grid-cols-2 gap-4">
                    {report.metrics.slice(0, 4).map((metric, index) => {
                      const IconComponent = getStatusIcon(metric.status)
                      return (
                        <Card key={index}>
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <IconComponent className={cn("h-4 w-4", getStatusColor(metric.status))} />
                                <span className="text-sm font-medium">{metric.name}</span>
                              </div>
                              <span className={cn("text-sm font-bold", getStatusColor(metric.status))}>
                                {metric.value}{metric.unit}
                              </span>
                            </div>
                            <Progress 
                              value={Math.min(100, (metric.value / metric.threshold.poor) * 100)} 
                              className="h-2"
                            />
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="metrics" className="flex-1 p-3">
                <ScrollArea className="h-full">
                  <div className="max-w-4xl mx-auto space-y-4">
                    {report.metrics.map((metric, index) => {
                      const IconComponent = getStatusIcon(metric.status)
                      const progress = Math.min(100, (metric.value / metric.threshold.poor) * 100)
                      
                      return (
                        <Card key={index}>
                          <CardHeader>
                            <CardTitle className="flex items-center justify-between text-lg">
                              <div className="flex items-center gap-2">
                                <IconComponent className={cn("h-5 w-5", getStatusColor(metric.status))} />
                                {metric.name}
                              </div>
                              <div className="flex items-center gap-2">
                                <span className={cn("text-xl font-bold", getStatusColor(metric.status))}>
                                  {metric.value}{metric.unit}
                                </span>
                                <Badge variant={metric.status === 'good' ? 'default' : 'secondary'}>
                                  {metric.status}
                                </Badge>
                              </div>
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground mb-3">
                              {metric.description}
                            </p>
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span>Progress</span>
                                <span>{Math.round(progress)}%</span>
                              </div>
                              <Progress value={progress} className="h-3" />
                              <div className="flex justify-between text-xs text-muted-foreground">
                                <span>Good: &lt;{metric.threshold.good}{metric.unit}</span>
                                <span>Poor: &gt;{metric.threshold.poor}{metric.unit}</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )
                    })}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="recommendations" className="flex-1 p-3">
                <div className="h-full max-w-4xl mx-auto">
                  <Card>
                    <CardHeader>
                      <CardTitle>Performance Recommendations</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {report.recommendations.map((recommendation, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                            <CheckCircleIcon className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                            <div>
                              <h4 className="font-medium mb-1">Recommendation {index + 1}</h4>
                              <p className="text-sm text-muted-foreground">{recommendation}</p>
                            </div>
                          </div>
                        ))}
                        
                        <div className="mt-6 p-4 border border-border rounded-lg">
                          <h4 className="font-medium mb-2">General Best Practices</h4>
                          <ul className="text-sm text-muted-foreground space-y-1">
                            <li>• Optimize images and use modern formats like WebP</li>
                            <li>• Minify CSS, JavaScript, and HTML files</li>
                            <li>• Enable compression (gzip/brotli) on your server</li>
                            <li>• Use CDN for static assets</li>
                            <li>• Implement lazy loading for images and non-critical resources</li>
                            <li>• Reduce unused JavaScript and CSS</li>
                            <li>• Optimize font loading</li>
                            <li>• Use efficient caching strategies</li>
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              <TabsContent value="export" className="flex-1 p-3">
                <div className="h-full max-w-4xl mx-auto space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Export Report</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">JSON Format</h4>
                        <div className="bg-muted p-4 rounded-lg">
                          <pre className="text-sm overflow-x-auto">
                            <code>{JSON.stringify({
                              url: report.url,
                              timestamp: report.timestamp.toISOString(),
                              score: report.score,
                              grade: report.grade,
                              metrics: report.metrics,
                              recommendations: report.recommendations
                            }, null, 2)}</code>
                          </pre>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          variant="outline"
                          onClick={() => {
                            const data = JSON.stringify(report, null, 2)
                            navigator.clipboard.writeText(data)
                          }}
                        >
                          <CopyIcon className="h-4 w-4 mr-2" />
                          Copy JSON
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => {
                            const data = JSON.stringify(report, null, 2)
                            const blob = new Blob([data], { type: 'application/json' })
                            const url = URL.createObjectURL(blob)
                            const a = document.createElement('a')
                            a.href = url
                            a.download = `performance-report-${Date.now()}.json`
                            document.body.appendChild(a)
                            a.click()
                            document.body.removeChild(a)
                            URL.revokeObjectURL(url)
                          }}
                        >
                          <DownloadIcon className="h-4 w-4 mr-2" />
                          Download JSON
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MonitorIcon className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">Ready to Analyze Performance</h3>
                <p className="text-muted-foreground mb-4">
                  Enter a URL and click "Analyze" to get a comprehensive performance report
                </p>
                <Button onClick={handleAnalyze} disabled={isAnalyzing || !url.trim()}>
                  <ZapIcon className={cn("h-4 w-4 mr-2", isAnalyzing && "animate-spin")} />
                  Start Analysis
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}