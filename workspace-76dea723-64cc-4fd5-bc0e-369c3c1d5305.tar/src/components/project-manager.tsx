'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  PlusIcon, 
  FolderIcon, 
  SearchIcon, 
  CalendarIcon,
  CodeIcon,
  GlobeIcon,
  MoreVerticalIcon,
  TrashIcon,
  EditIcon,
  ShareIcon
} from 'lucide-react'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'
import { ProjectDialog } from './project-dialog'

interface Project {
  id: string
  name: string
  description?: string
  template?: string
  isPublic: boolean
  createdAt: string
  updatedAt: string
  files: Array<{
    id: string
    name: string
    content: string
    language: string
    path: string
  }>
  author: {
    id: string
    name?: string
    email: string
  }
}

interface ProjectManagerProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onLoadProject: (project: Project) => void
  authorId: string
}

export function ProjectManager({ open, onOpenChange, onLoadProject, authorId }: ProjectManagerProps) {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)

  useEffect(() => {
    if (open && authorId) {
      loadProjects()
    }
  }, [open, authorId])

  const loadProjects = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/projects?authorId=${authorId}`)
      if (response.ok) {
        const data = await response.json()
        setProjects(data)
      }
    } catch (error) {
      console.error('Error loading projects:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreateProject = async (projectData: {
    name: string
    description: string
    template: string
    files: Array<{
      name: string
      content: string
      language: string
      path: string
    }>
  }) => {
    try {
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...projectData,
          authorId
        }),
      })

      if (response.ok) {
        const newProject = await response.json()
        setProjects(prev => [newProject, ...prev])
        onLoadProject(newProject)
      }
    } catch (error) {
      console.error('Error creating project:', error)
    }
  }

  const handleDeleteProject = async (projectId: string) => {
    if (!confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
      return
    }

    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        setProjects(prev => prev.filter(p => p.id !== projectId))
      }
    } catch (error) {
      console.error('Error deleting project:', error)
    }
  }

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getTemplateIcon = (template?: string) => {
    switch (template) {
      case 'react':
      case 'vue':
        return <CodeIcon className="h-4 w-4" />
      case 'html-css-js':
        return <GlobeIcon className="h-4 w-4" />
      default:
        return <FolderIcon className="h-4 w-4" />
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    })
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[800px] max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>My Projects</DialogTitle>
            <DialogDescription>
              Manage your web development projects
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col h-[60vh]">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 flex-1">
                <div className="relative flex-1 max-w-sm">
                  <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search projects..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <Button onClick={() => setShowCreateDialog(true)}>
                <PlusIcon className="h-4 w-4 mr-2" />
                New Project
              </Button>
            </div>

            {/* Projects List */}
            <ScrollArea className="flex-1">
              {loading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : filteredProjects.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
                  <FolderIcon className="h-12 w-12 mb-4" />
                  <p>No projects found</p>
                  <p className="text-sm">Create your first project to get started</p>
                </div>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {filteredProjects.map((project) => (
                    <Card key={project.id} className="cursor-pointer hover:shadow-md transition-shadow">
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-2">
                            {getTemplateIcon(project.template)}
                            <CardTitle className="text-lg">{project.name}</CardTitle>
                          </div>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-6 w-6">
                                <MoreVerticalIcon className="h-3 w-3" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => onLoadProject(project)}>
                                <EditIcon className="h-4 w-4 mr-2" />
                                Open
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <ShareIcon className="h-4 w-4 mr-2" />
                                Share
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => handleDeleteProject(project.id)}
                                className="text-destructive"
                              >
                                <TrashIcon className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                        {project.description && (
                          <CardDescription className="line-clamp-2">
                            {project.description}
                          </CardDescription>
                        )}
                      </CardHeader>
                      
                      <CardContent className="pt-0">
                        <div className="flex items-center justify-between text-sm text-muted-foreground">
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-1">
                              <CalendarIcon className="h-3 w-3" />
                              <span>{formatDate(project.updatedAt)}</span>
                            </div>
                            <Badge variant="secondary" className="text-xs">
                              {project.files.length} files
                            </Badge>
                          </div>
                          
                          {project.template && (
                            <Badge variant="outline" className="text-xs">
                              {project.template}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="mt-3">
                          <Button 
                            size="sm" 
                            className="w-full"
                            onClick={() => onLoadProject(project)}
                          >
                            Open Project
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      <ProjectDialog
        open={showCreateDialog}
        onOpenChange={setShowCreateDialog}
        onCreateProject={handleCreateProject}
      />
    </>
  )
}