'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { 
  FileIcon, 
  FolderIcon, 
  SettingsIcon, 
  GitBranchIcon, 
  PlayIcon, 
  SaveIcon,
  PlusIcon,
  SearchIcon,
  UserIcon,
  DatabaseIcon,
  PaletteIcon,
  ZapIcon,
  BarChartIcon,
  LayoutIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

const sidebarItems = [
  { icon: FileIcon, label: 'Explorer', id: 'explorer' },
  { icon: SearchIcon, label: 'Search', id: 'search' },
  { icon: DatabaseIcon, label: 'API Tester', id: 'api' },
  { icon: PaletteIcon, label: 'CSS Tools', id: 'css' },
  { icon: PaletteIcon, label: 'Colors', id: 'colors' },
  { icon: LayoutIcon, label: 'Components', id: 'components' },
  { icon: ZapIcon, label: 'Terminal', id: 'terminal' },
  { icon: BarChartIcon, label: 'Performance', id: 'performance' },
  { icon: GitBranchIcon, label: 'Git', id: 'git' },
  { icon: SettingsIcon, label: 'Settings', id: 'settings' }
]

interface SidebarProps {
  onToolSelect: (toolId: string) => void
}

export function Sidebar({ onToolSelect }: SidebarProps) {
  const [activeItem, setActiveItem] = useState('explorer')
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <div className={cn(
      "w-16 bg-muted border-r border-border flex flex-col transition-all duration-200",
      isCollapsed ? "w-12" : "w-16"
    )}>
      <div className="p-2">
        <Button
          variant="ghost"
          size="icon"
          className="w-full h-8"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <div className="w-4 h-4 bg-primary rounded-sm" />
        </Button>
      </div>
      
      <Separator />
      
      <div className="flex-1 p-2 space-y-1">
        {sidebarItems.map((item) => (
          <Button
            key={item.id}
            variant={activeItem === item.id ? "secondary" : "ghost"}
            size="icon"
            className="w-full h-8"
            onClick={() => {
              setActiveItem(item.id)
              onToolSelect(item.id)
            }}
          >
            <item.icon className="h-4 w-4" />
          </Button>
        ))}
      </div>
      
      <Separator />
      
      <div className="p-2 space-y-1">
        <Button variant="ghost" size="icon" className="w-full h-8">
          <PlusIcon className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="w-full h-8">
          <SaveIcon className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="p-2">
        <Button variant="ghost" size="icon" className="w-full h-8">
          <UserIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}