'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  CheckCircleIcon, 
  AlertCircleIcon, 
  GitBranchIcon, 
  GlobeIcon,
  TerminalIcon,
  BugIcon,
  CoffeeIcon
} from 'lucide-react'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'

interface File {
  id: string
  name: string
  content: string
  language: string
  path: string
  projectId: string
}

interface StatusBarProps {
  files: File[]
  activeFile?: File | null
}

export function StatusBar({ files, activeFile }: StatusBarProps) {
  const [branch, setBranch] = useState('main')
  const [language, setLanguage] = useState('JavaScript')
  const [encoding, setEncoding] = useState('UTF-8')
  const [lineEnding, setLineEnding] = useState('LF')
  const [indentSize, setIndentSize] = useState('2')

  // Update language when active file changes
  useEffect(() => {
    if (activeFile) {
      setLanguage(activeFile.language)
    }
  }, [activeFile])

  const getCursorPosition = () => {
    if (!activeFile) return { line: 1, column: 1 }
    
    const lines = activeFile.content.split('\n')
    // For simplicity, just show total lines and column 1
    // In a real editor, this would track actual cursor position
    return { line: lines.length, column: 1 }
  }

  const cursorPosition = getCursorPosition()

  const statusItems = [
    { icon: CheckCircleIcon, text: 'Ready', color: 'text-green-500' },
    { icon: GitBranchIcon, text: branch, color: 'text-blue-500' },
    { icon: GlobeIcon, text: 'No problems', color: 'text-gray-500' },
    { icon: TerminalIcon, text: 'Terminal', color: 'text-gray-500' },
    { icon: BugIcon, text: 'Debug', color: 'text-gray-500' },
    { icon: CoffeeIcon, text: 'UTF-8', color: 'text-gray-500' }
  ]

  return (
    <div className="h-6 border-t border-border bg-muted flex items-center px-4 text-xs text-muted-foreground">
      <div className="flex items-center gap-4 flex-1">
        {/* Ready Status */}
        <div className="flex items-center gap-1">
          <CheckCircleIcon className="h-3 w-3 text-green-500" />
          <span>Ready</span>
        </div>

        {/* Branch Selector */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-4 px-1 text-xs hover:bg-transparent">
              <GitBranchIcon className="h-3 w-3 mr-1" />
              {branch}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setBranch('main')}>
              main
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setBranch('develop')}>
              develop
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setBranch('feature/new-feature')}>
              feature/new-feature
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Problems */}
        <div className="flex items-center gap-1">
          <AlertCircleIcon className="h-3 w-3 text-yellow-500" />
          <span>0 errors, 0 warnings</span>
        </div>

        {/* Language Mode */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-4 px-1 text-xs hover:bg-transparent">
              {language}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setLanguage('JavaScript')}>
              JavaScript
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLanguage('TypeScript')}>
              TypeScript
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLanguage('HTML')}>
              HTML
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLanguage('CSS')}>
              CSS
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLanguage('JSON')}>
              JSON
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Encoding */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-4 px-1 text-xs hover:bg-transparent">
              {encoding}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setEncoding('UTF-8')}>
              UTF-8
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setEncoding('UTF-16 LE')}>
              UTF-16 LE
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setEncoding('UTF-16 BE')}>
              UTF-16 BE
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Line Ending */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-4 px-1 text-xs hover:bg-transparent">
              {lineEnding}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setLineEnding('LF')}>
              LF
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setLineEnding('CRLF')}>
              CRLF
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Indent Size */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-4 px-1 text-xs hover:bg-transparent">
              Spaces: {indentSize}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={() => setIndentSize('2')}>
              Spaces: 2
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setIndentSize('4')}>
              Spaces: 4
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setIndentSize('8')}>
              Spaces: 8
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Right side items */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1">
          <GlobeIcon className="h-3 w-3" />
          <span>Ln {cursorPosition.line}, Col {cursorPosition.column}</span>
        </div>
        
        <div className="flex items-center gap-1">
          <span>Spaces: {indentSize}</span>
        </div>
        
        <div className="flex items-center gap-1">
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  )
}