'use client'

import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { 
  ChevronUpIcon, 
  ChevronDownIcon, 
  MaximizeIcon,
  MinimizeIcon,
  TrashIcon,
  CopyIcon
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface TerminalOutput {
  id: string
  content: string
  type: 'command' | 'output' | 'error'
  timestamp: Date
}

export function Terminal() {
  const [isOpen, setIsOpen] = useState(true)
  const [isMaximized, setIsMaximized] = useState(false)
  const [input, setInput] = useState('')
  const [outputs, setOutputs] = useState<TerminalOutput[]>([
    {
      id: '1',
      content: 'Welcome to Web Dev Terminal!',
      type: 'output',
      timestamp: new Date()
    },
    {
      id: '2',
      content: 'Type "help" for available commands.',
      type: 'output',
      timestamp: new Date()
    }
  ])
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }

  useEffect(() => {
    scrollToBottom()
  }, [outputs])

  const executeCommand = (command: string) => {
    if (!command.trim()) return

    const commandOutput: TerminalOutput = {
      id: Date.now().toString(),
      content: `$ ${command}`,
      type: 'command',
      timestamp: new Date()
    }

    setOutputs(prev => [...prev, commandOutput])
    setHistory(prev => [...prev, command])
    setHistoryIndex(-1)

    // Simulate command execution
    setTimeout(() => {
      let response: TerminalOutput
      const cmd = command.toLowerCase().trim()

      switch (cmd) {
        case 'help':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Available commands:
  help     - Show this help message
  clear    - Clear terminal
  date     - Show current date and time
  echo     - Echo text back
  ls       - List files
  pwd      - Show current directory
  
  Development Tools:
  npm      - npm package manager commands
  git      - git version control commands
  node     - Node.js information
  next     - Next.js framework commands
  vue      - Vue.js framework commands
  angular  - Angular framework commands
  docker   - Docker container commands
  curl     - curl HTTP client examples
  ssh      - SSH connection commands
  python   - Python development commands
  code     - VS Code editor commands
  
  Framework Setup:
  create-react-app  - React app setup
  cra              - React app setup (alias)`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'clear':
          setOutputs([])
          return
        case 'date':
          response = {
            id: (Date.now() + 1).toString(),
            content: new Date().toString(),
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'pwd':
          response = {
            id: (Date.now() + 1).toString(),
            content: '/home/user/my-project',
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'ls':
          response = {
            id: (Date.now() + 1).toString(),
            content: `index.html  styles.css  script.js  package.json  README.md`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'node':
          response = {
            id: (Date.now() + 1).toString(),
            content: 'Node.js REPL not available in browser. Use browser console instead.',
            type: 'error',
            timestamp: new Date()
          }
          break
        case 'npm':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Available npm commands:
  npm init          - Initialize a new package.json
  npm install       - Install dependencies
  npm start         - Start the application
  npm test          - Run tests
  npm build         - Build the application
  npm run dev       - Start development server`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'git':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Available git commands:
  git init          - Initialize repository
  git status        - Check status
  git add .         - Add all files
  git commit -m "msg" - Commit changes
  git push          - Push to remote
  git pull          - Pull from remote
  git log           - View commit history`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'create-react-app':
        case 'cra':
          response = {
            id: (Date.now() + 1).toString(),
            content: `npx create-react-app my-app
cd my-app
npm start`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'next':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Next.js commands:
  npx create-next-app my-app
  cd my-app
  npm run dev     # Development server
  npm run build   # Production build
  npm start       # Production server
  npm run lint    # Run ESLint`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'vue':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Vue.js commands:
  npm create vue@latest my-project
  cd my-project
  npm install
  npm run dev     # Development server
  npm run build   # Production build`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'angular':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Angular commands:
  npm install -g @angular/cli
  ng new my-app
  cd my-app
  ng serve        # Development server
  ng build        # Production build
  ng test         # Run tests`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'docker':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Docker commands:
  docker build -t my-app .    # Build image
  docker run -p 3000:3000 my-app  # Run container
  docker ps                   # List containers
  docker images               # List images
  docker stop <container-id>   # Stop container
  docker rm <container-id>    # Remove container`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'curl':
          response = {
            id: (Date.now() + 1).toString(),
            content: `curl examples:
  curl https://api.example.com/users           # GET request
  curl -X POST https://api.example.com/users   # POST request
  curl -H "Content-Type: application/json" -d '{"name":"John"}' https://api.example.com/users
  curl -I https://api.example.com/users        # Headers only
  curl -v https://api.example.com/users        # Verbose output`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'ssh':
          response = {
            id: (Date.now() + 1).toString(),
            content: `SSH commands:
  ssh user@hostname                    # Basic SSH
  ssh -i key.pem user@hostname        # SSH with key
  ssh -p 2222 user@hostname           # SSH with port
  scp file.txt user@hostname:/path    # Copy file via SSH
  ssh-keygen -t rsa -b 4096           # Generate SSH key`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'python':
        case 'python3':
          response = {
            id: (Date.now() + 1).toString(),
            content: `Python commands:
  python script.py                   # Run script
  python -m venv venv                 # Create virtual environment
  source venv/bin/activate            # Activate venv (Linux/Mac)
  venv\\Scripts\\activate              # Activate venv (Windows)
  pip install package-name            # Install package
  pip freeze                          # List installed packages`,
            type: 'output',
            timestamp: new Date()
          }
          break
        case 'code':
          response = {
            id: (Date.now() + 1).toString(),
            content: `VS Code commands:
  code .                              # Open current directory
  code file.txt                       # Open specific file
  code --new-window                   # New window
  code --install-extension ms-python.python  # Install extension`,
            type: 'output',
            timestamp: new Date()
          }
          break
        default:
          if (cmd.startsWith('echo ')) {
            response = {
              id: (Date.now() + 1).toString(),
              content: command.slice(5),
              type: 'output',
              timestamp: new Date()
            }
          } else {
            response = {
              id: (Date.now() + 1).toString(),
              content: `Command not found: ${command}. Type 'help' for available commands.`,
              type: 'error',
              timestamp: new Date()
            }
          }
      }

      setOutputs(prev => [...prev, response])
    }, 100)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    executeCommand(input)
    setInput('')
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (history.length > 0) {
        const newIndex = historyIndex < history.length - 1 ? historyIndex + 1 : historyIndex
        setHistoryIndex(newIndex)
        setInput(history[history.length - 1 - newIndex])
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setInput(history[history.length - 1 - newIndex])
      } else if (historyIndex === 0) {
        setHistoryIndex(-1)
        setInput('')
      }
    }
  }

  const clearTerminal = () => {
    setOutputs([])
  }

  const copyOutput = () => {
    const text = outputs.map(output => output.content).join('\n')
    navigator.clipboard.writeText(text)
  }

  const terminalHeight = isMaximized ? 'h-96' : 'h-48'

  return (
    <div className={cn(
      "border-t border-border bg-muted flex flex-col transition-all duration-200",
      isOpen ? terminalHeight : "h-8"
    )}>
      <div className="flex items-center justify-between p-2 border-b border-border">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-5 w-5"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <ChevronDownIcon className="h-3 w-3" /> : <ChevronUpIcon className="h-3 w-3" />}
          </Button>
          <span className="text-xs font-medium">TERMINAL</span>
        </div>
        
        {isOpen && (
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5"
              onClick={clearTerminal}
            >
              <TrashIcon className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5"
              onClick={copyOutput}
            >
              <CopyIcon className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-5 w-5"
              onClick={() => setIsMaximized(!isMaximized)}
            >
              {isMaximized ? <MinimizeIcon className="h-3 w-3" /> : <MaximizeIcon className="h-3 w-3" />}
            </Button>
          </div>
        )}
      </div>
      
      {isOpen && (
        <div className="flex-1 flex flex-col">
          <ScrollArea className="flex-1 p-2" ref={scrollRef}>
            <div className="space-y-1 font-mono text-xs">
              {outputs.map((output) => (
                <div
                  key={output.id}
                  className={cn(
                    "whitespace-pre-wrap break-words",
                    output.type === 'command' && "text-primary",
                    output.type === 'error' && "text-destructive",
                    output.type === 'output' && "text-foreground"
                  )}
                >
                  {output.content}
                </div>
              ))}
            </div>
          </ScrollArea>
          
          <form onSubmit={handleSubmit} className="p-2 border-t border-border">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-primary">$</span>
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-background border border-border rounded px-2 py-1 text-xs font-mono focus:outline-none focus:ring-1 focus:ring-primary"
                placeholder="Type a command..."
                autoFocus
              />
            </div>
          </form>
        </div>
      )}
    </div>
  )
}