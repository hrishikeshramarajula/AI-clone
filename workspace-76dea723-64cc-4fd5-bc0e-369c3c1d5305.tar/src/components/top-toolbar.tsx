'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  FileIcon, 
  FolderIcon, 
  SaveIcon, 
  PlayIcon, 
  SettingsIcon,
  GitBranchIcon,
  ShareIcon,
  PlusIcon,
  SearchIcon,
  UserIcon,
  BellIcon
} from 'lucide-react'
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu'

interface TopToolbarProps {
  onOpenProjectManager: () => void
}

export function TopToolbar({ onOpenProjectManager }: TopToolbarProps) {
  const [projectName, setProjectName] = useState('my-project')

  return (
    <div className="h-10 border-b border-border bg-background flex items-center px-4 gap-4">
      {/* Project Name */}
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <FolderIcon className="h-4 w-4 text-muted-foreground" />
        <Input
          value={projectName}
          onChange={(e) => setProjectName(e.target.value)}
          className="h-6 text-sm bg-transparent border-none p-0 focus-visible:ring-0"
        />
        <Button
          variant="ghost"
          size="sm"
          className="h-6 px-2 text-xs"
          onClick={onOpenProjectManager}
        >
          Projects
        </Button>
      </div>

      {/* File Operations */}
      <div className="flex items-center gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2">
              <FileIcon className="h-4 w-4 mr-1" />
              File
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>
              <PlusIcon className="h-4 w-4 mr-2" />
              New File
            </DropdownMenuItem>
            <DropdownMenuItem>
              <FolderIcon className="h-4 w-4 mr-2" />
              New Folder
            </DropdownMenuItem>
            <DropdownMenuItem>
              <FileIcon className="h-4 w-4 mr-2" />
              Open File
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <SaveIcon className="h-4 w-4 mr-2" />
              Save
            </DropdownMenuItem>
            <DropdownMenuItem>
              <SaveIcon className="h-4 w-4 mr-2" />
              Save As...
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <SettingsIcon className="h-4 w-4 mr-2" />
              Settings
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 px-2">
              <PlusIcon className="h-4 w-4 mr-1" />
              New
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>
              <FileIcon className="h-4 w-4 mr-2" />
              New Project
            </DropdownMenuItem>
            <DropdownMenuItem>
              <FileIcon className="h-4 w-4 mr-2" />
              New File
            </DropdownMenuItem>
            <DropdownMenuItem>
              <FolderIcon className="h-4 w-4 mr-2" />
              New Folder
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <FileIcon className="h-4 w-4 mr-2" />
              From Template
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Run/Build Actions */}
      <div className="flex items-center gap-1">
        <Select defaultValue="development">
          <SelectTrigger className="w-32 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="development">Development</SelectItem>
            <SelectItem value="production">Production</SelectItem>
            <SelectItem value="test">Test</SelectItem>
          </SelectContent>
        </Select>
        
        <Button variant="default" size="sm" className="h-8 px-3">
          <PlayIcon className="h-4 w-4 mr-1" />
          Run
        </Button>
        
        <Button variant="outline" size="sm" className="h-8 px-3">
          Build
        </Button>
      </div>

      {/* Version Control */}
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <GitBranchIcon className="h-4 w-4" />
        </Button>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <SaveIcon className="h-4 w-4" />
        </Button>
        
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <ShareIcon className="h-4 w-4" />
        </Button>
        
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <SearchIcon className="h-4 w-4" />
        </Button>
      </div>

      {/* User Actions */}
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <BellIcon className="h-4 w-4" />
        </Button>
        
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <SettingsIcon className="h-4 w-4" />
        </Button>
        
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <UserIcon className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}