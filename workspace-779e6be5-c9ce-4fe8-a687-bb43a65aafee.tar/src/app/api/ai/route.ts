import { NextRequest, NextResponse } from 'next/server';
import { aiEngine } from '../../../lib/ai-engine';
import { AIResponse } from '../../../lib/types';

export async function GET() {
  try {
    const healthStatus = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        'z-ai-engine': 'configured',
        openai: !!process.env.OPENAI_API_KEY,
        openrouter: !!process.env.OPENROUTER_API_KEY,
        huggingface: !!process.env.HUGGINGFACE_API_KEY,
        ollama: !!process.env.OLLAMA_API_KEY
      },
      region: 'India',
      version: '2.0.0',
      engine: 'Z-AI Web Dev SDK'
    };
    
    return NextResponse.json({ health: healthStatus });
  } catch (error) {
    return NextResponse.json({ 
      health: { status: 'error', error: 'Health check failed' } 
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { message, model, searchType = 'chat' } = await request.json();
    
    if (!message?.trim()) {
      return NextResponse.json({
        success: false,
        error: 'Message is required and cannot be empty'
      }, { status: 400 });
    }
    
    console.log(`🚀 AI Request: "${message.substring(0, 50)}..." | Model: ${model} | Type: ${searchType}`);
    
    let response: AIResponse;
    
    // Handle different request types
    if (searchType === 'image') {
      response = await aiEngine.generateImage(message, model);
    } else if (searchType === 'search') {
      const searchResult = await aiEngine.performSearch(message);
      response = {
        success: true,
        response: searchResult.response + `\n\n---\n*✅ Powered by Z-AI Search Engine | Model: ${model} | Generated at ${new Date().toLocaleTimeString('en-IN', { timeZone: 'Asia/Kolkata' })} IST*`,
        searchResults: searchResult.searchResults,
        model: model,
        provider: 'Z-AI Search Engine'
      };
    } else {
      response = await aiEngine.generateResponse(message, searchType, model);
    }
    
    console.log(`✅ AI Response Generated: ${response.success ? 'Success' : 'Failed'} | Provider: ${response.provider}`);
    
    return NextResponse.json(response);
    
  } catch (error: any) {
    console.error('❌ AI API Error:', error);
    
    const errorResponse: AIResponse = {
      success: false,
      error: error.message || 'Unknown error occurred',
      response: `🔧 **Technical Issue Detected**

**Error**: ${error.message || 'Unknown error occurred'}

**🇮🇳 AI Agent Status**: 
• ✅ Z-AI Engine is operational
• ⚠️ Temporary service interruption detected
• 🔄 System will auto-recover

**🛠️ Immediate Solutions**:
1. **Try Again**: This is usually a temporary issue
2. **Refresh Page**: Reload the application
3. **Clear Browser Cache**: Remove old data
4. **Check Internet**: Ensure stable connection

**📞 Engine Status**: The Z-AI Engine is designed to be self-healing. Most issues resolve automatically within seconds.

**🕒 Timestamp**: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST`,
      model: 'Error Handler',
      provider: 'Z-AI Engine (Recovery Mode)'
    };
    
    return NextResponse.json(errorResponse, { status: 500 });
  }
}