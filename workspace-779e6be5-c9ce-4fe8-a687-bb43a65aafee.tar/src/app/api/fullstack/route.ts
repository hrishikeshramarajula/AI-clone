import { NextRequest, NextResponse } from 'next/server';
import { aiEngine } from '../../../lib/ai-engine';
import { FullStackProject } from '../../../lib/types';

export async function POST(request: NextRequest) {
  try {
    const { prompt, model, files } = await request.json();
    
    if (!prompt?.trim()) {
      return NextResponse.json({
        success: false,
        error: 'Project description is required'
      }, { status: 400 });
    }
    
    console.log(`🚀 Full-stack generation request: ${prompt.substring(0, 50)}...`);
    
    // Generate full-stack project using Z-AI Engine
    const project = await aiEngine.generateFullStackProject(prompt, files);
    
    console.log('✅ Full-stack project generated successfully');
    
    return NextResponse.json({
      success: true,
      project,
      model,
      generatedAt: new Date().toISOString()
    });
    
  } catch (error: any) {
    console.error('❌ Full-stack generation error:', error);
    return NextResponse.json({
      success: false,
      error: error.message || 'Full-stack generation failed',
      suggestion: 'The Z-AI Engine is designed to handle full-stack generation. Please try again or simplify your project description.'
    }, { status: 500 });
  }
}