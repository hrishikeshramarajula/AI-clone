import { NextRequest, NextResponse } from 'next/server';

interface HealthResponse {
  status: 'healthy' | 'unhealthy' | 'initializing';
  timestamp: string;
  services: {
    ai: 'available' | 'unavailable';
    image: 'available' | 'unavailable';
    fullstack: 'available' | 'unavailable';
    search: 'available' | 'unavailable';
  };
  message?: string;
  sdk_version?: string;
  config?: any;
}

export async function GET(request: NextRequest) {
  try {
    const healthResponse: HealthResponse = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        ai: 'unavailable',
        image: 'unavailable',
        fullstack: 'unavailable',
        search: 'unavailable'
      }
    };

    // Check if ZAI SDK is available and working
    try {
      const ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK is available');
      
      // Get SDK version if available
      if (ZAI.version) {
        healthResponse.sdk_version = ZAI.version;
      }
      
      // Try to create an instance to test functionality
      let zai;
      let config = null;
      
      try {
        const ZAIDefault = ZAI.default;
        if (typeof ZAIDefault.create === 'function') {
          zai = await ZAIDefault.create();
          console.log('ZAI instance created successfully via static create');
          config = zai.config;
        } else {
          throw new Error('ZAI.create not available');
        }
      } catch (createError) {
        console.log('ZAI.create failed, trying manual instantiation:', createError.message);
        
        // Try manual instantiation approach
        const ZAIDefault = ZAI.default;
        try {
          zai = new ZAIDefault({
            baseUrl: 'http://172.25.136.193:8080/v1',
            apiKey: 'Z.ai'
          });
          config = zai.config;
          console.log('ZAI instance created via manual instantiation');
        } catch (manualError) {
          throw new Error(`Both ZAI.create and manual instantiation failed: ${manualError.message}`);
        }
      }
      
      // Store config for debugging
      if (config) {
        healthResponse.config = {
          baseUrl: config.baseUrl,
          hasApiKey: !!config.apiKey,
          hasChatId: !!config.chatId,
          hasUserId: !!config.userId
        };
      }
      
      // Test AI chat functionality
      if (zai && typeof zai.chat?.completions?.create === 'function') {
        healthResponse.services.ai = 'available';
        console.log('AI chat functionality available');
        
        // Test with a simple request
        try {
          await zai.chat.completions.create({
            messages: [{ role: 'user', content: 'test' }],
            max_tokens: 1
          });
          console.log('AI chat functionality test successful');
        } catch (testError) {
          console.log('AI chat functionality test failed:', testError.message);
          healthResponse.services.ai = 'unavailable';
        }
      } else {
        console.log('AI chat functionality not available');
      }
      
      // Test image generation functionality
      if (zai && typeof zai.images?.generations?.create === 'function') {
        healthResponse.services.image = 'available';
        console.log('Image generation functionality available');
      } else {
        console.log('Image generation functionality not available');
      }
      
      // Test fullstack generation functionality (uses chat, so available if chat is available)
      if (healthResponse.services.ai === 'available') {
        healthResponse.services.fullstack = 'available';
        console.log('Fullstack generation functionality available');
      } else {
        console.log('Fullstack generation functionality not available');
      }
      
      // Test search functionality
      if (zai && typeof zai.functions?.invoke === 'function') {
        healthResponse.services.search = 'available';
        console.log('Search functionality available');
        
        // Test with a simple request
        try {
          await zai.functions.invoke("web_search", {
            query: "test",
            num: 1
          });
          console.log('Search functionality test successful');
        } catch (testError) {
          console.log('Search functionality test failed:', testError.message);
          healthResponse.services.search = 'unavailable';
        }
      } else {
        console.log('Search functionality not available');
      }
      
      // Overall health status
      if (healthResponse.services.ai === 'available') {
        healthResponse.status = 'healthy';
        healthResponse.message = 'ZAI SDK is operational and all core services are available';
      } else {
        healthResponse.status = 'unhealthy';
        healthResponse.message = 'Core AI functionality not available';
      }
      
    } catch (error) {
      console.error('ZAI SDK not available or failed to initialize:', error);
      healthResponse.services.ai = 'unavailable';
      healthResponse.services.image = 'unavailable';
      healthResponse.services.fullstack = 'unavailable';
      healthResponse.services.search = 'unavailable';
      healthResponse.status = 'unhealthy';
      healthResponse.message = 'ZAI SDK not available or failed to initialize';
    }

    return NextResponse.json(healthResponse);
  } catch (error) {
    console.error('Health check error:', error);
    return NextResponse.json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      services: {
        ai: 'unavailable',
        image: 'unavailable',
        fullstack: 'unavailable',
        search: 'unavailable'
      },
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}