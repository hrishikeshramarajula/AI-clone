import { NextRequest, NextResponse } from 'next/server';

interface ImageRequest {
  prompt: string;
  model: string;
  size?: string;
}

interface ImageResponse {
  imageData: string;
  prompt: string;
  model: string;
  timestamp: string;
}

async function generateImageWithZAI(prompt: string, model: string, size: string = '1024x1024'): Promise<string> {
  console.log('Generating image with ZAI SDK:', prompt, 'model:', model, 'size:', size);

  try {
    // Import the ZAI SDK
    const ZAI = await import('z-ai-web-dev-sdk');
    const ZAIDefault = ZAI.default;
    
    // Create ZAI instance
    let zai;
    try {
      if (typeof ZAIDefault.create === 'function') {
        zai = await ZAIDefault.create();
        console.log('ZAI instance created successfully for image generation');
        console.log('ZAI config:', zai.config);
      } else {
        throw new Error('ZAI.create not available');
      }
    } catch (createError) {
      console.log('ZAI.create failed, trying manual instantiation:', createError.message);
      
      // Try manual instantiation with default config
      try {
        zai = new ZAIDefault({
          baseUrl: 'http://172.25.136.193:8080/v1',
          apiKey: 'Z.ai'
        });
        console.log('ZAI instance created via manual instantiation for image generation');
      } catch (manualError) {
        throw new Error(`Both ZAI.create and manual instantiation failed: ${manualError.message}`);
      }
    }
    
    // Call the image generation
    let imageResponse;
    try {
      if (zai && typeof zai.images?.generations?.create === 'function') {
        imageResponse = await zai.images.generations.create({
          prompt: prompt,
          size: size
        });
        console.log('Image generation successful');
      } else {
        throw new Error('images.generations.create not available');
      }
    } catch (imageError) {
      console.log('Image generation failed:', imageError.message);
      throw imageError;
    }
    
    // Extract image data from response
    let imageData = '';
    if (imageResponse && imageResponse.data && Array.isArray(imageResponse.data)) {
      imageData = imageResponse[0]?.base64 || imageResponse[0]?.url || '';
    } else if (imageResponse && imageResponse.base64) {
      imageData = imageResponse.base64;
    } else if (imageResponse && imageResponse.url) {
      // If URL is returned, we need to fetch it
      const response = await fetch(imageResponse.url);
      const blob = await response.blob();
      imageData = await blobToBase64(blob);
    }
    
    if (!imageData) {
      throw new Error('No image data received');
    }
    
    return imageData;
  } catch (error) {
    console.error('ZAI Image Generation Error:', error);
    throw new Error(`ZAI image generation failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

// Helper function to convert blob to base64
async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1]; // Remove data:image/...;base64, prefix
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

export async function POST(request: NextRequest) {
  try {
    const body: ImageRequest = await request.json();
    const { prompt, model, size = '1024x1024' } = body;

    if (!prompt || !model) {
      return NextResponse.json(
        { error: 'Prompt and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing image generation request:', { prompt, model, size });

    // Try to generate the image with ZAI
    let imageData;
    let success = false;
    let errorMessage = '';

    try {
      imageData = await generateImageWithZAI(prompt, model, size);
      success = true;
    } catch (error) {
      console.error('Image generation failed:', error);
      errorMessage = error instanceof Error ? error.message : 'Unknown error';
      success = false;
    }

    if (success && imageData) {
      const imageResponse: ImageResponse = {
        imageData,
        prompt,
        model,
        timestamp: new Date().toISOString()
      };

      return NextResponse.json(imageResponse);
    } else {
      // Return a helpful response even when image generation fails
      return NextResponse.json(
        { 
          success: false,
          error: 'Image generation temporarily unavailable',
          details: errorMessage,
          prompt,
          fallbackMessage: `I understand you wanted to generate an image of: "${prompt}"

Unfortunately, I'm currently experiencing technical difficulties with image generation services. This could be due to:

• **High demand** on AI image generation services
• **Temporary maintenance** on AI servers  
• **API rate limits** or credential issues
• **Network connectivity** problems

**What you can do:**
• **Try again in a few minutes** - services often restore quickly
• **Use a different, more specific prompt** - simpler descriptions work better
• **Try different image models** - some may be more available than others
• **Check back later** - our team is working to restore full service

**Alternative suggestions:**
• I can help you create a detailed text description of what the image would look like
• I can suggest art styles and techniques for your concept
• I can help you write prompts for other image generation tools

The issue has been logged and our technical team is working to restore full image generation capabilities.`
        },
        { status: 200 } // Return 200 with helpful message instead of 500 error
      );
    }
  } catch (error) {
    console.error('Image generation error:', error);
    
    return NextResponse.json(
      { 
        success: false,
        error: 'Image generation service temporarily unavailable',
        details: error instanceof Error ? error.message : 'Unknown error',
        suggestion: `I apologize, but I'm experiencing technical difficulties with image generation. 

**Immediate solutions:**
• Try again in a few moments
• Use a simpler, more descriptive prompt
• Select a different image model from the available options

Our team is working to restore full service.`
      },
      { status: 200 } // Return 200 with helpful message
    );
  }
}