import { NextRequest, NextResponse } from 'next/server';
import { Task } from '../../../lib/types';

// In-memory storage (replace with database in production)
let tasks: Task[] = [];

export async function GET() {
  try {
    const activeTasks = tasks.filter(task => task.status === 'needs-review');
    
    return NextResponse.json({
      success: true,
      tasks: activeTasks,
      count: activeTasks.length,
      total: tasks.length
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch tasks'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const { content, status = 'needs-review' } = await request.json();
    
    if (!content?.trim()) {
      return NextResponse.json({
        success: false,
        error: 'Task content is required'
      }, { status: 400 });
    }
    
    const newTask: Task = {
      id: Date.now().toString(),
      content: content.trim(),
      status,
      timestamp: new Date().toISOString()
    };
    
    tasks.push(newTask);
    
    return NextResponse.json({
      success: true,
      task: newTask,
      message: 'Task created successfully'
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Failed to create task'
    }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const { id, status, content } = await request.json();
    
    const taskIndex = tasks.findIndex(task => task.id === id);
    
    if (taskIndex === -1) {
      return NextResponse.json({
        success: false,
        error: 'Task not found'
      }, { status: 404 });
    }
    
    if (status) tasks[taskIndex].status = status;
    if (content) tasks[taskIndex].content = content;
    
    return NextResponse.json({
      success: true,
      task: tasks[taskIndex],
      message: 'Task updated successfully'
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Failed to update task'
    }, { status: 500 });
  }
}