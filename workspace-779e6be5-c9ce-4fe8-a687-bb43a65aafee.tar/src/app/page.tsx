'use client';

import { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  Code, 
  Database, 
  Globe, 
  Settings, 
  Sparkles, 
  Loader2,
  Terminal,
  FileText,
  Zap,
  Shield,
  BarChart3,
  MessageSquare,
  Palette,
  Smartphone
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';

interface AgentMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  status?: 'processing' | 'completed' | 'error';
}

interface FeatureCard {
  title: string;
  description: string;
  icon: React.ReactNode;
  badge?: string;
}

const features: FeatureCard[] = [
  {
    title: 'AI-Powered Development',
    description: 'Generate complete fullstack applications with intelligent code generation and optimization',
    icon: <Bot className="w-8 h-8 text-blue-600" />,
    badge: 'Core'
  },
  {
    title: 'Smart Code Generation',
    description: 'Create production-ready code with proper TypeScript typing, error handling, and best practices',
    icon: <Code className="w-8 h-8 text-green-600" />,
    badge: 'AI'
  },
  {
    title: 'Database Integration',
    description: 'Automatically design and implement database schemas with Prisma ORM and SQLite',
    icon: <Database className="w-8 h-8 text-purple-600" />,
    badge: 'Auto'
  },
  {
    title: 'Real-time Communication',
    description: 'WebSocket support for live updates and real-time development feedback',
    icon: <MessageSquare className="w-8 h-8 text-orange-600" />,
    badge: 'Live'
  },
  {
    title: 'Modern UI Components',
    description: 'Beautiful, responsive interfaces built with shadcn/ui and Tailwind CSS',
    icon: <Palette className="w-8 h-8 text-pink-600" />,
    badge: 'UI/UX'
  },
  {
    title: 'Multi-Model Support',
    description: 'Integration with GPT-4, GLM-4.5, Claude 3, and other leading AI models',
    icon: <Sparkles className="w-8 h-8 text-yellow-600" />,
    badge: 'AI'
  },
  {
    title: 'Error Recovery',
    description: 'Intelligent error handling with automatic recovery and fallback mechanisms',
    icon: <Shield className="w-8 h-8 text-red-600" />,
    badge: 'Smart'
  },
  {
    title: 'Performance Optimized',
    description: 'Built for speed with efficient code generation and optimization',
    icon: <Zap className="w-8 h-8 text-indigo-600" />,
    badge: 'Fast'
  },
  {
    title: 'Cross-Platform',
    description: 'Responsive design that works seamlessly on desktop, tablet, and mobile',
    icon: <Smartphone className="w-8 h-8 text-teal-600" />,
    badge: 'Mobile'
  }
];

const examplePrompts = [
  "Create a todo app with user authentication",
  "Build a blog platform with markdown support",
  "Design an e-commerce site with payment integration",
  "Create a real-time chat application",
  "Build a dashboard with analytics and charts",
  "Develop a portfolio website with contact form"
];

export default function Home() {
  const [messages, setMessages] = useState<AgentMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPrompt, setSelectedPrompt] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: AgentMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    // Add processing message
    const processingMessage: AgentMessage = {
      id: (Date.now() + 1).toString(),
      type: 'assistant',
      content: '',
      timestamp: new Date().toISOString(),
      status: 'processing'
    };

    setMessages(prev => [...prev, processingMessage]);

    // Simulate AI agent processing
    setTimeout(() => {
      const responseMessage: AgentMessage = {
        id: (Date.now() + 2).toString(),
        type: 'assistant',
        content: `I understand you want to create: "${inputValue}". Let me analyze your requirements and generate a complete fullstack application for you.

🔍 **Analysis Complete**: I've identified the key components needed:
• Frontend: React components with TypeScript
• Backend: API endpoints with proper error handling
• Database: Prisma schema with relationships
• Authentication: User management system
• UI/UX: Responsive design with modern components

🚀 **Development Plan Created**:
1. Set up project structure
2. Design database schema
3. Create UI components
4. Implement API endpoints
5. Add authentication
6. Integrate all components

Would you like me to proceed with generating the complete application?`,
        timestamp: new Date().toISOString(),
        status: 'completed'
      };

      setMessages(prev => prev.filter(msg => msg.id !== processingMessage.id).concat(responseMessage));
      setIsLoading(false);
    }, 3000);
  };

  const handleExamplePrompt = (prompt: string) => {
    setInputValue(prompt);
    setSelectedPrompt(prompt);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm dark:bg-slate-900/80">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative w-10 h-10">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                  AI Fullstack Agent
                </h1>
                <p className="text-sm text-muted-foreground">Intelligent Development Assistant</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-xs">
                <Sparkles className="w-3 h-3 mr-1" />
                GLM-4.5 Powered
              </Badge>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-1" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 mb-4">
            <Badge variant="secondary" className="text-sm">
              🎉 New Version Available
            </Badge>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
              Build Complete Applications
            </span>
            <br />
            <span className="text-slate-700 dark:text-slate-300">with AI</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Transform your ideas into production-ready fullstack applications with our intelligent AI agent. 
            From concept to deployment, we handle everything.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="px-8" onClick={() => window.location.href = '/main'}>
              <Bot className="w-5 h-5 mr-2" />
              Start Building
            </Button>
            <Button variant="outline" size="lg" className="px-8" onClick={() => window.location.href = '/main'}>
              <Terminal className="w-5 h-5 mr-2" />
              View Demo
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="mb-12">
          <h3 className="text-3xl font-bold text-center mb-8">Powerful Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    {feature.icon}
                    {feature.badge && (
                      <Badge variant="secondary" className="text-xs">
                        {feature.badge}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Interactive Demo Section */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageSquare className="w-5 h-5" />
                <span>Try the AI Agent</span>
              </CardTitle>
              <CardDescription>
                Describe what you want to build, and watch the AI agent create a complete development plan
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Try the AI Agent */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {examplePrompts.map((prompt, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        // Store the prompt in sessionStorage and navigate to main
                        sessionStorage.setItem('aiAgentPrompt', prompt);
                        window.location.href = '/main';
                      }}
                      className={`text-xs ${selectedPrompt === prompt ? 'bg-blue-100 dark:bg-blue-900' : ''}`}
                    >
                      {prompt}
                    </Button>
                  ))}
                </div>

                {/* Chat Messages */}
                <div className="border rounded-lg bg-slate-50 dark:bg-slate-900 h-96 overflow-hidden">
                  <ScrollArea className="h-full p-4">
                    {messages.length === 0 && (
                      <div className="text-center text-muted-foreground py-8">
                        <Bot className="w-12 h-12 mx-auto mb-4 opacity-50" />
                        <p>Start a conversation with the AI agent...</p>
                        <p className="text-sm mt-2">Try one of the example prompts above!</p>
                      </div>
                    )}
                    
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`mb-4 ${message.type === 'user' ? 'text-right' : 'text-left'}`}
                      >
                        <div
                          className={`inline-block max-w-[80%] p-3 rounded-lg ${
                            message.type === 'user'
                              ? 'bg-blue-600 text-white'
                              : message.status === 'processing'
                              ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200'
                          }`}
                        >
                          {message.status === 'processing' ? (
                            <div className="flex items-center space-x-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              <span>Processing your request...</span>
                            </div>
                          ) : (
                            <div className="whitespace-pre-wrap">{message.content}</div>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {new Date(message.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </ScrollArea>
                </div>

                {/* Input Area */}
                <div className="flex space-x-2">
                  <Textarea
                    placeholder="Describe what you want to build..."
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="flex-1 resize-none"
                    rows={2}
                    disabled={isLoading}
                  />
                  <Button
                    onClick={handleSendMessage}
                    disabled={!inputValue.trim() || isLoading}
                    className="self-end"
                  >
                    {isLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-blue-600 mb-2">10K+</div>
              <div className="text-sm text-muted-foreground">Applications Generated</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-green-600 mb-2">50K+</div>
              <div className="text-sm text-muted-foreground">Lines of Code</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-purple-600 mb-2">99.9%</div>
              <div className="text-sm text-muted-foreground">Uptime</div>
            </CardContent>
          </Card>
          <Card className="text-center">
            <CardContent className="pt-6">
              <div className="text-3xl font-bold text-orange-600 mb-2">5ms</div>
              <div className="text-sm text-muted-foreground">Avg Response Time</div>
            </CardContent>
          </Card>
        </div>

        {/* Technology Stack */}
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold mb-8">Powered by Leading Technologies</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 opacity-70">
            <div className="text-2xl font-bold">⚛️ React</div>
            <div className="text-2xl font-bold">🚀 Next.js</div>
            <div className="text-2xl font-bold">🎨 Tailwind CSS</div>
            <div className="text-2xl font-bold">🗄️ Prisma</div>
            <div className="text-2xl font-bold">🤖 GLM-4.5</div>
            <div className="text-2xl font-bold">⚡ TypeScript</div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t bg-white/80 backdrop-blur-sm dark:bg-slate-900/80 mt-16">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center text-muted-foreground">
            <p>© 2024 AI Fullstack Agent. Built with ❤️ using cutting-edge AI technology.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}