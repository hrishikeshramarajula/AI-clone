import { AIMessage, SearchResult } from './types';

// OpenRouter API Call (Best for India)
export async function callOpenRouter(
  messages: AIMessage[], 
  model: string = 'anthropic/claude-3-sonnet'
): Promise<string> {
  console.log('🔄 OpenRouter API Call:', model);
  
  const modelMap: Record<string, string> = {
    'GLM-4.5': 'zhipuai/glm-4-9b-chat',
    'GLM-4.5 (India)': 'zhipuai/glm-4-9b-chat',
    '🇮🇳 GLM-4.5 (India)': 'zhipuai/glm-4-9b-chat',
    'Claude 3 Opus': 'anthropic/claude-3-opus',
    'Claude 3 Sonnet': 'anthropic/claude-3-sonnet',
    '🇮🇳 Claude 3 Sonnet (India)': 'anthropic/claude-3-sonnet',
    'Command R+': 'cohere/command-r-plus',
    'Gemini Pro': 'google/gemini-pro-1.5',
    'Llama 3 70B': 'meta-llama/llama-3-70b-instruct',
    'Mixtral 8x7B': 'mistralai/mixtral-8x7b-instruct',
    '🇮🇳 Mixtral 8x7B (India)': 'mistralai/mixtral-8x7b-instruct'
  };
  
  const selectedModel = modelMap[model] || 'anthropic/claude-3-sonnet';
  
  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
        'X-Title': 'AI Agent Backend'
      },
      body: JSON.stringify({
        model: selectedModel,
        messages: messages,
        temperature: 0.7,
        max_tokens: 2500,
        stream: false
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`OpenRouter API error (${response.status}): ${errorData.error?.message || response.statusText}`);
    }
    
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    if (!content) {
      throw new Error('No response content from OpenRouter');
    }
    
    console.log('✅ OpenRouter Success:', content.substring(0, 100) + '...');
    return content;
    
  } catch (error) {
    console.error('❌ OpenRouter Error:', error);
    throw error;
  }
}

// OpenAI API Call
export async function callOpenAI(
  messages: AIMessage[], 
  model: string = 'gpt-4'
): Promise<string> {
  console.log('🔄 OpenAI API Call:', model);
  
  const modelName = model.includes('GPT-4') ? 'gpt-4' : 'gpt-3.5-turbo';
  
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: modelName,
        messages: messages,
        temperature: 0.7,
        max_tokens: 2500
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`OpenAI API error (${response.status}): ${errorData.error?.message || response.statusText}`);
    }
    
    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;
    
    if (!content) {
      throw new Error('No response content from OpenAI');
    }
    
    console.log('✅ OpenAI Success:', content.substring(0, 100) + '...');
    return content;
    
  } catch (error) {
    console.error('❌ OpenAI Error:', error);
    throw error;
  }
}

// HuggingFace Image Generation
export async function generateImageHF(
  prompt: string, 
  model: string = 'stabilityai/stable-diffusion-2-1'
): Promise<string> {
  console.log('🔄 HuggingFace Image Generation:', prompt.substring(0, 50) + '...');
  
  const modelMap: Record<string, string> = {
    'Stable Diffusion': 'stabilityai/stable-diffusion-2-1',
    '🇮🇳 Stable Diffusion (India)': 'stabilityai/stable-diffusion-2-1',
    'MidJourney': 'prompthero/openjourney',
    'DALL-E': 'runwayml/stable-diffusion-v1-5'
  };
  
  const selectedModel = modelMap[model] || 'stabilityai/stable-diffusion-2-1';
  const apiUrl = `${process.env.HF_INFERENCE_URL}/${selectedModel}`;
  
  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          num_inference_steps: 20,
          guidance_scale: 7.5,
          width: 512,
          height: 512
        }
      })
    });
    
    if (!response.ok) {
      throw new Error(`HuggingFace API error (${response.status}): ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString('base64');
    
    console.log('✅ HuggingFace Image Success');
    return base64;
    
  } catch (error) {
    console.error('❌ HuggingFace Error:', error);
    throw error;
  }
}

// Web Search Function
export async function performWebSearch(query: string): Promise<SearchResult[]> {
  console.log('🔄 Web Search:', query);
  
  // Simple search results simulation (replace with real search API if needed)
  const searchResults: SearchResult[] = [
    {
      url: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      name: `Search: ${query}`,
      snippet: `Comprehensive search results and analysis for "${query}". This includes the latest information from multiple reliable sources.`,
      host_name: 'google.com',
      rank: 1,
      date: new Date().toISOString(),
      favicon: 'https://www.google.com/favicon.ico'
    },
    {
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(query.replace(/ /g, '_'))}`,
      name: `${query} - Wikipedia`,
      snippet: `Educational and reference information about ${query} from Wikipedia and other authoritative sources.`,
      host_name: 'wikipedia.org',
      rank: 2,
      date: new Date().toISOString(),
      favicon: 'https://en.wikipedia.org/static/favicon/wikipedia.ico'
    }
  ];
  
  console.log('✅ Search Results Generated');
  return searchResults;
}