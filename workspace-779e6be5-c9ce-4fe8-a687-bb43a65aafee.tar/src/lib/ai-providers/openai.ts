import { AIMessage } from '../../types/ai';

// Fallback OpenAI provider using ZAI SDK
export async function callAI(message: string, modelName: string, searchType: string = 'chat'): Promise<string> {
  try {
    // Try to import and use the z-ai-web-dev-sdk
    let ZAI;
    try {
      ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK imported successfully');
    } catch (importError) {
      console.error('Failed to import ZAI SDK:', importError);
      throw new Error('Failed to import AI SDK');
    }

    // Create system prompt based on search type
    let systemPrompt = 'You are a helpful AI assistant. Provide accurate, helpful, and comprehensive responses.';
    
    switch (searchType) {
      case 'search':
        systemPrompt = 'You are an AI assistant with web search capabilities. Provide accurate, up-to-date information with sources when possible.';
        break;
      case 'code':
        systemPrompt = 'You are an expert programmer. Generate clean, efficient, and well-documented code with proper error handling.';
        break;
      case 'analysis':
        systemPrompt = 'You are an expert analyst. Provide detailed, insightful analysis with data-driven insights and recommendations.';
        break;
      default:
        systemPrompt = 'You are a helpful AI assistant. Provide accurate, helpful, and comprehensive responses.';
    }

    console.log('Attempting to call OpenAI with model:', modelName, 'type:', searchType);

    // Try different approaches to use the ZAI SDK
    let completion;
    
    // Approach 1: Try using the SDK directly
    try {
      if (typeof ZAI.create === 'function') {
        const zai = await ZAI.create();
        console.log('ZAI instance created successfully');
        
        if (zai && typeof zai.chat?.completions?.create === 'function') {
          completion = await zai.chat.completions.create({
            messages: [
              {
                role: 'system',
                content: systemPrompt
              },
              {
                role: 'user',
                content: message
              }
            ],
            temperature: 0.7,
            max_tokens: 2000
          });
          console.log('AI call successful via chat.completions.create');
        } else {
          throw new Error('chat.completions.create not available');
        }
      } else {
        throw new Error('ZAI.create not available');
      }
    } catch (approach1Error) {
      console.log('Approach 1 failed:', approach1Error);
      
      // Approach 2: Try using the default export
      try {
        const zai = ZAI.default || ZAI;
        if (typeof zai === 'function') {
          const instance = await zai();
          if (instance && typeof instance.chat?.completions?.create === 'function') {
            completion = await instance.chat.completions.create({
              messages: [
                {
                  role: 'system',
                  content: systemPrompt
                },
                {
                  role: 'user',
                  content: message
                }
              ],
              temperature: 0.7,
              max_tokens: 2000
            });
            console.log('AI call successful via default export');
          } else {
            throw new Error('chat.completions.create not available on default export');
          }
        } else {
          throw new Error('Default export is not a function');
        }
      } catch (approach2Error) {
        console.log('Approach 2 failed:', approach2Error);
        
        // Approach 3: Try direct method calls
        try {
          const zai = ZAI.default || ZAI;
          if (zai && typeof zai.chat?.completions?.create === 'function') {
            completion = await zai.chat.completions.create({
              messages: [
                {
                  role: 'system',
                  content: systemPrompt
                },
                {
                  role: 'user',
                  content: message
                }
              ],
              temperature: 0.7,
              max_tokens: 2000
            });
            console.log('AI call successful via direct method');
          } else {
            throw new Error('Direct method call not available');
          }
        } catch (approach3Error) {
          console.log('Approach 3 failed:', approach3Error);
          throw new Error('All AI SDK approaches failed');
        }
      }
    }

    console.log('AI call successful, completion:', completion);

    // Handle different response formats
    if (completion && typeof completion === 'object') {
      // OpenAI-like format
      if (completion.choices && Array.isArray(completion.choices)) {
        const content = completion.choices[0]?.message?.content;
        if (content && typeof content === 'string' && content.trim().length > 0) {
          return content;
        }
      }
      // Direct response format
      else if (completion.content && typeof completion.content === 'string') {
        return completion.content;
      }
      // String response
      else if (typeof completion === 'string') {
        return completion;
      }
      // Try to extract content from other formats
      else if (completion.response || completion.answer || completion.text) {
        return completion.response || completion.answer || completion.text;
      }
    }

    throw new Error('Invalid response format from AI');
  } catch (error) {
    console.error('OpenAI API error:', error);
    throw error;
  }
}