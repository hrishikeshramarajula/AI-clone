import { SearchResult } from '../types/ai';

export interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export async function performWebSearch(query: string): Promise<SearchResult[]> {
  try {
    console.log('Performing web search for:', query);

    // Try to use the z-ai-web-dev-sdk for web search with multiple approaches
    let ZAI;
    try {
      ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK imported successfully for web search');
    } catch (importError) {
      console.error('Failed to import ZAI SDK for web search:', importError);
      // Return empty array instead of throwing - the AI will still provide helpful responses
      return [];
    }

    let searchResult;
    
    // Approach 1: Try using the SDK directly
    try {
      const ZAIDefault = ZAI.default;
      if (typeof ZAIDefault.create === 'function') {
        const zai = await ZAIDefault.create();
        console.log('ZAI instance created successfully for web search');
        console.log('ZAI config:', zai.config);
        
        if (zai && typeof zai.functions?.invoke === 'function') {
          searchResult = await zai.functions.invoke("web_search", {
            query: query,
            num: 5
          });
          console.log('Web search successful via functions.invoke');
          
          // Validate and format the search results
          if (Array.isArray(searchResult)) {
            return searchResult.map((result, index) => ({
              url: result.url || '',
              name: result.name || result.title || `Result ${index + 1}`,
              snippet: result.snippet || result.description || '',
              host_name: result.host_name || new URL(result.url || '').hostname || '',
              rank: result.rank || index + 1,
              date: result.date || new Date().toISOString(),
              favicon: result.favicon || ''
            }));
          }
        }
      }
    } catch (approach1Error) {
      console.log('Web search Approach 1 failed:', approach1Error.message);
    }
    
    // Approach 2: Try using manual instantiation
    try {
      const ZAIDefault = ZAI.default;
      const zai = new ZAIDefault({
        baseUrl: 'http://172.25.136.193:8080/v1',
        apiKey: 'Z.ai'
      });
      console.log('ZAI instance created via manual instantiation for web search');
      
      if (zai && typeof zai.functions?.invoke === 'function') {
        searchResult = await zai.functions.invoke("web_search", {
          query: query,
          num: 5
        });
        console.log('Web search successful via manual instantiation');
        
        // Validate and format the search results
        if (Array.isArray(searchResult)) {
          return searchResult.map((result, index) => ({
            url: result.url || '',
            name: result.name || result.title || `Result ${index + 1}`,
            snippet: result.snippet || result.description || '',
            host_name: result.host_name || new URL(result.url || '').hostname || '',
            rank: result.rank || index + 1,
            date: result.date || new Date().toISOString(),
            favicon: result.favicon || ''
          }));
        }
      }
    } catch (approach2Error) {
      console.log('Web search Approach 2 failed:', approach2Error.message);
    }

    // Approach 3: Try using chat completion for search simulation
    try {
      const ZAIDefault = ZAI.default;
      let instance;
      
      if (typeof ZAIDefault.create === 'function') {
        instance = await ZAIDefault.create();
      } else {
        instance = new ZAIDefault({
          baseUrl: 'http://172.25.136.193:8080/v1',
          apiKey: 'Z.ai'
        });
      }
      
      if (instance && typeof instance.chat?.completions?.create === 'function') {
        const searchResponse = await instance.chat.completions.create({
          messages: [
            {
              role: 'system',
              content: 'You are a web search assistant. Provide simulated search results for the given query. Return the results in a structured format with URLs, titles, and snippets.'
            },
            {
              role: 'user',
              content: `Provide search results for: ${query}\n\nReturn 3-5 results with:\n1. URL\n2. Title\n3. Snippet/description\n4. Host name\n\nFormat as a JSON array.`
            }
          ],
          temperature: 0.3,
          max_tokens: 1000
        });
        
        const responseText = searchResponse.choices?.[0]?.message?.content || '';
        
        // Try to parse JSON from the response
        try {
          const jsonMatch = responseText.match(/\[[\s\S]*\]/);
          if (jsonMatch) {
            const parsedResults = JSON.parse(jsonMatch[0]);
            if (Array.isArray(parsedResults)) {
              console.log('Web search successful via chat completion');
              return parsedResults.map((result, index) => ({
                url: result.url || '',
                name: result.name || result.title || `Result ${index + 1}`,
                snippet: result.snippet || result.description || '',
                host_name: result.host_name || new URL(result.url || '').hostname || '',
                rank: result.rank || index + 1,
                date: result.date || new Date().toISOString(),
                favicon: result.favicon || ''
              }));
            }
          }
        } catch (parseError) {
          console.log('Failed to parse chat completion search results:', parseError.message);
        }
      }
    } catch (approach3Error) {
      console.log('Web search Approach 3 failed:', approach3Error.message);
    }

    console.log('All web search approaches failed, returning empty results');
    return [];
    
  } catch (error) {
    console.error('Web search error:', error);
    // Return empty array instead of throwing - the AI will still provide helpful responses
    return [];
  }
}