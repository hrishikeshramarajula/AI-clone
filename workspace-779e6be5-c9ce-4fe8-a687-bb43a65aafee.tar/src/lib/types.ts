export interface AIMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export interface AIResponse {
  success: boolean;
  response: string;
  searchResults?: SearchResult[];
  imageData?: string;
  imagePrompt?: string;
  model?: string;
  error?: string;
  provider?: string;
}

export interface FullStackProject {
  frontend: string;
  backend: string;
  projectStructure: string;
  setupInstructions: string;
}

export interface Task {
  id: string;
  status: 'needs-review' | 'completed';
  timestamp: string;
  content: string;
}