// Test script for Z-AI Engine
const fetch = require('node-fetch');

async function testAIEngine() {
  console.log('🧪 Testing Z-AI Engine...\n');

  const testCases = [
    {
      name: 'Basic Chat',
      endpoint: '/api/ai',
      data: {
        message: 'Hello! Can you introduce yourself and explain what you can do?',
        model: 'Z-AI Engine',
        searchType: 'chat'
      }
    },
    {
      name: 'Code Generation',
      endpoint: '/api/ai',
      data: {
        message: 'Create a simple React component that displays a counter with increment and decrement buttons.',
        model: 'Z-AI Engine',
        searchType: 'code'
      }
    },
    {
      name: 'Analysis',
      endpoint: '/api/ai',
      data: {
        message: 'Analyze the benefits and drawbacks of using TypeScript in modern web development.',
        model: 'Z-AI Engine',
        searchType: 'analysis'
      }
    },
    {
      name: 'Health Check',
      endpoint: '/api/health',
      data: {}
    }
  ];

  for (const testCase of testCases) {
    try {
      console.log(`🔄 Testing: ${testCase.name}`);
      
      const response = await fetch('http://localhost:3000' + testCase.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testCase.data)
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`✅ ${testCase.name}: SUCCESS`);
        
        if (result.success !== undefined) {
          console.log(`   Status: ${result.success ? '✅ Working' : '❌ Failed'}`);
        }
        
        if (result.response) {
          console.log(`   Response: ${result.response.substring(0, 100)}...`);
        }
        
        if (result.health) {
          console.log(`   Health: ${result.health.status}`);
          console.log(`   Engine: ${result.health.engine || 'Unknown'}`);
        }
        
      } else {
        console.log(`❌ ${testCase.name}: HTTP ${response.status}`);
        const errorText = await response.text();
        console.log(`   Error: ${errorText.substring(0, 100)}...`);
      }
      
      console.log(''); // Empty line for readability
      
    } catch (error) {
      console.log(`❌ ${testCase.name}: Network Error - ${error.message}\n`);
    }
  }

  console.log('🎯 AI Engine Testing Complete!');
  console.log('📋 Summary:');
  console.log('• The Z-AI Engine should now provide reliable responses');
  console.log('• All external API dependencies have been replaced');
  console.log('• The engine includes fallback mechanisms for reliability');
  console.log('• Test the UI by sending messages through the chat interface');
}

testAIEngine().catch(console.error);