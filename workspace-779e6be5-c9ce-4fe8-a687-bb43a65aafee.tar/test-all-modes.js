// Comprehensive test script for all AI Engine modes
const https = require('https');

async function testAllModes() {
  console.log('🧪 Testing All AI Engine Modes...\n');

  const testCases = [
    {
      name: '💬 Chat Mode',
      endpoint: '/api/ai',
      data: {
        message: 'Hello! Can you tell me about yourself and what you can help me with?',
        model: 'Z-AI Engine',
        searchType: 'chat'
      }
    },
    {
      name: '💻 Code Mode',
      endpoint: '/api/ai',
      data: {
        message: 'Create a React component that displays a todo list with add, edit, delete functionality using useState hooks.',
        model: 'Z-AI Engine',
        searchType: 'code'
      }
    },
    {
      name: '📊 Analysis Mode',
      endpoint: '/api/ai',
      data: {
        message: 'Analyze the impact of artificial intelligence on modern software development practices and future trends.',
        model: 'Z-AI Engine',
        searchType: 'analysis'
      }
    },
    {
      name: '🔍 Search Mode',
      endpoint: '/api/ai',
      data: {
        message: 'What are the latest developments in quantum computing and how do they affect cryptography?',
        model: 'Z-AI Engine',
        searchType: 'search'
      }
    },
    {
      name: '🖼️ Image Mode',
      endpoint: '/api/ai',
      data: {
        message: 'Generate an image of a futuristic AI robot working in a modern office with neon lighting',
        model: 'Z-AI Engine',
        searchType: 'image'
      }
    },
    {
      name: '🚀 Fullstack Mode',
      endpoint: '/api/fullstack',
      data: {
        message: 'Create a task management application with user authentication, real-time updates, and mobile responsiveness',
        model: 'Z-AI Engine',
        files: []
      }
    },
    {
      name: '🏥 Health Check',
      endpoint: '/api/health',
      data: {}
    }
  ];

  const results = [];

  for (const testCase of testCases) {
    try {
      console.log(`🔄 Testing: ${testCase.name}`);
      
      const postData = JSON.stringify(testCase.data);
      
      const options = {
        hostname: 'localhost',
        port: 3000,
        path: testCase.endpoint,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData)
        }
      };

      const result = {
        name: testCase.name,
        status: '',
        httpStatus: 0,
        success: false,
        hasResponse: false,
        responseLength: 0,
        error: null
      };

      const req = https.request(options, (res) => {
        result.status = res.statusCode === 200 ? '✅ SUCCESS' : '❌ FAILED';
        result.httpStatus = res.statusCode;
        
        let data = '';
        
        res.on('data', (chunk) => {
          data += chunk;
        });
        
        res.on('end', () => {
          try {
            const jsonData = JSON.parse(data);
            result.success = jsonData.success !== undefined ? jsonData.success : true;
            result.hasResponse = !!jsonData.response;
            result.responseLength = jsonData.response ? jsonData.response.length : 0;
            
            console.log(`   ${result.status} (${result.httpStatus})`);
            console.log(`   Success: ${result.success ? '✅' : '❌'}`);
            console.log(`   Response: ${result.hasResponse ? '✅' : '❌'} (${result.responseLength} chars)`);
            
            if (jsonData.response) {
              console.log(`   Preview: ${jsonData.response.substring(0, 100)}...`);
            }
            
            if (jsonData.health) {
              console.log(`   Health: ${jsonData.health.status}`);
              console.log(`   Engine: ${jsonData.health.engine || 'Unknown'}`);
            }
            
          } catch (parseError) {
            console.log(`   ${result.status} (${result.httpStatus})`);
            console.log(`   Raw Response: ${data.substring(0, 100)}...`);
          }
          
          console.log(''); // Empty line for readability
        });
      });

      req.on('error', (error) => {
        result.error = error.message;
        console.log(`❌ ${testCase.name}: Network Error - ${error.message}`);
        console.log('');
      });

      req.write(postData);
      req.end();
      
      results.push(result);
      
    } catch (error) {
      console.log(`❌ ${testCase.name}: Setup Error - ${error.message}`);
      results.push({
        name: testCase.name,
        status: '❌ SETUP ERROR',
        success: false,
        error: error.message
      });
      console.log('');
    }
  }

  // Summary
  console.log('🎯 AI Engine Testing Complete!\n');
  console.log('📊 Test Results Summary:');
  console.log('='.repeat(50));
  
  const passedTests = results.filter(r => r.success || r.status.includes('SUCCESS')).length;
  const totalTests = results.length;
  
  results.forEach(result => {
    const statusIcon = result.success || result.status.includes('SUCCESS') ? '✅' : '❌';
    console.log(`${statusIcon} ${result.name}`);
    if (result.error) {
      console.log(`   Error: ${result.error}`);
    }
  });
  
  console.log('='.repeat(50));
  console.log(`📈 Overall Result: ${passedTests}/${totalTests} tests passed`);
  
  if (passedTests === totalTests) {
    console.log('🎉 ALL MODES WORKING PERFECTLY!');
    console.log('💡 Your AI Agent is now fully operational with all modes:');
    console.log('   💬 Chat - General conversation');
    console.log('   💻 Code - Programming assistance');
    console.log('   📊 Analysis - Data insights');
    console.log('   🔍 Search - Web-enhanced responses');
    console.log('   🖼️ Image - Image generation');
    console.log('   🚀 Fullstack - Complete application generation');
  } else {
    console.log('⚠️  Some modes need attention. Check the results above.');
  }
  
  console.log('\n🚀 Ready to use! Test the UI by sending messages in different modes.');
}

testAllModes().catch(console.error);