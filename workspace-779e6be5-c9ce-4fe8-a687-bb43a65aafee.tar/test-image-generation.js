// Test script for image generation
const fetch = require('node-fetch');

async function testImageGeneration() {
  console.log('🖼️ Testing Image Generation...\n');

  const testCases = [
    {
      name: 'Ganesha Image Generation',
      data: {
        message: 'generate image of ganesha',
        model: '🇮🇳 Stable Diffusion (India)',
        searchType: 'image'
      }
    },
    {
      name: 'Simple Landscape Image',
      data: {
        message: 'generate image of a beautiful mountain landscape with sunset',
        model: '🇮🇳 Stable Diffusion (India)',
        searchType: 'image'
      }
    },
    {
      name: 'Abstract Art Image',
      data: {
        message: 'generate image of abstract colorful art',
        model: '🇮🇳 Stable Diffusion (India)',
        searchType: 'image'
      }
    }
  ];

  for (const testCase of testCases) {
    try {
      console.log(`🔄 Testing: ${testCase.name}`);
      
      const response = await fetch('http://localhost:3000/api/ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(testCase.data)
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`✅ ${testCase.name}: SUCCESS`);
        console.log(`   Status: ${result.success ? '✅ Working' : '❌ Failed'}`);
        console.log(`   Provider: ${result.provider}`);
        console.log(`   Has Image Data: ${result.imageData ? '✅ Yes' : '❌ No'}`);
        
        if (result.response) {
          console.log(`   Response: ${result.response.substring(0, 100)}...`);
        }
        
        if (result.error) {
          console.log(`   Error: ${result.error}`);
        }
        
      } else {
        console.log(`❌ ${testCase.name}: HTTP ${response.status}`);
        const errorText = await response.text();
        console.log(`   Error: ${errorText.substring(0, 100)}...`);
      }
      
      console.log(''); // Empty line for readability
      
    } catch (error) {
      console.log(`❌ ${testCase.name}: Network Error - ${error.message}\n`);
    }
  }

  console.log('🎯 Image Generation Testing Complete!');
  console.log('📋 Summary:');
  console.log('• Image generation should now work with placeholder SVGs');
  console.log('• The AI engine generates beautiful placeholder images');
  console.log('• Real image generation will work when Z-AI services are available');
  console.log('• Test the UI by sending image generation requests');
  console.log('\n🎨 Try generating an image in the chat interface now!');
}

testImageGeneration().catch(console.error);