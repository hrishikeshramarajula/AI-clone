#!/bin/bash

echo "🧪 Testing All AI Engine Modes..."
echo "================================"

# Test Health Check
echo "🏥 Testing Health Check..."
curl -s http://localhost:3000/api/health | head -c 200
echo -e "\n"

# Test Chat Mode
echo "💬 Testing Chat Mode..."
curl -s -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello! Introduce yourself briefly","model":"Z-AI Engine","searchType":"chat"}' | head -c 300
echo -e "\n"

# Test Code Mode
echo "💻 Testing Code Mode..."
curl -s -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"message":"Create a simple Hello World function in JavaScript","model":"Z-AI Engine","searchType":"code"}' | head -c 300
echo -e "\n"

# Test Analysis Mode
echo "📊 Testing Analysis Mode..."
curl -s -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"message":"Analyze the benefits of using TypeScript in web development","model":"Z-AI Engine","searchType":"analysis"}' | head -c 300
echo -e "\n"

# Test Search Mode
echo "🔍 Testing Search Mode..."
curl -s -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"message":"What are the latest trends in artificial intelligence?","model":"Z-AI Engine","searchType":"search"}' | head -c 300
echo -e "\n"

# Test Image Mode
echo "🖼️ Testing Image Mode..."
curl -s -X POST http://localhost:3000/api/ai \
  -H "Content-Type: application/json" \
  -d '{"message":"Generate an image of a beautiful sunset over mountains","model":"Z-AI Engine","searchType":"image"}' | head -c 300
echo -e "\n"

# Test Fullstack Mode
echo "🚀 Testing Fullstack Mode..."
curl -s -X POST http://localhost:3000/api/fullstack \
  -H "Content-Type: application/json" \
  -d '{"message":"Create a simple todo application","model":"Z-AI Engine","files":[]}' | head -c 300
echo -e "\n"

echo "================================"
echo "🎯 AI Engine Testing Complete!"
echo "💡 If you see responses above, all modes are working!"
echo "🚀 Test the UI by sending messages in different modes."