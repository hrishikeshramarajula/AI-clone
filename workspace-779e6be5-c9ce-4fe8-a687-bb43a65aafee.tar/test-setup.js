const fetch = require('node-fetch');
require('dotenv').config({ path: '.env.local' });

async function testAllAPIs() {
  console.log('🇮🇳 Testing AI Agent APIs for India...\n');

  const tests = [
    {
      name: 'OpenRouter API',
      test: async () => {
        const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'http://localhost:3000'
          },
          body: JSON.stringify({
            model: 'anthropic/claude-3-sonnet',
            messages: [{ role: 'user', content: 'Hello from India! Say "OpenRouter is working perfectly!"' }],
            max_tokens: 100
          })
        });
        
        if (response.ok) {
          const data = await response.json();
          return { success: true, message: data.choices[0].message.content };
        } else {
          const error = await response.json();
          return { success: false, error: error.error?.message || response.statusText };
        }
      }
    },
    {
      name: 'HuggingFace API',
      test: async () => {
        const response = await fetch('https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            inputs: 'Hello from India!',
            parameters: { max_new_tokens: 50 }
          })
        });
        
        if (response.ok) {
          return { success: true, message: 'HuggingFace API is working!' };
        } else {
          return { success: false, error: response.statusText };
        }
      }
    },
    {
      name: 'OpenAI API',
      test: async () => {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: 'Say "OpenAI is working from India!"' }],
            max_tokens: 50
          })
        });
        
        if (response.ok) {
          const data = await response.json();
          return { success: true, message: data.choices[0].message.content };
        } else {
          const error = await response.json();
          return { success: false, error: error.error?.message || response.statusText };
        }
      }
    }
  ];

  for (const test of tests) {
    try {
      console.log(`Testing ${test.name}...`);
      const result = await test.test();
      
      if (result.success) {
        console.log(`✅ ${test.name}: ${result.message}\n`);
      } else {
        console.log(`❌ ${test.name}: ${result.error}\n`);
      }
    } catch (error) {
      console.log(`❌ ${test.name}: Network Error - ${error.message}\n`);
    }
  }

  // Test local endpoints
  console.log('Testing local endpoints...\n');
  
  try {
    const healthResponse = await fetch('http://localhost:3000/api/health');
    if (healthResponse.ok) {
      const health = await healthResponse.json();
      console.log('✅ Health Endpoint: Working');
      console.log('📊 Services Status:', JSON.stringify(health.health.services, null, 2));
    } else {
      console.log('❌ Health Endpoint: Failed');
    }
  } catch (error) {
    console.log('❌ Local Server: Not running. Start with `npm run dev`');
  }

  console.log('\n🎯 API Testing Complete! Your AI Agent is ready to work perfectly from India! 🇮🇳');
}

testAllAPIs().catch(console.error);