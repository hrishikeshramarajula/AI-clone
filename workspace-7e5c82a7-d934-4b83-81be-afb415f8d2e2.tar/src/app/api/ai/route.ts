import { NextRequest, NextResponse } from 'next/server';
import { callOpenRouter, callHuggingFaceText } from '../../../lib/ai-providers/openrouter';
import { generateImageHF, generateTextHF } from '../../../lib/ai-providers/huggingface';
import { performWebSearch } from '../../../lib/search';
import { AIMessage, AIResponse } from '../../../types/ai';

// Provider priority for India-friendly services
const PROVIDER_PRIORITY = ['openrouter', 'huggingface'];

async function getWorkingProvider(messages: AIMessage[], model: string, searchType: string) {
  const providers = {
    openrouter: async () => await callOpenRouter(messages, model),
    huggingface: async () => await callHuggingFaceText(messages[1].content, model)
  };

  let lastError;
  
  for (const providerName of PROVIDER_PRIORITY) {
    try {
      console.log(`Trying provider: ${providerName}`);
      const result = await providers[providerName]();
      console.log(`Success with provider: ${providerName}`);
      return { result, provider: providerName };
    } catch (error) {
      console.warn(`Provider ${providerName} failed:`, error.message);
      lastError = error;
      continue;
    }
  }
  
  throw lastError || new Error('All providers failed');
}

export async function POST(request: NextRequest) {
  try {
    const { message, model, searchType = 'chat' } = await request.json();
    
    if (!message) {
      return NextResponse.json(
        { success: false, error: 'Message is required' },
        { status: 400 }
      );
    }

    console.log(`Processing request: ${message} with model: ${model} and type: ${searchType}`);

    let response = '';
    let searchResults: any[] = [];
    let imageData: string | undefined;
    let imagePrompt: string | undefined;
    let usedProvider = '';

    // Handle different search types
    switch (searchType) {
      case 'search':
        // Perform web search first
        try {
          searchResults = await performWebSearch(message);
          console.log(`Web search completed with ${searchResults.length} results`);
        } catch (searchError) {
          console.warn('Web search failed, continuing without search results:', searchError);
          searchResults = [];
        }
        
        const searchContext = searchResults.map(result => 
          `Source: ${result.name}\nContent: ${result.snippet}`
        ).join('\n\n');

        const searchMessages: AIMessage[] = [
          {
            role: 'system',
            content: `You are an AI assistant that provides accurate, comprehensive answers based on search results and your knowledge. Use the search results to enhance your response.\n\nSearch Results:\n${searchContext}`
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          const searchResult = await getWorkingProvider(searchMessages, model, searchType);
          response = searchResult.result;
          usedProvider = searchResult.provider;
        } catch (providerError) {
          console.warn('All AI providers failed for search, providing fallback response');
          response = `I apologize, but I'm currently experiencing technical difficulties with AI services. However, I can provide some general information about: "${message}"

This could be due to:
• AI service connectivity issues
• High demand on AI services  
• Temporary service maintenance

Please try again in a few moments. The issue has been logged and our technical team is working on it.

In the meantime, you might want to:
• Try a more specific question
• Break down your request into smaller parts
• Try selecting a different AI model from the dropdown

**India-Friendly Models Available**:
🇮🇳 GLM-4.5 (OpenRouter) - Recommended for India
🇮🇳 Claude 3 Sonnet (OpenRouter) - Excellent performance
🇮🇳 Mixtral 8x7B (OpenRouter) - Free option`;
          usedProvider = 'fallback';
        }
        break;

      case 'image':
        imagePrompt = message;
        
        try {
          // Always try HuggingFace first for images (works well from India)
          imageData = await generateImageHF(message, model);
          response = `I've generated an image based on your prompt: "${message}". The image has been created successfully using HuggingFace! You can view it above.`;
          usedProvider = 'huggingface';
          console.log('Image generation successful');
        } catch (imageError) {
          console.error('Image generation failed:', imageError);
          response = `I apologize, but I encountered an issue generating the image. This could be due to:

• API limitations or server issues
• High demand on image generation services
• Temporary maintenance

Please try again with:
• A different, more descriptive prompt
• A simpler image request
• In a few moments when services are available

**Alternative Options**:
• Try the 🇮🇳 Stable Diffusion (India) model
• Use text-based AI models for image descriptions
• Contact support if the issue persists`;
          usedProvider = 'error';
        }
        break;

      case 'code':
        const codeMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are an expert software developer and coding assistant. Provide clear, well-commented, production-ready code solutions with explanations and best practices.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          const codeResult = await getWorkingProvider(codeMessages, model, searchType);
          response = codeResult.result;
          usedProvider = codeResult.provider;
        } catch (providerError) {
          console.warn('All AI providers failed for code, providing fallback response');
          response = `I apologize, but I'm currently experiencing technical difficulties with code generation services. However, I can provide some general guidance for: "${message}"

**For better code generation results, consider:**
• Being more specific about the programming language
• Including specific requirements or constraints
• Breaking down complex requests into smaller parts
• Providing context about your project structure

**Please try again in a few moments, or:**
• Switch to 🇮🇳 Mixtral 8x7B (India) - Free code expert
• Try 🇮🇳 GLM-4.5 (India) - Excellent for development
• Use 🇮🇳 Claude 3 Sonnet (India) - Great for code analysis

The technical team has been notified of this issue.`;
          usedProvider = 'fallback';
        }
        break;

      case 'analysis':
        const analysisMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are an expert data analyst and researcher. Provide thorough, evidence-based analysis with clear insights, trends, and actionable recommendations.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          const analysisResult = await getWorkingProvider(analysisMessages, model, searchType);
          response = analysisResult.result;
          usedProvider = analysisResult.provider;
        } catch (providerError) {
          console.warn('All AI providers failed for analysis, providing fallback response');
          response = `I apologize, but I'm currently experiencing technical difficulties with analysis services. However, I can offer some general insights on: "${message}"

**For better analysis results, consider:**
• Providing more specific data or context
• Specifying the type of analysis you need
• Including relevant metrics or parameters
• Being clear about your analysis goals

**Please try again shortly, or attempt with:**
• 🇮🇳 Claude 3 Sonnet (India) - Excellent for analysis
• 🇮🇳 GLM-4.5 (India) - Great for insights
• 🇮🇳 Mixtral 8x7B (India) - Free analysis option

Our team is working to resolve this issue.`;
          usedProvider = 'fallback';
        }
        break;

      default: // 'chat'
        const chatMessages: AIMessage[] = [
          {
            role: 'system',
            content: 'You are a helpful, knowledgeable, and friendly AI assistant. Provide accurate, detailed, and useful responses while maintaining a conversational tone.'
          },
          {
            role: 'user',
            content: message
          }
        ];

        try {
          const chatResult = await getWorkingProvider(chatMessages, model, searchType);
          response = chatResult.result;
          usedProvider = chatResult.provider;
        } catch (providerError) {
          console.warn('All AI providers failed for chat, providing fallback response');
          response = `I apologize, but I'm currently experiencing technical difficulties with AI chat services. However, I'm still here to help you with: "${message}"

**This could be due to:**
• Temporary AI service connectivity issues
• High demand on AI services
• Network connectivity problems
• Service maintenance

**Please try again in a few moments. In the meantime:**
• Check your internet connection
• Try selecting a different AI model
• Refresh the page and try again

**Recommended India-Friendly Models:**
🇮🇳 GLM-4.5 (OpenRouter) - Best overall for India
🇮🇳 Claude 3 Sonnet (OpenRouter) - Excellent performance  
🇮🇳 Mixtral 8x7B (OpenRouter) - Free and reliable

The issue has been logged and our technical team is working to restore full service.`;
          usedProvider = 'fallback';
        }
        break;
    }

    const aiResponse: AIResponse = {
      success: true,
      response: response + (usedProvider !== 'fallback' ? `\n\n*Powered by ${usedProvider}*` : ''),
      searchResults: searchResults.length > 0 ? searchResults : undefined,
      imageData,
      imagePrompt,
      model: `${model} (${usedProvider})`
    };

    return NextResponse.json(aiResponse);

  } catch (error: any) {
    console.error('AI API Error:', error);
    
    return NextResponse.json(
      { 
        success: false, 
        error: error.message || 'AI service error',
        response: `I apologize, but I'm experiencing technical difficulties. Here's what happened:

**Error**: ${error.message || 'Unknown error'}

**Solutions to try**:
• **Switch to OpenRouter models**: GLM-4.5, Claude 3 Sonnet work well from India
• **Use HuggingFace models**: Free and available globally
• **Check your internet connection**: Ensure stable connectivity
• **Try different models**: Some providers work better than others

**India-Friendly Models**:
✅ GLM-4.5 (OpenRouter) - Recommended
✅ Claude 3 Sonnet (OpenRouter) - Works well
✅ Stable Diffusion (HuggingFace) - For images
✅ Mixtral 8x7B (OpenRouter) - Free option

The service will automatically try the best available provider for your region.`
      }, 
      { status: 500 }
    );
  }
}