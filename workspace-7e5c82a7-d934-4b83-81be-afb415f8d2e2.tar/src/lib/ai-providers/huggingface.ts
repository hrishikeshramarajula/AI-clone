import { AIMessage } from '../../types/ai';

// Image generation using HuggingFace (works great from India)
export async function generateImageHF(prompt: string, model: string = 'stabilityai/stable-diffusion-2-1'): Promise<string> {
  try {
    console.log(`HuggingFace: Generating image with model ${model} for request from India`);
    
    const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Country': 'IN'
      },
      method: 'POST',
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          guidance_scale: 7.5,
          num_inference_steps: 50
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('HuggingFace Image API Error:', response.status, errorText);
      
      // Try different fallback models based on error type
      if (response.status === 401) {
        throw new Error('HuggingFace API key invalid or expired');
      } else if (response.status === 429) {
        throw new Error('HuggingFace rate limit exceeded');
      } else if (response.status === 503) {
        throw new Error('HuggingFace model loading or unavailable');
      }
      
      // Try fallback model if primary fails
      const fallbackModels = [
        'runwayml/stable-diffusion-v1-5',
        'prompthero/openjourney',
        'openskyml/dalle-mega-1'
      ];
      
      for (const fallbackModel of fallbackModels) {
        if (fallbackModel === model) continue;
        
        try {
          console.log(`Trying fallback model: ${fallbackModel}`);
          return await generateImageHF(prompt, fallbackModel);
        } catch (fallbackError) {
          console.warn(`Fallback model ${fallbackModel} failed:`, fallbackError.message);
          continue;
        }
      }
      
      throw new Error(`All image generation models failed. Last error: ${response.status} - ${errorText}`);
    }

    // Convert image blob to base64
    const imageBlob = await response.blob();
    const base64Image = await blobToBase64(imageBlob);
    
    console.log('Image generation successful');
    return base64Image;
  } catch (error: any) {
    console.error('HuggingFace Image Generation Error:', error);
    throw new Error(`Image generation failed: ${error.message}`);
  }
}

// Text generation using HuggingFace (renamed to avoid conflict)
export async function generateTextHF(prompt: string, model: string = 'microsoft/DialoGPT-medium'): Promise<string> {
  try {
    console.log(`HuggingFace: Generating text with model ${model} for request from India`);
    
    const response = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        'Content-Type': 'application/json',
        'X-Country': 'IN'
      },
      method: 'POST',
      body: JSON.stringify({
        inputs: prompt,
        parameters: {
          max_new_tokens: 1000,
          temperature: 0.7,
          do_sample: true,
          top_p: 0.9,
          top_k: 50
        }
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('HuggingFace Text API Error:', response.status, errorText);
      
      // Try fallback model
      if (model !== 'facebook/blenderbot-400M-distill') {
        console.log('Trying fallback model for text generation...');
        return generateTextHF(prompt, 'facebook/blenderbot-400M-distill');
      }
      
      throw new Error(`HuggingFace text generation failed: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    
    // Handle different response formats
    if (Array.isArray(result) && result.length > 0) {
      return result[0]?.generated_text || result[0]?.text || 'No response generated';
    } else if (result.generated_text) {
      return result.generated_text;
    } else if (result.text) {
      return result.text;
    }
    
    return 'No response generated';
  } catch (error: any) {
    console.error('HuggingFace Text Generation Error:', error);
    throw new Error(`Text generation failed: ${error.message}`);
  }
}

// Helper function to convert blob to base64
async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1]; // Remove data:image/...;base64, prefix
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}