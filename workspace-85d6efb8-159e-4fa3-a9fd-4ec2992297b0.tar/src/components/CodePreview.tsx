'use client';

import React, { useState } from 'react';
import { X, Copy, Download, Code, FileText, Server, FolderOpen, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';

interface CodePreviewProps {
  project: any;
  isVisible: boolean;
  onClose: () => void;
}

export function CodePreview({ project, isVisible, onClose }: CodePreviewProps) {
  const [activeTab, setActiveTab] = useState('frontend');
  const [copied, setCopied] = useState('');

  if (!isVisible || !project) return null;

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(type);
      setTimeout(() => setCopied(''), 2000);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
    }
  };

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const downloadProject = () => {
    // Create a zip-like structure (simplified)
    const files = [
      { name: 'package.json', content: project.packageJson || '{}' },
      { name: 'src/App.tsx', content: project.frontend || '' },
      { name: 'server/main.py', content: project.backend || '' },
      { name: 'README.md', content: project.setupInstructions || '' },
    ];

    files.forEach(file => {
      downloadFile(file.content, file.name);
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-6xl max-h-[90vh] flex flex-col">
        <CardHeader className="flex-shrink-0">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Code className="w-5 h-5" />
              Generated Full-Stack Project
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-hidden flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="frontend" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Frontend
              </TabsTrigger>
              <TabsTrigger value="backend" className="flex items-center gap-2">
                <Server className="w-4 h-4" />
                Backend
              </TabsTrigger>
              <TabsTrigger value="structure" className="flex items-center gap-2">
                <FolderOpen className="w-4 h-4" />
                Structure
              </TabsTrigger>
              <TabsTrigger value="setup" className="flex items-center gap-2">
                <Play className="w-4 h-4" />
                Setup
              </TabsTrigger>
            </TabsList>
            
            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <TabsContent value="frontend" className="mt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Frontend Code</h3>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(project.frontend || '', 'frontend')}
                      >
                        <Copy className="w-4 h-4 mr-1" />
                        {copied === 'frontend' ? 'Copied!' : 'Copy'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadFile(project.frontend || '', 'App.tsx')}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                        <code>{project.frontend || '// No frontend code generated'}</code>
                      </pre>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="backend" className="mt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Backend Code</h3>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(project.backend || '', 'backend')}
                      >
                        <Copy className="w-4 h-4 mr-1" />
                        {copied === 'backend' ? 'Copied!' : 'Copy'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadFile(project.backend || '', 'main.py')}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                        <code>{project.backend || '# No backend code generated'}</code>
                      </pre>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="structure" className="mt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Project Structure</h3>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(project.projectStructure || '', 'structure')}
                    >
                      <Copy className="w-4 h-4 mr-1" />
                      {copied === 'structure' ? 'Copied!' : 'Copy'}
                    </Button>
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto text-sm">
                        <code>{project.projectStructure || 'project-root/\n├── src/\n│   ├── components/\n│   ├── pages/\n│   └── App.tsx\n├── server/\n│   └── main.py\n├── package.json\n└── README.md'}</code>
                      </pre>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="setup" className="mt-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Setup Instructions</h3>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(project.setupInstructions || '', 'setup')}
                      >
                        <Copy className="w-4 h-4 mr-1" />
                        {copied === 'setup' ? 'Copied!' : 'Copy'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={downloadProject}
                      >
                        <Download className="w-4 h-4 mr-1" />
                        Download All
                      </Button>
                    </div>
                  </div>
                  <Card>
                    <CardContent className="p-4">
                      <div className="prose prose-sm max-w-none">
                        <div className="whitespace-pre-wrap text-sm">
                          {project.setupInstructions || `# Setup Instructions

## Frontend Setup
1. Navigate to the project directory
2. Install dependencies: \`npm install\`
3. Start development server: \`npm run dev\`

## Backend Setup
1. Navigate to the server directory
2. Install Python dependencies: \`pip install -r requirements.txt\`
3. Start the server: \`python main.py\`

## Project Structure
- \`src/\` - Frontend React components
- \`server/\` - Backend API code
- \`public/\` - Static assets
- \`package.json\` - Node.js dependencies

## Features
- Modern React frontend with TypeScript
- FastAPI backend with automatic API documentation
- Responsive design
- Real-time communication capabilities`}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </ScrollArea>
            </div>
          </Tabs>
        </CardContent>
        
        <div className="flex-shrink-0 p-4 border-t">
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Badge variant="secondary">
                <Code className="w-3 h-3 mr-1" />
                React + TypeScript
              </Badge>
              <Badge variant="secondary">
                <Server className="w-3 h-3 mr-1" />
                FastAPI + Python
              </Badge>
            </div>
            <Button onClick={downloadProject} className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Download Complete Project
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}