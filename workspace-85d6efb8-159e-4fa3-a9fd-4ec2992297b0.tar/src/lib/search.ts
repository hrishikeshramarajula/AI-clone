import { SearchResult } from '../types/ai';

export interface SearchResult {
  url: string;
  name: string;
  snippet: string;
  host_name: string;
  rank: number;
  date: string;
  favicon: string;
}

export async function performWebSearch(query: string): Promise<SearchResult[]> {
  try {
    console.log('Performing web search for:', query);

    // Try to use the z-ai-web-dev-sdk for web search with multiple approaches
    let ZAI;
    try {
      ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK imported successfully for web search');
    } catch (importError) {
      console.error('Failed to import ZAI SDK for web search:', importError);
      // Return empty array instead of throwing - the AI will still provide helpful responses
      return [];
    }

    let searchResult;
    
    // Approach 1: Try using the SDK directly
    try {
      if (typeof ZAI.create === 'function') {
        const zai = await ZAI.create();
        console.log('ZAI instance created successfully for web search');
        
        if (zai && typeof zai.functions?.invoke === 'function') {
          searchResult = await zai.functions.invoke("web_search", {
            query: query,
            num: 5
          });
          console.log('Web search successful via functions.invoke');
          return searchResult || [];
        }
      }
    } catch (approach1Error) {
      console.log('Web search Approach 1 failed:', approach1Error.message);
    }
    
    // Approach 2: Try using the default export
    try {
      const zai = ZAI.default || ZAI;
      if (typeof zai === 'function') {
        const instance = await zai();
        if (instance && typeof instance.functions?.invoke === 'function') {
          searchResult = await instance.functions.invoke("web_search", {
            query: query,
            num: 5
          });
          console.log('Web search successful via default export');
          return searchResult || [];
        }
      }
    } catch (approach2Error) {
      console.log('Web search Approach 2 failed:', approach2Error.message);
    }
    
    // Approach 3: Try direct method calls
    try {
      const zai = ZAI.default || ZAI;
      if (zai && typeof zai.functions?.invoke === 'function') {
        searchResult = await zai.functions.invoke("web_search", {
          query: query,
          num: 5
        });
        console.log('Web search successful via direct method');
        return searchResult || [];
      }
    } catch (approach3Error) {
      console.log('Web search Approach 3 failed:', approach3Error.message);
    }

    console.log('All web search approaches failed, returning empty results');
    return [];
    
  } catch (error) {
    console.error('Web search error:', error);
    // Return empty array instead of throwing - the AI will still provide helpful responses
    return [];
  }
}