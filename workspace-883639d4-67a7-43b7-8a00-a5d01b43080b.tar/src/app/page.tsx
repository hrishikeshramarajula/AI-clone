'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Slider } from '@/components/ui/slider'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Loader2, Download, History, Settings, Sparkles, Copy, RefreshCw, Trash2, Save, Upload, 
  Database, AlertTriangle, ChevronDown, ChevronUp
} from 'lucide-react'
import { 
  compressImage, 
  createThumbnail, 
  getStorageUsage, 
  formatBytes, 
  cleanupOldStorage,
  base64ToBlob,
  type CompressedImage 
} from '@/lib/imageUtils'

export default function Home() {
  // Image generation states
  const [prompt, setPrompt] = useState('')
  const [negativePrompt, setNegativePrompt] = useState('')
  const [style, setStyle] = useState('photorealistic')
  const [aspectRatio, setAspectRatio] = useState('1:1')
  const [quality, setQuality] = useState([80])
  const [numImages, setNumImages] = useState([1])
  const [seed, setSeed] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedImages, setGeneratedImages] = useState<string[]>([])
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [imageSize, setImageSize] = useState('1024x1024')
  const [history, setHistory] = useState<CompressedImage[]>([])
  
  // Common states
  const [activeTab, setActiveTab] = useState('generate')
  const [storageUsage, setStorageUsage] = useState({ used: 0, total: 5 * 1024 * 1024, available: 5 * 1024 * 1024 })
  const [isCompressing, setIsCompressing] = useState(false)

  // Load history from localStorage on component mount
  useEffect(() => {
    const savedHistory = localStorage.getItem('ai-image-generator-history')
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory))
      } catch (error) {
        console.error('Failed to load history:', error)
      }
    }
    
    // Update storage usage
    updateStorageUsage()
  }, [])

  // Update storage usage periodically
  useEffect(() => {
    const interval = setInterval(updateStorageUsage, 5000) // Update every 5 seconds
    return () => clearInterval(interval)
  }, [])

  // Save history to localStorage whenever it changes
  useEffect(() => {
    if (history.length > 0) {
      localStorage.setItem('ai-image-generator-history', JSON.stringify(history))
      updateStorageUsage()
    }
  }, [history])

  const updateStorageUsage = () => {
    const usage = getStorageUsage()
    setStorageUsage(usage)
    
    // Auto-clean if storage is getting full
    if (usage.used / usage.total > 0.8) {
      const cleanedHistory = cleanupOldStorage(history, 30)
      if (cleanedHistory.length !== history.length) {
        setHistory(cleanedHistory)
      }
    }
  }

  const handleGenerate = async () => {
    if (!prompt.trim()) return
    
    setIsGenerating(true)
    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          negativePrompt: showAdvanced ? negativePrompt : '',
          style,
          aspectRatio,
          quality: quality[0],
          numImages: numImages[0],
          seed: seed || undefined,
          imageSize
        })
      })
      
      const data = await response.json()
      if (data.success && data.images) {
        setGeneratedImages(prev => [...data.images, ...prev])
        
        // Compress and save to history
        setIsCompressing(true)
        try {
          const compressedImages: CompressedImage[] = []
          
          for (let i = 0; i < data.images.length; i++) {
            const imageData = data.images[i]
            
            // Compress the image
            const compressedFullImage = await compressImage(imageData)
            const thumbnail = await createThumbnail(imageData)
            
            const compressedItem: CompressedImage = {
              id: `${Date.now()}-${i}`,
              prompt: data.prompt,
              negativePrompt: negativePrompt,
              style,
              aspectRatio,
              quality: quality[0],
              timestamp: new Date().toISOString(),
              seed: seed || undefined,
              imageSize,
              thumbnail,
              fullImage: compressedFullImage
            }
            
            compressedImages.push(compressedItem)
          }
          
          setHistory(prev => [...compressedImages, ...prev])
        } catch (compressionError) {
          console.error('Compression failed:', compressionError)
          // Fallback: save original images without compression
          const fallbackItems: CompressedImage[] = data.images.map((imageData: string, index: number) => ({
            id: `${Date.now()}-${index}`,
            prompt: data.prompt,
            negativePrompt: negativePrompt,
            style,
            aspectRatio,
            quality: quality[0],
            timestamp: new Date().toISOString(),
            seed: seed || undefined,
            imageSize,
            thumbnail: `data:image/png;base64,${imageData}`, // Use original as thumbnail
            fullImage: `data:image/png;base64,${imageData}` // Use original as full image
          }))
          setHistory(prev => [...fallbackItems, ...prev])
        } finally {
          setIsCompressing(false)
        }
      }
    } catch (error) {
      console.error('Generation failed:', error)
    } finally {
      setIsGenerating(false)
    }
  }

  const downloadImage = (imageData: string, index: number, isFullImage: boolean = true) => {
    // Extract base64 data from data URL if needed
    const base64Data = imageData.startsWith('data:') ? imageData.split(',')[1] : imageData
    
    const link = document.createElement('a')
    link.download = `generated-image-${Date.now()}-${index}.${isFullImage ? 'jpg' : 'png'}`
    link.href = `data:image/${isFullImage ? 'jpeg' : 'png'};base64,${base64Data}`
    link.click()
  }

  const downloadFromHistory = (item: CompressedImage) => {
    // Extract base64 from data URL
    const base64Data = item.fullImage.split(',')[1]
    const blob = base64ToBlob(base64Data, 'image/jpeg')
    
    const link = document.createElement('a')
    link.download = `ai-image-${item.id}.jpg`
    link.href = URL.createObjectURL(blob)
    link.click()
    URL.revokeObjectURL(link.href)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  const generateRandomSeed = () => {
    setSeed(Math.floor(Math.random() * 1000000).toString())
  }

  const clearAll = () => {
    setGeneratedImages([])
  }

  const deleteFromHistory = (id: string) => {
    setHistory(prev => prev.filter(item => item.id !== id))
  }

  const clearHistory = () => {
    setHistory([])
    localStorage.removeItem('ai-image-generator-history')
  }

  const exportHistory = () => {
    const dataStr = JSON.stringify(history, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = `ai-image-history-${new Date().toISOString().split('T')[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const importHistory = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (e) => {
      try {
        const importedHistory = JSON.parse(e.target?.result as string)
        if (Array.isArray(importedHistory)) {
          setHistory(prev => [...importedHistory, ...prev])
        }
      } catch (error) {
        console.error('Failed to import history:', error)
        alert('Invalid history file')
      }
    }
    reader.readAsText(file)
    // Reset file input
    event.target.value = ''
  }

  const loadFromHistory = (item: CompressedImage) => {
    setPrompt(item.prompt)
    setNegativePrompt(item.negativePrompt)
    setStyle(item.style)
    setAspectRatio(item.aspectRatio)
    setQuality([item.quality])
    setImageSize(item.imageSize)
    if (item.seed) setSeed(item.seed)
    setActiveTab('generate')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              AI Image Generator
            </h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Create stunning images with AI. Describe what you want to see, and let artificial intelligence bring your imagination to life.
          </p>
        </div>

        {/* Storage Usage Alert */}
        {storageUsage.used / storageUsage.total > 0.7 && (
          <Alert className="mb-6">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Storage usage is at {Math.round((storageUsage.used / storageUsage.total) * 100)}%. 
              Old items will be automatically cleaned up when storage is full.
              <span className="ml-2">
                {formatBytes(storageUsage.used)} of {formatBytes(storageUsage.total)} used.
              </span>
            </AlertDescription>
          </Alert>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 max-w-lg mx-auto">
            <TabsTrigger value="generate" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Generate
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              History ({history.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="generate" className="space-y-6">
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Control Panel */}
              <div className="lg:col-span-1">
                <Card className="sticky top-8">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Settings className="w-5 h-5" />
                      Generation Controls
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Prompt</label>
                      <Textarea
                        placeholder="Describe the image you want to create..."
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="min-h-24 resize-none"
                      />
                      <p className="text-xs text-muted-foreground">
                        Be descriptive and specific for best results
                      </p>
                    </div>

                    {/* Basic Controls */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Style</label>
                        <Select value={style} onValueChange={setStyle}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="photorealistic">📸 Photorealistic</SelectItem>
                            <SelectItem value="digital-art">🎨 Digital Art</SelectItem>
                            <SelectItem value="anime">🀄 Anime</SelectItem>
                            <SelectItem value="oil-painting">🖼️ Oil Painting</SelectItem>
                            <SelectItem value="watercolor">💧 Watercolor</SelectItem>
                            <SelectItem value="sketch">✏️ Sketch</SelectItem>
                            <SelectItem value="3d-render">🎲 3D Render</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Image Size</label>
                        <Select value={imageSize} onValueChange={setImageSize}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="512x512">512×512 (Fast)</SelectItem>
                            <SelectItem value="1024x1024">1024×1024 (Standard)</SelectItem>
                            <SelectItem value="1024x1792">1024×1792 (Portrait)</SelectItem>
                            <SelectItem value="1792x1024">1792×1024 (Landscape)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Aspect Ratio</label>
                      <Select value={aspectRatio} onValueChange={setAspectRatio}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1:1">1:1 (Square)</SelectItem>
                          <SelectItem value="16:9">16:9 (Landscape)</SelectItem>
                          <SelectItem value="9:16">9:16 (Portrait)</SelectItem>
                          <SelectItem value="4:3">4:3 (Classic)</SelectItem>
                          <SelectItem value="3:2">3:2 (Photo)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Quality: {quality[0]}%</label>
                      <Slider
                        value={quality}
                        onValueChange={setQuality}
                        max={100}
                        min={10}
                        step={5}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Fast</span>
                        <span>Best</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Number of Images: {numImages[0]}</label>
                      <Slider
                        value={numImages}
                        onValueChange={setNumImages}
                        max={4}
                        min={1}
                        step={1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>1</span>
                        <span>4</span>
                      </div>
                    </div>

                    {/* Advanced Options */}
                    <div className="space-y-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowAdvanced(!showAdvanced)}
                        className="w-full justify-between"
                      >
                        <span className="flex items-center gap-2">
                          <Settings className="w-4 h-4" />
                          Advanced Options
                        </span>
                        {showAdvanced ? (
                          <ChevronUp className="w-4 h-4" />
                        ) : (
                          <ChevronDown className="w-4 h-4" />
                        )}
                      </Button>

                      {showAdvanced && (
                        <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Negative Prompt</label>
                            <Textarea
                              placeholder="What to avoid in the image..."
                              value={negativePrompt}
                              onChange={(e) => setNegativePrompt(e.target.value)}
                              className="min-h-16 resize-none"
                            />
                          </div>

                          <div className="space-y-2">
                            <label className="text-sm font-medium">Seed (for reproducible results)</label>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Optional seed number"
                                value={seed}
                                onChange={(e) => setSeed(e.target.value)}
                                className="flex-1"
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={generateRandomSeed}
                              >
                                <RefreshCw className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Generate Button */}
                    <Button
                      onClick={handleGenerate}
                      disabled={isGenerating || !prompt.trim()}
                      className="w-full"
                      size="lg"
                    >
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate Images
                        </>
                      )}
                    </Button>

                    {/* Generation Progress */}
                    {isGenerating && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Generating images...</span>
                          <span>{isCompressing ? 'Compressing...' : 'Processing...'}</span>
                        </div>
                        <Progress value={isCompressing ? 90 : 50} className="w-full" />
                        <p className="text-xs text-muted-foreground">
                          This may take a few moments depending on complexity and number of images
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Generated Images */}
              <div className="lg:col-span-2">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl font-semibold">Generated Images</h2>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">
                        {generatedImages.length} images
                      </Badge>
                      {generatedImages.length > 0 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={clearAll}
                        >
                          <Trash2 className="w-4 h-4 mr-1" />
                          Clear
                        </Button>
                      )}
                    </div>
                  </div>

                  {generatedImages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-16 border-2 border-dashed border-muted-foreground/25 rounded-lg">
                      <Sparkles className="w-16 h-16 text-muted-foreground/50 mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No Images Yet</h3>
                      <p className="text-muted-foreground text-center max-w-sm">
                        Your generated images will appear here. Start creating to build your gallery!
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {generatedImages.map((imageData, index) => (
                        <Card key={index} className="group overflow-hidden">
                          <div className="relative aspect-square bg-muted">
                            <img
                              src={`data:image/png;base64,${imageData}`}
                              alt={`Generated image ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity">
                              <div className="absolute inset-0 flex items-center justify-center gap-2">
                                <Button
                                  size="sm"
                                  variant="secondary"
                                  onClick={() => downloadImage(imageData, index, true)}
                                >
                                  <Download className="w-4 h-4 mr-1" />
                                  Full
                                </Button>
                                <Button
                                  size="sm"
                                  variant="secondary"
                                  onClick={() => downloadImage(imageData, index, false)}
                                >
                                  <Download className="w-4 h-4 mr-1" />
                                  Preview
                                </Button>
                              </div>
                            </div>
                          </div>
                          <div className="p-3">
                            <p className="text-sm font-medium mb-1 line-clamp-2">
                              {prompt}
                            </p>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>{style} • {imageSize}</span>
                              <span>#{generatedImages.length - index}</span>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <History className="w-5 h-5" />
                    Generation History
                  </span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={exportHistory}
                      disabled={history.length === 0}
                    >
                      <Save className="w-4 h-4 mr-1" />
                      Export
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => document.getElementById('import-history')?.click()}
                    >
                      <Upload className="w-4 h-4 mr-1" />
                      Import
                    </Button>
                    <input
                      id="import-history"
                      type="file"
                      accept=".json"
                      onChange={importHistory}
                      className="hidden"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={clearHistory}
                      disabled={history.length === 0}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {history.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16">
                    <History className="w-16 h-16 text-muted-foreground/50 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No History Yet</h3>
                    <p className="text-muted-foreground text-center max-w-sm">
                      Your generated images will appear here. Start creating to build your gallery!
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {history.map((item) => (
                      <Card key={item.id} className="group overflow-hidden">
                        <div className="relative aspect-square bg-muted">
                          <img
                            src={item.thumbnail}
                            alt={item.prompt}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 p-2">
                              <Button
                                size="sm"
                                variant="secondary"
                                onClick={() => downloadFromHistory(item)}
                                className="w-full"
                              >
                                <Download className="w-4 h-4 mr-1" />
                                Download
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => loadFromHistory(item)}
                                className="w-full"
                              >
                                <Copy className="w-4 h-4 mr-1" />
                                Use Prompt
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteFromHistory(item.id)}
                                className="w-full text-destructive hover:text-destructive"
                              >
                                <Trash2 className="w-4 h-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </div>
                        </div>
                        <div className="p-2">
                          <p className="text-xs font-medium mb-1 line-clamp-2">
                            {item.prompt}
                          </p>
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>{item.style}</span>
                            <span>{new Date(item.timestamp).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}