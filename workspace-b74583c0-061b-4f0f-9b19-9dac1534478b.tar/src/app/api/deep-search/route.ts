import { NextRequest } from 'next/server';
import { executeDeepResearch } from '@/lib/deepResearchSystem';
import { 
  createSuccessResponse, 
  createErrorResponse, 
  withErrorHandling,
  validateRequiredFields 
} from '@/lib/apiUtils';

type Result = {
  success: boolean;
  answer?: string;
  sources?: { url: string; snippet: string }[];
  error?: string;
  confidence?: number;
  processingTime?: number;
  analysis?: any;
};

export async function POST(request: NextRequest) {
  return withErrorHandling(async () => {
    const body = await request.json();
    
    // Validate required fields
    const validation = validateRequiredFields(body, ['query']);
    if (!validation.valid) {
      return createErrorResponse(validation.error!, 400);
    }

    const searchQuery = body.query as string;
    
    console.log(`🔍 Starting deep research for query: "${searchQuery}"`);
    
    // Execute comprehensive deep research
    const researchResults = await executeDeepResearch(searchQuery);
    
    // Format the response
    const formattedResponse = `🔍 **Deep Research Results**: "${searchQuery}"

${researchResults.response}

---
**Research Metadata:**
- **Confidence Score**: ${researchResults.confidenceScore.toFixed(2)}
- **Sources Analyzed**: ${researchResults.sourcesUsed.length}
- **Processing Time**: ${(researchResults.processingTime / 1000).toFixed(2)} seconds
- **Information Gaps Identified**: ${researchResults.informationGaps.length}
${researchResults.informationGaps.length > 0 ? `- **Gaps**: ${researchResults.informationGaps.join(', ')}` : ''}`;

    // Create source snippets
    const sourceSnippets = researchResults.sourcesUsed.map((url: string, index: number) => ({
      url,
      snippet: `Source ${index + 1}: ${url}`
    }));

    return createSuccessResponse(formattedResponse, {
      sources: sourceSnippets,
      confidence: researchResults.confidenceScore,
      processingTime: researchResults.processingTime,
      analysis: researchResults.analysis
    });
  });
}