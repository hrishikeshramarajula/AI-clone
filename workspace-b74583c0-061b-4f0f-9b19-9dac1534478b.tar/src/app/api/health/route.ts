import { NextRequest } from "next/server";
import { isZAIAvailable } from '@/lib/zaiHelper';
import { createSuccessResponse, createErrorResponse, withErrorHandling } from '@/lib/apiUtils';

export async function GET(request: NextRequest) {
  return withErrorHandling(async () => {
    console.log('🏥 Health check requested');
    
    // Check ZAI SDK availability
    let zaiStatus = 'unavailable';
    let zaiError = '';
    
    try {
      const zaiAvailable = await isZAIAvailable();
      zaiStatus = zaiAvailable ? 'available' : 'unavailable';
      console.log(`🤖 ZAI SDK status: ${zaiStatus}`);
    } catch (error: any) {
      zaiStatus = 'error';
      zaiError = error.message || 'Unknown error';
      console.error('❌ ZAI SDK health check failed:', error);
    }
    
    // Determine overall system status
    let overallStatus = 'healthy';
    if (zaiStatus === 'unavailable') {
      overallStatus = 'initializing';
    } else if (zaiStatus === 'error') {
      overallStatus = 'unhealthy';
    }
    
    const healthData = {
      status: overallStatus,
      timestamp: new Date().toISOString(),
      services: {
        zai_sdk: {
          status: zaiStatus,
          error: zaiError || undefined
        },
        api: {
          status: 'operational',
          version: '1.0.0'
        },
        database: {
          status: 'connected',
          type: 'sqlite'
        }
      },
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      environment: process.env.NODE_ENV || 'development'
    };
    
    return createSuccessResponse('Health check completed', healthData);
  });
}