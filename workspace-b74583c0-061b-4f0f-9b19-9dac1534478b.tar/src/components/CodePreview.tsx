'use client';
import { useState } from 'react';
import { Copy, Download, Eye, Code, FileText, Database, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface CodeFile {
  path: string;
  content: string;
  type: 'frontend' | 'backend' | 'database' | 'config' | 'style';
  language: string;
}

interface CodePreviewProps {
  files: CodeFile[];
  livePreview?: {
    html: string;
    css: string;
    javascript: string;
    componentPreview: string;
  };
  projectName: string;
  onCopyCode?: (filePath: string, content: string) => void;
  onDownloadFile?: (file: CodeFile) => void;
  onDownloadAll?: () => void;
}

const languageColors: Record<string, string> = {
  typescript: 'bg-blue-100 text-blue-800',
  javascript: 'bg-yellow-100 text-yellow-800',
  css: 'bg-pink-100 text-pink-800',
  json: 'bg-green-100 text-green-800',
  prisma: 'bg-purple-100 text-purple-800',
  sql: 'bg-orange-100 text-orange-800',
  html: 'bg-red-100 text-red-800',
  markdown: 'bg-gray-100 text-gray-800'
};

const typeIcons: Record<string, React.ReactNode> = {
  frontend: <FileText className="w-4 h-4" />,
  backend: <Code className="w-4 h-4" />,
  database: <Database className="w-4 h-4" />,
  config: <Settings className="w-4 h-4" />,
  style: <FileText className="w-4 h-4" />
};

export default function CodePreview({
  files,
  livePreview,
  projectName,
  onCopyCode,
  onDownloadFile,
  onDownloadAll
}: CodePreviewProps) {
  const [selectedFile, setSelectedFile] = useState<string>(files[0]?.path || '');
  const [copiedFile, setCopiedFile] = useState<string>('');
  const [previewMode, setPreviewMode] = useState<'code' | 'live'>('code');

  const currentFile = files.find(file => file.path === selectedFile);
  const frontendFiles = files.filter(file => file.type === 'frontend');
  const backendFiles = files.filter(file => file.type === 'backend');
  const databaseFiles = files.filter(file => file.type === 'database');
  const configFiles = files.filter(file => file.type === 'config');

  const handleCopyCode = async (filePath: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedFile(filePath);
      setTimeout(() => setCopiedFile(''), 2000);
      onCopyCode?.(filePath, content);
    } catch (error) {
      console.error('Failed to copy code:', error);
    }
  };

  const syntaxHighlight = (code: string, language: string): string => {
    // Simple syntax highlighting - in a real app, you'd use a library like Prism.js or highlight.js
    let highlighted = code
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

    // Basic keyword highlighting for TypeScript/JavaScript
    if (language === 'typescript' || language === 'javascript') {
      const keywords = ['function', 'const', 'let', 'var', 'if', 'else', 'return', 'import', 'export', 'from', 'class', 'interface', 'type', 'async', 'await'];
      keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g');
        highlighted = highlighted.replace(regex, `<span class="keyword text-purple-600 font-semibold">${keyword}</span>`);
      });

      // String highlighting
      highlighted = highlighted.replace(/(['"`])((?:(?!\1)[^\\]|\\.)*)(\1)/g, '<span class="string text-green-600">$1$2$3</span>');
      
      // Comment highlighting
      highlighted = highlighted.replace(/(\/\/.*$)/gm, '<span class="comment text-gray-500 italic">$1</span>');
      highlighted = highlighted.replace(/(\/\*[\s\S]*?\*\/)/g, '<span class="comment text-gray-500 italic">$1</span>');
    }

    // CSS highlighting
    if (language === 'css') {
      highlighted = highlighted.replace(/([a-zA-Z-]+)\s*:/g, '<span class="property text-blue-600">$1</span>:');
      highlighted = highlighted.replace(/:([^;]+);/g, ': <span class="value text-green-600">$1</span>;');
    }

    return highlighted;
  };

  const renderCodeBlock = (content: string, language: string) => {
    const highlightedCode = syntaxHighlight(content, language);
    
    return (
      <div className="relative">
        <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
          <code 
            dangerouslySetInnerHTML={{ __html: highlightedCode }}
            className="font-mono"
          />
        </pre>
        
        <div className="absolute top-2 right-2 flex gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => handleCopyCode(selectedFile, content)}
            className="bg-slate-800 hover:bg-slate-700"
          >
            <Copy className="w-3 h-3" />
            {copiedFile === selectedFile ? 'Copied!' : 'Copy'}
          </Button>
          
          {currentFile && (
            <Button
              size="sm"
              variant="secondary"
              onClick={() => onDownloadFile?.(currentFile)}
              className="bg-slate-800 hover:bg-slate-700"
            >
              <Download className="w-3 h-3" />
              Download
            </Button>
          )}
        </div>
      </div>
    );
  };

  const renderLivePreview = () => {
    if (!livePreview) return null;

    return (
      <div className="space-y-6">
        {/* Interactive Preview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Interactive Preview
            </CardTitle>
            <CardDescription>
              Live preview of your generated application with interactive elements
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg overflow-hidden">
              <iframe
                srcDoc={livePreview.html}
                className="w-full h-96 border-0"
                title="Live Preview"
                sandbox="allow-scripts allow-same-origin"
              />
            </div>
          </CardContent>
        </Card>

        {/* Component Code Preview */}
        <Card>
          <CardHeader>
            <CardTitle>React Component Preview</CardTitle>
            <CardDescription>
              Preview of the main React component with syntax highlighting
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderCodeBlock(livePreview.componentPreview, 'typescript')}
          </CardContent>
        </Card>

        {/* HTML/CSS/JS Code */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">HTML Structure</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {renderCodeBlock(livePreview.html, 'html')}
              </ScrollArea>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">CSS Styles</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {renderCodeBlock(livePreview.css, 'css')}
              </ScrollArea>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">JavaScript</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {renderCodeBlock(livePreview.javascript, 'javascript')}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">{projectName}</CardTitle>
              <CardDescription>
                Complete full-stack application with live preview and downloadable code
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button onClick={onDownloadAll} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download All
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Mode Toggle */}
      <div className="flex justify-center">
        <div className="bg-slate-100 dark:bg-slate-800 rounded-lg p-1 inline-flex">
          <Button
            variant={previewMode === 'code' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setPreviewMode('code')}
            className="flex items-center gap-2"
          >
            <Code className="w-4 h-4" />
            Code View
          </Button>
          <Button
            variant={previewMode === 'live' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setPreviewMode('live')}
            className="flex items-center gap-2"
          >
            <Eye className="w-4 h-4" />
            Live Preview
          </Button>
        </div>
      </div>

      {/* Main Content */}
      {previewMode === 'live' && livePreview ? (
        renderLivePreview()
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* File Explorer */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg">Project Files</CardTitle>
              <CardDescription>
                {files.length} files generated
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="space-y-2">
                  {frontendFiles.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm text-blue-600 mb-2">Frontend</h4>
                      {frontendFiles.map(file => (
                        <button
                          key={file.path}
                          onClick={() => setSelectedFile(file.path)}
                          className={`w-full text-left p-2 rounded-md text-sm flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 ${
                            selectedFile === file.path ? 'bg-blue-100 dark:bg-blue-900' : ''
                          }`}
                        >
                          {typeIcons[file.type]}
                          <span className="truncate">{file.path.split('/').pop()}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {backendFiles.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm text-green-600 mb-2">Backend</h4>
                      {backendFiles.map(file => (
                        <button
                          key={file.path}
                          onClick={() => setSelectedFile(file.path)}
                          className={`w-full text-left p-2 rounded-md text-sm flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 ${
                            selectedFile === file.path ? 'bg-green-100 dark:bg-green-900' : ''
                          }`}
                        >
                          {typeIcons[file.type]}
                          <span className="truncate">{file.path.split('/').pop()}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {databaseFiles.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm text-purple-600 mb-2">Database</h4>
                      {databaseFiles.map(file => (
                        <button
                          key={file.path}
                          onClick={() => setSelectedFile(file.path)}
                          className={`w-full text-left p-2 rounded-md text-sm flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 ${
                            selectedFile === file.path ? 'bg-purple-100 dark:bg-purple-900' : ''
                          }`}
                        >
                          {typeIcons[file.type]}
                          <span className="truncate">{file.path.split('/').pop()}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {configFiles.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-sm text-orange-600 mb-2">Config</h4>
                      {configFiles.map(file => (
                        <button
                          key={file.path}
                          onClick={() => setSelectedFile(file.path)}
                          className={`w-full text-left p-2 rounded-md text-sm flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-slate-800 ${
                            selectedFile === file.path ? 'bg-orange-100 dark:bg-orange-900' : ''
                          }`}
                        >
                          {typeIcons[file.type]}
                          <span className="truncate">{file.path.split('/').pop()}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Code Editor */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {currentFile && typeIcons[currentFile.type]}
                    {currentFile?.path}
                  </CardTitle>
                  {currentFile && (
                    <CardDescription className="flex items-center gap-2 mt-2">
                      <Badge className={languageColors[currentFile.language] || 'bg-gray-100 text-gray-800'}>
                        {currentFile.language}
                      </Badge>
                      <Badge variant="outline">{currentFile.type}</Badge>
                    </CardDescription>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {currentFile ? (
                <ScrollArea className="h-96">
                  {renderCodeBlock(currentFile.content, currentFile.language)}
                </ScrollArea>
              ) : (
                <div className="text-center text-muted-foreground py-8">
                  <Code className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Select a file to view its code</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* File Structure Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Project Structure</CardTitle>
          <CardDescription>
            Complete file structure of your generated application
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-lg font-mono text-sm">
            <div className="space-y-1">
              <div>📁 {projectName.toLowerCase().replace(' ', '-')}/</div>
              {files.map(file => (
                <div key={file.path} className="ml-4 flex items-center gap-2">
                  <span>📄</span>
                  <span>{file.path}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}