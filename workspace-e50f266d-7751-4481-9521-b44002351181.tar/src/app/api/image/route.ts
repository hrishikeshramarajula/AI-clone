import { NextRequest, NextResponse } from 'next/server';

interface ImageRequest {
  prompt: string;
  model: string;
  size?: string;
}

interface ImageResponse {
  imageData: string;
  prompt: string;
  model: string;
  timestamp: string;
}

async function generateImage(prompt: string, model: string, size: string = '1024x1024'): Promise<string> {
  try {
    console.log('Generating image with prompt:', prompt, 'model:', model, 'size:', size);

    // Try to import and use the z-ai-web-dev-sdk
    let ZAI;
    try {
      ZAI = await import('z-ai-web-dev-sdk');
      console.log('ZAI SDK imported successfully for image generation');
    } catch (importError) {
      console.error('Failed to import ZAI SDK for image generation:', importError);
      throw new Error('Failed to import AI SDK for image generation');
    }

    // Try different approaches to use the ZAI SDK for image generation
    let response;
    
    // Approach 1: Try using the SDK directly
    try {
      if (typeof ZAI.create === 'function') {
        const zai = await ZAI.create();
        console.log('ZAI instance created successfully for image generation');
        
        if (zai && typeof zai.images?.generations?.create === 'function') {
          response = await zai.images.generations.create({
            prompt,
            size
          });
          console.log('Image generation successful via images.generations.create');
        } else {
          throw new Error('images.generations.create not available');
        }
      } else {
        throw new Error('ZAI.create not available');
      }
    } catch (approach1Error) {
      console.log('Image generation Approach 1 failed:', approach1Error);
      
      // Approach 2: Try using the default export
      try {
        const zai = ZAI.default || ZAI;
        if (typeof zai === 'function') {
          const instance = await zai();
          if (instance && typeof instance.images?.generations?.create === 'function') {
            response = await instance.images.generations.create({
              prompt,
              size
            });
            console.log('Image generation successful via default export');
          } else {
            throw new Error('images.generations.create not available on default export');
          }
        } else {
          throw new Error('Default export is not a function');
        }
      } catch (approach2Error) {
        console.log('Image generation Approach 2 failed:', approach2Error);
        
        // Approach 3: Try direct method calls
        try {
          const zai = ZAI.default || ZAI;
          if (zai && typeof zai.images?.generations?.create === 'function') {
            response = await zai.images.generations.create({
              prompt,
              size
            });
            console.log('Image generation successful via direct method');
          } else {
            throw new Error('Direct method call not available');
          }
        } catch (approach3Error) {
          console.log('Image generation Approach 3 failed:', approach3Error);
          throw new Error('All image generation approaches failed');
        }
      }
    }

    console.log('Image generation successful, response type:', typeof response);

    // Handle different response formats
    if (response && typeof response === 'object') {
      // OpenAI-like format
      if (response.data && Array.isArray(response.data)) {
        const imageData = response.data[0]?.base64 || response.data[0]?.url;
        if (imageData) {
          // If it's a URL, we need to fetch it and convert to base64
          if (imageData.startsWith('http')) {
            const imageResponse = await fetch(imageData);
            const arrayBuffer = await imageResponse.arrayBuffer();
            const base64 = Buffer.from(arrayBuffer).toString('base64');
            return base64;
          }
          return imageData;
        }
      }
      // Direct response format
      else if (response.base64 || response.imageData) {
        return response.base64 || response.imageData;
      }
      // Try to extract from other formats
      else if (response.image_url || response.url) {
        const imageUrl = response.image_url || response.url;
        if (imageUrl.startsWith('http')) {
          const imageResponse = await fetch(imageUrl);
          const arrayBuffer = await imageResponse.arrayBuffer();
          const base64 = Buffer.from(arrayBuffer).toString('base64');
          return base64;
        }
        return imageUrl;
      }
    }

    throw new Error('Invalid response format from image generation');
  } catch (error) {
    console.error('Image generation error:', error);
    throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body: ImageRequest = await request.json();
    const { prompt, model, size = '1024x1024' } = body;

    if (!prompt || !model) {
      return NextResponse.json(
        { error: 'Prompt and model are required' },
        { status: 400 }
      );
    }

    console.log('Processing image generation request:', { prompt, model, size });

    const imageData = await generateImage(prompt, model, size);

    const imageResponse: ImageResponse = {
      imageData,
      prompt,
      model,
      timestamp: new Date().toISOString()
    };

    return NextResponse.json(imageResponse);
  } catch (error) {
    console.error('Image generation error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to generate image', 
        details: error instanceof Error ? error.message : 'Unknown error',
        suggestion: 'Please try again with a different prompt or check if the AI service is available.'
      },
      { status: 500 }
    );
  }
}