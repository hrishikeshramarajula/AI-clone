import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    ignoreBuildErrors: false,
  },
  // Enable React strict mode for better error handling
  reactStrictMode: true,
  webpack: (config, { dev }) => {
    if (dev) {
      // Configure webpack for development
      config.watchOptions = {
        aggregateTimeout: 300,
        poll: 1000,
        ignored: ['node_modules/**'],
      };
    }
    return config;
  },
  eslint: {
    // Don't ignore ESLint errors during builds
    ignoreDuringBuilds: false,
  },
};

export default nextConfig;
