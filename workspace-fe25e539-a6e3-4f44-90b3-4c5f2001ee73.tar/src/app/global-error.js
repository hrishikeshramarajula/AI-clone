'use client';

import { useEffect } from 'react';

export default function GlobalError({ error }) {
  useEffect(() => {
    console.error('Global error:', error);
  }, [error]);

  return (
    <html>
      <body>
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50 dark:from-slate-900 dark:to-slate-800">
          <div className="text-center max-w-md mx-auto p-6">
            <div className="text-6xl mb-4">😅</div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Oops! Something went wrong
            </h1>
            <p className="text-slate-600 dark:text-slate-400 mb-6">
              We encountered an unexpected error. Don't worry, our team has been notified and we're working on it.
            </p>
            <div className="space-y-3">
              <button
                onClick={() => window.location.reload()}
                className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Refresh Page
              </button>
              <button
                onClick={() => window.location.href = '/'}
                className="w-full bg-slate-200 text-slate-800 px-4 py-2 rounded-lg hover:bg-slate-300 transition-colors"
              >
                Go Home
              </button>
            </div>
            {process.env.NODE_ENV === 'development' && (
              <details className="mt-6 text-left">
                <summary className="cursor-pointer text-sm text-slate-500 hover:text-slate-700">
                  Error Details (Development Only)
                </summary>
                <pre className="mt-2 p-4 bg-slate-100 dark:bg-slate-800 rounded text-xs overflow-auto text-slate-700 dark:text-slate-300">
                  {error?.stack || error?.message || 'Unknown error'}
                </pre>
              </details>
            )}
          </div>
        </div>
      </body>
    </html>
  );
}