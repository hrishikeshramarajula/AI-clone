// Test script for deep research system
const { executeDeepResearch } = require('./src/lib/deepResearchSystem.ts');

async function testDeepResearch() {
  try {
    console.log('🧪 Testing Deep Research System...');
    
    const results = await executeDeepResearch('What are the health benefits of turmeric?');
    
    console.log('✅ Test completed successfully!');
    console.log('Results:', {
      confidence: results.confidenceScore,
      sources: results.sourcesUsed.length,
      processingTime: results.processingTime,
      responseLength: results.response.length
    });
    
  } catch (error) {
    console.error('❌ Test failed:', error);
  }
}

testDeepResearch();