const fs = require('fs');
require('dotenv').config({ path: '.env.local' });

async function testImageGeneration() {
  console.log('🧪 Testing Image Generation APIs...\n');

  const testPrompts = [
    'A beautiful sunset over mountains',
    'A futuristic city with flying cars',
    'A cute cat wearing sunglasses'
  ];

  const providers = ['huggingface', 'openai', 'auto'];

  for (const provider of providers) {
    console.log(`\n🔍 Testing ${provider.toUpperCase()} Provider:`);
    
    try {
      const response = await fetch('http://localhost:3000/api/generate-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: testPrompts[0],
          provider: provider,
          model: provider === 'openai' ? 'DALL-E 3' : 'Stable Diffusion',
          size: '1024x1024',
          optimize: true,
          saveToFile: true
        })
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`✅ ${provider}: Success`);
        console.log(`   Model: ${result.model}`);
        console.log(`   Provider: ${result.provider}`);
        
        if (result.imageData) {
          // Save test image
          const buffer = Buffer.from(result.imageData, 'base64');
          fs.writeFileSync(`test-${provider}.png`, buffer);
          console.log(`   💾 Image saved as test-${provider}.png`);
        }
      } else {
        const error = await response.json();
        console.log(`❌ ${provider}: ${error.error}`);
      }
    } catch (error) {
      console.log(`❌ ${provider}: Network error - ${error.message}`);
    }
  }

  // Test health endpoint
  console.log('\n🩺 Testing Health Endpoint:');
  try {
    const healthResponse = await fetch('http://localhost:3000/api/generate-image');
    if (healthResponse.ok) {
      const health = await healthResponse.json();
      console.log('✅ Health Check: Passed');
      console.log('📊 Available Providers:', Object.keys(health.health.providers));
    }
  } catch (error) {
    console.log('❌ Health Check: Failed');
  }

  console.log('\n🎯 Image Generation Testing Complete!');
}

testImageGeneration().catch(console.error);