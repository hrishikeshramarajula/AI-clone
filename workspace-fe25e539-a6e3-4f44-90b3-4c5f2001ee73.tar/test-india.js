const axios = require('axios');

async function testAPIs() {
  console.log('🇮🇳 Testing AI APIs from India...\n');

  // Test OpenRouter
  try {
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: 'anthropic/claude-3-sonnet',
      messages: [{ role: 'user', content: 'Hello from India!' }],
      max_tokens: 100
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'HTTP-Referer': 'http://localhost:3000',
        'X-Title': 'Test India'
      }
    });
    console.log('✅ OpenRouter: Working perfectly from India');
  } catch (error) {
    console.log('❌ OpenRouter:', error.message);
  }

  // Test HuggingFace
  try {
    const response = await axios.post('https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium', {
      inputs: 'Hello from India!'
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.HUGGINGFACE_API_KEY}`
      }
    });
    console.log('✅ HuggingFace: Working perfectly from India');
  } catch (error) {
    console.log('❌ HuggingFace:', error.message);
  }

  // Test OpenAI
  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: 'gpt-3.5-turbo',
      messages: [{ role: 'user', content: 'Hello from India!' }],
      max_tokens: 100
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      }
    });
    console.log('✅ OpenAI: Working from India');
  } catch (error) {
    console.log('❌ OpenAI:', error.response?.data?.error?.message || error.message);
  }
}

testAPIs();