import { NextRequest, NextResponse } from 'next/server';
import { checkZAIStatus, retryZAIInitialization } from '@/lib/zaiInitializer';
import { isZAIAvailable } from '@/lib/zaiHelper';

export async function GET(request: NextRequest) {
  try {
    // Check overall system health
    const zaiStatus = await checkZAIStatus();
    const zaiAvailable = await isZAIAvailable();
    
    // Get system information
    const uptime = process.uptime();
    const memoryUsage = process.memoryUsage();
    const nodeVersion = process.version;
    
    // Return comprehensive health status
    return NextResponse.json({
      success: true,
      status: 'healthy',
      timestamp: new Date().toISOString(),
      system: {
        uptime: uptime,
        nodeVersion: nodeVersion,
        memoryUsage: {
          rss: Math.round(memoryUsage.rss / 1024 / 1024), // MB
          heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
          heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024), // MB
          external: Math.round(memoryUsage.external / 1024 / 1024), // MB
        },
        platform: process.platform,
        arch: process.arch
      },
      zai: {
        available: zaiAvailable,
        initialized: zaiStatus.initialized,
        error: zaiStatus.error,
        status: zaiAvailable ? 'operational' : 'degraded'
      },
      services: {
        ai: zaiAvailable ? 'operational' : 'degraded',
        deepResearch: zaiAvailable ? 'operational' : 'limited',
        webSearch: 'operational', // Always works with fallback
        codeGeneration: zaiAvailable ? 'operational' : 'limited'
      },
      recommendations: zaiAvailable ? [] : [
        'ZAI SDK is currently unavailable - using fallback mode',
        'AI responses will be generated using pre-configured templates',
        'System will automatically retry initialization',
        'Full functionality will be restored when ZAI SDK becomes available'
      ]
    });
    
  } catch (error) {
    console.error('Health check failed:', error);
    
    return NextResponse.json({
      success: false,
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error',
      zai: {
        available: false,
        initialized: false,
        error: error instanceof Error ? error.message : 'Unknown error',
        status: 'failed'
      },
      services: {
        ai: 'failed',
        deepResearch: 'limited',
        webSearch: 'operational',
        codeGeneration: 'limited'
      },
      recommendations: [
        'System encountered an error during health check',
        'Please try again in a few moments',
        'Contact support if the issue persists'
      ]
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;
    
    if (action === 'retry-zai-initialization') {
      console.log('🔄 Manual retry of ZAI SDK initialization requested');
      
      const success = await retryZAIInitialization();
      
      if (success) {
        return NextResponse.json({
          success: true,
          message: 'ZAI SDK initialization successful',
          action: 'retry-zai-initialization',
          result: 'success'
        });
      } else {
        return NextResponse.json({
          success: false,
          message: 'ZAI SDK initialization failed',
          action: 'retry-zai-initialization',
          result: 'failed'
        }, { status: 500 });
      }
    }
    
    return NextResponse.json({
      success: false,
      message: 'Unknown action',
      action: action
    }, { status: 400 });
    
  } catch (error) {
    console.error('Health POST request failed:', error);
    
    return NextResponse.json({
      success: false,
      message: 'Request processing failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}