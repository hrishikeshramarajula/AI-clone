'use client';

import React from 'react';
import { AlertCircle, Info, AlertTriangle, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface HTMLRendererProps {
  content: string;
  className?: string;
}

export default function HTMLRenderer({ content, className = '' }: HTMLRendererProps) {
  // Simple HTML rendering with security considerations
  // In a production app, you'd want to use a proper HTML sanitizer like DOMPurify
  
  const renderHTML = (htmlContent: string) => {
    // Replace code blocks with styled components
    let processedContent = htmlContent;
    
    // Process code blocks
    processedContent = processedContent.replace(
      /<pre><code class="([^"]*)">([\s\S]*?)<\/code><\/pre>/g,
      (match, className, codeContent) => {
        return `<div class="code-block-wrapper my-4">
          <div class="code-header bg-gray-100 dark:bg-gray-800 px-4 py-2 rounded-t-lg border border-gray-200 dark:border-gray-700">
            <span class="text-sm font-mono text-gray-600 dark:text-gray-400">${className || 'code'}</span>
          </div>
          <pre class="bg-gray-900 text-gray-100 p-4 rounded-b-lg overflow-x-auto border border-gray-200 dark:border-gray-700 border-t-0"><code>${escapeHtml(codeContent)}</code></pre>
        </div>`;
      }
    );
    
    // Process inline code
    processedContent = processedContent.replace(
      /<code class="([^"]*?)">([^<]*?)<\/code>/g,
      (match, className, inlineCode) => {
        return `<code class="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded text-sm font-mono text-gray-800 dark:text-gray-200">${escapeHtml(inlineCode)}</code>`;
      }
    );
    
    // Process alerts/info boxes
    processedContent = processedContent.replace(
      /<div class="alert alert-info">([\s\S]*?)<\/div>/g,
      (match, content) => {
        return `<div class="my-4">${createAlert('info', content.trim())}</div>`;
      }
    );
    
    processedContent = processedContent.replace(
      /<div class="alert alert-success">([\s\S]*?)<\/div>/g,
      (match, content) => {
        return `<div class="my-4">${createAlert('success', content.trim())}</div>`;
      }
    );
    
    processedContent = processedContent.replace(
      /<div class="alert alert-warning">([\s\S]*?)<\/div>/g,
      (match, content) => {
        return `<div class="my-4">${createAlert('warning', content.trim())}</div>`;
      }
    );
    
    processedContent = processedContent.replace(
      /<div class="alert alert-error">([\s\S]*?)<\/div>/g,
      (match, content) => {
        return `<div class="my-4">${createAlert('error', content.trim())}</div>`;
      }
    );
    
    // Process lists
    processedContent = processedContent.replace(
      /<ul>([\s\S]*?)<\/ul>/g,
      (match, content) => {
        const items = content.replace(/<li>([\s\S]*?)<\/li>/g, '<li class="ml-4 my-1">• $1</li>');
        return `<ul class="my-4 space-y-1">${items}</ul>`;
      }
    );
    
    processedContent = processedContent.replace(
      /<ol>([\s\S]*?)<\/ol>/g,
      (match, content) => {
        const items = content.replace(/<li>([\s\S]*?)<\/li>/g, (match, itemContent, index) => {
          return `<li class="ml-4 my-1">${index + 1}. ${itemContent}</li>`;
        });
        return `<ol class="my-4 space-y-1 list-decimal list-inside">${items}</ol>`;
      }
    );
    
    // Process headings
    processedContent = processedContent.replace(
      /<h([1-6])>([^<]*)<\/h[1-6]>/g,
      (match, level, content) => {
        const sizeClasses = {
          '1': 'text-3xl font-bold',
          '2': 'text-2xl font-bold',
          '3': 'text-xl font-bold',
          '4': 'text-lg font-semibold',
          '5': 'text-base font-semibold',
          '6': 'text-sm font-semibold'
        };
        const sizeClass = sizeClasses[level as keyof typeof sizeClasses] || sizeClasses['3'];
        return `<h${level} class="${sizeClass} my-4 text-gray-900 dark:text-gray-100">${content}</h${level}>`;
      }
    );
    
    // Process paragraphs
    processedContent = processedContent.replace(
      /<p>([^<]*)<\/p>/g,
      (match, content) => {
        return `<p class="my-3 text-gray-700 dark:text-gray-300 leading-relaxed">${content}</p>`;
      }
    );
    
    // Process bold and italic
    processedContent = processedContent.replace(
      /<strong>([^<]*)<\/strong>/g,
      (match, content) => {
        return `<strong class="font-semibold text-gray-900 dark:text-gray-100">${content}</strong>`;
      }
    );
    
    processedContent = processedContent.replace(
      /<em>([^<]*)<\/em>/g,
      (match, content) => {
        return `<em class="italic text-gray-700 dark:text-gray-300">${content}</em>`;
      }
    );
    
    // Process links
    processedContent = processedContent.replace(
      /<a href="([^"]*)">([^<]*)<\/a>/g,
      (match, href, content) => {
        return `<a href="${href}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 underline">${content}</a>`;
      }
    );
    
    // Process blockquotes
    processedContent = processedContent.replace(
      /<blockquote>([\s\S]*?)<\/blockquote>/g,
      (match, content) => {
        return `<blockquote class="border-l-4 border-gray-300 dark:border-gray-600 pl-4 my-4 italic text-gray-600 dark:text-gray-400">${content.trim()}</blockquote>`;
      }
    );
    
    return processedContent;
  };
  
  const escapeHtml = (text: string) => {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  };
  
  const createAlert = (type: 'info' | 'success' | 'warning' | 'error', content: string) => {
    const icons = {
      info: <Info className="h-4 w-4" />,
      success: <CheckCircle className="h-4 w-4" />,
      warning: <AlertTriangle className="h-4 w-4" />,
      error: <AlertCircle className="h-4 w-4" />
    };
    
    const variants = {
      info: 'bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800',
      success: 'bg-green-50 dark:bg-green-950 border-green-200 dark:border-green-800',
      warning: 'bg-yellow-50 dark:bg-yellow-950 border-yellow-200 dark:border-yellow-800',
      error: 'bg-red-50 dark:bg-red-950 border-red-200 dark:border-red-800'
    };
    
    const textColors = {
      info: 'text-blue-800 dark:text-blue-200',
      success: 'text-green-800 dark:text-green-200',
      warning: 'text-yellow-800 dark:text-yellow-200',
      error: 'text-red-800 dark:text-red-200'
    };
    
    return `
      <div class="flex items-start space-x-2 p-4 rounded-lg border ${variants[type]}">
        ${icons[type]}
        <div class="flex-1">
          <div class="${textColors[type]} text-sm">${content}</div>
        </div>
      </div>
    `;
  };

  // For security, we'll use a simple approach that only allows specific HTML tags
  const sanitizedContent = renderHTML(content);
  
  return (
    <div 
      className={`prose prose-sm dark:prose-invert max-w-none ${className}`}
      dangerouslySetInnerHTML={{ 
        __html: sanitizedContent 
      }}
    />
  );
}